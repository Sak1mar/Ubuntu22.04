# ScreenBUS v2.3 PRE-PHASE1 上传包

本包只证明 v2.3 协议、源码、配置、测试、PDF 与运输归档通过本地验收；不证明服务器、ENGINEERING_A0、训练或科研方法门已运行。

当前边界：`PROTOCOL_V2_3_READY`；`SOURCE_REPAIR_PASS`；`ENGINEERING_A0_NOT_RUN`；`PHASE1_NOT_RUN`；`G3_NOT_RUN`；`PHASE2_NOT_RUN`；`SCIENTIFIC_DECISION_NO_DECISION`。

固定顺序：

`P0_PROTOCOL_REPAIR -> G2_SERVER_ENGINEERING -> ENGINEERING_A0 -> PHASE1_FIVE_FOLD_ONE_SEED -> G3_METHOD_GATE -> PHASE2_THREE_SEEDS_AND_FULL_BASELINES -> EXTERNAL_POSITIVE_STRESS -> RESULT_FREEZE`

服务器唯一入口：

```bash
chmod +x server_bundle/env/run_in_frozen_container.sh
./server_bundle/env/run_in_frozen_container.sh overnight
```

只能先执行 G2。fresh G2 PASS 前禁止 ENGINEERING_A0。所有可变服务器工作必须位于 `~/Yanjingjia`。
