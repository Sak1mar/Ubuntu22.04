# ScreenBUS v2.2 数据与计算可行性

## 结论

`PROTOCOL_V2_2_READY`。BUS-UCLM clean 足以启动患者级 nested outer OOF 方法研究；缺少独立正常患者队列不阻断方法论文，只阻断临床筛查、正常患者特异度、外部正常人群泛化和部署/安全主张。服务器工程和所有训练均未运行。

## 固定数据角色

- `BUS-UCLM clean`：唯一正式主证据；五个 outer folds、单种子 2027。选择、阈值、校准、NMS 和后处理仅使用相应 outer-train 的 inner/meta folds。
- `BUSI`：`OPTIONAL_IMAGE_LEVEL_SANITY_CHECK_NOT_PAPER_EVIDENCE`。不作患者级验证，不产生正常患者特异度，不授权 Phase-2，不替代 BUS-UCLM nested OOF；未运行不阻断方法论文。
- `BrEaST`：仅在 Phase-1 通过后作为阳性病灶外部域压力测试；四名正常患者只能逐例描述。
- `BUS-BRA`：仅 `positive-pretraining-only`，且所有适用基线必须公平暴露；公平性或计算负担过高时整体删除预训练路线。

## 已核实边界

- `VERIFIED`：冻结 clean manifest 为 607 图、32 患者；正式 clean nested OOF 使用 31 名患者，五个 outer folds 患者互斥，封存患者不进入正式评估。
- `VERIFIED`：多组件阳性证据稀少，禁止宣称 proven multi-lesion generalization。
- `PROTOCOL_ONLY`：所有 bootstrap 按患者重采样；每个 outer-test 患者只评估一次；跨折代码与配置必须冻结。
- `NOT_RUN`：G2、ENGINEERING_A0、Phase-1、Phase-2、外部阳性压力测试和结果冻结。

## 工程边界

ENGINEERING_A0 只检查数据读取/患者 fold、forward/backward、FP32/AMP、峰值显存、checkpoint/resume、输出 schema、predicted-box 坐标回投、空 mask、scheduler/归档。它不得按性能选 B3/B4/B5，不得用 outer-test 选路线，不得产生论文结果或宣称有效。

目标服务器的 3x RTX 3090、CUDA 12.1、固定依赖、官方权重、算子、确定性和 `<22 GiB` 峰值门仍须由 G2/ENGINEERING_A0 实测；本地协议修复不能替代服务器证据。

## Phase-1 前硬条件

1. P0 协议包通过静态审计；
2. G2 在目标服务器通过；
3. ENGINEERING_A0 仅以工程检查通过；
4. BUS-UCLM clean manifest 和患者折哈希通过；
5. 所有五折使用同一冻结代码、配置和种子 2027；
6. outer-test 不参与任何中途路线、阈值或后处理选择；
7. PointRend 在 Phase-1 禁止运行。
