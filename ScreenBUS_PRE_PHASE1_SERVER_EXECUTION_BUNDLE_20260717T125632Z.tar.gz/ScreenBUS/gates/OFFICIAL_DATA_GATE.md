# ScreenBUS 官方数据门

结论：`OFFICIAL_DATA_GATE_PASS`。核心 A0 数据 BUS-UCLM v3 的官方匿名访问、许可/DOI、冻结开发清单、患者级 5-fold、像素审计引用和封存边界均通过。BUS-BRA 只允许 `positive_pretraining_only`；其原始归档 SHA-256 为 `UNVERIFIED`，因此该缺口不能被写成已验证。

## 官方来源与访问

2026-07-16T10:46:56Z 在未提供登录、token 或 cookie 的条件下实际检查来源；2026-07-16T11:31:47Z 完成官方 ZIP 全量匿名下载与本地哈希：

- BUS-UCLM v3：Mendeley 官方数据页与 public folders API 均返回 HTTP 200；官方公开文件做 1 byte range 请求返回 HTTP 206。DOI `10.17632/7fvgj4jsp7.3`，许可 `CC BY 4.0`。
- BUS-UCLM 官方 ZIP：从稳定入口 `https://data.mendeley.com/public-api/zip/7fvgj4jsp7/download/3` 完整下载 `336713241` bytes，本地计算 SHA-256 为 `7cb15270f1a2c920b4cd89122acc5dd399eae0fe545893a44596676225ac313e`，central directory 含 1,367 项。该哈希是本地全流计算值，不是提供方元数据。证据为 `artifacts/data/busuclm_v3_archive_verification.json`；临时签名 S3 URL 未固化。
- BUS-BRA v1.0：Zenodo 官方记录页与 REST API 均返回 HTTP 200；`BUSBRA.zip` 做 1 byte range 请求返回 HTTP 206。DOI `10.5281/zenodo.8231412`，许可 `CC BY 4.0`。

因此当前官方源可匿名读取。BUS-UCLM ZIP 保存在被忽略的本地 cache；只检查归档字节和 central directory，未提取或解码任何图像/掩膜 payload，未访问封存患者像素，也没有编写 G4 下载器。

## BUS-UCLM 冻结开发门

- 冻结开发集：607 张、32 名患者；373 张 normal、234 张 positive；28 名 mixed、2 名 all-normal、2 名 all-positive。
- 主线程独立读取 607 对图像/掩膜后，以 8-connectivity 审计阳性 mask：223 张单组件、10 张双组件、1 张三组件；11 张多组件图来自 6 名患者且全部良性。证据为 `bootstrap/evidence/busuclm_component_audit.json`，SHA-256 `01b5eb7071164d79dd7e10998fcbcf94fc7b092091839ffc8c61f15cf16e695f`。
- 独立像素审计记录：image hash、mask hash、几何、空 mask 语义、重复 image hash、重复 image ID 的错误数均为 0。
- 封存患者 `ANFO, COPE, CRCI, ELCO, FLKA` 与几何排除患者 `HESN` 在开发 manifest 中均为 0 行；`FETCH_COMPLETE.json` 记录封存像素请求 0、排除像素请求 0；来源 gate 的 protected pixel rows 为 0。
- 5 个 fold 均为患者级分割，train/validation 患者交集依次为 `0,0,0,0,0`。验证集图像数为 `125,122,119,120,121`，患者数为 `7,7,6,6,6`；32 名开发患者各恰好进入一次验证集。

## BUS-BRA 角色纠正

BUS-BRA 清单包含 1,875 张阳性图、1,064 名患者，没有 normal empty-mask 样本。其冻结角色强制为：

`positive_pretraining_only`

复制的旧 gate 中 `external positive-only two-view direction check` 只保留为来源证据，`source_gate_role_inherited=false`，不得继承为当前实验角色。若使用 BUS-BRA 预训练：

1. 不得再把同一数据当外部测试集；
2. 所有适用主基线必须获得相同数据暴露；
3. 必须报告 no-pretrain 敏感性分析，否则主结论保持 no-BUS-BRA 条件；
4. BUS-BRA 不得用于验证正常图空输出或正常图假阳性控制。

官方/来源 marker 记录归档大小 `133917740` bytes、MD5 `1f8b2be6476d58fc97bfb5e5a1ea9bab`。原始 BUS-BRA 归档 SHA-256 未记录，状态严格为 `UNVERIFIED`。

## 可移植证据

必要文本证据已按字节复制到 `bootstrap/evidence/`；校验入口为：

```bash
cd "$SCREENBUS_ROOT"
shasum -a 256 -c bootstrap/evidence/MANIFEST.sha256
```

所有运行引用均使用仓库相对路径。复制的 BUS-BRA 旧 gate 内仍有历史 `/Users/...` 字符串，这是保持源文件 hash 所需的不可变来源文本，不得被任何运行时代码解析或使用；当前门本身不依赖原 Mac 绝对路径。

`bootstrap/evidence/` 未包含像素或大文件；完整 BUS-UCLM ZIP 只存在于被 `.gitignore` 排除的本地 `cache/`。未创建 G4 下载器。
