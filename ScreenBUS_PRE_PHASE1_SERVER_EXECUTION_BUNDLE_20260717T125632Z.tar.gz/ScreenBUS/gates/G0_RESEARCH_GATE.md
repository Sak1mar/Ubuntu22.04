# G0 Research Gate

## 判定

`CONDITIONAL_GO`

ScreenBUS 不能以“自动提示、正常图空输出、边界细化、mask 质量头、OOF 或 risk-coverage”中的任何一个作为新贡献。这些主张均已被一手先例直接占据。当前只剩一个窄且尚未成立的研究残差：

> 在 normal-inclusive 2D frame-level BUS 输入上，对 detector-prompted medical foundation model 产生的 0-to-K 候选，分离 lesion-existence 与 conditional mask-quality，并用患者级 cross-fitted acceptance 同时审计 detector miss、正常图假阳性、predicted-box mask 质量和 selective risk。

这只是 `RESEARCH_HYPOTHESIS`。它只有在 A0 中显著胜过 detector score、SAM predicted IoU、SAM stability、box-jitter variance、面积/连通域规则、轻量 MaskIoU regressor 和 image-level hard gate 时才可能转为贡献。未发现完全同构工作不能写成“首次”。

## 评分

| 项目 | 分数 | 状态 | 依据 |
|---|---:|---|---|
| 1. 临床/任务问题真实 | 5/5 | VERIFIED | 2023 年 normal-inclusive BUS 工作直接展示普通分割器在正常图上的假阳性；BUS-UCLM 官方数据描述明确要求测正常图 FP。 |
| 2. 最窄残差未被直接覆盖 | 2/5 | INFERRED | 自动提示、正常门控、候选质量和 selective segmentation 均被占据；本轮只未核实到它们在同一 BUS 0-to-K 协议中的精确结合。缺席不是 novelty 证明。 |
| 3. 组合有可证伪耦合假设 | 4/5 | VERIFIED_PROTOCOL | B5 必须在匹配 lesion sensitivity 下胜过最强简单拒识，且 existence 与 conditional quality 分头训练；可被直接杀死。 |
| 4. 数据支持正常图与单病灶主故事 | 4/5 | VERIFIED | 607 图/32 患者、373 normal/234 positive；223 个阳性单组件。患者少且单中心，限制明确。 |
| 5. 基线可公平重训 | 3/5 | PARTIAL | nnU-Net、DeepLabV3+、Mask R-CNN、SAM/MedSAM 和 AutoSAMUS 有公开实现；APG-SAM 未确认官方代码，Auto-BUSAM 已定位论文关联仓库。任何 ScreenBUS 侧改写仍只能标为 adapted control，不能冒充官方复现。 |
| 6. verifier 有足够失败样本 | 2/5 | UNVERIFIED | 阳性图数量足以尝试，但 detector miss、假候选与低质量 mask 的实际数量只能由严格 OOF A0 确认。 |
| 7. 单张 RTX 3090 可完成 | 3/5 | INFERRED | 冻结 encoder、候选串行和 AMP 设计合理；目标服务器 G2 尚未通过，显存与耗时未验证。 |
| 8. 当前证据支持论文主张 | 2/5 | CONDITIONAL | 只支持问题与协议，不支持方法收益。所有 first/部署/多病灶泛化/US-PointRend 主张必须删除。 |

总分：`25/40`。分数不是 GO 的充分条件；条件化来自可运行且可被 A0 杀死的窄残差。

## 直接碰撞

1. `VERIFIED` — Zhang et al., 2023, DOI `10.1002/acm2.13863`：正常/异常分类分支 + BUS 分割，直接占据 normal-inclusive hard-gate 故事。
2. `VERIFIED` — N-Unet, 2026, DOI `10.3390/jimaging12050194`：分类驱动的 normal foreground suppression。
3. `VERIFIED` — APG-SAM, DOI `10.1016/j.eswa.2025.127048`：乳腺超声 detector-generated prompts + SAM + boundary-aware optimization。
4. `VERIFIED` — Auto-BUSAM, DOI `10.1016/j.displa.2025.103314`：YOLOv8 box prompt + SAM。
5. `VERIFIED` — AutoSAMUS, DOI `10.1007/978-3-031-72111-3_3`：超声 end-to-end auto prompting。
6. `VERIFIED` — Mask Scoring R-CNN：candidate mask IoU prediction 不是新概念。
7. `VERIFIED` — SAM 官方 AMG：predicted IoU、stability、NMS 和小区域规则已经是原生质量过滤器。
8. `VERIFIED` — selective medical segmentation 与 failure-detection benchmark：referral、risk-coverage/AURC 及简单一致性分数均是既有协议。
9. `VERIFIED` — SAM-U：多扰动 box prompt 的不确定性与 prompt-jitter stability 已有先例。
10. `VERIFIED` — Reverse Classification Accuracy：无测试 GT 的医学分割质量预测和失败转介已有先例。
11. `VERIFIED` — 2004 BUS CAD：含正常图的两阶段 candidate detection + candidate-validity classification 已有先例。

完整矩阵见 `gates/novelty_collision_matrix.csv`，原始来源清单见 `sources/research_screenbus_g0_primary_sources.json`。

## 自动执行的路线降级

- 删除“US-PointRend”贡献名。G1/G3 中仅保留 `PointRend refinement diagnostic`；除非存在明确超声特异机制且相对原版 PointRend 的直接消融通过，否则不得恢复。
- 删除所有 first claim：detector+SAM、automatic prompt、normal empty output、mask-quality head、prompt stability、OOF、selective segmentation、risk-coverage。
- verifier 不得作为独立算法创新；候选贡献仅是 normal-inclusive BUS 场景下的双目标、cross-fitted candidate acceptance 与端到端评估耦合。
- B1 必须包含强 image-level hard gate；B5 必须与 SAM 原生分数、规则和轻量 MaskIoU regressor 匹配敏感度比较。
- 多组件 11 张仅逐例压力测试；部署与筛查主张禁止。

## 下一门

允许进入 G1 与目标服务器 G2，但不允许进入 G4。G3 若不能击败简单拒识，必须判 `NO_GO_VERIFIER`；定位或 predicted-box 分割失败则判 `NO_GO_AUTOMATIC_PROMPT`。
