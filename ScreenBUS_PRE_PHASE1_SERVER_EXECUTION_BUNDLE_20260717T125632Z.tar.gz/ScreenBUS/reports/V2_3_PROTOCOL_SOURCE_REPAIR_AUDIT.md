# ScreenBUS v2.3 protocol and source repair audit

- Task: `P0_V2_3_PROTOCOL_AND_SOURCE_REPAIR`
- Protocol: `2.3`
- Local verdict: `SOURCE_REPAIR_PASS`
- Scientific decision: `SCIENTIFIC_DECISION_NO_DECISION`
- Performance results: `NOT_GENERATED`
- CUDA / server / ENGINEERING_A0 / Phase-1 / G3 / Phase-2: `NOT_RUN`

## Repaired defects

1. Removed the unregistered preferential hard-negative path. The verifier now uses every legal inner-OOF candidate, gives every patient equal total mass, applies no detector-score negative reweighting, and rejects outer-test candidates. Canonical configs require the exact `hard_negative_mining.enabled=false` contract and fail closed on missing, legacy, extra, or contradictory fields.
2. Replaced in-sample `lightweight_quality_regressor` scoring with patient `GroupKFold` meta-OOF scoring. Every score records training patients, held-out patients, fold, and checkpoint SHA-256. Threshold selection rejects any non-meta-OOF source or self-trained patient score. The final all-outer-train control is restricted to outer-test inference.
3. Replaced candidate-count sufficiency with four unique-patient counts and per-held-out-fold patient-class evidence. Candidate replication cannot increase the gate. Insufficient evidence maps only to `NO_DECISION_INSUFFICIENT_EVIDENCE`.
4. Preserved `empty` / `refer` / `accept`. Added `negative_view_action_rate`; normal `refer` counts as an action but not as a raw accepted-mask FP. Positive `refer` remains a zero-recall, zero-Dice, full-cohort-risk failure. Raw negative-view FP is descriptive only.
5. Moved the 0.85 localization CI gate, -0.05 B3-minus-Mask-R-CNN CI gate, measured latency/VRAM escape, action-rate reduction, recall/Dice noninferiority, referral, and coverage thresholds into v2.3 config and protocol constants. Boundary contact returns `NO_DECISION`.
6. Replaced the random A0 verifier surrogate with target-server checks that instantiate the active B1, FPN detector, Mask R-CNN, MedSAM decoder, canonical verifier and six controls; validate reprojection/schema/states; compare restored model/optimizer/scheduler states; and test scheduler lease plus archive recovery. This implementation was inspected and unit-tested but not executed locally because A0 and CUDA are forbidden in P0.
7. Froze Phase-2 as `SAME_COHORT_MULTI_SEED_AND_FULL_BASELINE_SENSITIVITY` with `independent_confirmation=false`, `external_validation=false`, `phase1_selection_bias_removed=false`, and sealed patients excluded from primary inference.
8. Retired v2.2 execution helpers. Active imports, configs, schemas, state machine, orchestrator, status store, prompt, route-freeze, registry, PDF builder, and packager point to v2.3. Historical v2.1/v2.2 marker modules and PDFs remain read-only.

## Modified or added surfaces

- Protocol/config/runtime: `protocol_v2_3.py`, retired `protocol_v2_1.py` and `protocol_v2_2.py`, `config.py`, `refine_verify.py`, `metrics.py`, `worker.py`, `phase1_runner.py`, `engineering_a0.py`, `full_runner.py`, `pipeline.py`, `cli.py`, `g3_method_gate.py`, `g3_validation.py`, and all three active YAML configs under `server_bundle/screenbus_a0_v2/configs/`.
- Operations/schemas: `server_bundle/ops/orchestrator.py`, `status_store.py`, `g3_validation.py`, `build_upload_bundle.py`, `build_pre_a0_v2_1_bundle.py`, `run_v2_3_synthetic_integration.py`, and the active v2.3 engineering/Phase-1/G3 schemas. The predictive v2.1 schema remains a reject-all retired schema.
- Tests: v2.3 protocol/source/PDF regressions plus updated authorization, G3, schema, ops, and package tests under `server_bundle/screenbus_a0_v2/tests/` and `server_bundle/tests/`.
- Governance/docs: `ccfa.yaml`, `experiments/experiment-registry.yaml`, `project/route-freeze.md`, `project/PREDICTIVE_A0_PILOT_MANIFEST_SCHEMA.md`, `prompts/ScreenBUS_Codex_双环境总控Prompt.md`, `README_UPLOAD_CN.md`, `README_PRE_A0_V2_1_CN.md`, `server_bundle/README_SERVER_CN.md`, `reports/build_screenbus_experiment_plan.py`, `reports/build_screenbus_experiment_plan_v2.py`, and `reports/build_screenbus_experiment_plan_v2_3.py`.
- Outputs: `output/pdf/ScreenBUS_实验方案与科研动机_v2.3.pdf`, `reports/V2_3_CANONICAL_VERIFIER_SYNTHETIC_EXECUTION.json`, and `gates/V2_3_PRETRAINING_STATUS.json`.

## Executed local acceptance

| Check | Result | Evidence |
|---|---|---|
| Python compile | PASS | `python -m compileall -q server_bundle/screenbus_a0_v2 server_bundle/ops reports` |
| Active unit tests | PASS | 98 passed; the audit venv skipped the optional `jsonschema` module only |
| Schema tests | PASS | 4 passed under system Python with `jsonschema 4.26.0` |
| JSON/YAML parse | PASS | 65 files parsed |
| JSON Schema metaschema | PASS | 6 schemas validated as Draft 2020-12 |
| Shell syntax | PASS | 4 scripts passed both `bash -n` and `sh -n` |
| Canonical verifier integration | PASS | Canonical `server_a0.yaml`; 48 synthetic candidates; 16 patients; CPU only; verifier and all controls executed; `KeyError=false`; 4 patient GroupKFold checkpoints; self-training overlap 0 |
| PDF build/text | PASS | 7-page complete A4 PDF; required literals extracted |
| PDF render/visual inspection | PASS | All 7 pages rendered and visually inspected; Chinese embedded; no missing text, clipping, or overlap that changes meaning |
| Historical PDF integrity | PASS | v1.0 `9ce3bb6163b67713e180081937613dab8914865c5b6bdda8e0f7b07175e0a3a8`; v2.2 `8dd90d97cffebbaebce05478cffbc7debf08ebcb83ad2c4bc70dd5b5a3a635b5` |

The canonical integration evidence is in `reports/V2_3_CANONICAL_VERIFIER_SYNTHETIC_EXECUTION.json`. It is a CPU synthetic source-path test, not data training and not scientific evidence.

## Transport-envelope rule

The final archive is built only after this report is frozen because the report is itself a manifest-bound payload. The archive path and archive SHA-256 therefore cannot be embedded here without a circular hash dependency. The authoritative final transport evidence is the external `.manifest.json`, `.sha256` sidecar, and successful independent `verify` output. Any transport verification failure invalidates `SOURCE_REPAIR_PASS` and requires `SOURCE_REPAIR_BLOCKED`.

## Hard boundary

`ENGINEERING_A0_NOT_RUN`; `PHASE1_NOT_RUN`; `G3_NOT_RUN`; `PHASE2_NOT_RUN`; server execution `NOT_RUN`; performance results `NOT_GENERATED`. The only next action is transport to the target server and G2 execution under `~/Yanjingjia`. A0 remains forbidden until a fresh G2 PASS.
