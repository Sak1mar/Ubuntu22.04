#!/usr/bin/env python3
"""Build the complete ScreenBUS v2.3 protocol PDF without running training."""

from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output" / "pdf" / "ScreenBUS_实验方案与科研动机_v2.3.pdf"
NAVY = colors.HexColor("#17324D")
TEAL = colors.HexColor("#147D7E")
PALE = colors.HexColor("#EAF3F4")
INK = colors.HexColor("#20303C")
MUTED = colors.HexColor("#60727F")
RED = colors.HexColor("#9B2C2C")


def _styles():
    pdfmetrics.registerFont(
        TTFont("ScreenBUS-CN", "/System/Library/Fonts/STHeiti Medium.ttc", subfontIndex=0)
    )
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("TitleCN", parent=base["Title"], fontName="ScreenBUS-CN", fontSize=25, leading=34, textColor=colors.white, alignment=TA_LEFT, spaceAfter=10),
        "subtitle": ParagraphStyle("SubtitleCN", parent=base["Normal"], fontName="ScreenBUS-CN", fontSize=11, leading=18, textColor=colors.white),
        "h1": ParagraphStyle("H1CN", parent=base["Heading1"], fontName="ScreenBUS-CN", fontSize=18, leading=25, textColor=NAVY, spaceBefore=5, spaceAfter=9),
        "h2": ParagraphStyle("H2CN", parent=base["Heading2"], fontName="ScreenBUS-CN", fontSize=13, leading=19, textColor=TEAL, spaceBefore=8, spaceAfter=5),
        "body": ParagraphStyle("BodyCN", parent=base["BodyText"], fontName="ScreenBUS-CN", fontSize=9.5, leading=16, textColor=INK, spaceAfter=6),
        "small": ParagraphStyle("SmallCN", parent=base["BodyText"], fontName="ScreenBUS-CN", fontSize=8, leading=12, textColor=MUTED),
        "code": ParagraphStyle("CodeCN", parent=base["BodyText"], fontName="Courier", fontSize=7.6, leading=11, textColor=INK, backColor=colors.HexColor("#F3F6F8"), borderPadding=5, spaceAfter=5),
        "callout": ParagraphStyle("CalloutCN", parent=base["BodyText"], fontName="ScreenBUS-CN", fontSize=10, leading=16, textColor=RED, backColor=colors.HexColor("#FFF1F0"), borderColor=colors.HexColor("#E5A3A0"), borderWidth=0.6, borderPadding=8, spaceAfter=8),
        "center": ParagraphStyle("CenterCN", parent=base["BodyText"], fontName="ScreenBUS-CN", fontSize=9, leading=14, alignment=TA_CENTER, textColor=INK),
    }


def _p(text: str, style: str, styles: dict) -> Paragraph:
    return Paragraph(text, styles[style])


def _table(rows, widths, styles, header=True):
    converted = [[_p(str(value), "small", styles) for value in row] for row in rows]
    table = Table(converted, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    commands = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#B7C7CE")),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("ROWBACKGROUNDS", (0, 1 if header else 0), (-1, -1), [colors.white, colors.HexColor("#F7FAFB")]),
    ]
    if header:
        commands += [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white)]
    table.setStyle(TableStyle(commands))
    return table


def _header_footer(canvas, doc):
    canvas.saveState()
    width, height = A4
    canvas.setStrokeColor(colors.HexColor("#C7D5DB"))
    canvas.line(18 * mm, height - 14 * mm, width - 18 * mm, height - 14 * mm)
    canvas.setFont("ScreenBUS-CN", 7.5)
    canvas.setFillColor(MUTED)
    canvas.drawString(18 * mm, height - 10.5 * mm, "ScreenBUS v2.3 - 训练前完整协议")
    canvas.drawRightString(width - 18 * mm, 10 * mm, f"第 {doc.page} 页")
    canvas.restoreState()


def build() -> Path:
    styles = _styles()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(OUTPUT), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=20 * mm, bottomMargin=17 * mm, title="ScreenBUS v2.3 实验方案与科研动机", author="ScreenBUS")
    story = []

    cover = Table([[[
        _p("ScreenBUS v2.3", "title", styles),
        _p("正常视图感知的全自动乳腺超声病灶分割", "subtitle", styles),
        Spacer(1, 8 * mm),
        _p("完整科研动机、实验协议、工程门与证据边界", "subtitle", styles),
        Spacer(1, 12 * mm),
        _p("P0_V2_3_PROTOCOL_AND_SOURCE_REPAIR", "code", styles),
        _p("版本状态: PROTOCOL_V2_3_READY / SOURCE_REPAIR_PASS", "subtitle", styles),
        _p("执行状态: ENGINEERING_A0_NOT_RUN / PHASE1_NOT_RUN / G3_NOT_RUN / PHASE2_NOT_RUN", "subtitle", styles),
        _p("科研判定: SCIENTIFIC_DECISION_NO_DECISION", "subtitle", styles),
    ]]], colWidths=[174 * mm], rowHeights=[235 * mm])
    cover.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), NAVY), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 15 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 15 * mm)]))
    story += [cover, PageBreak()]

    story += [
        _p("1. 科研动机与问题定义", "h1", styles),
        _p("乳腺超声分割通常在病灶已知存在、单病灶、裁剪或人工框提示的条件下评价。真实筛查式输入同时包含病灶视图、正常视图、病灶缺失视图、多病灶视图与成像伪影。若系统对每幅图都强制输出掩膜，正常视图假阳性会被结构性忽略。ScreenBUS 将任务冻结为从完整视图产生 0 到 K 个掩膜，并显式允许 empty、refer、accept 三种动作。", "body", styles),
        _p("研究问题不是单纯提高正例 Dice，而是在患者级、正常视图包含的队列上，检验 detect - prompt - verify 路线能否降低需要临床动作的阴性视图比例，同时不牺牲病灶召回和患者宏平均 Dice。", "body", styles),
        _p("临床主张硬边界", "h2", styles),
        _p("缺少独立正常患者队列不阻断内部方法实验，但阻断临床筛查验证、正常患者特异度、外部正常人群泛化、部署与安全主张。状态固定为 CLINICAL_SCREENING_CLAIM_BLOCKED_MISSING_INDEPENDENT_NORMAL_PATIENT_COHORT。", "callout", styles),
        _p("2. 数据能力与证据角色", "h1", styles),
        _table([
            ["数据源", "允许角色", "禁止解释"],
            ["BUS-UCLM clean", "唯一正式主证据；患者级 nested outer OOF", "不得把同队列多种子写成独立确认"],
            ["BUSI", "可选图像级 sanity check，不是论文患者级证据", "不授权 Phase-2；不报告正常患者特异度"],
            ["BrEaST", "Phase-1 后阳性病灶域外压力测试", "4 名正常患者仅逐例描述"],
            ["BUS-BRA", "公平暴露前提下的 positive-only 预训练或删除路线", "不能验证 empty 输出或正常视图控制"],
            ["5 名 sealed 患者", "保持封存", "不得并入主结果，不足以支持正式正常人群推断"],
        ], [34 * mm, 70 * mm, 70 * mm], styles),
        PageBreak(),
    ]

    story += [
        _p("3. 系统冻结与基线", "h1", styles),
        _table([
            ["ID", "定义", "Phase-1 角色"],
            ["B0", "DeepLabV3+ 直接语义分割", "B1 组件"],
            ["B1", "B0 + 图像级存在性硬门", "必需基线"],
            ["B2", "FPN detector", "定位组件和 detector-score 控制"],
            ["B3", "FPN + MedSAM，predicted box 为主", "必需系统"],
            ["B4", "B3 + original PointRend", "仅 G3 后可选边界消融"],
            ["B5", "B3 + 患者级交叉拟合双头 verifier", "主方法"],
            ["Mask R-CNN", "R50-FPN 实例分割", "B3 机制比较"],
            ["nnU-Net v2 2D", "正式完整基线", "Phase-2 全基线敏感性"],
            ["AutoBUSAM adapted", "YOLOv8s + SAM LoRA 适配实现", "明确标注非官方复现"],
        ], [24 * mm, 95 * mm, 55 * mm], styles),
        _p("六个简单控制全部注册: detector_score、sam_predicted_iou、sam_stability、jitter_variance、area_component_rule、lightweight_quality_regressor。最强控制只能在患者分组 meta-OOF 分数上选择。所有控制与 B5 必须进入同一 image-state 和 full-cohort 评价函数。没有质量头的控制只有 empty/accept；不得把 B5 的 refer 静默改写成 empty。", "body", styles),
        _p("4. 三态输出语义", "h1", styles),
        _table([
            ["状态", "定义", "统计处理"],
            ["empty", "不存在通过 existence threshold 的候选", "正例 empty 计召回、Dice 和 full-cohort risk 失败"],
            ["refer", "疑似存在，但所有 existence-positive 候选质量不足", "不是正常；正例 refer 保留在召回、Dice、风险失败分母"],
            ["accept", "存在且至少一个候选质量通过", "输出掩膜并正常评价"],
        ], [30 * mm, 72 * mm, 72 * mm], styles),
        _p("negative_view_action_rate = 阴性视图中至少一个 accepted mask 或发生 refer 的视图比例。原始 negative-view FP rate 继续描述，但不能单独授权 GO。automatic coverage = 1 - overall referral rate。", "callout", styles),
        PageBreak(),
    ]

    story += [
        _p("5. Matching 与主要指标", "h1", styles),
        _p("主 matching 使用按候选置信度排序的一对一 box-center-in-reference-component 规则。敏感性 matching 使用按置信度排序的一对一 box IoU，阈值 0.30。GT box 与 jittered GT box 仅作诊断上界或鲁棒性检查，不能进入主结论。", "body", styles),
        _table([
            ["层级", "冻结指标"],
            ["定位", "patient-cluster bootstrap recall @ 1 FP/view，报告 95% CI"],
            ["分割", "patient-macro Dice；lesion recall；HD95；Boundary F1，主容差 2 px，报告 1/2/3 px"],
            ["正常视图", "negative_view_action_rate 为主；raw negative-view FP rate 为描述"],
            ["选择性系统", "overall referral rate、automatic coverage、full-cohort conservative risk"],
            ["失败预测", "存在性与条件质量分离；quality success 定义为 valid 且 Dice >= 0.75"],
            ["不确定性", "患者簇 bootstrap 2000 次；患者配对差值 CI"],
        ], [43 * mm, 131 * mm], styles),
        _p("6. 患者级 nested OOF", "h1", styles),
        _p("Phase-1 使用 outer folds [0,1,2,3,4] 和唯一 seed 2027。每个 outer-test 患者仅评价一次。每个 outer-train 内使用 4 折患者 GroupKFold 产生 detector/MedSAM 候选与 verifier meta-OOF 分数。任何 outer-test 候选禁止进入 verifier 训练、阈值选择、控制排序、NMS 或后处理选择。", "body", styles),
        _p("lightweight_quality_regressor 必须患者级交叉拟合。每个评分保存 training_patient_ids、heldout_patient_ids、fold 与 checkpoint SHA-256；若评分患者出现在训练患者集合中立即失败。全部 outer-train 上的最终质量模型只用于 outer-test 推理。", "callout", styles),
        _p("7. Verifier 训练与证据充分性", "h1", styles),
        _p("v2.3 删除 preferential hard-negative mining。hard_negative_mining.enabled=false。使用全部合法 inner-OOF 候选；每名患者总权重相等；不按 detector score 对阴性候选额外加权；不设固定 per-patient candidate cap。", "body", styles),
        _table([
            ["患者级条件", "最小值"],
            ["existence-positive unique patients", "8"],
            ["existence-negative unique patients", "8"],
            ["quality-success unique patients", "8"],
            ["quality-failure unique patients", "8"],
            ["每个 held-out meta fold 的上述四类", "每类至少 1 名独立患者"],
        ], [112 * mm, 62 * mm], styles),
        _p("候选数量仅作描述。复制候选不能增加 unique-patient evidence。任一患者级条件不足时只能输出 NO_DECISION_INSUFFICIENT_EVIDENCE，禁止转换为 NO_GO。", "callout", styles),
        PageBreak(),
    ]

    story += [
        _p("8. ENGINEERING_A0", "h1", styles),
        _p("ENGINEERING_A0 只能在目标 CUDA 服务器由 orchestrator 相邻状态机调用。它必须执行真实活动模块，不得以随机 CandidateVerifier 替代。样本仅来自 outer-train 或专用 synthetic fixture，不读取 outer-test 性能。", "body", styles),
        _table([
            ["必须实际检查", "通过语义"],
            ["B1 forward/backward；FPN detector forward/backward；Mask R-CNN forward/backward", "真实活动模型损失可反传"],
            ["MedSAM decoder forward/backward", "官方活动 decoder 可反传"],
            ["predicted-box 坐标回投；真实候选 schema", "值与字段 fail closed"],
            ["verifier + 全部简单控制的最小患者分组训练/推理", "canonical config 路径，无 KeyError"],
            ["empty/refer/accept", "三态不可合并"],
            ["checkpoint 恢复", "model、optimizer、scheduler 完全一致"],
            ["FP32、AMP、峰值显存", "实际执行并记录"],
            ["scheduler lease、失败、归档恢复", "持久 lease 与归档哈希可恢复"],
        ], [105 * mm, 69 * mm], styles),
        _p("A0_PASS 仅授权 Phase-1，不产生论文结果、不做方法选择、不授权临床主张。当前 ENGINEERING_A0_NOT_RUN。", "callout", styles),
        _p("9. G3 精确决策阈值", "h1", styles),
        _table([
            ["门", "精确规则", "决策"],
            ["定位", "recall@1 FP/view 的 95% CI 上限 < 0.85", "NO_GO_AUTOMATIC_PROMPT"],
            ["定位不确定", "95% CI 跨越或接触 0.85", "NO_DECISION_INSUFFICIENT_EVIDENCE"],
            ["B3 vs Mask R-CNN", "B3 patient-macro Dice - Mask R-CNN 的 CI 上限 < -0.05，且无实测效率优势", "NO_GO_MEDSAM_ROUTE"],
            ["效率逃生", "预测端到端 latency ratio <= 0.80 或 peak-VRAM ratio <= 0.80", "仅实测可用"],
            ["B3 不确定", "Dice 差值 CI 跨越或接触 -0.05", "NO_DECISION"],
        ], [38 * mm, 96 * mm, 40 * mm], styles),
        PageBreak(),
    ]

    story += [
        _p("10. B5 主门与候选池门", "h1", styles),
        _p("候选池 oracle 在 0.98 lesion sensitivity 下必须表明阴性视图 FP 有可下降空间，否则 NO_GO_CANDIDATE_POOL。该 oracle 不授权方法 GO。", "body", styles),
        _table([
            ["B5 vs 最强简单控制", "同时满足"],
            ["negative_view_action_rate", "绝对下降 >= 0.05"],
            ["lesion recall 差值", "患者配对 bootstrap 95% CI 下限 > -0.02"],
            ["patient-macro Dice 差值", "患者配对 bootstrap 95% CI 下限 > -0.01"],
            ["overall referral rate", "<= 0.10"],
            ["automatic coverage", ">= 0.90"],
            ["分母与评价", "正例 refer 保留为失败；所有控制同一 full-cohort evaluator"],
            ["泄漏与伪影", "label/text/color artifact audit 全部为 false"],
        ], [70 * mm, 104 * mm], styles),
        _p("上述条件缺一即 NO_GO_VERIFIER；患者证据不足、单类 meta fold、阈值不稳定或 CI 不可稳定估计优先输出 NO_DECISION_INSUFFICIENT_EVIDENCE。", "callout", styles),
        _p("11. Phase-2 证据语义", "h1", styles),
        _p("Phase-2 在相同 BUS-UCLM outer folds 上执行多种子与完整基线，只能标记 SAME_COHORT_MULTI_SEED_AND_FULL_BASELINE_SENSITIVITY。必须写 independent_confirmation=false、external_validation=false、phase1_selection_bias_removed=false。Phase-1 结果决定是否继续项目，因此 Phase-2 不能消除选择偏倚。", "body", styles),
        _p("禁止写独立确认、确认性验证或外部验证。5 名 sealed 患者不得并入主结果；其规模不足以支持正式正常人群推断。", "callout", styles),
        _p("12. 公平性、局限与禁止主张", "h1", styles),
        _p("所有基线使用相同患者划分、数据暴露、outer-test 次数和 bootstrap 单元。BUS-BRA 如无法对适用基线公平暴露则删除整个预训练路线。AutoBUSAM 必须标记 adapted reimplementation。B4 仅在 G3 后作为 original PointRend 边界消融，不能冒充超声特异贡献。", "body", styles),
        _p("允许主张仅限内部患者级方法证据、normal-inclusive / lesion-free-view-aware 分割、0-to-K 输出、patient-level nested OOF、交叉拟合候选接纳与存在性/条件质量分离。禁止临床有效、正常患者特异度、外部正常人群验证、首次 detector-plus-SAM、novel PointRend、部署或安全主张。", "body", styles),
        PageBreak(),
    ]

    story += [
        _p("13. 状态机、产物与硬停止", "h1", styles),
        _p("P0_PROTOCOL_REPAIR -> G2_SERVER_ENGINEERING -> ENGINEERING_A0 -> PHASE1_FIVE_FOLD_ONE_SEED -> G3_METHOD_GATE -> PHASE2_THREE_SEEDS_AND_FULL_BASELINES -> EXTERNAL_POSITIVE_STRESS -> RESULT_FREEZE", "code", styles),
        _table([
            ["阶段", "当前状态"],
            ["协议与源码修复", "PROTOCOL_V2_3_READY / SOURCE_REPAIR_PASS"],
            ["ENGINEERING_A0", "ENGINEERING_A0_NOT_RUN"],
            ["Phase-1", "PHASE1_NOT_RUN"],
            ["G3", "G3_NOT_RUN"],
            ["Phase-2", "PHASE2_NOT_RUN"],
            ["性能结果", "NOT GENERATED"],
            ["科研决策", "SCIENTIFIC_DECISION_NO_DECISION"],
        ], [66 * mm, 108 * mm], styles),
        _p("本 PDF 是完整合并版训练前协议，不是 v2.2 的补丁页。旧 v1.0 与 v2.2 PDF 保持字节不变并仅作历史版本。v2.3 本地验收完成后硬停止：不得连接服务器，不得运行 ENGINEERING_A0，不得启动 CUDA、Phase-1、G3 或 Phase-2，不得生成性能结果。", "callout", styles),
        _p("唯一允许的下一阶段动作: 将已校验 PRE-PHASE1 v2.3 运输包上传至目标服务器，在 ~/Yanjingjia 范围内执行 G2；只有 fresh G2 PASS 后才允许 ENGINEERING_A0。", "body", styles),
        Spacer(1, 8 * mm),
        _p("文档冻结日期: 2026-07-17 | 协议版本: 2.3 | 所有训练和性能阶段: NOT RUN", "center", styles),
    ]

    doc.build(story, onFirstPage=_header_footer, onLaterPages=_header_footer)
    return OUTPUT


if __name__ == "__main__":
    print(build())
