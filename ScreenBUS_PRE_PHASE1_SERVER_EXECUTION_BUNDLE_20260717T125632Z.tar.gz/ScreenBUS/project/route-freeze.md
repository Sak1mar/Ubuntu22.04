# ScreenBUS v2.3 Route Freeze

Status: `PROTOCOL_V2_3_READY`; `SOURCE_REPAIR_PASS`; `ENGINEERING_A0_NOT_RUN`; `PHASE1_NOT_RUN`; `G3_NOT_RUN`; `PHASE2_NOT_RUN`; `SCIENTIFIC_DECISION_NO_DECISION`; `CLINICAL_SCREENING_CLAIM_BLOCKED_MISSING_INDEPENDENT_NORMAL_PATIENT_COHORT`.

Active state machine:

`P0_PROTOCOL_REPAIR -> G2_SERVER_ENGINEERING -> ENGINEERING_A0 -> PHASE1_FIVE_FOLD_ONE_SEED -> G3_METHOD_GATE -> PHASE2_THREE_SEEDS_AND_FULL_BASELINES -> EXTERNAL_POSITIVE_STRESS -> RESULT_FREEZE`

## Data and claims

- BUS-UCLM clean is the only formal primary evidence and uses patient-level nested outer OOF.
- BUSI is optional image-level sanity checking, never patient-level validation or a Phase-2 authorization source.
- BrEaST is a positive-lesion external stress test only; four normal patients are case descriptions only.
- BUS-BRA is positive-pretraining-only and must be removed if equal baseline exposure is not feasible.
- Five sealed patients remain outside primary results and cannot support normal-population inference.
- Missing independent normal patients block clinical validation, specificity, deployment, and safety claims, not the internal method experiment.

## System and states

B1, Mask R-CNN, B3, all six simple controls, and B5 are mandatory in Phase-1. B4 original PointRend is forbidden before G3 and is only an optional boundary ablation afterward.

Image state is exactly one of:

- `empty`: no existence-positive candidate;
- `refer`: existence-positive but quality-insufficient;
- `accept`: existence-positive and quality-passing.

Positive refer remains a failure in lesion recall, patient-macro Dice, and full-cohort conservative risk. Controls without a quality head are empty/accept only. Every method uses the same image-state and full-cohort evaluator.

`negative_view_action_rate` is the fraction of negative views with at least one accepted mask or any refer. Raw negative-view FP remains descriptive and cannot alone authorize GO.

## Verifier and controls

- `hard_negative_mining.enabled=false`.
- Use all legal inner-OOF candidates; outer-test candidates are forbidden.
- Each patient has equal total weight; detector score never adds negative weight.
- Lightweight quality scores used for threshold selection and control ranking are patient GroupKFold meta-OOF only.
- Per score retain training patient IDs, held-out patient IDs, fold, and checkpoint SHA-256; self-scoring is fatal.
- Final all-outer-train quality model is outer-test inference only.

Patient evidence minima are 8 unique patients for existence-positive, existence-negative, quality-success, and quality-failure. Each held-out meta fold needs at least one unique patient in every class. Candidate counts are descriptive only. Insufficiency yields `NO_DECISION_INSUFFICIENT_EVIDENCE`, never `NO_GO`.

## ENGINEERING_A0

Target-server A0 must execute actual B1, FPN detector, Mask R-CNN, MedSAM decoder, predicted-box reprojection, candidate schema, grouped verifier and all controls, three states, full checkpoint restore, FP32/AMP/VRAM, and scheduler lease/failure/archive recovery. Only outer-train or synthetic fixtures are allowed. A0 authorizes Phase-1 only and creates no paper result.

## G3

- Localization: patient-cluster bootstrap recall@1 FP/view. CI upper `< 0.85` gives `NO_GO_AUTOMATIC_PROMPT`; CI touching/crossing `0.85` gives `NO_DECISION_INSUFFICIENT_EVIDENCE`.
- B3 minus Mask R-CNN patient-macro Dice: CI upper `< -0.05` without measured efficiency advantage gives `NO_GO_MEDSAM_ROUTE`; CI touching/crossing `-0.05` gives `NO_DECISION`. Efficiency escape requires measured end-to-end latency ratio `<=0.80` or peak-VRAM ratio `<=0.80`.
- B5 vs strongest meta-OOF simple control must simultaneously obtain action-rate reduction `>=0.05`, recall-delta CI low `>-0.02`, Dice-delta CI low `>-0.01`, referral `<=0.10`, coverage `>=0.90`, identical full-cohort evaluation, and clean leakage/artifact audits.

## Phase-2 semantics

Same-cohort Phase-2 is `SAME_COHORT_MULTI_SEED_AND_FULL_BASELINE_SENSITIVITY` with `independent_confirmation=false`, `external_validation=false`, and `phase1_selection_bias_removed=false`. It cannot be called independent confirmation or confirmatory validation.

## Hard stop

CUDA training, SSH, G2, ENGINEERING_A0, Phase-1, G3, and Phase-2 were not run during v2.3 repair. Performance results are `NOT GENERATED`. The only next action is transport to the target server for G2; A0 remains forbidden until fresh G2 PASS.
