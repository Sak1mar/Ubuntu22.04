# Superseded independent-pilot contract

Status: `REMOVED_FROM_EFFECTIVE_PROTOCOL_V2_3`

This legacy filename is retained only so old links fail visibly instead of silently selecting a missing file. ScreenBUS v2.3 has no independent predictive-pilot prerequisite and no pilot manifest can authorize Phase-1 or Phase-2.

The absence of an independent normal-patient cohort is recorded only as:

`CLINICAL_SCREENING_CLAIM_BLOCKED_MISSING_INDEPENDENT_NORMAL_PATIENT_COHORT`

It blocks clinical screening validation, normal-patient specificity, external normal-population generalization, deployment, and triage-safety claims. It does not block the BUS-UCLM clean patient-level nested-OOF method study.

Effective data contracts are defined in `project/route-freeze.md`, `experiments/experiment-registry.yaml`, `server_bundle/screenbus_a0_v2/protocol_v2_3.py`, and the v2.3 YAML configurations.
