# ScreenBUS PRE-PHASE1 v2.3 上传包说明

文件名仅为旧链接兼容；内容和执行权均属于 v2.3。旧 v2.2 不得被 orchestrator 调用。

状态：`PROTOCOL_V2_3_READY`、`SOURCE_REPAIR_PASS`、`ENGINEERING_A0_NOT_RUN`、`PHASE1_NOT_RUN`、`G3_NOT_RUN`、`PHASE2_NOT_RUN`、`SCIENTIFIC_DECISION_NO_DECISION`。

本地非训练验证：

```bash
python -m compileall -q server_bundle/screenbus_a0_v2 server_bundle/ops
PYTHONPATH=server_bundle pytest -q server_bundle/screenbus_a0_v2/tests server_bundle/tests
python reports/build_screenbus_experiment_plan_v2_3.py
```

这些检查不得写成 CUDA、ENGINEERING_A0、Phase-1、G3 或性能 PASS。训练与性能结果均为 `NOT GENERATED`。
