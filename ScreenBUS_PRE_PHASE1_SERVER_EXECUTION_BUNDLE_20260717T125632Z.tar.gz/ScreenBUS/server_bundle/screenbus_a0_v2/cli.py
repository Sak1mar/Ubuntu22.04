from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .authorization import read_worker_split, require_canonical_config, require_scheduler_lease, sha256_file
from .config import load_config


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="screenbus-v2.3")
    commands = parser.add_subparsers(dest="command", required=True)
    engineering = commands.add_parser("engineering-a0", help="run bounded engineering checks only")
    engineering.add_argument("--config", required=True, type=Path)
    phase1 = commands.add_parser("phase1", help="run all five outer folds with seed 2027")
    phase1.add_argument("--config", required=True, type=Path)
    g3 = commands.add_parser("g3", help="independently recompute G3 after complete Phase-1")
    g3.add_argument("--config", required=True, type=Path)
    phase2 = commands.add_parser("phase2", help="run authorized three-seed/full-baseline expansion")
    phase2.add_argument("--config", required=True, type=Path)
    phase2_fold = commands.add_parser("phase2-fold", help=argparse.SUPPRESS)
    phase2_fold.add_argument("--config", required=True, type=Path)
    phase2_fold.add_argument("--seed", required=True, type=int)
    phase2_fold.add_argument("--outer-fold", required=True, type=int)
    phase2_fold.add_argument("--run-dir", required=True, type=Path)
    worker = commands.add_parser("worker", help=argparse.SUPPRESS)
    worker.add_argument("--config", required=True, type=Path)
    worker.add_argument("--split", required=True, type=Path)
    worker.add_argument("--run-dir", required=True, type=Path)
    worker.add_argument("--operation", required=True)
    worker.add_argument("--inner-fold", type=int)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    root = Path(os.environ.get("SCREENBUS_ROOT", "")).resolve()
    if args.command == "engineering-a0":
        config = require_canonical_config(args.config, root, "engineering_a0")
        from .engineering_a0 import run_engineering_a0

        result = run_engineering_a0(config)
    elif args.command == "phase1":
        config = require_canonical_config(args.config, root, "phase1")
        from .pipeline import run_phase1

        result = run_phase1(config)
    elif args.command == "g3":
        config = require_canonical_config(args.config, root, "phase1")
        from .g3_method_gate import run_g3

        result = run_g3(config)
    elif args.command == "phase2":
        config = require_canonical_config(args.config, root, "phase2")
        from .full_runner import run_full

        result = run_full(config)
    elif args.command == "phase2-fold":
        config = require_canonical_config(args.config, root, "phase2")
        run_dir = args.run_dir.resolve()
        expected_command = [
            sys.executable, "-m", "screenbus_a0_v2.cli", "phase2-fold",
            "--config", str(config), "--seed", str(args.seed),
            "--outer-fold", str(args.outer_fold), "--run-dir", str(run_dir),
        ]
        require_scheduler_lease(root, config, expected_scope="phase2", expected_command=expected_command)
        from .full_runner import run_full_fold

        result = run_full_fold(config, args.outer_fold, args.seed, run_dir)
    elif args.command == "worker":
        split_path = args.split.resolve()
        run_dir = args.run_dir.resolve()
        split = read_worker_split(split_path, run_dir)
        mode = str(split["mode"])
        config = require_canonical_config(args.config, root, mode)
        expected_command = [
            sys.executable, "-m", "screenbus_a0_v2.cli", "worker",
            "--config", str(config), "--split", str(split_path),
            "--run-dir", str(run_dir), "--operation", args.operation,
        ]
        if args.inner_fold is not None:
            expected_command.extend(["--inner-fold", str(args.inner_fold)])
        require_scheduler_lease(root, config, expected_scope=mode, expected_command=expected_command)
        cfg = load_config(config)
        if cfg.get("mode") != mode or split.get("config_sha256") != sha256_file(config):
            raise RuntimeError("WORKER_CONFIG_OR_SPLIT_MODE_BINDING_DRIFT")
        from .worker import run_worker

        run_worker(args.operation, config, split_path, run_dir, args.inner_fold)
        return 0
    else:
        raise AssertionError(args.command)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
