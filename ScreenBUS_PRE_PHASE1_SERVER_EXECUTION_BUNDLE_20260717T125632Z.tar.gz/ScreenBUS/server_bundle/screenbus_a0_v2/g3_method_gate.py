"""Independent ScreenBUS v2.3 G3 method-gate recomputation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import load_config, resolve_environment
from .g3_validation import compute_screenbus_a0_v2_code_tree_sha256
from .protocol_v2_3 import decide_g3_method_gate
from .util import atomic_json, sha256_file, utc_now


def run_g3(config_path: Path) -> dict[str, Any]:
    cfg = load_config(config_path)
    if cfg["mode"] != "phase1":
        raise RuntimeError("G3_REQUIRES_PHASE1_CONFIG")
    env = resolve_environment()
    root = env["SCREENBUS_ROOT"]
    phase1_root = env["SCREENBUS_OUTPUT_ROOT"] / "phase1"
    completion_path = phase1_root / "PHASE1_COMPLETE.json"
    report_path = phase1_root / "PHASE1_FIVE_FOLD_REPORT.json"
    completion = json.loads(completion_path.read_text(encoding="utf-8"))
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if completion.get("status") != "PHASE1_FIVE_FOLD_ONE_SEED_COMPLETE_PENDING_G3":
        raise RuntimeError("G3_FORBIDDEN_BEFORE_PHASE1_COMPLETE")
    if completion.get("completed_outer_folds") != [0, 1, 2, 3, 4]:
        raise RuntimeError("G3_FORBIDDEN_BEFORE_ALL_FIVE_FOLDS_COMPLETE")
    if completion.get("phase1_report_sha256") != sha256_file(report_path):
        raise RuntimeError("G3_PHASE1_REPORT_BINDING_DRIFT")
    decision = decide_g3_method_gate(report, cfg["thresholds"])
    payload = {
        "schema_version": 3,
        "protocol_version": "2.3",
        "gate": "G3_METHOD_GATE",
        "evaluated_at": utc_now(),
        "decision": decision,
        "status": "G3_RECOMPUTED_FROM_COMPLETE_PHASE1",
        "phase1_completion": report["phase1_completion"],
        "phase1_report": report,
        "phase2_authorized": decision == "GO_EXPAND_TO_PHASE2",
        "point_rend_phase1": "FORBIDDEN_NOT_RUN",
        "provenance": {
            "inner_meta_only_selection": True,
            "outer_test_interim_selection": False,
            "config_sha256": sha256_file(config_path),
            "manifest_sha256": sha256_file(root / cfg["manifest"]),
            "phase1_report_path": str(report_path),
            "phase1_report_sha256": sha256_file(report_path),
            "code_tree_sha256": compute_screenbus_a0_v2_code_tree_sha256(root),
        },
    }
    atomic_json(root / "gates" / "G3_A0_DECISION.json", payload)
    markdown = root / "gates" / "G3_A0_DECISION.md"
    markdown.write_text(
        "# ScreenBUS v2.3 G3 method gate\n\n"
        f"Decision: `{decision}`\n\n"
        "Recomputed only after all five outer folds completed with seed 2027. "
        "Phase-1 PointRend was forbidden and not run.\n",
        encoding="utf-8",
    )
    return payload


__all__ = ["run_g3"]
