"""Read-only retired ScreenBUS v2.1 marker; it has no execution authority."""

PROTOCOL_VERSION = "2.1"
ACTIVE = False
