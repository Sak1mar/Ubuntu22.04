from __future__ import annotations

import contextlib
import csv
import hashlib
import json
import os
import random
import subprocess
import tempfile
import time
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import torch


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_tree(paths: Iterable[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: str(item)):
        digest.update(str(path).encode())
        digest.update(sha256_file(path).encode())
    return digest.hexdigest()


def _json_default(value: Any) -> Any:
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    raise TypeError(f"Cannot JSON serialize {type(value)!r}")


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name, suffix=".partial", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=False, default=_json_default)
            handle.write("\n")
        os.replace(temporary, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(temporary)


def atomic_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = sorted({key for row in rows for key in row})
    fd, temporary = tempfile.mkstemp(prefix=path.name, suffix=".partial", dir=path.parent)
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        os.replace(temporary, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(temporary)


def seed_everything(seed: int, deterministic: bool = True) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False


def require_cuda(device_name: str) -> torch.device:
    if device_name != "cuda":
        raise RuntimeError("Server A0/full protocols require config device=cuda")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable; refusing to run server A0")
    properties = torch.cuda.get_device_properties(0)
    total_gib = properties.total_memory / (1024**3)
    if "3090" not in properties.name or total_gib < 22.0:
        raise RuntimeError(f"Expected an RTX 3090 with about 24 GiB, found {properties.name} ({total_gib:.2f} GiB)")
    return torch.device("cuda:0")


def git_commit(root: Path) -> str:
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, text=True, capture_output=True, check=False
    )
    return result.stdout.strip() if result.returncode == 0 else "UNBORN_OR_NOT_A_GIT_REPOSITORY"


class StageLedger:
    def __init__(self, path: Path, config_hash: str, resume: bool):
        self.path = path
        self.config_hash = config_hash
        self.resume = resume
        if path.exists() and resume:
            self.data = json.loads(path.read_text(encoding="utf-8"))
            if self.data.get("config_sha256") != config_hash:
                raise RuntimeError("Refusing resume: configuration hash changed")
        else:
            self.data = {
                "schema_version": 1,
                "config_sha256": config_hash,
                "created_at": utc_now(),
                "stages": {},
            }
            atomic_json(self.path, self.data)

    def complete(self, stage: str, artifacts: list[Path], metadata: dict[str, Any] | None = None) -> None:
        missing = [str(path) for path in artifacts if not path.exists()]
        if missing:
            raise RuntimeError(f"Cannot mark {stage} complete; missing artifacts: {missing}")
        self.data["stages"][stage] = {
            "status": "COMPLETE",
            "completed_at": utc_now(),
            "artifacts": {str(path): sha256_file(path) for path in artifacts if path.is_file()},
            "metadata": metadata or {},
        }
        atomic_json(self.path, self.data)

    def is_complete(self, stage: str) -> bool:
        if not self.resume:
            return False
        entry = self.data.get("stages", {}).get(stage, {})
        if entry.get("status") != "COMPLETE":
            return False
        for raw_path, expected in entry.get("artifacts", {}).items():
            path = Path(raw_path)
            if not path.is_file() or sha256_file(path) != expected:
                return False
        return True


class Timer:
    def __enter__(self):
        self.started = time.perf_counter()
        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()
        return self

    def __exit__(self, *_args):
        self.seconds = time.perf_counter() - self.started
        self.peak_vram_gib = (
            torch.cuda.max_memory_allocated() / (1024**3) if torch.cuda.is_available() else 0.0
        )

