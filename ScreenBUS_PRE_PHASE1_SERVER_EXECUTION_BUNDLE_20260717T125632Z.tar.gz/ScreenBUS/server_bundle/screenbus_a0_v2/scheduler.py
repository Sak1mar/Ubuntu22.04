from __future__ import annotations

import json
import os
import re
import signal
import shlex
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from .util import atomic_json, utc_now


@dataclass
class GPUTask:
    task_id: str
    command: list[str]
    memory_class: str = "heavy"
    metadata: dict[str, Any] = field(default_factory=dict)
    environment: dict[str, str] = field(default_factory=dict)
    retries: int = 0
    force_exclusive: bool = False
    attempt: int = 0


@dataclass
class RunningTask:
    task: GPUTask
    gpu_id: int
    process: subprocess.Popen
    log_path: Path
    log_handle: Any
    started_at: str
    peak_vram_gib: float = 0.0
    pgid: int | None = None
    run_token: str | None = None
    proc_start_ticks: int | None = None
    boot_id: str | None = None
    lease_path: Path | None = None
    vram_limit_exceeded: bool = False


ACTIVE_LEASE_STATES = {
    "LAUNCH_INTENT",
    "CHILD_REGISTERED",
    "PARENT_CONFIRMED",
}
TERMINAL_LEASE_STATES = {
    "EXITED",
    "EXITED_RETRY_QUEUED",
    "LAUNCH_FAILED",
    "DEAD_RECLAIMABLE",
}
LEASE_TOKEN_ENV = "SCREENBUS_TASK_RUN_TOKEN"
LEASE_PATH_ENV = "SCREENBUS_TASK_LEASE"


def _boot_id(proc_root: Path = Path("/proc")) -> str | None:
    try:
        value = (proc_root / "sys" / "kernel" / "random" / "boot_id").read_text(
            encoding="utf-8"
        ).strip()
    except OSError:
        return None
    return value or None


def _proc_identity(pid: int, proc_root: Path = Path("/proc")) -> dict[str, Any] | None:
    """Return PID-reuse-safe Linux process identity from ``/proc/<pid>/stat``."""
    try:
        raw = (proc_root / str(int(pid)) / "stat").read_text(encoding="utf-8")
    except (OSError, ValueError):
        return None
    closing = raw.rfind(")")
    if closing < 0:
        return None
    fields = raw[closing + 1 :].split()
    # fields[0] is stat field 3 (state), fields[2] is field 5 (pgrp), and
    # fields[19] is field 22 (starttime).
    if len(fields) <= 19:
        return None
    try:
        pgid = int(fields[2])
        start_ticks = int(fields[19])
    except ValueError:
        return None
    return {
        "pid": int(pid),
        "pgid": pgid,
        "state": fields[0],
        "proc_start_ticks": start_ticks,
    }


def _proc_run_token(pid: int, proc_root: Path = Path("/proc")) -> tuple[bool, str | None]:
    """Return (readable, token) for a process' initial execution environment."""
    try:
        raw = (proc_root / str(int(pid)) / "environ").read_bytes()
    except (OSError, ValueError):
        return False, None
    prefix = (LEASE_TOKEN_ENV + "=").encode()
    for item in raw.split(b"\0"):
        if item.startswith(prefix):
            return True, item[len(prefix) :].decode("utf-8", errors="strict")
    return True, None


def _lease_live_pids(
    lease: dict[str, Any], proc_root: Path = Path("/proc")
) -> list[int]:
    """Find a live root/descendant that still owns a persisted launch token.

    The root PID is matched with Linux start ticks to prevent PID reuse. Child
    processes are matched by process group and the inherited unguessable token.
    If ``/proc`` exists but an exact root identity's environment is unreadable,
    the root is conservatively treated as live.
    """
    if not proc_root.is_dir():
        raise RuntimeError("SCHEDULER_LEASE_LIVENESS_UNVERIFIABLE: /proc is unavailable")
    expected_boot = lease.get("boot_id")
    current_boot = _boot_id(proc_root)
    if expected_boot and current_boot and expected_boot != current_boot:
        return []
    token = lease.get("run_token")
    if not isinstance(token, str) or not re.fullmatch(r"[0-9a-f]{32}", token):
        raise RuntimeError("SCHEDULER_LEASE_INVALID: unsafe or absent run token")
    raw_pid = lease.get("pid")
    raw_pgid = lease.get("pgid")
    raw_start = lease.get("proc_start_ticks")
    expected_pid = int(raw_pid) if isinstance(raw_pid, int) and raw_pid > 0 else None
    expected_pgid = int(raw_pgid) if isinstance(raw_pgid, int) and raw_pgid > 0 else None
    expected_start = int(raw_start) if isinstance(raw_start, int) and raw_start >= 0 else None
    live: list[int] = []
    for candidate in proc_root.iterdir():
        if not candidate.name.isdigit():
            continue
        pid = int(candidate.name)
        identity = _proc_identity(pid, proc_root)
        if identity is None or identity["state"] == "Z":
            continue
        exact_root = (
            expected_pid is not None
            and pid == expected_pid
            and expected_pgid is not None
            and identity["pgid"] == expected_pgid
            and expected_start is not None
            and identity["proc_start_ticks"] == expected_start
        )
        grouped_descendant = (
            expected_pgid is not None and identity["pgid"] == expected_pgid
        )
        if not exact_root and not grouped_descendant and expected_pgid is not None:
            continue
        readable, observed_token = _proc_run_token(pid, proc_root)
        if observed_token == token or (grouped_descendant and not readable):
            live.append(pid)
    return sorted(set(live))


def _query_gpus(gpu_ids: Sequence[int]) -> dict[int, dict[str, float | str]]:
    result = subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=index,name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(f"nvidia-smi query failed: {result.stderr.strip()}")
    observed: dict[int, dict[str, float | str]] = {}
    for line in result.stdout.splitlines():
        index, name, total, free = [part.strip() for part in line.split(",", 3)]
        physical = int(index)
        if physical in gpu_ids:
            observed[physical] = {
                "name": name,
                "total_gib": float(total) / 1024,
                "free_gib": float(free) / 1024,
            }
    if set(observed) != set(gpu_ids):
        raise RuntimeError(f"Requested GPU_IDS={list(gpu_ids)}, observed={sorted(observed)}")
    for gpu_id, info in observed.items():
        if "3090" not in str(info["name"]) or float(info["total_gib"]) < 22.0:
            raise RuntimeError(f"GPU {gpu_id} is not an approximately 24 GiB RTX 3090: {info}")
    return observed


def _query_pid_vram_mib() -> dict[int, float]:
    result = subprocess.run(
        [
            "nvidia-smi",
            "--query-compute-apps=pid,used_memory",
            "--format=csv,noheader,nounits",
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        return {}
    usage: dict[int, float] = {}
    for line in result.stdout.splitlines():
        parts = [part.strip() for part in line.split(",")]
        if len(parts) >= 2 and parts[0].isdigit():
            usage[int(parts[0])] = float(parts[1])
    return usage


def _query_process_groups() -> dict[int, int]:
    """Return PID -> process-group ID for descendant-aware VRAM accounting.

    Every scheduled worker is launched with ``start_new_session=True``, so its
    PID is also the process-group ID inherited by normal subprocesses (notably
    nnU-Net command-line workers).  Counting only the top-level Python PID
    would otherwise miss child-process CUDA allocations.
    """
    result = subprocess.run(
        ["ps", "-e", "-o", "pid=", "-o", "pgid="],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        return {}
    groups: dict[int, int] = {}
    for line in result.stdout.splitlines():
        parts = line.split()
        if len(parts) == 2 and all(part.isdigit() for part in parts):
            groups[int(parts[0])] = int(parts[1])
    return groups


def _task_vram_mib(root_pid: int, usage: dict[int, float], groups: dict[int, int]) -> float:
    """Sum CUDA memory for the complete scheduled process group."""
    grouped = sum(value for pid, value in usage.items() if groups.get(pid) == root_pid)
    return grouped if grouped else usage.get(root_pid, 0.0)


class ResourceAwareScheduler:
    """Bounded, auditable scheduler for independent single-GPU workers."""

    def __init__(self, cfg: dict, output_root: Path):
        scheduler_cfg = cfg["scheduler"]
        raw_ids = os.environ.get(scheduler_cfg.get("gpu_ids_env", "GPU_IDS"), "")
        self.gpu_ids = (
            [int(value.strip()) for value in raw_ids.split(",") if value.strip()]
            if raw_ids
            else [int(value) for value in scheduler_cfg["default_gpu_ids"]]
        )
        if len(set(self.gpu_ids)) != len(self.gpu_ids):
            raise ValueError(f"Duplicate GPU id in {self.gpu_ids}")
        self.per_gpu_concurrency = int(
            os.environ.get("SCREENBUS_PER_GPU_CONCURRENCY", scheduler_cfg["per_gpu_concurrency"])
        )
        if self.per_gpu_concurrency <= 0:
            raise ValueError("per_gpu_concurrency must be positive")
        self.min_free = float(
            os.environ.get("SCREENBUS_MIN_FREE_VRAM_GIB", scheduler_cfg["min_free_vram_gib"])
        )
        self.poll_seconds = float(scheduler_cfg["poll_seconds"])
        self.max_wait_without_progress = float(
            os.environ.get(
                "SCREENBUS_SCHEDULER_STALL_TIMEOUT_SECONDS",
                scheduler_cfg["max_wait_without_progress_seconds"],
            )
        )
        if self.max_wait_without_progress <= 0:
            raise ValueError("max_wait_without_progress_seconds must be positive")
        configured_oom_retries = int(scheduler_cfg["oom_max_retries"])
        requested_oom_retries = int(os.environ.get("SCREENBUS_OOM_MAX_RETRIES", "0"))
        if configured_oom_retries != 0 or requested_oom_retries != 0:
            raise ValueError(
                "Formal ScreenBUS runs require oom_max_retries=0; OOM retry/backoff "
                "or post-failure configuration mutation is forbidden"
            )
        self.oom_max_retries = 0
        self.heavy_exclusive = bool(scheduler_cfg["heavy_exclusive"])
        self.memory_gib = {key: float(value) for key, value in scheduler_cfg["memory_gib"].items()}
        self.max_peak_vram_gib = float(cfg["runtime"]["max_peak_vram_gib"])
        self.root = output_root / "scheduler"
        self.log_dir = self.root / "logs"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.lease_dir = self.root / "leases"
        if self.lease_dir.is_symlink():
            raise RuntimeError(f"SCHEDULER_LEASE_DIR_UNSAFE: {self.lease_dir}")
        self.lease_dir.mkdir(parents=True, exist_ok=True)
        self.status_path = self.root / "STATUS.json"
        self.scope = str(cfg.get("mode", "unknown"))
        self.config_sha256 = str(cfg.get("_config_sha256", "UNSPECIFIED"))
        self.expected_task_ids: list[str] = []
        self._restored_status: dict[str, Any] = {}
        self.completed: list[dict[str, Any]] = []
        self.failed: list[dict[str, Any]] = []
        self.cancelled: list[dict[str, Any]] = []
        self.submitted: list[str] = []
        # A0 uses cumulative expected-task sets, but always replays the narrow
        # training phase first.  Records from a later phase in a resumed STATUS
        # must survive that temporary narrowing without entering the active
        # accounting partition.
        self.deferred_completed: list[dict[str, Any]] = []
        self.deferred_failed: list[dict[str, Any]] = []
        self.deferred_cancelled: list[dict[str, Any]] = []
        self.deferred_submitted: list[str] = []
        self.running: list[RunningTask] = []
        self.retry_history: list[dict[str, Any]] = []
        self.reclaimed_leases: list[dict[str, Any]] = []
        self._restored_retry_state: dict[str, dict[str, Any]] = {}
        self.dynamic_concurrency = self.per_gpu_concurrency
        _query_gpus(self.gpu_ids)
        self._restore_matching_status()
        self._audit_persistent_leases()
        self._restore_retry_controls()

    def _restore_matching_status(self) -> None:
        """Restore same-protocol accounting so a resumed full run stays auditable."""
        if not self.status_path.is_file():
            return
        try:
            payload = json.loads(self.status_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"SCHEDULER_STATUS_INVALID: {exc}") from exc
        if not isinstance(payload, dict):
            raise RuntimeError("SCHEDULER_STATUS_INVALID: root is not an object")
        if (
            payload.get("scheduler_scope") != self.scope
            or payload.get("config_sha256") != self.config_sha256
        ):
            return
        list_fields = {
            "completed": "completed",
            "failed": "failed",
            "cancelled_not_run": "cancelled",
            "submitted_task_ids": "submitted",
            "retry_history": "retry_history",
            "expected_task_ids": "expected_task_ids",
        }
        for source, destination in list_fields.items():
            observed = payload.get(source, [])
            if not isinstance(observed, list):
                raise RuntimeError(f"SCHEDULER_STATUS_INVALID: {source} is not a list")
            setattr(self, destination, list(observed))
        deferred = payload.get("deferred_accounting", {})
        if not isinstance(deferred, dict):
            raise RuntimeError(
                "SCHEDULER_STATUS_INVALID: deferred_accounting is not an object"
            )
        deferred_fields = {
            "completed": "deferred_completed",
            "failed": "deferred_failed",
            "cancelled_not_run": "deferred_cancelled",
            "submitted_task_ids": "deferred_submitted",
        }
        for source, destination in deferred_fields.items():
            observed = deferred.get(source, [])
            if not isinstance(observed, list):
                raise RuntimeError(
                    f"SCHEDULER_STATUS_INVALID: deferred_accounting.{source} is not a list"
                )
            setattr(self, destination, list(observed))
        restored_dynamic = payload.get(
            "dynamic_per_gpu_concurrency", self.per_gpu_concurrency
        )
        if (
            isinstance(restored_dynamic, bool)
            or not isinstance(restored_dynamic, int)
            or restored_dynamic < 1
            or restored_dynamic > self.per_gpu_concurrency
        ):
            raise RuntimeError(
                "SCHEDULER_STATUS_INVALID: dynamic_per_gpu_concurrency is invalid"
            )
        self.dynamic_concurrency = restored_dynamic
        reclaimed = payload.get("reclaimed_leases", [])
        if not isinstance(reclaimed, list):
            raise RuntimeError("SCHEDULER_STATUS_INVALID: reclaimed_leases is not a list")
        self.reclaimed_leases = list(reclaimed)
        self._restored_status = payload

    def _read_lease(self, path: Path) -> dict[str, Any]:
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f"SCHEDULER_LEASE_INVALID: unsafe lease path {path}")
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"SCHEDULER_LEASE_INVALID: {path}: {exc}") from exc
        if not isinstance(payload, dict):
            raise RuntimeError(f"SCHEDULER_LEASE_INVALID: root is not an object: {path}")
        state = payload.get("state")
        if state not in ACTIVE_LEASE_STATES | TERMINAL_LEASE_STATES:
            raise RuntimeError(
                f"SCHEDULER_LEASE_INVALID: unsupported state {state!r}: {path}"
            )
        task_id = payload.get("task_id")
        token = payload.get("run_token")
        attempt = payload.get("attempt")
        if (
            not isinstance(task_id, str)
            or not re.fullmatch(r"[A-Za-z0-9_.-]+", task_id)
            or not isinstance(token, str)
            or not re.fullmatch(r"[0-9a-f]{32}", token)
            or isinstance(attempt, bool)
            or not isinstance(attempt, int)
            or attempt < 0
        ):
            raise RuntimeError(f"SCHEDULER_LEASE_INVALID: identity fields: {path}")
        if state in {"CHILD_REGISTERED", "PARENT_CONFIRMED"} and (
            isinstance(payload.get("pid"), bool)
            or not isinstance(payload.get("pid"), int)
            or payload["pid"] <= 0
            or isinstance(payload.get("pgid"), bool)
            or not isinstance(payload.get("pgid"), int)
            or payload["pgid"] <= 0
        ):
            raise RuntimeError(
                f"SCHEDULER_LEASE_INVALID: registered lease lacks PID/PGID: {path}"
            )
        return payload

    def _write_lease(self, path: Path, payload: dict[str, Any]) -> None:
        try:
            path.resolve().relative_to(self.lease_dir.resolve())
        except (OSError, ValueError) as exc:
            raise RuntimeError(f"SCHEDULER_LEASE_INVALID: unsafe destination {path}") from exc
        if path.is_symlink():
            raise RuntimeError(f"SCHEDULER_LEASE_INVALID: symlink destination {path}")
        atomic_json(path, payload)
        with path.open("rb") as handle:
            os.fsync(handle.fileno())
        directory_fd = os.open(
            self.lease_dir, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        )
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)

    def _audit_persistent_leases(self) -> None:
        """Fail closed if a worker from a dead scheduler is still executing."""
        for path in sorted(self.lease_dir.glob("*.json")):
            lease = self._read_lease(path)
            if lease["state"] not in ACTIVE_LEASE_STATES:
                continue
            live_pids = _lease_live_pids(lease)
            if live_pids:
                raise RuntimeError(
                    "SCHEDULER_LIVE_LEASE_CONFLICT: refusing to resubmit task "
                    f"{lease['task_id']} attempt={lease['attempt']} token={lease['run_token']} "
                    f"while process-group members remain alive: {live_pids}"
                )
            previous_state = lease["state"]
            orphan_oom = False
            raw_log = lease.get("log")
            if isinstance(raw_log, str) and raw_log:
                log_path = Path(raw_log)
                try:
                    log_path.resolve().relative_to(self.log_dir.resolve())
                except (OSError, ValueError):
                    raise RuntimeError(
                        f"SCHEDULER_LEASE_INVALID: unsafe log path {log_path}"
                    )
                if log_path.is_symlink():
                    raise RuntimeError(
                        f"SCHEDULER_LEASE_INVALID: symlink log path {log_path}"
                    )
                if log_path.is_file():
                    log_text = log_path.read_text(
                        encoding="utf-8", errors="replace"
                    ).lower()
                    orphan_oom = (
                        "out of memory" in log_text
                        or "cuda error: out of memory" in log_text
                    )
            lease.update(
                {
                    "state": "DEAD_RECLAIMABLE",
                    "previous_state": previous_state,
                    "reclaimed_at": utc_now(),
                    "reclaim_reason": (
                        "DEAD_WORKER_LOG_PROVES_CUDA_OOM"
                        if orphan_oom
                        else "NO_LIVE_PROCESS_WITH_MATCHING_PID_PGID_AND_RUN_TOKEN"
                    ),
                }
            )
            if orphan_oom:
                retries_before = lease.get("retry_count_before")
                concurrency_before = lease.get(
                    "dynamic_per_gpu_concurrency_before"
                )
                if (
                    isinstance(retries_before, bool)
                    or not isinstance(retries_before, int)
                    or retries_before < 0
                    or isinstance(concurrency_before, bool)
                    or not isinstance(concurrency_before, int)
                    or concurrency_before < 1
                ):
                    raise RuntimeError(
                        "SCHEDULER_RETRY_STATE_INVALID: orphan OOM lease lacks prior controls"
                    )
                lease.update(
                    {
                        "retry_count_after": retries_before + 1,
                        "forced_exclusive_after": True,
                        "dynamic_per_gpu_concurrency_after": max(
                            1, concurrency_before - 1
                        ),
                        "orphan_oom_detected": True,
                    }
                )
            self._write_lease(path, lease)
            self.reclaimed_leases.append(
                {
                    "task_id": lease["task_id"],
                    "attempt": lease["attempt"],
                    "run_token": lease["run_token"],
                    "lease": str(path),
                    "previous_state": previous_state,
                    "reclaimed_at": lease["reclaimed_at"],
                }
            )

    def _lease_evidence(self) -> list[dict[str, Any]]:
        evidence = []
        for path in sorted(self.lease_dir.glob("*.json")):
            payload = self._read_lease(path)
            evidence.append({**payload, "lease": str(path)})
        return evidence

    def _restore_retry_controls(self) -> None:
        """Recover consumed OOM budget and backoff from STATUS and durable leases."""
        states: dict[str, dict[str, Any]] = {}

        def observe(
            task_id: Any,
            retry_count: Any,
            forced_exclusive: Any,
            dynamic_concurrency: Any,
        ) -> None:
            if not isinstance(task_id, str) or not re.fullmatch(
                r"[A-Za-z0-9_.-]+", task_id
            ):
                raise RuntimeError("SCHEDULER_RETRY_STATE_INVALID: unsafe task id")
            if (
                isinstance(retry_count, bool)
                or not isinstance(retry_count, int)
                or retry_count < 0
            ):
                raise RuntimeError(
                    f"SCHEDULER_RETRY_STATE_INVALID: {task_id} retry_count={retry_count!r}"
                )
            state = states.setdefault(
                task_id, {"retry_count": 0, "force_exclusive": False}
            )
            state["retry_count"] = max(state["retry_count"], retry_count)
            state["force_exclusive"] = bool(
                state["force_exclusive"] or forced_exclusive or retry_count > 0
            )
            if dynamic_concurrency is not None:
                if (
                    isinstance(dynamic_concurrency, bool)
                    or not isinstance(dynamic_concurrency, int)
                    or dynamic_concurrency < 1
                    or dynamic_concurrency > self.per_gpu_concurrency
                ):
                    raise RuntimeError(
                        "SCHEDULER_RETRY_STATE_INVALID: dynamic concurrency is invalid"
                    )
                self.dynamic_concurrency = min(
                    self.dynamic_concurrency, dynamic_concurrency
                )

        for entry in self.retry_history:
            if not isinstance(entry, dict):
                raise RuntimeError("SCHEDULER_RETRY_STATE_INVALID: history entry")
            if entry.get("reason") != "CUDA_OOM":
                continue
            retry_count = entry.get("retry_count", entry.get("next_attempt"))
            observe(
                entry.get("task_id"),
                retry_count,
                entry.get("forced_exclusive"),
                entry.get("dynamic_per_gpu_concurrency"),
            )
        for lease in self._lease_evidence():
            if (
                lease.get("scheduler_scope") != self.scope
                or lease.get("config_sha256") != self.config_sha256
            ):
                continue
            retry_count = lease.get(
                "retry_count_after", lease.get("retry_count_before")
            )
            if retry_count is None:
                continue
            observe(
                lease.get("task_id"),
                retry_count,
                lease.get(
                    "forced_exclusive_after", lease.get("force_exclusive_before")
                ),
                lease.get(
                    "dynamic_per_gpu_concurrency_after",
                    lease.get("dynamic_per_gpu_concurrency_before"),
                ),
            )
        self._restored_retry_state = states

    def _apply_restored_retry_state(self, task: GPUTask) -> None:
        state = getattr(self, "_restored_retry_state", {}).get(task.task_id)
        if state is None:
            return
        task.retries = max(task.retries, int(state["retry_count"]))
        task.force_exclusive = bool(
            task.force_exclusive or state.get("force_exclusive")
        )

    @staticmethod
    def _validate_task_ids(task_ids: Sequence[str], label: str) -> list[str]:
        normalized = [str(value) for value in task_ids]
        if len(normalized) != len(set(normalized)):
            raise ValueError(f"Duplicate {label} task ids: {normalized}")
        invalid = [value for value in normalized if not re.fullmatch(r"[A-Za-z0-9_.-]+", value)]
        if invalid:
            raise ValueError(f"Unsafe {label} task ids: {invalid}")
        return normalized

    def _next_log_attempt(self, task_id: str) -> int:
        observed = []
        for path in self.log_dir.glob(f"{task_id}.attempt*.log"):
            match = re.fullmatch(re.escape(task_id) + r"\.attempt(\d+)\.log", path.name)
            if match:
                observed.append(int(match.group(1)))
        lease_dir = getattr(self, "lease_dir", None)
        if isinstance(lease_dir, Path):
            for path in lease_dir.glob(f"{task_id}.attempt*.json"):
                match = re.fullmatch(
                    re.escape(task_id) + r"\.attempt(\d+)\.json", path.name
                )
                if match:
                    observed.append(int(match.group(1)))
        return max(observed, default=-1) + 1

    def _validated_completed_log(self, entry: dict[str, Any]) -> Path:
        raw = entry.get("log")
        if not isinstance(raw, str) or not raw:
            raise RuntimeError(f"SCHEDULER_COMPLETED_LOG_MISSING: {entry.get('task_id')}")
        path = Path(raw)
        try:
            path.resolve().relative_to(self.log_dir.resolve())
        except (OSError, ValueError) as exc:
            raise RuntimeError(
                f"SCHEDULER_COMPLETED_LOG_UNSAFE: {entry.get('task_id')}: {path}"
            ) from exc
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(
                f"SCHEDULER_COMPLETED_LOG_MISSING: {entry.get('task_id')}: {path}"
            )
        return path

    def _recover_precompleted(self, task_id: str, prior_submitted: set[str]) -> None:
        matches = [entry for entry in self.completed if str(entry.get("task_id")) == task_id]
        if len(matches) > 1:
            raise RuntimeError(f"SCHEDULER_DUPLICATE_COMPLETION: {task_id}")
        if matches:
            self._validated_completed_log(matches[0])
            return
        if task_id not in prior_submitted:
            raise RuntimeError(
                f"SCHEDULER_RESUME_EVIDENCE_MISSING: valid task output {task_id} has no prior submission"
            )
        logs = sorted(
            self.log_dir.glob(f"{task_id}.attempt*.log"),
            key=lambda path: path.stat().st_mtime_ns,
        )
        if not logs:
            raise RuntimeError(
                f"SCHEDULER_RESUME_EVIDENCE_MISSING: valid task output {task_id} has no worker log"
            )
        gpu_id = None
        for raw_gpu_id, gpu in self._restored_status.get("gpus", {}).items():
            if task_id in gpu.get("running_task_ids", []):
                gpu_id = int(raw_gpu_id)
                break
        self.completed.append(
            {
                "task_id": task_id,
                "gpu_id": gpu_id,
                "return_code": 0,
                "started_at": None,
                "finished_at": utc_now(),
                "peak_vram_gib": None,
                "log": str(logs[-1]),
                "command": "RECOVERED_FROM_VALID_FOLD_OUTPUT",
                "retry": None,
                "attempt": None,
                "oom": False,
                "metadata": {},
                "reproducibility_environment": {},
                "insufficient_events": False,
                "accounting_recovery": "VALID_TASK_OUTPUT_AND_PRIOR_SUBMISSION_WITH_LOG",
            }
        )

    @staticmethod
    def _record_task_id(entry: dict[str, Any], label: str) -> str:
        if not isinstance(entry, dict):
            raise RuntimeError(f"SCHEDULER_STATUS_INVALID: {label} entry is not an object")
        task_id = entry.get("task_id")
        if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+", task_id):
            raise RuntimeError(
                f"SCHEDULER_STATUS_INVALID: unsafe {label} task id {task_id!r}"
            )
        return task_id

    def _activate_expected_partition(self, expected: set[str]) -> set[str]:
        """Activate only ``expected`` records while retaining later-phase history."""
        all_submitted = [*self.submitted, *self.deferred_submitted]
        if len(all_submitted) != len(set(all_submitted)):
            raise RuntimeError(
                "SCHEDULER_STATUS_INVALID: duplicate active/deferred submitted task ids"
            )
        submitted_set = set(all_submitted)
        combined = {
            "completed": [*self.completed, *self.deferred_completed],
            "failed": [*self.failed, *self.deferred_failed],
            "cancelled": [*self.cancelled, *self.deferred_cancelled],
        }
        outcome_ids: list[str] = []
        for label, records in combined.items():
            outcome_ids.extend(self._record_task_id(entry, label) for entry in records)
        if len(outcome_ids) != len(set(outcome_ids)):
            raise RuntimeError(
                "SCHEDULER_STATUS_INVALID: duplicate active/deferred outcome task ids"
            )
        if not set(outcome_ids).issubset(submitted_set):
            raise RuntimeError(
                "SCHEDULER_STATUS_INVALID: outcome records include unsubmitted task ids"
            )

        self.completed = [
            entry
            for entry in combined["completed"]
            if self._record_task_id(entry, "completed") in expected
        ]
        self.failed = [
            entry
            for entry in combined["failed"]
            if self._record_task_id(entry, "failed") in expected
        ]
        self.cancelled = [
            entry
            for entry in combined["cancelled"]
            if self._record_task_id(entry, "cancelled") in expected
        ]
        self.deferred_completed = [
            entry
            for entry in combined["completed"]
            if self._record_task_id(entry, "completed") not in expected
        ]
        self.deferred_failed = [
            entry
            for entry in combined["failed"]
            if self._record_task_id(entry, "failed") not in expected
        ]
        self.deferred_cancelled = [
            entry
            for entry in combined["cancelled"]
            if self._record_task_id(entry, "cancelled") not in expected
        ]
        self.deferred_submitted = [
            task_id for task_id in all_submitted if task_id not in expected
        ]
        return submitted_set

    def _can_run(self, task: GPUTask, gpu_id: int, gpu: dict[str, Any]) -> bool:
        if task.memory_class not in self.memory_gib:
            raise ValueError(f"Unknown memory_class {task.memory_class!r}")
        running = [entry for entry in self.running if entry.gpu_id == gpu_id]
        exclusive = task.force_exclusive or (self.heavy_exclusive and task.memory_class == "heavy")
        if exclusive and running:
            return False
        if any(
            entry.task.force_exclusive
            or (self.heavy_exclusive and entry.task.memory_class == "heavy")
            for entry in running
        ):
            return False
        if len(running) >= self.dynamic_concurrency:
            return False
        requested = self.memory_gib[task.memory_class]
        reserved = sum(self.memory_gib[entry.task.memory_class] for entry in running)
        # The total-memory reservation prevents overcommit when several workers
        # are launched from the same nvidia-smi snapshot before they allocate.
        if reserved + requested + self.min_free > float(gpu["free_gib"]):
            return False
        return True

    def _select_gpu(
        self, task: GPUTask, gpu_info: dict[int, dict[str, Any]]
    ) -> int | None:
        """Admit on the least-loaded eligible GPU.

        Running-task count is the primary key so independent light/medium jobs
        spread across all configured GPUs before any one GPU receives a second
        worker.  Reservation and observed free VRAM then break ties, preserving
        the same fail-closed capacity checks as :meth:`_can_run`.
        """
        candidates: list[tuple[tuple[float, ...], int]] = []
        gpu_order = {gpu_id: index for index, gpu_id in enumerate(self.gpu_ids)}
        for gpu_id in self.gpu_ids:
            if not self._can_run(task, gpu_id, gpu_info[gpu_id]):
                continue
            running = [entry for entry in self.running if entry.gpu_id == gpu_id]
            reserved = sum(
                self.memory_gib[entry.task.memory_class] for entry in running
            )
            candidates.append(
                (
                    (
                        float(len(running)),
                        reserved,
                        -float(gpu_info[gpu_id]["free_gib"]),
                        float(gpu_order[gpu_id]),
                    ),
                    gpu_id,
                )
            )
        return min(candidates)[1] if candidates else None

    def _launch(self, task: GPUTask, gpu_id: int) -> None:
        log_path = self.log_dir / f"{task.task_id}.attempt{task.attempt}.log"
        lease_path = self.lease_dir / f"{task.task_id}.attempt{task.attempt}.json"
        if lease_path.exists() or lease_path.is_symlink():
            raise RuntimeError(
                f"SCHEDULER_LEASE_COLLISION: {task.task_id} attempt={task.attempt}"
            )
        run_token = uuid.uuid4().hex
        launch_intent = {
            "schema_version": 1,
            "state": "LAUNCH_INTENT",
            "scheduler_scope": self.scope,
            "config_sha256": self.config_sha256,
            "task_id": task.task_id,
            "attempt": task.attempt,
            "retry_count_before": task.retries,
            "force_exclusive_before": task.force_exclusive,
            "dynamic_per_gpu_concurrency_before": self.dynamic_concurrency,
            "memory_class": task.memory_class,
            "gpu_id": gpu_id,
            "run_token": run_token,
            "parent_pid": os.getpid(),
            "command": task.command,
            "log": str(log_path),
            "intent_created_at": utc_now(),
        }
        # This durable intent is written before Popen. A replacement scheduler
        # can therefore detect even the narrow parent-death/child-start window.
        self._write_lease(lease_path, launch_intent)
        log_handle = log_path.open("w", encoding="utf-8")
        environment = os.environ.copy()
        environment.update(task.environment)
        environment["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
        environment["SCREENBUS_ASSIGNED_GPU"] = str(gpu_id)
        environment[LEASE_TOKEN_ENV] = run_token
        environment[LEASE_PATH_ENV] = str(lease_path.resolve())
        launcher_command = [
            sys.executable,
            str(Path(__file__).with_name("task_launcher.py").resolve()),
            "--lease",
            str(lease_path.resolve()),
            "--run-token",
            run_token,
            "--",
            *task.command,
        ]
        try:
            process = subprocess.Popen(
                launcher_command,
                env=environment,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                text=True,
                start_new_session=True,
            )
        except BaseException as exc:
            log_handle.close()
            launch_intent.update(
                {
                    "state": "LAUNCH_FAILED",
                    "launch_failed_at": utc_now(),
                    "launch_error": f"{type(exc).__name__}: {exc}",
                }
            )
            self._write_lease(lease_path, launch_intent)
            raise

        registration: dict[str, Any] | None = None
        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline:
            observed = self._read_lease(lease_path)
            if (
                observed.get("state") == "CHILD_REGISTERED"
                and observed.get("run_token") == run_token
                and observed.get("pid") == process.pid
                and observed.get("pgid") == process.pid
            ):
                registration = observed
                break
            if process.poll() is not None and observed.get("state") == "LAUNCH_INTENT":
                break
            time.sleep(0.01)
        if registration is None:
            return_code = process.poll()
            if return_code is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
            log_handle.close()
            failed = self._read_lease(lease_path)
            failed.update(
                {
                    "state": "LAUNCH_FAILED",
                    "launch_failed_at": utc_now(),
                    "return_code": process.returncode,
                    "launch_error": "CHILD_DID_NOT_ATOMICALLY_REGISTER_LEASE",
                }
            )
            self._write_lease(lease_path, failed)
            raise RuntimeError(
                f"SCHEDULER_CHILD_LEASE_REGISTRATION_FAILED: {task.task_id}; see {log_path}"
            )
        registration.update(
            {
                "state": "PARENT_CONFIRMED",
                "parent_confirmed_at": utc_now(),
                "parent_observed_pid": process.pid,
            }
        )
        self._write_lease(lease_path, registration)
        self.running.append(
            RunningTask(
                task,
                gpu_id,
                process,
                log_path,
                log_handle,
                utc_now(),
                pgid=int(registration["pgid"]),
                run_token=run_token,
                proc_start_ticks=registration.get("proc_start_ticks"),
                boot_id=registration.get("boot_id"),
                lease_path=lease_path,
            )
        )

    def _finish_lease(
        self,
        entry: RunningTask,
        *,
        state: str,
        return_code: int,
        oom: bool,
        retry_count_after: int | None = None,
    ) -> None:
        if entry.lease_path is None:
            raise RuntimeError(f"SCHEDULER_RUNNING_TASK_HAS_NO_LEASE: {entry.task.task_id}")
        lease = self._read_lease(entry.lease_path)
        if (
            lease.get("state") not in {"CHILD_REGISTERED", "PARENT_CONFIRMED"}
            or lease.get("run_token") != entry.run_token
            or lease.get("pid") != entry.process.pid
            or lease.get("pgid") != entry.pgid
        ):
            raise RuntimeError(
                f"SCHEDULER_LEASE_COMPLETION_DRIFT: {entry.task.task_id}"
            )
        lease.update(
            {
                "state": state,
                "finished_at": utc_now(),
                "return_code": return_code,
                "oom": oom,
                "peak_vram_gib": entry.peak_vram_gib,
            }
        )
        if retry_count_after is not None:
            lease.update(
                {
                    "retry_count_after": retry_count_after,
                    "forced_exclusive_after": True,
                    "dynamic_per_gpu_concurrency_after": self.dynamic_concurrency,
                }
            )
        self._write_lease(entry.lease_path, lease)

    def _status(self, queued: Sequence[GPUTask]) -> None:
        gpu_info = _query_gpus(self.gpu_ids)
        planned: dict[int, list[str]] = {gpu_id: [] for gpu_id in self.gpu_ids}
        for index, task in enumerate(queued):
            planned[self.gpu_ids[index % len(self.gpu_ids)]].append(task.task_id)
        cancelled = getattr(self, "cancelled", [])
        submitted = getattr(self, "submitted", [])
        accounted_ids = (
            [task.task_id for task in queued]
            + [entry.task.task_id for entry in self.running]
            + [str(item["task_id"]) for item in self.completed]
            + [str(item["task_id"]) for item in self.failed]
            + [str(item["task_id"]) for item in cancelled]
        )
        partition_valid = (
            bool(submitted)
            and len(submitted) == len(set(submitted))
            and len(accounted_ids) == len(set(accounted_ids))
            and set(accounted_ids) == set(submitted)
        )
        if submitted and not partition_valid:
            raise RuntimeError(
                f"SCHEDULER_ACCOUNTING_INVARIANT_FAILED: submitted={submitted}, accounted={accounted_ids}"
            )
        expected_valid = (
            not self.expected_task_ids
            or (
                len(self.expected_task_ids) == len(set(self.expected_task_ids))
                and set(self.expected_task_ids) == set(submitted)
            )
        )
        if not expected_valid:
            raise RuntimeError(
                "SCHEDULER_EXPECTED_TASK_INVARIANT_FAILED: "
                f"expected={self.expected_task_ids}, submitted={submitted}"
            )
        deferred_submitted = self._validate_task_ids(
            self.deferred_submitted, "deferred submitted"
        )
        deferred_outcome_ids = [
            self._record_task_id(entry, label)
            for label, records in (
                ("deferred completed", self.deferred_completed),
                ("deferred failed", self.deferred_failed),
                ("deferred cancelled", self.deferred_cancelled),
            )
            for entry in records
        ]
        if (
            len(deferred_outcome_ids) != len(set(deferred_outcome_ids))
            or not set(deferred_outcome_ids).issubset(set(deferred_submitted))
            or set(deferred_submitted) & set(submitted)
        ):
            raise RuntimeError(
                "SCHEDULER_DEFERRED_ACCOUNTING_INVARIANT_FAILED: "
                f"submitted={deferred_submitted}, outcomes={deferred_outcome_ids}"
            )
        for entry in self.completed:
            self._validated_completed_log(entry)
        for entry in self.deferred_completed:
            self._validated_completed_log(entry)
        terminal = not queued and not self.running
        accounting_complete = terminal and partition_valid and expected_valid
        if terminal and submitted and not accounting_complete:
            raise RuntimeError("SCHEDULER_TERMINAL_ACCOUNTING_INCOMPLETE")
        payload = {
            "schema_version": 1,
            "updated_at": utc_now(),
            "scheduler_scope": self.scope,
            "config_sha256": self.config_sha256,
            "gpu_ids": self.gpu_ids,
            "configured_per_gpu_concurrency": self.per_gpu_concurrency,
            "dynamic_per_gpu_concurrency": self.dynamic_concurrency,
            "queued_count": len(queued),
            "running_count": len(self.running),
            "completed_count": len(self.completed),
            "failed_count": len(self.failed),
            "cancelled_count": len(cancelled),
            "submitted_count": len(submitted),
            "submitted_task_ids": submitted,
            "expected_task_ids": self.expected_task_ids,
            "queued_task_ids": [task.task_id for task in queued],
            "running_task_ids": [entry.task.task_id for entry in self.running],
            "running": [
                {
                    "task_id": entry.task.task_id,
                    "gpu_id": entry.gpu_id,
                    "pid": entry.process.pid,
                    "pgid": entry.pgid,
                    "run_token": entry.run_token,
                    "proc_start_ticks": entry.proc_start_ticks,
                    "boot_id": entry.boot_id,
                    "log": str(entry.log_path),
                    "attempt": entry.task.attempt,
                    "retry_count": entry.task.retries,
                    "force_exclusive": entry.task.force_exclusive,
                    "lease": str(entry.lease_path) if entry.lease_path else None,
                    "started_at": entry.started_at,
                }
                for entry in self.running
            ],
            "completed_task_ids": [str(item["task_id"]) for item in self.completed],
            "failed_task_ids": [str(item["task_id"]) for item in self.failed],
            "cancelled_task_ids": [str(item["task_id"]) for item in cancelled],
            "retry_history": self.retry_history,
            "reclaimed_leases": self.reclaimed_leases,
            "launch_leases": self._lease_evidence(),
            "gpus": {
                str(gpu_id): {
                    **gpu_info[gpu_id],
                    "running_task_ids": [entry.task.task_id for entry in self.running if entry.gpu_id == gpu_id],
                    "queued_task_ids": planned[gpu_id],
                    "peak_vram_gib_by_task": {
                        entry.task.task_id: entry.peak_vram_gib
                        for entry in self.running
                        if entry.gpu_id == gpu_id
                    },
                    "completed_count": sum(item.get("gpu_id") == gpu_id for item in self.completed),
                }
                for gpu_id in self.gpu_ids
            },
            "completed": self.completed,
            "failed": self.failed,
            "cancelled_not_run": cancelled,
            "deferred_accounting": {
                "submitted_task_ids": deferred_submitted,
                "completed": self.deferred_completed,
                "failed": self.deferred_failed,
                "cancelled_not_run": self.deferred_cancelled,
            },
            "accounting_complete": accounting_complete,
        }
        atomic_json(self.status_path, payload)

    def run(
        self,
        tasks: Sequence[GPUTask],
        *,
        expected_task_ids: Sequence[str] | None = None,
        precompleted_task_ids: Sequence[str] | None = None,
    ) -> None:
        queued = list(tasks)
        new_task_ids = self._validate_task_ids(
            [task.task_id for task in queued], "submitted"
        )
        if not hasattr(self, "submitted"):
            self.submitted = []
        if not hasattr(self, "cancelled"):
            self.cancelled = []
        if not hasattr(self, "expected_task_ids"):
            self.expected_task_ids = []
        for name in (
            "deferred_completed",
            "deferred_failed",
            "deferred_cancelled",
            "deferred_submitted",
        ):
            if not hasattr(self, name):
                setattr(self, name, [])

        expected: list[str] | None = None
        precompleted: list[str] = []
        if expected_task_ids is not None:
            expected = self._validate_task_ids(expected_task_ids, "expected")
            precompleted = self._validate_task_ids(
                precompleted_task_ids or [], "precompleted"
            )
            if not expected:
                raise ValueError("expected_task_ids must not be empty")
            if set(new_task_ids) & set(precompleted):
                raise ValueError("A task cannot be both queued and precompleted")
            if set(new_task_ids) | set(precompleted) != set(expected):
                raise ValueError(
                    "Full scheduler expected tasks must equal queued plus valid precompleted tasks: "
                    f"expected={expected}, queued={new_task_ids}, precompleted={precompleted}"
                )
            prior_submitted = self._activate_expected_partition(set(expected))
        else:
            prior_submitted = {str(value) for value in self.submitted}

        resubmitted = set(new_task_ids)
        resolved = resubmitted | set(precompleted)
        self.completed = [
            entry for entry in self.completed if str(entry.get("task_id")) not in resubmitted
        ]
        self.failed = [
            entry for entry in self.failed if str(entry.get("task_id")) not in resolved
        ]
        self.cancelled = [
            entry for entry in self.cancelled if str(entry.get("task_id")) not in resolved
        ]
        for task in queued:
            self._apply_restored_retry_state(task)
            task.attempt = self._next_log_attempt(task.task_id)

        if expected is not None:
            for task_id in precompleted:
                self._recover_precompleted(task_id, prior_submitted)
            self.expected_task_ids = expected
            self.submitted = expected
        else:
            combined_ids = [
                *[value for value in self.submitted if str(value) not in resubmitted],
                *new_task_ids,
            ]
            if len(combined_ids) != len(set(combined_ids)):
                raise ValueError(
                    f"Duplicate scheduler task ids across resume batches: {combined_ids}"
                )
            self.submitted = combined_ids
        last_progress = time.monotonic()
        self._status(queued)
        while queued or self.running:
            gpu_info = _query_gpus(self.gpu_ids)
            launched = True
            while launched and queued:
                launched = False
                for task in list(queued):
                    gpu_id = self._select_gpu(task, gpu_info)
                    if gpu_id is not None:
                        queued.remove(task)
                        self._launch(task, gpu_id)
                        # Persist the confirmed child PID/PGID/token immediately,
                        # rather than waiting for the next polling interval.
                        self._status(queued)
                        last_progress = time.monotonic()
                        launched = True
                    if launched:
                        break
            time.sleep(self.poll_seconds if self.running else min(self.poll_seconds, 1.0))
            usage = _query_pid_vram_mib()
            process_groups = _query_process_groups()
            for entry in self.running:
                entry.peak_vram_gib = max(
                    entry.peak_vram_gib,
                    _task_vram_mib(entry.process.pid, usage, process_groups) / 1024,
                )
                if (
                    entry.peak_vram_gib >= self.max_peak_vram_gib
                    and entry.process.poll() is None
                    and not entry.vram_limit_exceeded
                ):
                    entry.vram_limit_exceeded = True
                    entry.log_handle.write(
                        "\nSCREENBUS_VRAM_LIMIT_EXCEEDED: "
                        f"observed={entry.peak_vram_gib:.6f} GiB "
                        f"limit={self.max_peak_vram_gib:.6f} GiB; terminating without retry\n"
                    )
                    entry.log_handle.flush()
                    if entry.pgid is not None:
                        os.killpg(entry.pgid, signal.SIGTERM)
                    else:
                        entry.process.terminate()
            for entry in list(self.running):
                return_code = entry.process.poll()
                if return_code is None:
                    continue
                entry.log_handle.close()
                self.running.remove(entry)
                log_text = entry.log_path.read_text(encoding="utf-8", errors="replace")
                oom = "out of memory" in log_text.lower() or "cuda error: out of memory" in log_text.lower()
                record = {
                    "task_id": entry.task.task_id,
                    "gpu_id": entry.gpu_id,
                    "return_code": return_code,
                    "started_at": entry.started_at,
                    "finished_at": utc_now(),
                    "peak_vram_gib": entry.peak_vram_gib,
                    "log": str(entry.log_path),
                    "command": shlex.join(entry.task.command),
                    "retry": entry.task.retries,
                    "attempt": entry.task.attempt,
                    "force_exclusive": entry.task.force_exclusive,
                    "pid": entry.process.pid,
                    "pgid": entry.pgid,
                    "run_token": entry.run_token,
                    "proc_start_ticks": entry.proc_start_ticks,
                    "boot_id": entry.boot_id,
                    "lease": str(entry.lease_path) if entry.lease_path else None,
                    "oom": oom,
                    "metadata": entry.task.metadata,
                    "reproducibility_environment": {
                        key: value
                        for key, value in entry.task.environment.items()
                        if key in {"PYTHONHASHSEED", "SCREENBUS_SEED"}
                    },
                    "insufficient_events": "INSUFFICIENT_" in log_text,
                    "no_decision": (
                        "NO_DECISION" in log_text or "UNSTABLE_THRESHOLD" in log_text
                    ),
                }
                if entry.vram_limit_exceeded or entry.peak_vram_gib >= self.max_peak_vram_gib:
                    self._finish_lease(
                        entry,
                        state="EXITED",
                        return_code=return_code,
                        oom=oom,
                    )
                    record["reason"] = "VRAM_LIMIT_EXCEEDED"
                    record["limit_gib"] = self.max_peak_vram_gib
                    record["evidence_preserved"] = True
                    self.failed.append(record)
                    last_progress = time.monotonic()
                elif return_code == 0:
                    self._finish_lease(
                        entry,
                        state="EXITED",
                        return_code=return_code,
                        oom=oom,
                    )
                    self.completed.append(record)
                    last_progress = time.monotonic()
                else:
                    self._finish_lease(
                        entry,
                        state="EXITED",
                        return_code=return_code,
                        oom=oom,
                    )
                    self.failed.append(record)
                    last_progress = time.monotonic()
            if queued and not self.running and time.monotonic() - last_progress >= self.max_wait_without_progress:
                observed = _query_gpus(self.gpu_ids)
                blocked = queued.pop(0)
                self.failed.append(
                    {
                        "task_id": blocked.task_id,
                        "return_code": None,
                        "finished_at": utc_now(),
                        "reason": "BLOCKED_INSUFFICIENT_FREE_VRAM",
                        "required_memory_class": blocked.memory_class,
                        "required_gib": self.memory_gib[blocked.memory_class] + self.min_free,
                        "observed_gpus": observed,
                        "waited_seconds": time.monotonic() - last_progress,
                    }
                )
                self.cancelled.extend(
                    {
                        "task_id": task.task_id,
                        "at": utc_now(),
                        "reason": "NOT_RUN_AFTER_CAPACITY_BLOCKER",
                        "upstream_task_id": blocked.task_id,
                    }
                    for task in queued
                )
                queued.clear()
            self._status(queued)
            if self.failed:
                # Finish no additional queued work after a hard failure. Running
                # workers are allowed to finish so their evidence is preserved.
                self.cancelled.extend(
                    {
                        "task_id": task.task_id,
                        "at": utc_now(),
                        "reason": "NOT_RUN_AFTER_UPSTREAM_TASK_FAILURE",
                        "failed_task_ids": [entry["task_id"] for entry in self.failed],
                    }
                    for task in queued
                )
                queued.clear()
                if not self.running:
                    break
        self._status([])
        if self.failed:
            failed_ids = [entry["task_id"] for entry in self.failed]
            if any(
                entry.get("insufficient_events") or entry.get("no_decision")
                for entry in self.failed
            ):
                from .data import InsufficientEvents

                raise InsufficientEvents(
                    f"NO_DECISION in GPU worker tasks {failed_ids}; see {self.status_path}"
                )
            raise RuntimeError(f"GPU worker tasks failed: {failed_ids}; see {self.status_path}")
