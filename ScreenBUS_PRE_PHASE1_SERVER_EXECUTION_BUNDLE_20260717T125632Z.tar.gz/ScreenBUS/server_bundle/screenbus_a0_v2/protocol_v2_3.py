"""Machine-checkable ScreenBUS v2.3 experiment protocol.

Pure protocol constants and fail-closed decision logic. Importing this module
does not read data, allocate CUDA memory, or authorize a training stage.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Mapping, Sequence


PROTOCOL_VERSION = "2.3"

STATE_MACHINE = (
    "P0_PROTOCOL_REPAIR",
    "G2_SERVER_ENGINEERING",
    "ENGINEERING_A0",
    "PHASE1_FIVE_FOLD_ONE_SEED",
    "G3_METHOD_GATE",
    "PHASE2_THREE_SEEDS_AND_FULL_BASELINES",
    "EXTERNAL_POSITIVE_STRESS",
    "RESULT_FREEZE",
)

METHOD_DEFINITIONS = {
    "B0": "DeepLabV3+ direct semantic segmentation",
    "B1": "B0 + image-level presence hard gate",
    "B2": "FPN detector",
    "B3": "FPN + MedSAM (predicted box primary)",
    "B4": "B3 + original PointRend (optional post-G3 boundary ablation only)",
    "B5": "B3 + patient-cross-fitted dual-head candidate verifier",
}

SIMPLE_CONTROLS = (
    "detector_score",
    "sam_predicted_iou",
    "sam_stability",
    "jitter_variance",
    "area_component_rule",
    "lightweight_quality_regressor",
)

PHASE1_REQUIRED_METHODS = (
    "B1",
    "Mask R-CNN",
    "B3",
    *SIMPLE_CONTROLS,
    "B5",
)

PRIMARY_COMPARISON = "B5 vs strongest_inner_meta_oof_simple_control"
MECHANISTIC_COMPARISON = "B3 vs Mask R-CNN"
OPTIONAL_POST_G3_COMPARISON = "B4 vs B3"
PHASE2_EVIDENCE_SEMANTICS = "SAME_COHORT_MULTI_SEED_AND_FULL_BASELINE_SENSITIVITY"

ENGINEERING_A0_CHECKS = (
    "data_loading_and_patient_folds",
    "b1_forward_backward",
    "fpn_detector_forward_backward",
    "mask_rcnn_forward_backward",
    "medsam_decoder_forward_backward",
    "predicted_box_coordinate_reprojection",
    "real_candidate_schema",
    "verifier_and_all_simple_controls_grouped_train_infer",
    "empty_refer_accept_states",
    "checkpoint_resume_model_optimizer_scheduler",
    "fp32_amp_peak_vram",
    "scheduler_lease_failure_archive_recovery",
)

PHASE1_REQUIRED_OUTPUTS = (
    "phase1_completion",
    "predicted_box_localization",
    "b3_vs_mask_rcnn",
    "candidate_pool_oracle_at_98pct_lesion_sensitivity",
    "event_sufficiency",
    "simple_control_inner_meta_oof_ranking",
    "b5_vs_strongest_simple_control",
    "artifact_and_leakage_audit",
)

PATIENT_EVIDENCE_MINIMUMS = {
    "existence_positive_unique_patients": 8,
    "existence_negative_unique_patients": 8,
    "quality_success_unique_patients": 8,
    "quality_failure_unique_patients": 8,
}

FINAL_PRETRAINING_STATUS = {
    "protocol": "PROTOCOL_V2_3_READY",
    "source_repair": "SOURCE_REPAIR_PASS",
    "engineering_a0": "ENGINEERING_A0_NOT_RUN",
    "phase1": "PHASE1_NOT_RUN",
    "g3": "G3_NOT_RUN",
    "phase2": "PHASE2_NOT_RUN",
    "scientific_decision": "SCIENTIFIC_DECISION_NO_DECISION",
    "clinical_screening_claim": (
        "CLINICAL_SCREENING_CLAIM_BLOCKED_MISSING_INDEPENDENT_NORMAL_PATIENT_COHORT"
    ),
}

ALLOWED_METHOD_PAPER_CLAIMS = (
    "normal-inclusive / lesion-free-view-aware BUS segmentation",
    "0-to-K mask output",
    "patient-level nested OOF",
    "cross-fitted candidate acceptance",
    "separating lesion existence from conditional mask quality",
    "internal patient-level evidence",
    "external positive-domain stress test",
)

PROHIBITED_CLAIMS = (
    "clinically validated screening system",
    "normal-patient specificity",
    "external normal-population validation",
    "independent confirmation from Phase-2",
    "confirmatory validation from Phase-2",
    "first detector-plus-SAM",
    "novel PointRend",
    "proven multi-lesion generalization",
    "clinical deployment or safety claim",
)


def _require(condition: bool, code: str) -> None:
    if not condition:
        raise ValueError(code)


def patient_evidence_from_rows(
    rows: Sequence[Mapping[str, Any]], *, failure_dice_threshold: float
) -> dict[str, int]:
    """Count evidence by unique patient; duplicating candidates cannot help."""

    groups: dict[str, set[str]] = {
        "existence_positive_unique_patients": set(),
        "existence_negative_unique_patients": set(),
        "quality_success_unique_patients": set(),
        "quality_failure_unique_patients": set(),
    }
    for row in rows:
        if row.get("is_sentinel"):
            continue
        patient = str(row["patient_id"])
        valid = bool(int(row["candidate_valid"]))
        groups[
            "existence_positive_unique_patients"
            if valid
            else "existence_negative_unique_patients"
        ].add(patient)
        if valid:
            groups[
                "quality_success_unique_patients"
                if float(row["mask_dice"]) >= float(failure_dice_threshold)
                else "quality_failure_unique_patients"
            ].add(patient)
    return {name: len(patient_ids) for name, patient_ids in groups.items()}


def meta_fold_patient_evidence(
    rows: Sequence[Mapping[str, Any]],
    meta_folds: Sequence[int],
    *,
    failure_dice_threshold: float,
) -> dict[str, dict[str, int]]:
    _require(len(rows) == len(meta_folds), "META_FOLD_EVIDENCE_ALIGNMENT_INVALID")
    folded: dict[int, list[Mapping[str, Any]]] = defaultdict(list)
    for row, fold in zip(rows, meta_folds):
        if int(fold) >= 0:
            folded[int(fold)].append(row)
    return {
        str(fold): patient_evidence_from_rows(
            fold_rows, failure_dice_threshold=failure_dice_threshold
        )
        for fold, fold_rows in sorted(folded.items())
    }


def patient_evidence_is_sufficient(
    counts: Mapping[str, Any], fold_counts: Mapping[str, Mapping[str, Any]]
) -> bool:
    if any(int(counts.get(name, 0)) < minimum for name, minimum in PATIENT_EVIDENCE_MINIMUMS.items()):
        return False
    if not fold_counts:
        return False
    return all(
        all(int(fold.get(name, 0)) >= 1 for name in PATIENT_EVIDENCE_MINIMUMS)
        for fold in fold_counts.values()
    )


def validate_phase1_completion(completion: Mapping[str, Any]) -> None:
    _require(completion.get("seed") == 2027, "PHASE1_SEED_MUST_BE_2027")
    _require(completion.get("outer_folds") == [0, 1, 2, 3, 4], "PHASE1_REQUIRES_ALL_FIVE_OUTER_FOLDS")
    _require(completion.get("completed_outer_folds") == [0, 1, 2, 3, 4], "G3_FORBIDDEN_BEFORE_ALL_FIVE_OUTER_FOLDS_COMPLETE")
    _require(completion.get("outer_test_evaluations_per_patient") == 1, "OUTER_TEST_PATIENT_MUST_BE_EVALUATED_EXACTLY_ONCE")
    _require(completion.get("frozen_code_sha256_across_folds") is True, "PHASE1_CODE_MUST_BE_FROZEN_ACROSS_FOLDS")
    _require(completion.get("outer_test_used_for_route_or_threshold_selection") is False, "OUTER_TEST_SELECTION_FORBIDDEN")
    _require(completion.get("methods") == list(PHASE1_REQUIRED_METHODS), "PHASE1_METHOD_SET_DRIFT")
    _require(completion.get("pointrend_executed") is False, "POINTREND_FORBIDDEN_IN_PHASE1")


def decide_g3_method_gate(report: Mapping[str, Any], thresholds: Mapping[str, Any]) -> str:
    """Recompute G3 using CI boundaries and full-cohort action semantics."""

    _require(
        report.get("schema_version") == 3
        and report.get("protocol_version") == PROTOCOL_VERSION,
        "PHASE1_REPORT_PROTOCOL_MUST_BE_V2_3",
    )
    missing = sorted(set(PHASE1_REQUIRED_OUTPUTS) - set(report))
    if missing:
        raise ValueError(f"PHASE1_OUTPUT_SCHEMA_INCOMPLETE: {missing}")
    validate_phase1_completion(report["phase1_completion"])

    controls = report["simple_control_inner_meta_oof_ranking"]
    _require(
        isinstance(controls, Mapping)
        and set(controls.get("controls", ())) == set(SIMPLE_CONTROLS)
        and controls.get("strongest_control") in SIMPLE_CONTROLS
        and controls.get("selection_score_source") == "PATIENT_GROUPED_META_OOF_ONLY",
        "G3_ALL_CONTROLS_AND_META_OOF_STRONGEST_REQUIRED",
    )

    sufficiency = report["event_sufficiency"]
    if (
        not patient_evidence_is_sufficient(
            sufficiency.get("unique_patient_counts", {}),
            sufficiency.get("meta_fold_unique_patient_counts", {}),
        )
        or sufficiency.get("any_meta_fold_single_class", True)
        or float(sufficiency.get("max_fold_threshold_range", float("inf")))
        > float(thresholds["max_fold_threshold_range"])
        or not sufficiency.get("confidence_intervals_stably_estimable", False)
    ):
        return "NO_DECISION_INSUFFICIENT_EVIDENCE"

    localization = report["predicted_box_localization"]
    loc_low = float(localization.get("recall_ci_low", float("-inf")))
    loc_high = float(localization.get("recall_ci_high", float("inf")))
    loc_gate = float(thresholds["localization_recall_at_1_fp_per_view"])
    if loc_high < loc_gate:
        return "NO_GO_AUTOMATIC_PROMPT"
    if loc_low <= loc_gate <= loc_high:
        return "NO_DECISION_INSUFFICIENT_EVIDENCE"

    medsam = report["b3_vs_mask_rcnn"]
    dice_high = float(medsam.get("dice_delta_ci_high", float("inf")))
    dice_low = float(medsam.get("dice_delta_ci_low", float("-inf")))
    dice_gate = float(thresholds["b3_mask_rcnn_dice_delta_ci_upper_no_go"])
    latency = medsam.get("measured_end_to_end_latency_ratio")
    vram = medsam.get("measured_peak_vram_ratio")
    efficiency_measured = bool(medsam.get("efficiency_measured", False))
    efficiency_advantage = efficiency_measured and (
        (latency is not None and float(latency) <= float(thresholds["efficiency_ratio_max"]))
        or (vram is not None and float(vram) <= float(thresholds["efficiency_ratio_max"]))
    )
    if dice_high < dice_gate and not efficiency_advantage:
        return "NO_GO_MEDSAM_ROUTE"
    if dice_low <= dice_gate <= dice_high:
        return "NO_DECISION_INSUFFICIENT_EVIDENCE"

    oracle = report["candidate_pool_oracle_at_98pct_lesion_sensitivity"]
    _require(float(oracle.get("lesion_sensitivity", -1.0)) == 0.98, "G3_ORACLE_MUST_USE_98PCT_LESION_SENSITIVITY")
    if not oracle.get("negative_view_fp_reduction_attainable", False):
        return "NO_GO_CANDIDATE_POOL"

    primary = report["b5_vs_strongest_simple_control"]
    audit = report["artifact_and_leakage_audit"]
    quantitative_pass = (
        float(primary.get("absolute_negative_view_action_rate_reduction", float("-inf")))
        >= float(thresholds["b5_min_absolute_negative_view_action_rate_reduction"])
        and float(primary.get("lesion_recall_delta_ci_low", float("-inf")))
        > float(thresholds["b5_lesion_recall_delta_ci_lower_min"])
        and float(primary.get("patient_macro_dice_delta_ci_low", float("-inf")))
        > float(thresholds["b5_patient_macro_dice_delta_ci_lower_min"])
        and float(primary.get("overall_referral_rate", float("inf")))
        <= float(thresholds["b5_max_overall_referral_rate"])
        and float(primary.get("automatic_coverage", float("-inf")))
        >= float(thresholds["b5_min_automatic_coverage"])
        and primary.get("positive_refer_counted_as_failure") is True
        and primary.get("all_controls_same_full_cohort_evaluator") is True
    )
    if not quantitative_pass or any(
        bool(audit.get(key, True))
        for key in ("label_leakage", "text_artifact_dependency", "color_artifact_dependency")
    ):
        return "NO_GO_VERIFIER"
    return "GO_EXPAND_TO_PHASE2"


def validate_state_transition(current: str, requested: str) -> None:
    _require(current in STATE_MACHINE, "UNKNOWN_CURRENT_PROTOCOL_STAGE")
    _require(requested in STATE_MACHINE, "UNKNOWN_REQUESTED_PROTOCOL_STAGE")
    current_index = STATE_MACHINE.index(current)
    _require(
        current_index + 1 < len(STATE_MACHINE)
        and STATE_MACHINE[current_index + 1] == requested,
        "NON_ADJACENT_PROTOCOL_TRANSITION_FORBIDDEN",
    )


def assert_no_independent_normal_cohort_claim_overreach(
    claims: Sequence[str], *, independent_normal_patient_cohort_available: bool
) -> None:
    if independent_normal_patient_cohort_available:
        return
    lowered = "\n".join(str(claim).lower() for claim in claims)
    for prohibited in (
        "clinical screening validation",
        "normal-patient specificity",
        "external normal-population generalization",
        "clinical deployment",
        "triage safety",
    ):
        _require(prohibited not in lowered, "CLINICAL_CLAIM_REQUIRES_INDEPENDENT_NORMAL_COHORT")


__all__ = [name for name in globals() if name.isupper()] + [
    "assert_no_independent_normal_cohort_claim_overreach",
    "decide_g3_method_gate",
    "meta_fold_patient_evidence",
    "patient_evidence_from_rows",
    "patient_evidence_is_sufficient",
    "validate_phase1_completion",
    "validate_state_transition",
]
