from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Sequence

from .util import sha256_file


LEAKAGE_ABLATION_SLUG = "non_oof_verifier_leakage_demonstration"
LEAKAGE_ABLATION_LABEL = "LEAKAGE_DEMONSTRATION_ABLATION_NOT_VALID_METHOD"


def leakage_ablation_paths(run_dir: Path) -> dict[str, Path]:
    root = run_dir / "ablations" / LEAKAGE_ABLATION_SLUG
    verifier_dir = root / "verifier"
    return {
        "root": root,
        "training_candidates_dir": root / "training_candidates",
        "training_candidates": root / "training_candidates" / "candidates.jsonl",
        "verifier_dir": verifier_dir,
        "verifier_checkpoint": verifier_dir / "non_oof_verifier.pt",
        "thresholds": verifier_dir / "thresholds.json",
        "evaluation_scores": verifier_dir / "evaluation_scores.json",
        "provenance": root / "provenance.json",
        "result": root / "result.json",
    }


def validate_self_generated_training_candidates(
    rows: Sequence[dict[str, Any]],
    split: dict[str, Any],
    detector_training_patient_ids: set[str],
) -> dict[str, Any]:
    if split.get("mode") != "phase2":
        raise RuntimeError("The non-OOF leakage demonstration is Phase-2 only")
    if not rows:
        raise RuntimeError("Non-OOF leakage demonstration generated no candidate rows")
    if any(row.get("condition") != "predicted_box" for row in rows):
        raise RuntimeError("Leakage demonstration accepts predicted-box candidates only")

    expected_images = set(split["train_image_ids"])
    generated_images = {str(row["image_id"]) for row in rows}
    expected_patients = set(split["train_patient_ids"])
    generated_patients = {str(row["patient_id"]) for row in rows}
    evaluation_patients = set(split["evaluation_patient_ids"])
    if generated_images != expected_images:
        raise RuntimeError(
            "Leakage candidate image coverage mismatch: "
            f"missing={sorted(expected_images - generated_images)}, "
            f"extra={sorted(generated_images - expected_images)}"
        )
    if generated_patients != expected_patients:
        raise RuntimeError("Leakage candidate patients do not equal the frozen outer-train patients")
    if detector_training_patient_ids != expected_patients:
        raise RuntimeError("Final detector training patients do not equal the frozen outer-train patients")
    overlap = detector_training_patient_ids & generated_patients
    if overlap != expected_patients:
        raise RuntimeError("Leakage demonstration failed to establish the required complete patient overlap")
    if evaluation_patients & detector_training_patient_ids:
        raise RuntimeError("Outer-test patients overlap the final-detector training patients")
    for row in rows:
        if row.get("candidate_source") != "final_detector_on_its_own_outer_train_images":
            raise RuntimeError("Unexpected candidate source in leakage demonstration")
        if set(row.get("training_patient_ids", [])) != detector_training_patient_ids:
            raise RuntimeError("Candidate row detector-training provenance mismatch")
        if set(row.get("candidate_generation_patient_ids", [])) != generated_patients:
            raise RuntimeError("Candidate row generation-patient provenance mismatch")
        if set(row.get("training_generation_patient_overlap_ids", [])) != overlap:
            raise RuntimeError("Candidate row does not explicitly record the known patient overlap")
        if row.get("protocol_label") != LEAKAGE_ABLATION_LABEL:
            raise RuntimeError("Candidate row lacks the mandatory invalid-method label")

    return {
        "detector_training_patient_ids": sorted(detector_training_patient_ids),
        "candidate_generation_patient_ids": sorted(generated_patients),
        "training_generation_patient_overlap_ids": sorted(overlap),
        "training_generation_patient_overlap_count": len(overlap),
        "overlap_is_complete_outer_train": True,
        "outer_test_patient_ids": sorted(evaluation_patients),
        "outer_test_is_patient_disjoint": True,
    }


def tag_leakage_ablation_result(
    row: dict[str, Any], paths: dict[str, Path], overlap_count: int
) -> dict[str, Any]:
    tagged = dict(row)
    tagged.update(
        {
            "method": LEAKAGE_ABLATION_LABEL,
            "table_role": "ABLATION",
            "valid_method": False,
            "claim_status": LEAKAGE_ABLATION_LABEL,
            "candidate_generation_protocol": "FINAL_DETECTOR_ON_ITS_OWN_OUTER_TRAIN_IMAGES",
            "known_training_generation_patient_overlap": True,
            "training_generation_patient_overlap_count": int(overlap_count),
            "g3_eligible": False,
            "main_table_eligible": False,
            "provenance_file": str(paths["provenance"]),
            "verifier_checkpoint": str(paths["verifier_checkpoint"]),
            "threshold_file": str(paths["thresholds"]),
            "calibration_status": (
                "patient_disjoint_verifier_holdout_but_detector_candidate_generation_is_non_oof_INVALID"
            ),
        }
    )
    return tagged


def leakage_verifier_ready(paths: dict[str, Path], expected_detector_sha256: str) -> bool:
    try:
        required = (
            paths["training_candidates"],
            paths["training_candidates_dir"] / "metadata.json",
            paths["verifier_checkpoint"],
            paths["thresholds"],
            paths["evaluation_scores"],
            paths["provenance"],
        )
        if any(not path.is_file() for path in required):
            return False
        provenance = json.loads(paths["provenance"].read_text(encoding="utf-8"))
        thresholds = json.loads(paths["thresholds"].read_text(encoding="utf-8"))
        scores = json.loads(paths["evaluation_scores"].read_text(encoding="utf-8"))
        if any(
            payload.get("protocol_label") != LEAKAGE_ABLATION_LABEL
            for payload in (provenance, thresholds, scores)
        ):
            return False
        if provenance.get("valid_method") is not False:
            return False
        if provenance.get("legal_oof_verifier_artifacts_unchanged") is not True:
            return False
        expected = {
            "candidate_jsonl_sha256": sha256_file(paths["training_candidates"]),
            "candidate_metadata_sha256": sha256_file(
                paths["training_candidates_dir"] / "metadata.json"
            ),
            "final_detector_checkpoint_sha256": expected_detector_sha256,
            "verifier_checkpoint_sha256": sha256_file(paths["verifier_checkpoint"]),
            "thresholds_sha256": sha256_file(paths["thresholds"]),
            "evaluation_scores_sha256": sha256_file(paths["evaluation_scores"]),
        }
        return all(provenance.get(key) == value for key, value in expected.items())
    except (OSError, KeyError, json.JSONDecodeError):
        return False


def main_table_rows(rows: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
    return [row for row in rows if row.get("table_role") == "MAIN_TABLE"]
