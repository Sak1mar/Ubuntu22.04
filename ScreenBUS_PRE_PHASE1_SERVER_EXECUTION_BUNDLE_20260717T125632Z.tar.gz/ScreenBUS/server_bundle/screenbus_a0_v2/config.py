from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

import yaml

from .protocol_v2_3 import (
    ENGINEERING_A0_CHECKS,
    MECHANISTIC_COMPARISON,
    METHOD_DEFINITIONS,
    OPTIONAL_POST_G3_COMPARISON,
    PATIENT_EVIDENCE_MINIMUMS,
    PHASE2_EVIDENCE_SEMANTICS,
    PHASE1_REQUIRED_METHODS,
    PRIMARY_COMPARISON,
    PROTOCOL_VERSION,
    SIMPLE_CONTROLS,
    STATE_MACHINE,
)


REQUIRED_ENV = (
    "SCREENBUS_ROOT",
    "SCREENBUS_DATA_ROOT",
    "SCREENBUS_CACHE_ROOT",
    "SCREENBUS_OUTPUT_ROOT",
    "SCREENBUS_WEIGHT_ROOT",
    "MEDSAM_CKPT",
)

PRIMARY_MATCH = "box_center_in_reference_component_confidence_ordered_one_to_one"
SENSITIVITY_MATCH = "box_iou_confidence_ordered_one_to_one"
PHASE2_METHODS = {
    "nnunet_v2_2d",
    "deeplabv3plus_hard_gate",
    "mask_rcnn_r50_fpn",
    "autobusam_adapted_yolov8s_sam_lora",
    "b3_fpn_medsam",
    "b5_oof_verifier",
}
# Compatibility name used by reporting code and tests.
FULL_METHODS = PHASE2_METHODS

EXISTENCE_FEATURES = [
    "detector_score",
    "detector_rank_inverse",
    "image_presence_probability",
    "box_area_ratio",
    "box_aspect_log",
    "border_touch",
]
QUALITY_FEATURES = [
    "sam_predicted_iou",
    "jitter_iou_mean",
    "jitter_iou_variance_inverse",
    "jitter_iou_worst",
    "box_mask_coverage",
    "area_ratio",
    "component_count_log",
    "compactness",
]
INTERACTION_FEATURES = [
    "detector_score_x_image_presence_probability",
    "sam_predicted_iou_x_jitter_iou_variance_inverse",
    "box_mask_coverage_x_area_plausibility",
]


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(f"PROTOCOL_V2_3_CONFIG_INVALID: {message}")


def _validate_dataset_roles(cfg: dict[str, Any]) -> None:
    roles = cfg.get("dataset_roles", {})
    _require(roles.get("bus_uclm_clean") == "ONLY_FORMAL_PRIMARY_EVIDENCE", "BUS-UCLM clean role drift")
    _require(
        roles.get("busi") == "OPTIONAL_IMAGE_LEVEL_SANITY_CHECK_NOT_PAPER_EVIDENCE",
        "BUSI must remain an optional image-level sanity check",
    )
    _require(roles.get("busi_required") is False, "BUSI absence must not block the method paper")
    _require(
        roles.get("busi_patient_level_validation_forbidden") is True,
        "BUSI patient-level validation is forbidden",
    )
    _require(
        roles.get("busi_full_authorization_forbidden") is True,
        "BUSI cannot authorize Phase-2",
    )
    _require(
        roles.get("breast") == "POST_PHASE1_EXTERNAL_POSITIVE_LESION_STRESS_ONLY",
        "BrEaST role drift",
    )
    _require(
        roles.get("breast_four_normal_patients") == "CASE_BY_CASE_DESCRIPTION_ONLY",
        "BrEaST normal patients may only be described case by case",
    )
    _require(
        roles.get("bus_bra") == "POSITIVE_PRETRAINING_ONLY_OR_DELETE_ROUTE",
        "BUS-BRA role drift",
    )
    _require(
        roles.get("bus_bra_equal_exposure_for_applicable_baselines") is True,
        "BUS-BRA exposure must be fair across applicable baselines",
    )


def _validate_common_scientific_contract(cfg: dict[str, Any]) -> None:
    _require(cfg.get("method_definitions") == METHOD_DEFINITIONS, "B0-B5 definitions drift")
    comparisons = cfg.get("comparisons", {})
    _require(comparisons.get("primary") == PRIMARY_COMPARISON, "Primary comparison drift")
    _require(comparisons.get("mechanistic") == MECHANISTIC_COMPARISON, "mechanistic comparison drift")
    _require(
        comparisons.get("optional_post_g3") == OPTIONAL_POST_G3_COMPARISON,
        "PointRend comparison must be post-G3 only",
    )
    _require(comparisons.get("b5_default_input") == "B3", "B5 must use B3 candidates")
    _require(cfg.get("primary_analysis_cohort") == "bus_uclm_clean", "BUS-UCLM clean must be primary")
    _validate_dataset_roles(cfg)
    _require(cfg.get("manifest") == "bootstrap/evidence/BUS-UCLM/busuclm_route2_dev.csv", "formal manifest drift")
    _require(cfg.get("nested_patient_outer_oof") is True, "patient-level nested outer OOF is mandatory")
    _require(cfg.get("outer_test_route_modification_forbidden") is True, "outer-test route modification must be forbidden")
    _require(cfg.get("outer_test_threshold_selection_forbidden") is True, "outer-test threshold selection must be forbidden")
    _require(cfg.get("inner_meta_only_selection") is True, "selection/calibration/NMS/postprocess must be inner/meta only")
    _require(int(cfg.get("inner_folds", 0)) == 4, "inner folds must be 4")
    _require(int(cfg.get("detector_top_k", 0)) == 10, "detector top-K must be 10")
    _require(float(cfg.get("failure_dice_threshold", -1)) == 0.75, "failure Dice must be 0.75")
    _require(int(cfg.get("bootstrap_replicates", 0)) == 2000, "patient bootstrap must use 2000 replicates")
    matching = cfg.get("matching", {})
    _require(matching.get("primary") == PRIMARY_MATCH, "primary matching drift")
    _require(matching.get("sensitivity") == SENSITIVITY_MATCH, "sensitivity matching drift")
    _require(float(matching.get("sensitivity_box_iou_threshold", -1)) == 0.30, "sensitivity IoU drift")
    verifier = cfg.get("verifier", {})
    _require(verifier.get("model") == "two_head_l2_logistic_regression", "verifier model drift")
    _require(verifier.get("point_rend_features_default") is False, "PointRend features cannot enter default B5")
    _require(verifier.get("existence_features") == EXISTENCE_FEATURES, "existence features drift")
    _require(verifier.get("quality_features") == QUALITY_FEATURES, "quality features drift")
    _require(verifier.get("interaction_features") == INTERACTION_FEATURES, "interaction features drift")
    _require(
        verifier.get("hard_negative_mining")
        == {
            "enabled": False,
            "training_candidates": "all_legal_inner_oof",
            "patient_weighting": "equal_total_weight_per_patient",
            "detector_score_negative_reweighting": False,
            "outer_test_candidates_forbidden": True,
        },
        "preferential hard-negative mining must be fully disabled",
    )
    _require(
        verifier.get("minimum_patient_evidence")
        == {
            **PATIENT_EVIDENCE_MINIMUMS,
            "each_heldout_meta_fold_each_class_unique_patients_min": 1,
        },
        "patient-level evidence minimums drift",
    )
    _require(
        set(verifier.get("threshold_stability", {})).issuperset({"selection", "final_rule", "max_fold_threshold_range"}),
        "threshold stability contract missing",
    )
    _require(
        float(verifier["threshold_stability"]["max_fold_threshold_range"]) == 0.25,
        "threshold range cap must be 0.25",
    )
    thresholds = cfg.get("thresholds", {})
    _require(
        thresholds.get("b5_required_simple_controls") == list(SIMPLE_CONTROLS),
        "all six simple controls are mandatory",
    )
    _require(float(thresholds.get("localization_recall_at_1_fp_per_view", -1)) == 0.85, "localization CI gate drift")
    _require(float(thresholds.get("b3_mask_rcnn_dice_delta_ci_upper_no_go", 0)) == -0.05, "B3 vs Mask R-CNN CI gate drift")
    _require(float(thresholds.get("efficiency_ratio_max", -1)) == 0.80, "measured efficiency ratio gate drift")
    _require(float(thresholds.get("b5_min_absolute_negative_view_action_rate_reduction", -1)) == 0.05, "action-rate reduction gate drift")
    _require(float(thresholds.get("b5_lesion_recall_delta_ci_lower_min", 0)) == -0.02, "recall CI gate drift")
    _require(float(thresholds.get("b5_patient_macro_dice_delta_ci_lower_min", 0)) == -0.01, "Dice CI gate drift")
    _require(float(thresholds.get("b5_max_overall_referral_rate", -1)) == 0.10, "referral-rate gate drift")
    _require(float(thresholds.get("b5_min_automatic_coverage", -1)) == 0.90, "coverage gate drift")
    _require(float(cfg.get("target_lesion_sensitivity", -1)) == 0.98, "oracle/working point must use 98 percent lesion sensitivity")


def validate_protocol_config(cfg: dict[str, Any]) -> None:
    _require(str(cfg.get("protocol_version")) == PROTOCOL_VERSION, "protocol version must be 2.3")
    mode = cfg.get("mode")
    _require(mode in {"engineering_a0", "phase1", "phase2"}, "unknown execution mode")
    _require(tuple(cfg.get("state_machine", ())) == STATE_MACHINE, "state machine drift")
    if mode == "engineering_a0":
        _require(cfg.get("protocol_stage") == "ENGINEERING_A0", "engineering stage drift")
        _require(tuple(cfg.get("allowed_checks", ())) == ENGINEERING_A0_CHECKS, "engineering check boundary drift")
        _require(cfg.get("performance_based_method_selection_forbidden") is True, "engineering A0 cannot select B3/B4/B5")
        _require(cfg.get("outer_test_use_forbidden") is True, "engineering A0 cannot use outer-test")
        _require(cfg.get("paper_results_authorized") is False, "engineering A0 cannot create paper results")
        _require(cfg.get("method_effectiveness_claim_authorized") is False, "engineering A0 cannot claim effectiveness")
        _require(cfg.get("current_status") == "NOT_RUN", "engineering A0 status must remain NOT_RUN")
        return

    _validate_common_scientific_contract(cfg)
    _require(cfg.get("outer_folds") == [0, 1, 2, 3, 4], "all five outer folds are mandatory")
    if mode == "phase1":
        _require(cfg.get("protocol_stage") == "PHASE1_FIVE_FOLD_ONE_SEED", "Phase-1 stage drift")
        _require(cfg.get("seeds") == [2027], "Phase-1 must use only seed 2027")
        _require(cfg.get("required_methods") == list(PHASE1_REQUIRED_METHODS), "Phase-1 method set drift")
        _require(cfg.get("all_folds_same_frozen_code") is True, "Phase-1 code must be frozen across folds")
        _require(cfg.get("each_outer_test_patient_evaluated_once") is True, "outer-test reuse drift")
        _require(cfg.get("g3_before_all_folds_forbidden") is True, "G3 cannot run early")
        _require(cfg.get("pointrend", {}).get("enabled") is False, "PointRend is forbidden in Phase-1")
        return

    _require(cfg.get("protocol_stage") == "PHASE2_THREE_SEEDS_AND_FULL_BASELINES", "Phase-2 stage drift")
    _require(cfg.get("authorization_decision") == "GO_EXPAND_TO_PHASE2", "Phase-2 requires fresh G3 GO")
    _require(cfg.get("seeds") == [2027, 3407, 8819], "Phase-2 seed grid drift")
    _require(set(cfg.get("registered_methods", ())) == PHASE2_METHODS, "Phase-2 baseline set drift")
    _require(cfg.get("evidence_semantics") == PHASE2_EVIDENCE_SEMANTICS, "Phase-2 same-cohort sensitivity semantics drift")
    _require(cfg.get("independent_confirmation") is False, "Phase-2 is not independent confirmation")
    _require(cfg.get("external_validation") is False, "Phase-2 is not external validation")
    _require(cfg.get("phase1_selection_bias_removed") is False, "Phase-2 cannot erase Phase-1 selection bias")
    _require(cfg.get("sealed_patients_in_primary_results") is False, "sealed patients cannot enter primary results")
    _require(cfg.get("sealed_patients_support_normal_population_inference") is False, "sealed patients cannot support normal-population inference")
    point = cfg.get("pointrend", {})
    _require(point.get("enabled") == "ONLY_AFTER_G3_B3_B5_GO", "PointRend authorization drift")
    _require(point.get("implementation") == "original_pointrend", "only original PointRend is permitted")
    _require(point.get("ultrasound_specific_contribution_name_forbidden") is True, "US-PointRend name must remain forbidden")


def load_config(path: str | Path) -> dict[str, Any]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as handle:
        cfg = yaml.safe_load(handle)
    if not isinstance(cfg, dict) or cfg.get("schema_version") != 3:
        raise ValueError(f"Unsupported or malformed v2.3 configuration: {path}")
    validate_protocol_config(cfg)
    cfg["_config_path"] = str(path)
    cfg["_config_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    return cfg


def resolve_environment() -> dict[str, Path]:
    missing = [name for name in REQUIRED_ENV if not os.environ.get(name)]
    if missing:
        raise RuntimeError("Missing required environment variables: " + ", ".join(missing))
    env = {name: Path(os.environ[name]).expanduser().resolve() for name in REQUIRED_ENV}
    for name in ("SCREENBUS_ROOT", "SCREENBUS_DATA_ROOT", "SCREENBUS_CACHE_ROOT", "SCREENBUS_WEIGHT_ROOT"):
        if not env[name].exists():
            raise FileNotFoundError(f"{name} does not exist: {env[name]}")
    env["SCREENBUS_OUTPUT_ROOT"].mkdir(parents=True, exist_ok=True)
    if not env["MEDSAM_CKPT"].is_file():
        raise FileNotFoundError(f"MEDSAM_CKPT is not a file: {env['MEDSAM_CKPT']}")
    return env


def resolve_project_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (root / path).resolve()


def canonical_config(cfg: dict[str, Any]) -> str:
    filtered = {key: value for key, value in cfg.items() if not key.startswith("_")}
    return json.dumps(filtered, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
