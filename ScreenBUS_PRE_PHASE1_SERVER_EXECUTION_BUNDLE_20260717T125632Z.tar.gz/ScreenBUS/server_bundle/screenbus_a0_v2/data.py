from __future__ import annotations

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import torch
from PIL import Image
from scipy import ndimage
from torch.utils.data import Dataset
from torchvision.transforms import functional as TF

from .util import sha256_file


PROTECTED_PATIENTS = {"HESN", "ANFO", "COPE", "CRCI", "ELCO", "FLKA"}
EXPECTED = {
    "images": 607,
    "patients": 32,
    "normal": 373,
    "positive": 234,
    "components_1": 223,
    "components_2": 10,
    "components_3": 1,
}


@dataclass(frozen=True)
class ManifestRecord:
    image_id: str
    patient_id: str
    label: str
    is_positive: bool
    cv_fold: int
    image_path: Path
    mask_path: Path
    image_sha256: str
    mask_sha256: str
    width: int
    height: int
    is_clean: bool = True
    has_mark: bool = False
    has_doppler: bool = False
    has_combined: bool = False


def _resolve_data_path(data_root: Path, project_root: Path, raw: str) -> Path:
    relative = Path(raw)
    candidates = [data_root / relative, project_root / relative]
    if relative.parts and relative.parts[0] == "data":
        candidates.insert(0, data_root / Path(*relative.parts[1:]))
    existing = [candidate.resolve() for candidate in candidates if candidate.is_file()]
    unique = list(dict.fromkeys(existing))
    if len(unique) != 1:
        raise FileNotFoundError(
            f"Expected exactly one existing resolution for {raw!r}; found {len(unique)}: {unique}"
        )
    return unique[0]


def mask_binary(path: Path) -> np.ndarray:
    array = np.asarray(Image.open(path))
    if array.ndim == 3:
        array = np.any(array > 0, axis=2)
    else:
        array = array > 0
    return array.astype(np.uint8)


def connected_instances(mask: np.ndarray) -> list[np.ndarray]:
    labels, count = ndimage.label(mask.astype(bool), structure=np.ones((3, 3), dtype=np.uint8))
    return [(labels == index).astype(np.uint8) for index in range(1, count + 1)]


def instance_boxes(instances: Sequence[np.ndarray]) -> np.ndarray:
    boxes: list[list[float]] = []
    for mask in instances:
        ys, xs = np.nonzero(mask)
        if not len(xs):
            continue
        # torchvision boxes are x1,y1,x2,y2 with the upper endpoint exclusive.
        boxes.append([float(xs.min()), float(ys.min()), float(xs.max() + 1), float(ys.max() + 1)])
    return np.asarray(boxes, dtype=np.float32).reshape(-1, 4)


class FrozenManifest:
    def __init__(self, records: list[ManifestRecord], manifest_path: Path, manifest_sha256: str):
        self.records = records
        self.manifest_path = manifest_path
        self.manifest_sha256 = manifest_sha256

    @classmethod
    def load(
        cls,
        manifest_path: Path,
        data_root: Path,
        project_root: Path,
        strict_hash_audit: bool = True,
        pixel_excluded_folds: set[int] | None = None,
        mask_access_excluded_folds: set[int] | None = None,
    ) -> "FrozenManifest":
        pixel_excluded_folds = pixel_excluded_folds or set()
        # Efficiency workers may consume the evaluation images while remaining
        # strictly prediction-only.  In that mode even hashing or opening a mask
        # file would make ``ground_truth_pixels_read=False`` untrue, so mask
        # access has its own fail-closed exclusion set instead of overloading the
        # outer-test image exclusion policy.
        mask_access_excluded_folds = mask_access_excluded_folds or set()
        mask_pixel_excluded_folds = pixel_excluded_folds | mask_access_excluded_folds
        rows = list(csv.DictReader(manifest_path.open("r", encoding="utf-8", newline="")))
        records: list[ManifestRecord] = []
        seen_ids: set[str] = set()
        for row in rows:
            image_id = row["image_id"]
            patient_id = row["case_id"]
            if image_id in seen_ids:
                raise RuntimeError(f"Duplicate image_id in frozen manifest: {image_id}")
            if patient_id in PROTECTED_PATIENTS:
                raise RuntimeError(f"Protected patient is present in development manifest: {patient_id}")
            image_path = _resolve_data_path(data_root, project_root, row["image"])
            mask_path = _resolve_data_path(data_root, project_root, row["mask"])
            cv_fold = int(row["cv_fold"])
            if strict_hash_audit and cv_fold not in pixel_excluded_folds:
                actual_image_hash = sha256_file(image_path)
                if actual_image_hash != row["image_sha256"]:
                    raise RuntimeError(f"DATA_GATE_FAIL image hash mismatch for {image_id}")
            if strict_hash_audit and cv_fold not in mask_pixel_excluded_folds:
                actual_mask_hash = sha256_file(mask_path)
                if actual_mask_hash != row["mask_sha256"]:
                    raise RuntimeError(f"DATA_GATE_FAIL mask hash mismatch for {image_id}")
            expected_size = (int(row["image_width"]), int(row["image_height"]))
            if cv_fold not in pixel_excluded_folds:
                with Image.open(image_path) as image:
                    image_size = image.size
                if image_size != expected_size:
                    raise RuntimeError(f"DATA_GATE_FAIL image geometry mismatch for {image_id}")
            if cv_fold not in mask_pixel_excluded_folds:
                with Image.open(mask_path) as mask:
                    mask_size = mask.size
                if mask_size != expected_size:
                    raise RuntimeError(f"DATA_GATE_FAIL mask geometry mismatch for {image_id}")
            records.append(
                ManifestRecord(
                    image_id=image_id,
                    patient_id=patient_id,
                    label=row["label"],
                    is_positive=bool(int(row["is_positive"])),
                    cv_fold=cv_fold,
                    image_path=image_path,
                    mask_path=mask_path,
                    image_sha256=row["image_sha256"],
                    mask_sha256=row["mask_sha256"],
                    width=expected_size[0],
                    height=expected_size[1],
                    is_clean=bool(int(row.get("is_clean_metadata", "1"))),
                    has_mark=bool(int(row.get("has_mark", "0"))),
                    has_doppler=bool(int(row.get("has_doppler", "0"))),
                    has_combined=bool(int(row.get("has_combined", "0"))),
                )
            )
            seen_ids.add(image_id)
        frozen = cls(records, manifest_path, sha256_file(manifest_path))
        frozen.audit_expected_counts(mask_pixel_excluded_folds)
        return frozen

    def audit_expected_counts(self, pixel_excluded_folds: set[int] | None = None) -> None:
        pixel_excluded_folds = pixel_excluded_folds or set()
        counts = {
            "images": len(self.records),
            "patients": len({record.patient_id for record in self.records}),
            "normal": sum(not record.is_positive for record in self.records),
            "positive": sum(record.is_positive for record in self.records),
            "components_1": 0,
            "components_2": 0,
            "components_3": 0,
        }
        for record in self.records:
            if record.cv_fold in pixel_excluded_folds:
                continue
            mask = mask_binary(record.mask_path)
            components = len(connected_instances(mask))
            if record.is_positive != bool(components):
                raise RuntimeError(f"DATA_GATE_FAIL empty-mask semantics mismatch for {record.image_id}")
            if components:
                key = f"components_{components}"
                if key not in counts:
                    raise RuntimeError(f"DATA_GATE_FAIL unexpected {components} components for {record.image_id}")
                counts[key] += 1
        for key in ("images", "patients", "normal", "positive"):
            if counts[key] != EXPECTED[key]:
                raise RuntimeError(f"DATA_GATE_FAIL expected {EXPECTED}, observed {counts}")
        if not pixel_excluded_folds:
            for key in ("components_1", "components_2", "components_3"):
                if counts[key] != EXPECTED[key]:
                    raise RuntimeError(f"DATA_GATE_FAIL expected {EXPECTED}, observed {counts}")

    def outer_split(self, fold: int) -> tuple[list[ManifestRecord], list[ManifestRecord]]:
        if fold not in range(5):
            raise ValueError(f"Outer fold must be 0..4, got {fold}")
        train = [record for record in self.records if record.cv_fold != fold]
        test = [record for record in self.records if record.cv_fold == fold]
        assert_patient_disjoint(train, test, context=f"outer_fold_{fold}")
        return train, test

    def clean_outer_split(self, fold: int) -> tuple[list[ManifestRecord], list[ManifestRecord]]:
        """Return the PDF-frozen clean primary cohort for one patient outer fold."""
        train, test = self.outer_split(fold)
        clean_train = [record for record in train if record.is_clean]
        clean_test = [record for record in test if record.is_clean]
        assert_patient_disjoint(clean_train, clean_test, context=f"clean_outer_fold_{fold}")
        return clean_train, clean_test


def patient_statistics(records: Sequence[ManifestRecord]) -> dict[str, dict[str, int]]:
    result: dict[str, dict[str, int]] = {}
    for record in records:
        stats = result.setdefault(record.patient_id, {"images": 0, "positive_images": 0, "normal_images": 0, "lesions": 0})
        stats["images"] += 1
        if record.is_positive:
            stats["positive_images"] += 1
            stats["lesions"] += len(connected_instances(mask_binary(record.mask_path)))
        else:
            stats["normal_images"] += 1
    return result


def _stable_key(patient_id: str, seed: int) -> str:
    return hashlib.sha256(f"{seed}:{patient_id}".encode()).hexdigest()


def assign_inner_folds(records: Sequence[ManifestRecord], folds: int, seed: int) -> dict[str, int]:
    stats = patient_statistics(records)
    if len(stats) < folds:
        raise InsufficientEvents(f"Need at least {folds} patients for inner cross-fitting")
    loads = [{"lesions": 0, "normals": 0, "images": 0, "patients": 0} for _ in range(folds)]
    assignment: dict[str, int] = {}
    ordered = sorted(
        stats,
        key=lambda p: (-(stats[p]["lesions"] + stats[p]["normal_images"]), _stable_key(p, seed)),
    )
    for patient in ordered:
        fold = min(
            range(folds),
            key=lambda index: (
                loads[index]["patients"],
                loads[index]["lesions"],
                loads[index]["normals"],
                loads[index]["images"],
                index,
            ),
        )
        assignment[patient] = fold
        loads[fold]["lesions"] += stats[patient]["lesions"]
        loads[fold]["normals"] += stats[patient]["normal_images"]
        loads[fold]["images"] += stats[patient]["images"]
        loads[fold]["patients"] += 1
    if set(assignment) != set(stats):
        raise RuntimeError("Inner fold assignment is incomplete")
    return assignment


def assert_patient_disjoint(
    first: Sequence[ManifestRecord], second: Sequence[ManifestRecord], context: str
) -> None:
    overlap = {record.patient_id for record in first} & {record.patient_id for record in second}
    if overlap:
        raise RuntimeError(f"PATIENT_LEAKAGE in {context}: {sorted(overlap)}")


class InsufficientEvents(RuntimeError):
    pass


class BUSDataset(Dataset):
    def __init__(
        self,
        records: Sequence[ManifestRecord],
        task: str,
        image_size: int | None = None,
        augment: bool = False,
        seed: int = 2027,
    ):
        if task not in {"semantic", "detection", "raw"}:
            raise ValueError(task)
        self.records = list(records)
        self.task = task
        self.image_size = image_size
        self.augment = augment
        self.seed = seed
        self.epoch = 0

    def __len__(self) -> int:
        return len(self.records)

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch

    def __getitem__(self, index: int):
        record = self.records[index]
        image = Image.open(record.image_path).convert("RGB")
        mask_array = mask_binary(record.mask_path)
        mask = Image.fromarray(mask_array * 255)
        generator = torch.Generator().manual_seed(self.seed + self.epoch * len(self) + index)
        flip = self.augment and bool(torch.rand((), generator=generator) < 0.5)
        if flip:
            image = TF.hflip(image)
            mask = TF.hflip(mask)
        if self.image_size is not None:
            image = TF.resize(image, [self.image_size, self.image_size], antialias=True)
            mask = TF.resize(mask, [self.image_size, self.image_size], interpolation=TF.InterpolationMode.NEAREST)
        image_tensor = TF.to_tensor(image)
        mask_tensor = (TF.pil_to_tensor(mask)[0] > 0).to(torch.uint8)
        if self.task == "semantic":
            return {
                "image": image_tensor,
                "mask": mask_tensor.float().unsqueeze(0),
                "presence": torch.tensor(float(record.is_positive)),
                "image_id": record.image_id,
                "patient_id": record.patient_id,
            }
        instances = connected_instances(mask_tensor.numpy())
        boxes = torch.from_numpy(instance_boxes(instances))
        instance_tensor = (
            torch.from_numpy(np.stack(instances)).to(torch.uint8)
            if instances
            else torch.zeros((0, mask_tensor.shape[0], mask_tensor.shape[1]), dtype=torch.uint8)
        )
        target = {
            "boxes": boxes,
            "labels": torch.ones((len(boxes),), dtype=torch.int64),
            "masks": instance_tensor,
            "image_id": torch.tensor([index]),
            "area": ((boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])).float(),
            "iscrowd": torch.zeros((len(boxes),), dtype=torch.int64),
        }
        if self.task == "detection":
            return image_tensor, target, record
        return image_tensor, target, record, mask_tensor


def detection_collate(batch):
    images, targets, records = zip(*batch)
    return list(images), list(targets), list(records)
