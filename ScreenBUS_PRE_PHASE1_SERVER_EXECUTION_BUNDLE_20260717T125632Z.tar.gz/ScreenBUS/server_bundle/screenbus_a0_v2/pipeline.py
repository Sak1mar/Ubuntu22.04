from __future__ import annotations

import json
import os
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Sequence

import numpy as np
from PIL import Image

from .candidates import load_candidate_mask, load_candidate_rows
from .config import load_config, resolve_environment, resolve_project_path
from .data import (
    FrozenManifest,
    assign_inner_folds,
    assert_patient_disjoint,
)
from .metrics import (
    aurc,
    evaluate_candidate_method,
    verifier_component_metrics,
)
from .protocol_v2_3 import SIMPLE_CONTROLS as FROZEN_SIMPLE_CONTROLS
from .util import atomic_json, sha256_file


GO_DECISIONS = {"GO_EXPAND_TO_PHASE2"}
SIMPLE_CONTROLS = list(FROZEN_SIMPLE_CONTROLS)


def _jittered_gt_drop_within_limit(predicted_dice: float, jittered_gt_dice: float, limit: float) -> bool:
    """Return whether jittered-GT minus predicted-box degradation is allowed."""
    return (jittered_gt_dice - predicted_dice) <= limit


def _choose_g3_decision(
    automatic_prompt_pass: bool,
    _pointrend_pass_ignored_in_v2_2: bool,
    _b4_verifier_ignored_in_v2_2: bool,
    b3_verifier_pass: bool,
) -> str:
    if not automatic_prompt_pass:
        return "NO_GO_AUTOMATIC_PROMPT"
    if not b3_verifier_pass:
        return "NO_GO_VERIFIER"
    return "GO_EXPAND_TO_PHASE2"


def _gate_passed(path: Path, accepted_decisions: set[str] | None = None) -> dict[str, Any]:
    if not path.is_file():
        raise RuntimeError(f"Required gate is absent: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if accepted_decisions is not None:
        if payload.get("decision") not in accepted_decisions:
            raise RuntimeError(f"Gate {path} decision is {payload.get('decision')}, expected one of {accepted_decisions}")
    elif payload.get("status") != "PASS" and payload.get("decision") not in {
        "PASS",
        "SERVER_READY",
        "G2_SERVER_READY",
        "OFFICIAL_DATA_GATE_PASS",
    }:
        raise RuntimeError(f"Gate has not passed: {path}: {payload.get('decision') or payload.get('status')}")
    return payload


def _worker_command(config_path: Path, split_path: Path, run_dir: Path, operation: str, fold=None) -> list[str]:
    command = [
        sys.executable,
        "-m",
        "screenbus_a0_v2.cli",
        "worker",
        "--config",
        str(config_path),
        "--split",
        str(split_path),
        "--run-dir",
        str(run_dir),
        "--operation",
        operation,
    ]
    if fold is not None:
        command += ["--inner-fold", str(fold)]
    return command


def _checkpoint_valid(path: Path) -> bool:
    metadata_path = path.with_suffix(".json")
    if not path.is_file() or not metadata_path.is_file():
        return False
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        return metadata.get("checkpoint_sha256") == sha256_file(path)
    except (json.JSONDecodeError, OSError):
        return False


def _candidate_valid(
    path: Path,
    expected_checkpoint_sha256: str | None = None,
    expected_medsam_checkpoint_sha256: str | None = None,
    expected_autobusam_adapter_sha256: str | None = None,
) -> bool:
    metadata_path = path.parent / "metadata.json"
    if not path.is_file() or not metadata_path.is_file():
        return False
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata.get("candidate_jsonl_sha256") != sha256_file(path):
            return False
        rows = load_candidate_rows(path)
        checked_masks: dict[str, str] = {}
        for row in rows:
            mask_path = Path(row["mask_file"])
            if not mask_path.is_file():
                return False
            expected_mask_hash = row.get("mask_file_sha256")
            if str(mask_path) not in checked_masks:
                checked_masks[str(mask_path)] = sha256_file(mask_path)
            if expected_mask_hash != checked_masks[str(mask_path)]:
                return False
            if expected_checkpoint_sha256 is not None:
                observed = row.get("checkpoint_sha256") or row.get("upstream_checkpoint_sha256")
                if observed != expected_checkpoint_sha256:
                    return False
            if (
                expected_medsam_checkpoint_sha256 is not None
                and row.get("medsam_decoder_checkpoint_sha256")
                != expected_medsam_checkpoint_sha256
            ):
                return False
            if (
                expected_autobusam_adapter_sha256 is not None
                and row.get("autobusam_sam_lora_checkpoint_sha256")
                != expected_autobusam_adapter_sha256
            ):
                return False
        return True
    except (json.JSONDecodeError, OSError):
        return False


def _merge_oof(run_dir: Path, split: dict[str, Any], folds: int) -> Path:
    merged: list[dict[str, Any]] = []
    observed_images: set[str] = set()
    provenance_rows: list[dict[str, Any]] = []
    assignment = {patient: int(fold) for patient, fold in split["inner_assignment"].items()}
    for fold in range(folds):
        path = run_dir / "candidates" / f"inner_{fold}" / "candidates.jsonl"
        rows = load_candidate_rows(path)
        if not rows:
            raise RuntimeError(f"OOF fold {fold} generated no image records")
        for row in rows:
            if row["condition"] != "predicted_box":
                raise RuntimeError("OOF candidate set contains a non-predicted-box condition")
            if assignment[row["patient_id"]] != fold:
                raise RuntimeError(f"OOF provenance fold mismatch for {row['image_id']}")
            if row["patient_id"] in set(row["training_patient_ids"]):
                raise RuntimeError(f"PATIENT_LEAKAGE in OOF candidate {row['image_id']}")
            observed_images.add(row["image_id"])
            merged.append(row)
        provenance_rows.append(
            {
                "inner_fold": fold,
                "candidate_jsonl": str(path),
                "candidate_jsonl_sha256": sha256_file(path),
                "heldout_patient_ids": sorted({row["patient_id"] for row in rows}),
                "training_patient_ids": sorted(set(rows[0]["training_patient_ids"])),
            }
        )
    if observed_images != set(split["train_image_ids"]):
        missing = set(split["train_image_ids"]) - observed_images
        extra = observed_images - set(split["train_image_ids"])
        raise RuntimeError(f"OOF coverage mismatch; missing={sorted(missing)}, extra={sorted(extra)}")
    output = run_dir / "candidates" / "oof_merged.jsonl"
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(f".{os.getpid()}.partial")
    with temporary.open("w", encoding="utf-8") as handle:
        for row in merged:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
    os.replace(temporary, output)
    atomic_json(
        run_dir / "provenance" / "oof_provenance.json",
        {
            "schema_version": 1,
            "status": "PASS_NO_PATIENT_LEAKAGE",
            "candidate_count_including_empty_sentinels": len(merged),
            "image_count": len(observed_images),
            "patient_count": len(assignment),
            "folds": provenance_rows,
            "merged_sha256": sha256_file(output),
        },
    )
    return output


def _flatten_result(
    method: str,
    condition: str,
    metrics: dict[str, float],
    intervals: dict[str, tuple[float, float]],
    threshold: float,
    threshold_source: str,
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "method": method,
        "box_condition": condition,
        "acceptance_threshold": threshold,
        "threshold_source": threshold_source,
    }
    row.update(metrics)
    for name, interval in intervals.items():
        row[f"{name}_ci_low"] = interval[0]
        row[f"{name}_ci_high"] = interval[1]
    return row


def _evaluate_rows(
    method: str,
    condition: str,
    rows: Sequence[dict[str, Any]],
    scores: Sequence[float],
    threshold: float,
    cfg: dict,
    seed: int,
    threshold_source: str,
    quality_scores: Sequence[float] | None = None,
    quality_threshold: float | None = None,
    failure_ranking_scores: Sequence[float] | None = None,
) -> dict[str, Any]:
    metrics, intervals = evaluate_candidate_method(
        rows,
        scores,
        threshold,
        cfg["bootstrap_replicates"],
        seed,
        quality_scores=quality_scores,
        quality_threshold=quality_threshold,
        failure_ranking_scores=failure_ranking_scores,
    )
    row = _flatten_result(method, condition, metrics, intervals, threshold, threshold_source)
    if quality_scores is not None:
        row.update(verifier_component_metrics(rows, scores, quality_scores))
        row["existence_threshold"] = threshold
        row["quality_threshold"] = quality_threshold
        row["decision_states"] = (
            "empty_if_no_existence;refer_if_exists_but_quality_low;accept_if_both_pass"
        )
        row["normal_fp_metric_component"] = "calibrated_existence_score"
        row["failure_probability_definition"] = (
            "1_minus_joint_existence_times_conditional_quality_score"
        )
    else:
        row["failure_probability_definition"] = "1_minus_scalar_control_score"
    row["calibration_status"] = (
        "patient_disjoint_separate_existence_platt_and_conditional_quality_affine"
        if method.startswith("B5_OOF_Verifier")
        else "uncalibrated_preregistered_score"
    )
    return row


def _save_failure_cases(
    rows: Sequence[dict[str, Any]],
    existence_scores: Sequence[float],
    quality_scores: Sequence[float],
    output_dir: Path,
    limit: int,
    existence_threshold: float,
    quality_threshold: float,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    by_image: dict[str, list[tuple[dict[str, Any], float, float]]] = defaultdict(list)
    for row, existence, quality in zip(rows, existence_scores, quality_scores):
        by_image[row["image_id"]].append((row, float(existence), float(quality)))
    failures: list[tuple[int, dict[str, Any], float, float, str, str]] = []
    for image_rows in by_image.values():
        first = image_rows[0][0]
        real = [item for item in image_rows if not item[0].get("is_sentinel")]
        if not real and int(first["gt_lesion_count"]) > 0:
            failures.append((0, first, -1e9, -1e9, "empty", "POSITIVE_ZERO_CANDIDATE_FULL_COVERAGE_FAILURE"))
            continue
        existence_positive = [item for item in real if item[1] >= existence_threshold]
        if real and int(first["gt_lesion_count"]) > 0 and not existence_positive:
            row, existence, quality = max(real, key=lambda item: item[1])
            failures.append((0, row, existence, quality, "empty", "POSITIVE_NO_EXISTENCE_CANDIDATE_FAILURE"))
        elif int(first["gt_lesion_count"]) > 0 and not any(
            quality >= quality_threshold for _row, _existence, quality in existence_positive
        ):
            row, existence, quality = max(existence_positive, key=lambda item: item[2])
            failures.append((1, row, existence, quality, "refer", "POSITIVE_REFER_CONSERVATIVELY_COUNTED_AS_FAILURE"))
        for row, existence, quality in real:
            if row["failure"]:
                state = (
                    "empty"
                    if existence < existence_threshold
                    else "refer" if quality < quality_threshold else "accept"
                )
                failures.append((2, row, existence, quality, state, "CANDIDATE_FAILURE"))
    failures.sort(key=lambda item: (item[0], item[1].get("mask_dice", 0.0), item[2]))
    for rank, (_priority, row, existence, quality, state, failure_type) in enumerate(failures[:limit]):
        image = np.asarray(Image.open(row["image_file"]).convert("RGB")).copy()
        if row.get("is_sentinel"):
            overlay = image
        else:
            prediction = load_candidate_mask(row).astype(bool)
            red = np.zeros_like(image)
            red[..., 0] = 255
            overlay = np.where(prediction[..., None], (0.55 * image + 0.45 * red).astype(np.uint8), image)
        stem = f"{rank:03d}_{row['image_id']}_candidate{row['candidate_index']}"
        Image.fromarray(overlay).save(output_dir / f"{stem}.png")
        atomic_json(
            output_dir / f"{stem}.json",
            {
                "rank": rank,
                "image_id": row["image_id"],
                "patient_id": row["patient_id"],
                "candidate_index": row["candidate_index"],
                "verifier_existence_score": existence,
                "verifier_quality_score": quality,
                "verifier_joint_score": existence * quality,
                "decision_state": state,
                "existence_threshold": existence_threshold,
                "quality_threshold": quality_threshold,
                "candidate_valid": row["candidate_valid"],
                "mask_dice": row["mask_dice"],
                "failure": row["failure"],
                "failure_type": failure_type,
                "full_coverage_denominator_retained": True,
                "refer_is_not_normal": True,
                "checkpoint_sha256": row.get("checkpoint_sha256"),
                "refiner_checkpoint_sha256": row.get("refiner_checkpoint_sha256"),
                "annotation": "ACTUAL_HELDOUT_PREDICTION_FAILURE_CASE",
            },
        )


def _write_g3(root: Path, payload: dict[str, Any], markdown: str) -> None:
    atomic_json(root / "gates" / "G3_A0_DECISION.json", payload)
    path = root / "gates" / "G3_A0_DECISION.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(markdown.rstrip() + "\n", encoding="utf-8")


def _freeze_run_spec(run_dir: Path, spec: dict[str, Any]) -> None:
    path = run_dir / "RUN_SPEC.json"
    if path.exists():
        observed = json.loads(path.read_text(encoding="utf-8"))
        if observed != spec:
            raise RuntimeError(
                "Refusing to mix resumed artifacts: current config/manifest/split/code fingerprint differs from RUN_SPEC.json"
            )
    else:
        atomic_json(path, spec)


def build_phase1_split(config_path: Path, outer_fold: int) -> dict[str, Any]:
    """Build one legal nested-OOF split; this function does not start training."""

    cfg = load_config(config_path)
    if cfg["mode"] != "phase1" or outer_fold not in cfg["outer_folds"]:
        raise ValueError("PHASE1_SPLIT_SCOPE_INVALID")
    env = resolve_environment()
    root = env["SCREENBUS_ROOT"]
    manifest = FrozenManifest.load(
        resolve_project_path(root, cfg["manifest"]),
        env["SCREENBUS_DATA_ROOT"],
        root,
        cfg["strict_hash_audit"],
        pixel_excluded_folds=set(),
    )
    outer_train_all, outer_test_all = manifest.outer_split(outer_fold)
    train_records = [record for record in outer_train_all if record.is_clean]
    evaluation_records = [record for record in outer_test_all if record.is_clean]
    assert_patient_disjoint(train_records, evaluation_records, f"phase1_outer_fold_{outer_fold}")
    assignment = assign_inner_folds(train_records, int(cfg["inner_folds"]), 2027)
    return {
        "schema_version": 2,
        "protocol_version": "2.3",
        "mode": "phase1",
        "seed": 2027,
        "outer_fold": outer_fold,
        "train_image_ids": [record.image_id for record in train_records],
        "evaluation_image_ids": [record.image_id for record in evaluation_records],
        "train_patient_ids": sorted({record.patient_id for record in train_records}),
        "evaluation_patient_ids": sorted({record.patient_id for record in evaluation_records}),
        "inner_assignment": assignment,
        "selection_scope": "OUTER_TRAIN_INNER_META_ONLY",
        "outer_test_route_or_threshold_selection_forbidden": True,
        "outer_test_evaluation_count_per_patient": 1,
        "pointrend_forbidden": True,
        "config_sha256": cfg["_config_sha256"],
        "manifest_sha256": manifest.manifest_sha256,
    }


def run_phase1(config_path: Path) -> dict[str, Any]:
    """Run the five-fold Phase-1 executor through its dedicated implementation."""

    from .phase1_runner import run_phase1 as execute_phase1

    return execute_phase1(config_path)
