"""Fail-closed v2.3 G3 validation and independent decision recomputation."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .config import load_config
from .protocol_v2_3 import decide_g3_method_gate


GO_DECISIONS = frozenset({"GO_EXPAND_TO_PHASE2"})
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class G3ValidationError(RuntimeError):
    def __init__(self, code: str, detail: str):
        self.code = code
        self.detail = detail
        super().__init__(f"{code}: {detail}")


@dataclass(frozen=True)
class ValidatedG3:
    decision: str
    seed: int
    outer_folds: tuple[int, ...]
    phase1_config_path: Path
    manifest_path: Path
    phase1_report_path: Path
    config_sha256: str
    manifest_sha256: str
    phase1_report_sha256: str
    code_tree_sha256: str


def _fail(code: str, detail: str) -> None:
    raise G3ValidationError(code, detail)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError as exc:
        _fail("G3_CONTEXT_FILE_UNREADABLE", f"{path}: {exc}")
    return digest.hexdigest()


def compute_screenbus_a0_v2_code_tree_sha256(root: str | Path) -> str:
    code_root = Path(root).expanduser().resolve() / "server_bundle" / "screenbus_a0_v2"
    paths = [
        path
        for path in code_root.rglob("*")
        if path.is_file() and not path.is_symlink() and path.suffix in {".py", ".yaml", ".yml"}
    ]
    if not paths:
        _fail("G3_CODE_TREE_EMPTY", str(code_root))
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: str(item)):
        digest.update(str(path).encode())
        digest.update(_sha256_file(path).encode())
    return digest.hexdigest()


def _require_sha(provenance: Mapping[str, Any], key: str) -> str:
    value = provenance.get(key)
    if not isinstance(value, str) or _SHA256_RE.fullmatch(value) is None:
        _fail("G3_PROVENANCE_INVALID", f"{key} must be a lowercase SHA-256")
    return value


def validate_g3_go_payload(
    payload: Mapping[str, Any],
    *,
    root: str | Path,
    phase1_config_path: str | Path | None = None,
) -> ValidatedG3:
    """Validate a GO only after independently recomputing the five-fold gate."""

    if not isinstance(payload, Mapping):
        _fail("G3_PAYLOAD_INVALID", "root must be an object")
    project_root = Path(root).expanduser().resolve()
    config_path = (
        Path(phase1_config_path).expanduser().resolve()
        if phase1_config_path is not None
        else project_root / "server_bundle" / "screenbus_a0_v2" / "configs" / "server_a0.yaml"
    )
    canonical_config = project_root / "server_bundle" / "screenbus_a0_v2" / "configs" / "server_a0.yaml"
    if config_path != canonical_config.resolve():
        _fail("G3_PHASE1_CONFIG_INVALID", "only the canonical Phase-1 config is allowed")
    try:
        cfg = load_config(config_path)
    except Exception as exc:
        _fail("G3_PHASE1_CONFIG_INVALID", str(exc))
    if cfg.get("mode") != "phase1":
        _fail("G3_PHASE1_CONFIG_INVALID", "server_a0.yaml must be mode=phase1")
    if payload.get("schema_version") != 3 or payload.get("protocol_version") != "2.3":
        _fail("G3_SCHEMA_INVALID", "schema/protocol must be 3/v2.3")
    if payload.get("gate") != "G3_METHOD_GATE":
        _fail("G3_SCHEMA_INVALID", "gate must be G3_METHOD_GATE")
    decision = payload.get("decision")
    if decision not in GO_DECISIONS:
        _fail("G3_GO_DECISION_INVALID", f"decision={decision!r}")
    if payload.get("phase2_authorized") is not True:
        _fail("G3_AUTHORIZATION_INVALID", "GO must set phase2_authorized=true")
    if payload.get("point_rend_phase1") != "FORBIDDEN_NOT_RUN":
        _fail("G3_PHASE1_POINTREND_INVALID", "PointRend must not have run in Phase-1")
    report = payload.get("phase1_report")
    if not isinstance(report, Mapping):
        _fail("G3_PHASE1_REPORT_INVALID", "phase1_report must be embedded for recomputation")
    try:
        recomputed = decide_g3_method_gate(report, cfg["thresholds"])
    except (KeyError, TypeError, ValueError) as exc:
        _fail("G3_RECOMPUTATION_FAILED", str(exc))
    if recomputed != decision:
        _fail("G3_DECISION_MISMATCH", f"stored={decision}, recomputed={recomputed}")

    provenance = payload.get("provenance")
    if not isinstance(provenance, Mapping):
        _fail("G3_PROVENANCE_INVALID", "provenance must be an object")
    if provenance.get("inner_meta_only_selection") is not True:
        _fail("G3_PROVENANCE_INVALID", "inner/meta-only selection proof missing")
    if provenance.get("outer_test_interim_selection") is not False:
        _fail("G3_PROVENANCE_INVALID", "outer-test interim selection must be false")
    config_sha = _require_sha(provenance, "config_sha256")
    manifest_sha = _require_sha(provenance, "manifest_sha256")
    report_sha = _require_sha(provenance, "phase1_report_sha256")
    code_sha = _require_sha(provenance, "code_tree_sha256")
    manifest_path = project_root / cfg["manifest"]
    raw_report_path = provenance.get("phase1_report_path")
    if not isinstance(raw_report_path, str) or not raw_report_path:
        _fail("G3_PROVENANCE_INVALID", "phase1_report_path missing")
    report_path = Path(raw_report_path)
    report_path = report_path.resolve() if report_path.is_absolute() else (project_root / report_path).resolve()
    try:
        manifest_path.resolve().relative_to(project_root)
        report_path.relative_to(project_root)
    except ValueError as exc:
        _fail("G3_PROVENANCE_INVALID", f"Phase-1 inputs must remain under project root: {exc}")
    observed = {
        "config_sha256": _sha256_file(config_path),
        "manifest_sha256": _sha256_file(manifest_path),
        "phase1_report_sha256": _sha256_file(report_path),
        "code_tree_sha256": compute_screenbus_a0_v2_code_tree_sha256(project_root),
    }
    expected = {
        "config_sha256": config_sha,
        "manifest_sha256": manifest_sha,
        "phase1_report_sha256": report_sha,
        "code_tree_sha256": code_sha,
    }
    if observed != expected:
        _fail("G3_CONTEXT_DRIFT", f"expected={expected}, observed={observed}")
    return ValidatedG3(
        decision=str(decision),
        seed=2027,
        outer_folds=(0, 1, 2, 3, 4),
        phase1_config_path=config_path,
        manifest_path=manifest_path,
        phase1_report_path=report_path,
        config_sha256=config_sha,
        manifest_sha256=manifest_sha,
        phase1_report_sha256=report_sha,
        code_tree_sha256=code_sha,
    )


__all__ = [
    "G3ValidationError",
    "GO_DECISIONS",
    "ValidatedG3",
    "compute_screenbus_a0_v2_code_tree_sha256",
    "validate_g3_go_payload",
]
