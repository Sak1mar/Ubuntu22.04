from __future__ import annotations

import argparse
import inspect
import importlib
import json
import os
import random
from pathlib import Path

import numpy as np
import torch


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-id", required=True)
    parser.add_argument("--configuration", required=True)
    parser.add_argument("--fold", default="all")
    parser.add_argument("--trainer", required=True)
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--checkpoint-save-every", required=True, type=int)
    parser.add_argument("--training-spec", required=True)
    parser.add_argument("--continue-training", action="store_true")
    args = parser.parse_args(argv)
    os.environ["PYTHONHASHSEED"] = str(args.seed)
    os.environ["SCREENBUS_SEED"] = str(args.seed)
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    def seed_all() -> None:
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)

    seed_all()
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    run_training_module = importlib.import_module("nnunetv2.run.run_training")
    from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer
    from .nnunet_baseline import (
        NNUNET_PLANS_IDENTIFIER,
        NNUNET_SEED_INJECTION,
        validate_nnunet_preprocess_completion,
    )
    from .nnunet_trainers import register_checkpoint_cadence
    from .util import atomic_json, sha256_file, utc_now

    training_spec_path = Path(args.training_spec)
    canonical_spec_path = (
        Path(os.environ["nnUNet_preprocessed"]).resolve().parent
        / "TRAIN_RUN_SPEC.json"
    )
    if (
        training_spec_path.is_symlink()
        or not training_spec_path.is_file()
        or training_spec_path.resolve() != canonical_spec_path
    ):
        raise RuntimeError("NNUNET_LAUNCHER_NONCANONICAL_TRAINING_SPEC")
    training_spec = json.loads(training_spec_path.read_text(encoding="utf-8"))
    expected_spec_context = {
        "dataset_id": int(args.dataset_id),
        "configuration": args.configuration,
        "fold": str(args.fold),
        "trainer": args.trainer,
        "seed": int(args.seed),
        "checkpoint_save_every_epochs": int(args.checkpoint_save_every),
    }
    spec_drift = {
        key: {"expected": value, "observed": training_spec.get(key)}
        for key, value in expected_spec_context.items()
        if training_spec.get(key) != value
    }
    if spec_drift:
        raise RuntimeError(f"NNUNET_LAUNCHER_TRAINING_SPEC_DRIFT: {spec_drift}")
    dataset_name = training_spec.get("dataset_name")
    if not isinstance(dataset_name, str) or not dataset_name:
        raise RuntimeError("NNUNET_LAUNCHER_DATASET_NAME_MISSING")
    preprocess_binding = validate_nnunet_preprocess_completion(
        canonical_spec_path.parent,
        dataset_id=int(args.dataset_id),
        dataset_name=dataset_name,
        configuration=args.configuration,
    )
    expected_preprocess_binding = {
        "preprocess_marker_path": preprocess_binding["marker_path"],
        "preprocess_marker_sha256": preprocess_binding["marker_sha256"],
        "preprocessed_tree_sha256": preprocess_binding["tree_sha256"],
    }
    preprocess_drift = {
        key: {"expected": value, "observed": training_spec.get(key)}
        for key, value in expected_preprocess_binding.items()
        if training_spec.get(key) != value
    }
    if preprocess_drift:
        raise RuntimeError(
            f"NNUNET_LAUNCHER_PREPROCESS_BINDING_DRIFT: {preprocess_drift}"
        )
    plans_path = (
        Path(os.environ["nnUNet_preprocessed"])
        / dataset_name
        / f"{NNUNET_PLANS_IDENTIFIER}.json"
    )
    dataset_json_path = Path(os.environ["nnUNet_raw"]) / dataset_name / "dataset.json"
    for current_path, hash_key in (
        (plans_path, "plans_sha256"),
        (dataset_json_path, "dataset_json_sha256"),
    ):
        if (
            current_path.is_symlink()
            or not current_path.is_file()
            or training_spec.get(hash_key) != sha256_file(current_path)
        ):
            raise RuntimeError(f"NNUNET_LAUNCHER_INPUT_HASH_DRIFT: {hash_key}")
    training_spec_sha256 = sha256_file(training_spec_path)

    original_find_trainer = run_training_module.recursive_find_trainer_class_by_name
    resolved_trainer = original_find_trainer(args.trainer)
    registered_trainer = register_checkpoint_cadence(
        resolved_trainer,
        args.checkpoint_save_every,
    )
    original_save_checkpoint = registered_trainer.save_checkpoint

    def save_checkpoint_with_resume_binding(self, filename: str) -> None:
        original_save_checkpoint(self, filename)
        checkpoint = Path(filename)
        if checkpoint.name != "checkpoint_latest.pth" or not checkpoint.is_file():
            return
        atomic_json(
            checkpoint.with_suffix(".screenbus_resume.json"),
            {
                "schema_version": 1,
                "status": "BOUND_FOR_RESUME",
                "checkpoint_filename": checkpoint.name,
                "checkpoint_sha256": sha256_file(checkpoint),
                "training_spec_sha256": training_spec_sha256,
                "effective_seed": int(args.seed),
                "configuration": args.configuration,
                "fold": str(args.fold),
                "trainer": args.trainer,
                "dataset_id": int(args.dataset_id),
                "dataset_name": dataset_name,
                "plans_identifier": NNUNET_PLANS_IDENTIFIER,
                "plans_sha256": training_spec["plans_sha256"],
                "dataset_json_sha256": training_spec["dataset_json_sha256"],
                "preprocess_marker_sha256": training_spec[
                    "preprocess_marker_sha256"
                ],
                "preprocessed_tree_sha256": training_spec[
                    "preprocessed_tree_sha256"
                ],
                "config_sha256": training_spec["config_sha256"],
                "checkpoint_save_every_epochs": int(args.checkpoint_save_every),
                "seed_injection": NNUNET_SEED_INJECTION,
                "deterministic_algorithms": True,
                "created_at": utc_now(),
            },
        )

    registered_trainer.save_checkpoint = save_checkpoint_with_resume_binding

    def find_screenbus_trainer(name: str):
        if name == args.trainer:
            return registered_trainer
        return original_find_trainer(name)

    run_training_module.recursive_find_trainer_class_by_name = find_screenbus_trainer
    run_training = run_training_module.run_training

    # nnU-Net variants may initialize augmentation RNGs inside initialize or
    # on_train_start. Patch the base lifecycle so the registered ScreenBUS seed
    # is applied both before and after those hooks, rather than relying only on
    # process-start RNG state.
    original_initialize = nnUNetTrainer.initialize
    original_on_train_start = nnUNetTrainer.on_train_start

    def seeded_initialize(self, *positional, **keyword):
        seed_all()
        result = original_initialize(self, *positional, **keyword)
        seed_all()
        self.screenbus_effective_seed = args.seed
        return result

    def seeded_on_train_start(self, *positional, **keyword):
        seed_all()
        result = original_on_train_start(self, *positional, **keyword)
        seed_all()
        self.screenbus_effective_seed = args.seed
        return result

    nnUNetTrainer.initialize = seeded_initialize
    nnUNetTrainer.on_train_start = seeded_on_train_start

    supplied = {
        "dataset_name_or_id": args.dataset_id,
        "dataset_name_or_id_or_path": args.dataset_id,
        "configuration": args.configuration,
        "fold": args.fold,
        "trainer_class_name": args.trainer,
        "plans_identifier": "nnUNetPlans",
        "pretrained_weights": None,
        "num_gpus": 1,
        "use_compressed_data": False,
        "export_validation_probabilities": False,
        "continue_training": args.continue_training,
        "only_run_validation": False,
        "disable_checkpointing": False,
        "val_with_best": False,
        "device": torch.device("cuda", 0),
    }
    signature = inspect.signature(run_training)
    kwargs = {name: supplied[name] for name in signature.parameters if name in supplied}
    required = [
        name
        for name, parameter in signature.parameters.items()
        if parameter.default is inspect.Parameter.empty and name not in kwargs
    ]
    if required:
        raise RuntimeError(f"Unsupported nnUNetv2 run_training signature; unresolved required args: {required}")
    run_training(**kwargs)
    checkpoints = list(Path(os.environ["nnUNet_results"]).rglob("checkpoint_final.pth"))
    if not checkpoints:
        raise RuntimeError("Seeded nnU-Net run finished without checkpoint_final.pth")
    for checkpoint in checkpoints:
        atomic_json(
            checkpoint.with_suffix(".screenbus_seed.json"),
            {
                "effective_seed": args.seed,
                "checkpoint_sha256": sha256_file(checkpoint),
                "seed_injection": "nnUNetTrainer.initialize_and_on_train_start_pre_and_post_hooks",
                "deterministic_algorithms": True,
                "checkpoint_save_every_epochs": args.checkpoint_save_every,
            },
        )
    for orphan in Path(os.environ["nnUNet_results"]).rglob(
        "checkpoint_latest.screenbus_resume.json"
    ):
        if not orphan.with_name("checkpoint_latest.pth").is_file():
            orphan.unlink()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
