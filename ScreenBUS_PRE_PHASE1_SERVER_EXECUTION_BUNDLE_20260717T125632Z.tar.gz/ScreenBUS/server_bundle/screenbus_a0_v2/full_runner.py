from __future__ import annotations

import json
import os
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch

from .g3_validation import G3ValidationError, validate_g3_go_payload

from .candidates import load_candidate_rows
from .authorization import (
    require_canonical_config,
    require_scheduler_lease,
    validate_full_live_attestation,
    validate_server_execution_context,
    write_full_live_attestation,
)
from .config import load_config, resolve_environment, resolve_project_path
from .data import FrozenManifest, assign_inner_folds, assert_patient_disjoint, connected_instances, mask_binary
from .leakage_ablation import (
    LEAKAGE_ABLATION_LABEL,
    LEAKAGE_ABLATION_SLUG,
    leakage_ablation_paths,
    leakage_verifier_ready,
    main_table_rows,
    tag_leakage_ablation_result,
)
from .metrics import (
    aurc,
    detection_recall_at_fp_per_image,
    evaluate_candidate_method,
    full_cohort_selective_curve,
    paired_patient_bootstrap,
    risk_coverage_curve,
)
from .nnunet_baseline import nnunet_completion_valid
from .pipeline import (
    GO_DECISIONS,
    SIMPLE_CONTROLS,
    _candidate_valid,
    _checkpoint_valid,
    _evaluate_rows,
    _freeze_run_spec,
    _gate_passed,
    _merge_oof,
)
from .scheduler import GPUTask, ResourceAwareScheduler
from .util import atomic_csv, atomic_json, git_commit, seed_everything, sha256_file, sha256_tree, utc_now
from .worker import run_worker


def _measure(operation, output_path: Path, image_count: int) -> None:
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
    started = time.perf_counter()
    operation()
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    seconds = time.perf_counter() - started
    peak = torch.cuda.max_memory_allocated() / (1024**3) if torch.cuda.is_available() else None
    if peak is not None:
        # The full-fold worker receives this limit through its caller closure;
        # callers additionally retain the measured artifact on success.
        limit = float(os.environ.get("SCREENBUS_MAX_PEAK_VRAM_GIB", "22"))
        if peak >= limit:
            raise RuntimeError(f"VRAM_LIMIT_EXCEEDED: {peak:.3f} GiB >= {limit} GiB")
    atomic_json(
        output_path,
        {
            "seconds": seconds,
            "image_count": image_count,
            "seconds_per_image": seconds / image_count if image_count else None,
            "throughput_images_per_second": image_count / seconds if seconds else None,
            "peak_vram_gib": peak,
            "measurement": "worker_wall_clock_with_cuda_synchronize",
        },
    )


def _parameter_count(checkpoint: Path) -> int | None:
    if not checkpoint.is_file():
        return None
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if payload.get("parameter_count") is not None:
        return int(payload["parameter_count"])
    state = payload.get("model")
    if not isinstance(state, dict):
        return None
    return int(sum(value.numel() for value in state.values() if isinstance(value, torch.Tensor)))


def _table_role(row: dict[str, Any]) -> str:
    if row["method"] == LEAKAGE_ABLATION_LABEL:
        return "ABLATION"
    if row["box_condition"] in {
        "gt_box_upper_bound",
        "jittered_gt_box_robustness",
        "jittered_gt_box_10pct_sensitivity_only",
        "predicted_box_medsam_512_sensitivity_only",
    }:
        return "DIAGNOSTIC"
    if row["method"].startswith("Control_") or row["method"].startswith("B0_"):
        return "ABLATION"
    if (
        "Diagnostic_Ablation" in row["method"]
        or row.get("pointrend_role") == "diagnostic_ablation_only"
    ):
        return "DIAGNOSTIC"
    return "MAIN_TABLE"


def _validate_main_table_contract(
    rows: Sequence[dict[str, Any]], include_pointrend_main: bool
) -> None:
    expected = {
        "nnUNet_v2_2D",
        "B1_DeepLabV3Plus_HardGate",
        "MaskRCNN_R50_FPN",
        "AutoBUSAM_adapted_YOLOv8s_SAMLoRA",
        "B3_FPN_MedSAM",
        "B5_OOF_Verifier",
    }
    main_rows = main_table_rows(rows)
    observed = {str(row["method"]) for row in main_rows}
    if observed != expected or len(main_rows) != len(expected):
        raise RuntimeError(
            "Main table method contract drift: "
            f"expected={sorted(expected)}, observed={sorted(observed)}"
        )
def _authorized_g3(root: Path, *, live_authorization: str = "attestation") -> dict[str, Any]:
    """Require the exact fresh G3 bytes bound by this orchestrator run."""
    gate_path = root / "gates" / "G3_A0_DECISION.json"
    gate = _gate_passed(gate_path, GO_DECISIONS)
    status_path = root / "server_bundle" / "STATUS.json"
    try:
        status = json.loads(status_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"FULL_FORBIDDEN_WITHOUT_STATUS_BOUND_G3: {exc}") from exc
    stage = status.get("stages", {}).get("G3_METHOD_GATE", {})
    binding = stage.get("gate_binding")
    g2_path = root / "gates" / "G2_SERVER_READY.json"
    g2_stage = status.get("stages", {}).get("G2_SERVER_ENGINEERING", {})
    g2_bindings = g2_stage.get("output_bindings")
    try:
        g2 = json.loads(g2_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"FULL_FORBIDDEN_WITHOUT_BOUND_G2: {exc}") from exc
    g2_key = str(g2_path.resolve())
    g2_bound = g2_bindings.get(g2_key) if isinstance(g2_bindings, dict) else None
    g2_sha = sha256_file(g2_path)
    if (
        g2_stage.get("state") != "PASSED"
        or not isinstance(g2_bindings, dict)
        or set(g2_bindings) != {g2_key}
        or not isinstance(g2_bound, dict)
        or g2_bound.get("sha256") != g2_sha
        or g2_bound.get("bytes") != g2_path.stat().st_size
        or g2.get("decision") != "SERVER_READY"
        or g2.get("status") != "PASS"
        or status.get("decisions", {}).get("g2") != "SERVER_READY"
    ):
        raise RuntimeError("FULL_FORBIDDEN_G2_BINDING_DRIFT")
    observed_sha = sha256_file(gate_path)
    expected = {
        "path": str(gate_path.resolve()),
        "sha256": observed_sha,
        "bytes": gate_path.stat().st_size,
        "decision": gate["decision"],
        "status_run_id": status.get("run_id"),
        "g3_attempt": int(stage.get("attempt", 0)),
        "g2_gate_sha256": g2_sha,
    }
    if stage.get("state") != "PASSED" or not isinstance(binding, dict):
        raise RuntimeError("PHASE2_FORBIDDEN_WITHOUT_PASSED_G3_BINDING")
    drift = {
        key: {"bound": binding.get(key), "observed": value}
        for key, value in expected.items()
        if binding.get(key) != value
    }
    if drift:
        raise RuntimeError(f"FULL_FORBIDDEN_G3_BINDING_DRIFT: {drift}")
    if status.get("decisions", {}).get("g3") != gate["decision"]:
        raise RuntimeError("FULL_FORBIDDEN_STATUS_G3_DECISION_DRIFT")
    required_phase1_outputs = (
        gate_path,
        Path(os.environ["SCREENBUS_OUTPUT_ROOT"]) / "phase1" / "PHASE1_COMPLETE.json",
        Path(os.environ["SCREENBUS_OUTPUT_ROOT"]) / "phase1" / "PHASE1_FIVE_FOLD_REPORT.json",
    )
    output_bindings = stage.get("output_bindings")
    expected_output_keys = {str(path.resolve()) for path in required_phase1_outputs}
    if not isinstance(output_bindings, dict) or set(output_bindings) != expected_output_keys:
        raise RuntimeError("PHASE2_FORBIDDEN_PHASE1_OUTPUT_BINDING_SET_DRIFT")
    for path in required_phase1_outputs:
        bound = output_bindings.get(str(path.resolve()))
        if (
            not isinstance(bound, dict)
            or not path.is_file()
            or bound.get("sha256") != sha256_file(path)
            or bound.get("bytes") != path.stat().st_size
        ):
            raise RuntimeError(f"PHASE2_FORBIDDEN_PHASE1_OUTPUT_BINDING_DRIFT: {path}")
    try:
        validate_g3_go_payload(gate, root=root)
    except G3ValidationError as exc:
        raise RuntimeError(f"FULL_FORBIDDEN_G3_SEMANTIC_INVALID: {exc}") from exc
    context_binding = validate_server_execution_context(
        root,
        status,
        g2,
        g2_sha256=g2_sha,
        g3_sha256=observed_sha,
        g3_decision=gate["decision"],
        authorization_stage_attempt=int(stage["attempt"]),
    )
    if live_authorization == "perform":
        live_attestation = write_full_live_attestation(root, context_binding)
    elif live_authorization == "attestation":
        live_attestation = validate_full_live_attestation(root, context_binding)
    else:
        raise RuntimeError(
            f"FULL_FORBIDDEN_INVALID_LIVE_AUTHORIZATION_MODE: {live_authorization!r}"
        )
    gate["status_run_id"] = status["run_id"]
    gate["g3_attempt"] = int(stage["attempt"])
    gate["bound_sha256"] = observed_sha
    gate["live_attestation"] = live_attestation
    return gate


def _load_required_efficiency(
    path: Path,
    method: str,
    expected_checkpoint_sha256: str | None = None,
) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"EFFICIENCY_INCOMPLETE for {method}: {path}: {exc}") from exc
    if payload.get("method") != method:
        raise RuntimeError(
            f"EFFICIENCY_METHOD_MISMATCH: expected={method}, observed={payload.get('method')}"
        )
    required_positive = (
        "seconds_per_image",
        "throughput_images_per_second",
        "peak_vram_gib",
        "total_system_parameter_count",
    )
    invalid = []
    for key in required_positive:
        value = payload.get(key)
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not np.isfinite(float(value))
            or float(value) <= 0
        ):
            invalid.append(key)
    if invalid:
        raise RuntimeError(f"EFFICIENCY_INCOMPLETE for {method}: invalid fields={invalid}")
    if payload.get("measurement_status") != "MEASURED_PREDICTED_ONLY_END_TO_END":
        raise RuntimeError(f"EFFICIENCY_NOT_PREDICTED_ONLY for {method}")
    if payload.get("ground_truth_pixels_read") is not False:
        raise RuntimeError(f"EFFICIENCY_GT_CONTAMINATION for {method}")
    if (
        expected_checkpoint_sha256 is not None
        and payload.get("checkpoint_sha256") != expected_checkpoint_sha256
    ):
        raise RuntimeError(
            f"EFFICIENCY_CHECKPOINT_BINDING_DRIFT for {method}: "
            f"expected={expected_checkpoint_sha256}, observed={payload.get('checkpoint_sha256')}"
        )
    return payload


def _scores_all(rows: Sequence[dict[str, Any]]) -> list[float]:
    return [-1e9 if row.get("is_sentinel") else 1.0 for row in rows]


FROC_TARGET_FP_PER_IMAGE = (0.25, 0.5, 1.0, 2.0, 4.0)


def _detection_froc_rows(
    rows: Sequence[dict[str, Any]], seed: int, fold: int
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for target in FROC_TARGET_FP_PER_IMAGE:
        observed = detection_recall_at_fp_per_image(rows, target)
        if not all(np.isfinite(float(observed[key])) for key in ("recall", "fp_per_image", "threshold")):
            raise RuntimeError(f"Non-finite FROC result at target {target}: {observed}")
        output.append(
            {
                "seed": seed,
                "outer_fold": fold,
                "method": "B2_FPN_Detector",
                "target_fp_per_image": target,
                "lesion_recall": observed["recall"],
                "observed_fp_per_image": observed["fp_per_image"],
                "detector_score_threshold": observed["threshold"],
                "threshold_source": "OUTER_TEST_FROC_SWEEP_REPORTING_ONLY_NOT_MODEL_SELECTION",
                "table_role": "DETECTION_FROC_TABLE",
            }
        )
    return output


def _system_reduction_rows(
    results: Sequence[dict[str, Any]],
    b5_name: str,
    include_pointrend_main: bool,
    target_sensitivity: float,
    strongest_control_name: str,
    seed: int,
    fold: int,
) -> list[dict[str, Any]]:
    """Report the frozen >=98% sensitivity normal-FP comparisons literally."""
    by_method = {
        row["method"]: row
        for row in results
        if row.get("box_condition") == "predicted_box"
    }
    screenbus = by_method[b5_name]
    strongest_control = by_method.get(f"Control_{strongest_control_name}")
    if strongest_control is None:
        raise RuntimeError(
            f"Frozen inner/meta-OOF strongest control missing: {strongest_control_name}"
        )
    references: list[tuple[str, dict[str, Any] | None, str | None]] = [
        ("B3", by_method.get("B3_FPN_MedSAM"), None),
        (
            "B4",
            by_method.get("B4_OriginalPointRend_Diagnostic")
            if include_pointrend_main
            else None,
            None if include_pointrend_main else "NOT_APPLICABLE_G3_REMOVED_POINTREND",
        ),
        (
            "STRONGEST_SIMPLE_CONTROL",
            strongest_control,
            None if strongest_control is not None else "NO_SIMPLE_CONTROL_MET_TARGET_SENSITIVITY",
        ),
    ]
    output: list[dict[str, Any]] = []
    for role, reference, preset_status in references:
        status = preset_status or "ELIGIBILITY_PENDING"
        reduction: float | None = None
        reference_name = reference["method"] if reference is not None else None
        reference_sensitivity = float(reference["lesion_sensitivity"]) if reference is not None else None
        reference_fp = float(reference["normal_fp_masks_per_image"]) if reference is not None else None
        screenbus_sensitivity = float(screenbus["lesion_sensitivity"])
        screenbus_fp = float(screenbus["normal_fp_masks_per_image"])
        if preset_status is None and reference is not None:
            if screenbus_sensitivity < target_sensitivity:
                status = "TARGET_NOT_MET_BY_SCREENBUS"
            elif reference_sensitivity is None or reference_sensitivity < target_sensitivity:
                status = "TARGET_NOT_MET_BY_REFERENCE"
            elif reference_fp is None or not np.isfinite(reference_fp) or not np.isfinite(screenbus_fp):
                status = "NONFINITE_NORMAL_FP_METRIC"
            elif reference_fp <= 0:
                status = "UNDEFINED_RELATIVE_REDUCTION_REFERENCE_ZERO_FP"
            else:
                reduction = (reference_fp - screenbus_fp) / reference_fp
                status = "COMPARABLE_AT_OR_ABOVE_TARGET_SENSITIVITY"
        output.append(
            {
                "seed": seed,
                "outer_fold": fold,
                "screenbus_method": b5_name,
                "reference_role": role,
                "reference_method": reference_name,
                "target_lesion_sensitivity": target_sensitivity,
                "screenbus_lesion_sensitivity": screenbus_sensitivity,
                "reference_lesion_sensitivity": reference_sensitivity,
                "screenbus_normal_fp_masks_per_image": screenbus_fp,
                "reference_normal_fp_masks_per_image": reference_fp,
                "relative_normal_fp_reduction": reduction,
                "status": status,
                "operating_point_source": "FROZEN_INNER_TRAIN_CALIBRATION_NOT_OUTER_TEST_TUNING",
                "table_role": "SYSTEM_OPERATING_POINT",
            }
        )
    return output


def _accepted_by_image(rows, scores, threshold):
    result: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row, score in zip(rows, scores):
        if not row.get("is_sentinel") and float(score) >= threshold:
            result[row["image_id"]].append(row)
    return result


def _multicomponent_rows(method, rows, scores, threshold, seed, fold):
    accepted = _accepted_by_image(rows, scores, threshold)
    by_image: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_image[row["image_id"]].append(row)
    output = []
    for image_id, image_rows in by_image.items():
        first = image_rows[0]
        if int(first["gt_lesion_count"]) <= 1:
            continue
        chosen = accepted.get(image_id, [])
        matched = {int(row["matched_lesion"]) for row in chosen if row["candidate_valid"]}
        best_dice = []
        for lesion in range(int(first["gt_lesion_count"])):
            values = [float(row["mask_dice"]) for row in chosen if row["candidate_valid"] and int(row["matched_lesion"]) == lesion]
            best_dice.append(max(values) if values else 0.0)
        output.append(
            {
                "seed": seed,
                "outer_fold": fold,
                "method": method,
                "image_id": image_id,
                "patient_id": first["patient_id"],
                "gt_component_count": first["gt_lesion_count"],
                "detected_component_count": len(matched),
                "accepted_candidate_count": len(chosen),
                "false_positive_candidate_count": sum(not row["candidate_valid"] for row in chosen),
                "lesion_macro_dice": float(np.mean(best_dice)),
                "role": "DESCRIPTIVE_STRESS_TEST_ONLY_NO_GENERALIZATION_CLAIM",
            }
        )
    return output


def run_full_fold(config_path: Path, fold: int, seed: int, run_dir: Path) -> dict[str, Any]:
    root_from_env = Path(os.environ.get("SCREENBUS_ROOT", "")).resolve()
    config_path = require_canonical_config(config_path, root_from_env, "phase2")
    cfg = load_config(config_path)
    env = resolve_environment()
    root = env["SCREENBUS_ROOT"]
    if root != root_from_env:
        raise RuntimeError("FULL_FOLD_FORBIDDEN_SCREENBUS_ROOT_ENV_DRIFT")
    if seed not in {int(value) for value in cfg["seeds"]}:
        raise RuntimeError(f"FULL_FOLD_SEED_OUTSIDE_CANONICAL_GRID: {seed}")
    if fold not in {int(value) for value in cfg["outer_folds"]}:
        raise RuntimeError(f"FULL_FOLD_OUTER_FOLD_OUTSIDE_CANONICAL_GRID: {fold}")
    canonical_run_dir = (
        env["SCREENBUS_OUTPUT_ROOT"] / "phase2" / f"seed_{seed}" / f"fold_{fold}"
    ).resolve()
    if run_dir.is_symlink() or run_dir.resolve() != canonical_run_dir:
        raise RuntimeError(
            "FULL_FOLD_NONCANONICAL_RUN_DIR: "
            f"expected={canonical_run_dir}, observed={run_dir.resolve()}"
        )
    expected_command = [
        sys.executable,
        "-m",
        "screenbus_a0_v2.cli",
        "phase2-fold",
        "--config",
        str(config_path),
        "--seed",
        str(seed),
        "--outer-fold",
        str(fold),
        "--run-dir",
        str(canonical_run_dir),
    ]
    lease = require_scheduler_lease(
        root_from_env,
        config_path,
        expected_scope="phase2",
        expected_command=expected_command,
    )
    if lease.get("task_id") != f"phase2_seed{seed}_fold{fold}":
        raise RuntimeError("FULL_FOLD_SCHEDULER_TASK_ID_MISMATCH")
    if lease.get("memory_class") != "heavy":
        raise RuntimeError("FULL_FOLD_REQUIRES_HEAVY_EXCLUSIVE_SCHEDULER_LEASE")
    if os.environ.get("PYTHONHASHSEED") != str(seed):
        raise RuntimeError(
            "PYTHONHASHSEED must be set before interpreter start for each full seed; "
            f"expected={seed}, observed={os.environ.get('PYTHONHASHSEED')!r}"
        )
    g3 = _authorized_g3(root, live_authorization="attestation")
    include_pointrend_main = g3["decision"] == "GO_EXPAND_TO_PHASE2"
    selected_pointrend_variant = "generic" if include_pointrend_main else None
    os.environ["SCREENBUS_MAX_PEAK_VRAM_GIB"] = str(cfg["runtime"]["max_peak_vram_gib"])
    seed_everything(seed, cfg["deterministic"])
    manifest = FrozenManifest.load(
        resolve_project_path(root, cfg["manifest"]),
        env["SCREENBUS_DATA_ROOT"],
        root,
        cfg["strict_hash_audit"],
        pixel_excluded_folds={fold},
    )
    train_records_all, eval_records = manifest.outer_split(fold)
    train_records = [record for record in train_records_all if record.is_clean]
    primary_eval_records = [record for record in eval_records if record.is_clean]
    assert_patient_disjoint(train_records, eval_records, f"full_outer_fold_{fold}")
    assignment = assign_inner_folds(train_records, int(cfg["inner_folds"]), seed)
    nnunet_dataset_id = int(cfg["nnunet"]["dataset_id"]) + fold
    split = {
        "schema_version": 1,
        "mode": "phase2",
        "seed": seed,
        "pythonhashseed_at_process_start": os.environ.get("PYTHONHASHSEED"),
        "outer_fold": fold,
        "train_image_ids": [record.image_id for record in train_records],
        "evaluation_image_ids": [record.image_id for record in eval_records],
        "primary_evaluation_image_ids": [record.image_id for record in primary_eval_records],
        "primary_analysis_cohort": "bus_uclm_clean",
        "train_patient_ids": sorted({record.patient_id for record in train_records}),
        "evaluation_patient_ids": sorted({record.patient_id for record in eval_records}),
        "inner_assignment": assignment,
        "include_pointrend_main": include_pointrend_main,
        "selected_pointrend_variant": selected_pointrend_variant,
        "manifest_sha256": manifest.manifest_sha256,
        "config_sha256": cfg["_config_sha256"],
        "outer_test_access_policy": "OPEN_ONLY_AFTER_SPLIT_AND_CONFIG_FREEZE_FOR_THIS_FOLD",
    }
    split_path = run_dir / "provenance" / "split.json"
    atomic_json(split_path, split)
    code_files = [
        path
        for path in (root / "server_bundle" / "screenbus_a0_v2").rglob("*")
        if path.is_file() and path.suffix in {".py", ".yaml", ".yml"}
    ]
    _freeze_run_spec(
        run_dir,
        {
            "schema_version": 1,
            "mode": "phase2",
            "seed": seed,
            "pythonhashseed_at_process_start": os.environ.get("PYTHONHASHSEED"),
            "outer_fold": fold,
            "config_sha256": cfg["_config_sha256"],
            "manifest_sha256": manifest.manifest_sha256,
            "split_sha256": sha256_file(split_path),
            "git_commit": git_commit(root),
            "code_tree_sha256": sha256_tree(code_files),
            "g3_decision": g3["decision"],
            "selected_pointrend_variant": selected_pointrend_variant,
            "g3_gate_sha256": sha256_file(root / "gates" / "G3_A0_DECISION.json"),
            "g3_status_run_id": g3["status_run_id"],
            "g3_attempt": g3["g3_attempt"],
            "nnunet_dataset_base_id": int(cfg["nnunet"]["dataset_id"]),
            "nnunet_configuration": cfg["nnunet"]["configuration"],
            "nnunet_trainer": cfg["nnunet"]["trainer"],
        },
    )
    checkpoints = run_dir / "checkpoints"
    operations = [
        ("train_deeplab", checkpoints / "deeplab.pt", None),
        ("train_mask", checkpoints / "mask_rcnn.pt", None),
        ("train_autobusam", checkpoints / "autobusam_yolo.pt", None),
    ]
    for operation, checkpoint, inner in operations:
        medsam_missing = operation == "train_detector_final" and not _checkpoint_valid(
            checkpoints / "medsam_final.pt"
        )
        autobusam_lora_missing = operation == "train_autobusam" and not _checkpoint_valid(
            checkpoints / "autobusam_sam_lora.pt"
        )
        if not _checkpoint_valid(checkpoint) or medsam_missing or autobusam_lora_missing:
            run_worker(operation, config_path, split_path, run_dir, inner)
    for inner in range(cfg["inner_folds"]):
        checkpoint = checkpoints / f"detector_inner_{inner}.pt"
        if not _checkpoint_valid(checkpoint) or not _checkpoint_valid(
            checkpoints / f"medsam_inner_{inner}.pt"
        ):
            run_worker("train_detector_inner", config_path, split_path, run_dir, inner)
    if (
        not _checkpoint_valid(checkpoints / "detector_final.pt")
        or not _checkpoint_valid(checkpoints / "medsam_final.pt")
        or not (checkpoints / "final_refit_epochs.json").is_file()
    ):
        run_worker("train_detector_final", config_path, split_path, run_dir, None)
    runtime_dir = run_dir / "runtime"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    leakage_paths = leakage_ablation_paths(run_dir)
    for inner in range(cfg["inner_folds"]):
        path = run_dir / "candidates" / f"inner_{inner}" / "candidates.jsonl"
        if not _candidate_valid(
            path,
            sha256_file(checkpoints / f"detector_inner_{inner}.pt"),
            sha256_file(checkpoints / f"medsam_inner_{inner}.pt"),
        ):
            heldout_count = sum(assignment[record.patient_id] == inner for record in train_records)
            _measure(
                lambda inner=inner: run_worker("candidates_inner", config_path, split_path, run_dir, inner),
                runtime_dir / f"candidates_inner_{inner}.json",
                heldout_count,
            )
    eval_candidate_path = run_dir / "candidates" / "evaluation" / "candidates.jsonl"
    if not _candidate_valid(
        eval_candidate_path,
        sha256_file(checkpoints / "detector_final.pt"),
        sha256_file(checkpoints / "medsam_final.pt"),
    ):
        _measure(
            lambda: run_worker("candidates_eval", config_path, split_path, run_dir),
            runtime_dir / "b3_inference.json",
            len(eval_records),
        )
    if not _candidate_valid(
        leakage_paths["training_candidates"],
        sha256_file(checkpoints / "detector_final.pt"),
        sha256_file(checkpoints / "medsam_final.pt"),
    ):
        _measure(
            lambda: run_worker(
                "candidates_non_oof_leakage_train", config_path, split_path, run_dir
            ),
            runtime_dir / "non_oof_leakage_candidate_generation.json",
            len(train_records),
        )
    if not _candidate_valid(
        run_dir / "baselines" / "b1" / "candidates.jsonl",
        sha256_file(checkpoints / "deeplab.pt"),
    ):
        _measure(
            lambda: run_worker("infer_deeplab", config_path, split_path, run_dir),
            runtime_dir / "deeplab_inference.json",
            len(eval_records) * 2,
        )
    if not _candidate_valid(
        run_dir / "baselines" / "mask_rcnn" / "candidates.jsonl",
        sha256_file(checkpoints / "mask_rcnn.pt"),
    ):
        _measure(
            lambda: run_worker("infer_mask", config_path, split_path, run_dir),
            runtime_dir / "mask_rcnn_inference.json",
            len(eval_records),
        )
    if not _candidate_valid(
        run_dir / "baselines" / "autobusam_style" / "candidates.jsonl",
        sha256_file(checkpoints / "autobusam_yolo.pt"),
        expected_autobusam_adapter_sha256=sha256_file(
            checkpoints / "autobusam_sam_lora.pt"
        ),
    ):
        _measure(
            lambda: run_worker("infer_autobusam", config_path, split_path, run_dir),
            runtime_dir / "autobusam_inference.json",
            len(eval_records),
        )
    nnunet_root = run_dir / "nnunet"
    nnunet_candidates = nnunet_root / "candidates.jsonl"

    def validate_nnunet_outputs() -> tuple[bool, str, str | None]:
        return nnunet_completion_valid(
            nnunet_root,
            dataset_id=nnunet_dataset_id,
            configuration=cfg["nnunet"]["configuration"],
            trainer=cfg["nnunet"]["trainer"],
            fold=fold,
            seed=seed,
            config_sha256=cfg["_config_sha256"],
            expected_image_ids=[record.image_id for record in eval_records],
            expected_training_image_ids=[
                record.image_id for record in train_records
            ],
            expected_training_patient_ids=[
                record.patient_id for record in train_records
            ],
            expected_evaluation_patient_ids=[
                record.patient_id for record in eval_records
            ],
        )

    nnunet_valid, nnunet_reason, nnunet_checkpoint_sha256 = (
        validate_nnunet_outputs()
    )
    if (
        nnunet_valid
        and nnunet_checkpoint_sha256 is not None
        and not _candidate_valid(nnunet_candidates, nnunet_checkpoint_sha256)
    ):
        raise RuntimeError(
            "NNUNET_COMPLETION_PIPELINE_CANDIDATE_INVALID: " + nnunet_reason
        )
    if not nnunet_valid or nnunet_checkpoint_sha256 is None:
        _measure(
            lambda: run_worker("nnunet", config_path, split_path, run_dir),
            runtime_dir / "nnunet_train_and_inference.json",
            len(eval_records),
        )
        nnunet_valid, nnunet_reason, nnunet_checkpoint_sha256 = (
            validate_nnunet_outputs()
        )
    if (
        not nnunet_valid
        or nnunet_checkpoint_sha256 is None
        or not _candidate_valid(nnunet_candidates, nnunet_checkpoint_sha256)
    ):
        raise RuntimeError(f"NNUNET_COMPLETION_INVALID_AFTER_WORKER: {nnunet_reason}")
    _merge_oof(run_dir, split, int(cfg["inner_folds"]))
    if not (run_dir / "verifier_selection.json").is_file():
        _measure(
            lambda: run_worker("postprocess", config_path, split_path, run_dir),
            runtime_dir / "pointrend_verifier.json",
            len(eval_records),
        )
    baseline_runtime = [
        ("B1_DeepLabV3Plus_HardGate", runtime_dir / "b1_predicted_only.json"),
        ("MaskRCNN_R50_FPN", runtime_dir / "mask_rcnn_predicted_only.json"),
        ("AutoBUSAM_adapted_YOLOv8s_SAMLoRA", runtime_dir / "autobusam_predicted_only.json"),
    ]
    try:
        for method, path in baseline_runtime:
            _load_required_efficiency(path, method)
    except RuntimeError:
        run_worker("benchmark_baseline_chains", config_path, split_path, run_dir)
        for method, path in baseline_runtime:
            _load_required_efficiency(path, method)
    required_chain_runtime = [runtime_dir / "b3_predicted_only.json", runtime_dir / "b5_predicted_only.json"]
    if include_pointrend_main:
        required_chain_runtime.append(runtime_dir / "b4_predicted_only.json")
    try:
        chain_methods = {
            "b3_predicted_only.json": "B3_FPN_MedSAM",
            "b4_predicted_only.json": "B4_OriginalPointRend_Diagnostic",
            "b5_predicted_only.json": "B5_OOF_Verifier",
        }
        for path in required_chain_runtime:
            _load_required_efficiency(path, chain_methods[path.name])
    except RuntimeError:
        run_worker("benchmark_predicted_chains", config_path, split_path, run_dir)
    nnunet_runtime = runtime_dir / "nnunet_predicted_only.json"
    try:
        _load_required_efficiency(
            nnunet_runtime,
            "nnUNet_v2_2D",
            nnunet_checkpoint_sha256,
        )
    except RuntimeError:
        run_worker("benchmark_nnunet_predict_only", config_path, split_path, run_dir)
        _load_required_efficiency(
            nnunet_runtime,
            "nnUNet_v2_2D",
            nnunet_checkpoint_sha256,
        )
    if not leakage_verifier_ready(
        leakage_paths, sha256_file(checkpoints / "detector_final.pt")
    ):
        _measure(
            lambda: run_worker(
                "fit_non_oof_leakage_verifier", config_path, split_path, run_dir
            ),
            runtime_dir / "non_oof_leakage_verifier.json",
            len(eval_records),
        )

    raw = load_candidate_rows(eval_candidate_path)
    raw_predicted_all = [row for row in raw if row["condition"] == "predicted_box"]
    raw_predicted = [row for row in raw_predicted_all if bool(int(row.get("is_clean", 0)))]
    pointrend_status = json.loads(
        (run_dir / "pointrend_diagnostic_status.json").read_text(encoding="utf-8")
    )
    pointrend_complete = pointrend_status["status"] == "COMPLETE"
    if include_pointrend_main and not pointrend_complete:
        include_pointrend_main = False
        atomic_json(
            run_dir / "pointrend_nonblocking_fallback.json",
            {
                "decision": "POINTREND_OPTIONAL_REMOVED",
                "reason": pointrend_status,
                "main_route": "B3_MedSAM_plus_B5_verifier",
                "point_rend_features_entered_main_verifier": False,
            },
        )
    refined_all = (
        load_candidate_rows(Path(pointrend_status["selected_evaluation_candidates"]))
        if pointrend_complete
        else []
    )
    refined = [row for row in refined_all if bool(int(row.get("is_clean", 0)))]
    # v2.3 freezes B5 to B3 candidates. PointRend remains a separate B4
    # diagnostic gain and must never silently change the Primary method.
    verifier_input_all = raw_predicted_all
    verifier_input = raw_predicted
    verifier_dir = run_dir / "verifier_b3"
    thresholds = json.loads((verifier_dir / "thresholds.json").read_text(encoding="utf-8"))
    evaluation_scores_all = json.loads(
        (verifier_dir / "evaluation_scores.json").read_text(encoding="utf-8")
    )
    clean_score_indices = [
        index
        for index, row in enumerate(verifier_input_all)
        if bool(int(row.get("is_clean", 0)))
    ]
    evaluation_scores = {
        name: [values[index] for index in clean_score_indices]
        for name, values in evaluation_scores_all.items()
    }
    detector_threshold = float(thresholds["detector_score"]["threshold"])
    results: list[dict[str, Any]] = []
    method_sources = [
        ("nnUNet_v2_2D", run_dir / "nnunet" / "candidates.jsonl"),
        ("B0_DeepLabV3Plus", run_dir / "baselines" / "b0" / "candidates.jsonl"),
        ("B1_DeepLabV3Plus_HardGate", run_dir / "baselines" / "b1" / "candidates.jsonl"),
        ("MaskRCNN_R50_FPN", run_dir / "baselines" / "mask_rcnn" / "candidates.jsonl"),
        ("AutoBUSAM_adapted_YOLOv8s_SAMLoRA", run_dir / "baselines" / "autobusam_style" / "candidates.jsonl"),
    ]
    multicomponent: list[dict[str, Any]] = []
    all_method_rows: dict[str, list[dict[str, Any]]] = {}
    for method, path in method_sources:
        all_rows = load_candidate_rows(path)
        all_method_rows[method] = all_rows
        rows = [row for row in all_rows if bool(int(row.get("is_clean", 0)))]
        scores = _scores_all(rows)
        results.append(_evaluate_rows(method, rows[0]["condition"], rows, scores, 0.0, cfg, seed, "fixed_model_output"))
        multicomponent += _multicomponent_rows(method, all_rows, _scores_all(all_rows), 0.0, seed, fold)
    detector_scores = [
        -1e9 if row.get("is_sentinel") else row["feature_map"]["detector_score"] for row in raw_predicted
    ]
    results.append(
        _evaluate_rows(
            "B3_FPN_MedSAM", "predicted_box", raw_predicted, detector_scores, detector_threshold, cfg, seed, "inner_oof"
        )
    )
    multicomponent += _multicomponent_rows(
        "B3_FPN_MedSAM",
        raw_predicted_all,
        [
            -1e9 if row.get("is_sentinel") else row["feature_map"]["detector_score"]
            for row in raw_predicted_all
        ],
        detector_threshold,
        seed,
        fold,
    )
    if pointrend_complete:
        refined_scores = [
            -1e9 if row.get("is_sentinel") else row["feature_map"]["detector_score"] for row in refined
        ]
        b4_name = (
            "B4_OriginalPointRend_Diagnostic"
            if include_pointrend_main
            else "VanillaPointRend_Diagnostic_NotUSSpecific_NotMain"
        )
        results.append(
            _evaluate_rows(b4_name, "predicted_box", refined, refined_scores, detector_threshold, cfg, seed, "inner_oof")
        )
    b5_name = "B5_OOF_Verifier"
    for method in SIMPLE_CONTROLS + ["verifier"]:
        is_verifier = method == "verifier"
        name = b5_name if method == "verifier" else f"Control_{method}"
        operating_scores = (
            evaluation_scores["verifier_existence"]
            if is_verifier
            else evaluation_scores[method]
        )
        operating_threshold = float(
            thresholds[method]["existence_threshold"]
            if is_verifier
            else thresholds[method]["threshold"]
        )
        results.append(
            _evaluate_rows(
                name,
                "predicted_box",
                verifier_input,
                operating_scores,
                operating_threshold,
                cfg,
                seed,
                "patient_level_inner_fold_oof_only",
                quality_scores=(
                    evaluation_scores["verifier_quality"] if is_verifier else None
                ),
                quality_threshold=(
                    float(thresholds[method]["quality_threshold"])
                    if is_verifier
                    else None
                ),
                failure_ranking_scores=(
                    evaluation_scores["verifier"] if is_verifier else None
                ),
            )
        )
        if is_verifier:
            multicomponent += _multicomponent_rows(
                name,
                verifier_input_all,
                evaluation_scores_all["verifier_existence"],
                operating_threshold,
                seed,
                fold,
            )
    for condition in (
        "gt_box_upper_bound",
        "jittered_gt_box_robustness",
        "jittered_gt_box_10pct_sensitivity_only",
    ):
        rows = [
            row
            for row in raw
            if row["condition"] == condition and bool(int(row.get("is_clean", 0)))
        ]
        results.append(_evaluate_rows("B3_FPN_MedSAM", condition, rows, _scores_all(rows), 0.0, cfg, seed, "diagnostic"))
    leakage_threshold_payload = json.loads(
        leakage_paths["thresholds"].read_text(encoding="utf-8")
    )
    leakage_score_payload = json.loads(
        leakage_paths["evaluation_scores"].read_text(encoding="utf-8")
    )
    expected_leakage_keys = [
        f"{row['image_id']}:{row['candidate_index']}:{row['condition']}"
        for row in raw_predicted_all
    ]
    if leakage_score_payload.get("image_candidate_keys") != expected_leakage_keys:
        raise RuntimeError("Leakage ablation evaluation-score alignment mismatch")
    leakage_threshold = float(
        leakage_threshold_payload["verifier"]["existence_threshold"]
    )
    leakage_result = _evaluate_rows(
        LEAKAGE_ABLATION_LABEL,
        "predicted_box",
        raw_predicted,
        [
            leakage_score_payload["verifier_existence"][index]
            for index, row in enumerate(raw_predicted_all)
            if bool(int(row.get("is_clean", 0)))
        ],
        leakage_threshold,
        cfg,
        seed,
        "NON_OOF_FINAL_DETECTOR_SELF_TRAIN_CANDIDATES_INVALID_ABLATION_ONLY",
        quality_scores=[
            leakage_score_payload["verifier_quality"][index]
            for index, row in enumerate(raw_predicted_all)
            if bool(int(row.get("is_clean", 0)))
        ],
        quality_threshold=float(
            leakage_threshold_payload["verifier"]["quality_threshold"]
        ),
        failure_ranking_scores=[
            leakage_score_payload["verifier"][index]
            for index, row in enumerate(raw_predicted_all)
            if bool(int(row.get("is_clean", 0)))
        ],
    )
    leakage_provenance = json.loads(
        leakage_paths["provenance"].read_text(encoding="utf-8")
    )
    leakage_result = tag_leakage_ablation_result(
        leakage_result,
        leakage_paths,
        int(
            leakage_provenance["candidate_provenance"][
                "training_generation_patient_overlap_count"
            ]
        ),
    )
    results.append(leakage_result)
    for row in results:
        row["seed"] = seed
        row["outer_fold"] = fold
        row["pointrend_role"] = (
            "diagnostic_ablation_only"
            if row["method"] == "B4_OriginalPointRend_Diagnostic"
            else "not_in_b5_default"
        )
        if row["method"] == "B5_OOF_Verifier":
            row["b5_upstream"] = "B3_FPN_MedSAM"
        row["table_role"] = _table_role(row)
        if row["method"] != LEAKAGE_ABLATION_LABEL:
            row["claim_status"] = "ACTUAL_OUTER_TEST_RESULT_NOT_YET_AGGREGATED"
    _validate_main_table_contract(results, include_pointrend_main)
    risk: list[dict[str, Any]] = []
    for method in SIMPLE_CONTROLS + ["verifier"]:
        is_verifier = method == "verifier"
        candidate_ranking_scores = evaluation_scores[method]
        existence_scores = (
            evaluation_scores["verifier_existence"]
            if is_verifier
            else evaluation_scores[method]
        )
        operating_threshold = float(
            thresholds[method]["existence_threshold"]
            if is_verifier
            else thresholds[method]["threshold"]
        )
        curve = risk_coverage_curve(method, verifier_input, candidate_ranking_scores)
        score = aurc(curve)
        for row in curve:
            row.update(
                seed=seed,
                outer_fold=fold,
                aurc=score,
                scope="candidate_level_diagnostic_only",
                ranking_score_definition=(
                    "joint_existence_times_conditional_quality"
                    if is_verifier
                    else "scalar_simple_control"
                ),
            )
            risk.append(row)
        cohort_curve = full_cohort_selective_curve(
            method,
            verifier_input,
            existence_scores,
            operating_threshold=operating_threshold,
            quality_scores=(
                evaluation_scores["verifier_quality"] if is_verifier else None
            ),
            quality_threshold=(
                float(thresholds[method]["quality_threshold"])
                if is_verifier
                else None
            ),
        )
        cohort_aurc = aurc(
            [
                {"coverage": row["coverage"], "risk": row["automatic_risk"]}
                for row in cohort_curve
                if np.isfinite(row["automatic_risk"])
            ]
        )
        for row in cohort_curve:
            row.update(seed=seed, outer_fold=fold, aurc=cohort_aurc)
            risk.append(row)
        operating = next(row for row in cohort_curve if row["operating_point"])
        result_name = b5_name if method == "verifier" else f"Control_{method}"
        result_row = next(row for row in results if row["method"] == result_name)
        for key in (
            "coverage",
            "referral_rate",
            "referred_positive_images",
            "referred_normal_images",
            "zero_candidate_positive_images",
            "conservative_lesion_sensitivity",
        ):
            result_row[f"selective_{key}"] = operating[key]
    detection_froc = _detection_froc_rows(raw_predicted, seed, fold)
    if len(detection_froc) != len(FROC_TARGET_FP_PER_IMAGE) or not any(
        np.isclose(float(row["target_fp_per_image"]), 1.0) for row in detection_froc
    ):
        raise RuntimeError("Frozen FROC grid or recall-at-1 FP/image row is incomplete")
    system_reduction = _system_reduction_rows(
        results,
        b5_name,
        include_pointrend_main,
        float(cfg["target_lesion_sensitivity"]),
        str(thresholds["strongest_simple_control"]["name"]),
        seed,
        fold,
    )
    if {row["reference_role"] for row in system_reduction} != {
        "B3",
        "B4",
        "STRONGEST_SIMPLE_CONTROL",
    }:
        raise RuntimeError("Frozen system operating-point comparisons are incomplete")
    robustness: list[dict[str, Any]] = []
    secondary_cfg = {**cfg, "bootstrap_replicates": 0}

    def add_robustness(
        method: str,
        rows_all: list[dict[str, Any]],
        scores_all: list[float],
        threshold: float,
        *,
        quality_all: list[float] | None = None,
        quality_threshold: float | None = None,
    ) -> None:
        cohort_filters = {
            "BUS_UCLM_all": lambda row: True,
            "marked": lambda row: bool(int(row.get("has_mark", 0))),
            "doppler": lambda row: bool(int(row.get("has_doppler", 0))),
            "combined": lambda row: bool(int(row.get("has_combined", 0))),
        }
        for cohort, predicate in cohort_filters.items():
            indices = [index for index, row in enumerate(rows_all) if predicate(row)]
            if not indices:
                continue
            cohort_rows = [rows_all[index] for index in indices]
            result = _evaluate_rows(
                method,
                cohort,
                cohort_rows,
                [scores_all[index] for index in indices],
                threshold,
                secondary_cfg,
                seed,
                "frozen_inner_oof_working_point_secondary_no_retuning",
                quality_scores=(
                    [quality_all[index] for index in indices]
                    if quality_all is not None
                    else None
                ),
                quality_threshold=quality_threshold,
            )
            result.update(seed=seed, outer_fold=fold, table_role="ROBUSTNESS_SECONDARY")
            robustness.append(result)

    for method, rows_all in all_method_rows.items():
        if method == "B0_DeepLabV3Plus":
            continue
        add_robustness(method, rows_all, _scores_all(rows_all), 0.0)
    add_robustness(
        "B3_FPN_MedSAM",
        raw_predicted_all,
        [
            -1e9 if row.get("is_sentinel") else row["feature_map"]["detector_score"]
            for row in raw_predicted_all
        ],
        detector_threshold,
    )
    if pointrend_complete:
        add_robustness(
            b4_name,
            refined_all,
            [
                -1e9 if row.get("is_sentinel") else row["feature_map"]["detector_score"]
                for row in refined_all
            ],
            detector_threshold,
        )
    add_robustness(
        b5_name,
        verifier_input_all,
        evaluation_scores_all["verifier_existence"],
        float(thresholds["verifier"]["existence_threshold"]),
        quality_all=evaluation_scores_all["verifier_quality"],
        quality_threshold=float(thresholds["verifier"]["quality_threshold"]),
    )
    atomic_csv(run_dir / "results.csv", results)
    atomic_csv(run_dir / "robustness.csv", robustness)
    real_verifier_rows = [row for row in verifier_input if not row.get("is_sentinel")]
    atomic_csv(
        run_dir / "failure_threshold_sensitivity.csv",
        [
            {
                "seed": seed,
                "outer_fold": fold,
                "analysis_cohort": "BUS_UCLM_clean_outer_OOF",
                "dice_threshold": threshold,
                "role": "PRIMARY" if threshold == cfg["failure_dice_threshold"] else "SENSITIVITY_ONLY",
                "candidate_count": len(real_verifier_rows),
                "failure_count": sum(
                    int(not row["candidate_valid"] or float(row["mask_dice"]) < threshold)
                    for row in real_verifier_rows
                ),
                "g3_gate_eligible": threshold == cfg["failure_dice_threshold"],
            }
            for threshold in [
                cfg["failure_dice_threshold"],
                *cfg["failure_dice_sensitivity_thresholds"],
            ]
        ],
    )
    atomic_json(
        leakage_paths["result"],
        {
            "schema_version": 1,
            "protocol_label": LEAKAGE_ABLATION_LABEL,
            "table_role": "ABLATION",
            "valid_method": False,
            "g3_eligible": False,
            "main_table_eligible": False,
            "result": next(
                row for row in results if row["method"] == LEAKAGE_ABLATION_LABEL
            ),
            "provenance": str(leakage_paths["provenance"]),
            "provenance_sha256": sha256_file(leakage_paths["provenance"]),
        },
    )
    atomic_csv(run_dir / "risk_coverage.csv", risk)
    atomic_csv(run_dir / "multicomponent_cases.csv", multicomponent)
    atomic_csv(run_dir / "detection_froc.csv", detection_froc)
    atomic_csv(run_dir / "system_operating_point.csv", system_reduction)

    efficiency: list[dict[str, Any]] = []
    required_runtime = [
        *baseline_runtime,
        ("B3_FPN_MedSAM", runtime_dir / "b3_predicted_only.json"),
        (b5_name, runtime_dir / "b5_predicted_only.json"),
        ("nnUNet_v2_2D", runtime_dir / "nnunet_predicted_only.json"),
    ]
    if include_pointrend_main:
        required_runtime.insert(
            1,
            (
                "B4_OriginalPointRend_Diagnostic",
                runtime_dir / "b4_predicted_only.json",
            ),
        )
    for method, runtime_path in required_runtime:
        expected_runtime_checkpoint = (
            nnunet_checkpoint_sha256 if method == "nnUNet_v2_2D" else None
        )
        runtime = _load_required_efficiency(
            runtime_path, method, expected_runtime_checkpoint
        )
        efficiency.append(
            {
                "seed": seed,
                "outer_fold": fold,
                "method": method,
                "parameter_count": runtime["total_system_parameter_count"],
                "total_system_parameter_count": runtime["total_system_parameter_count"],
                "seconds_per_image": runtime["seconds_per_image"],
                "throughput_images_per_second": runtime["throughput_images_per_second"],
                "peak_vram_gib": runtime["peak_vram_gib"],
                "measurement_status": runtime["measurement_status"],
                "parameter_scope": runtime["parameter_scope"],
                "peak_vram_scope": "predicted_only_deployed_system",
                "box_condition": runtime["box_condition"],
                "ground_truth_pixels_read": runtime["ground_truth_pixels_read"],
                "checkpoint_sha256": runtime.get("checkpoint_sha256"),
                "mean_candidates_per_image": (
                    sum(not row.get("is_sentinel") for row in verifier_input)
                    / len({row["image_id"] for row in verifier_input})
                    if method.startswith(("B3_", "B4_", "B5_"))
                    else None
                ),
            }
        )
    observed_required = {
        row["method"]
        for row in efficiency
        if row.get("measurement_status") == "MEASURED_PREDICTED_ONLY_END_TO_END"
    }
    expected_required = {method for method, _ in required_runtime}
    if observed_required != expected_required:
        raise RuntimeError(
            f"EFFICIENCY_REQUIRED_METHODS_INCOMPLETE: expected={expected_required}, observed={observed_required}"
        )
    atomic_csv(run_dir / "efficiency.csv", efficiency)
    efficiency_runtime_hashes = {
        str(path.relative_to(run_dir)): sha256_file(path) for _, path in required_runtime
    }
    completion = {
        "schema_version": 1,
        "status": "COMPLETE",
        "seed": seed,
        "outer_fold": fold,
        "completed_at": utc_now(),
        "results_sha256": sha256_file(run_dir / "results.csv"),
        "robustness_sha256": sha256_file(run_dir / "robustness.csv"),
        "failure_threshold_sensitivity_sha256": sha256_file(
            run_dir / "failure_threshold_sensitivity.csv"
        ),
        "risk_coverage_sha256": sha256_file(run_dir / "risk_coverage.csv"),
        "multicomponent_sha256": sha256_file(run_dir / "multicomponent_cases.csv"),
        "efficiency_sha256": sha256_file(run_dir / "efficiency.csv"),
        "efficiency_runtime_sha256s": efficiency_runtime_hashes,
        "efficiency_status": "COMPLETE_PREDICTED_ONLY_END_TO_END_REQUIRED_METHODS",
        "detection_froc_sha256": sha256_file(run_dir / "detection_froc.csv"),
        "system_operating_point_sha256": sha256_file(run_dir / "system_operating_point.csv"),
        "leakage_ablation_provenance_sha256": sha256_file(leakage_paths["provenance"]),
        "leakage_ablation_result_sha256": sha256_file(leakage_paths["result"]),
        "nnunet_completion_sha256": sha256_file(
            nnunet_root / "NNUNET_COMPLETE.json"
        ),
        "nnunet_checkpoint_sha256": nnunet_checkpoint_sha256,
        "g3_decision": g3["decision"],
        "pointrend_role": "optional_key_secondary" if include_pointrend_main else "not_reportable",
        "b5_default_upstream": "B3_FPN_MedSAM",
    }
    atomic_json(run_dir / "fold_complete.json", completion)
    return completion


def _fold_complete(path: Path, expected_spec: dict[str, Any] | None = None) -> bool:
    marker = path / "fold_complete.json"
    if expected_spec is None or marker.is_symlink() or not marker.is_file():
        return False
    try:
        spec_path = path / "RUN_SPEC.json"
        if spec_path.is_symlink() or not spec_path.is_file():
            raise RuntimeError(f"Completed fold lacks RUN_SPEC.json: {path}")
        observed_spec = json.loads(spec_path.read_text(encoding="utf-8"))
        drift = {
            key: {"expected": value, "observed": observed_spec.get(key)}
            for key, value in expected_spec.items()
            if observed_spec.get(key) != value
        }
        if drift:
            raise RuntimeError(f"STALE_FULL_RESUME_FINGERPRINT at {path}: {drift}")
        split_path = path / "provenance" / "split.json"
        if (
            split_path.is_symlink()
            or not split_path.is_file()
            or observed_spec.get("split_sha256") != sha256_file(split_path)
        ):
            return False
        split = json.loads(split_path.read_text(encoding="utf-8"))
        split_expected = {
            "mode": "phase2",
            "seed": expected_spec["seed"],
            "outer_fold": expected_spec["outer_fold"],
            "config_sha256": expected_spec["config_sha256"],
            "manifest_sha256": expected_spec["manifest_sha256"],
        }
        if any(split.get(key) != value for key, value in split_expected.items()):
            return False
        sequence_fields = (
            "train_image_ids",
            "evaluation_image_ids",
            "train_patient_ids",
            "evaluation_patient_ids",
        )
        if any(
            not isinstance(split.get(key), list)
            or not split[key]
            or any(not isinstance(value, str) or not value for value in split[key])
            or len(split[key]) != len(set(split[key]))
            for key in sequence_fields
        ):
            return False
        if set(split["train_image_ids"]) & set(split["evaluation_image_ids"]):
            return False
        if set(split["train_patient_ids"]) & set(split["evaluation_patient_ids"]):
            return False
        payload = json.loads(marker.read_text(encoding="utf-8"))
        base_complete = all(
            (path / file).is_file() and sha256_file(path / file) == payload[key]
            for file, key in [
                ("results.csv", "results_sha256"),
                ("robustness.csv", "robustness_sha256"),
                (
                    "failure_threshold_sensitivity.csv",
                    "failure_threshold_sensitivity_sha256",
                ),
                ("risk_coverage.csv", "risk_coverage_sha256"),
                ("multicomponent_cases.csv", "multicomponent_sha256"),
                ("efficiency.csv", "efficiency_sha256"),
                ("detection_froc.csv", "detection_froc_sha256"),
                ("system_operating_point.csv", "system_operating_point_sha256"),
                (
                    f"ablations/{LEAKAGE_ABLATION_SLUG}/provenance.json",
                    "leakage_ablation_provenance_sha256",
                ),
                (
                    f"ablations/{LEAKAGE_ABLATION_SLUG}/result.json",
                    "leakage_ablation_result_sha256",
                ),
            ]
        )
        if not base_complete:
            return False
        runtime_hashes = payload.get("efficiency_runtime_sha256s")
        if not isinstance(runtime_hashes, dict) or not runtime_hashes:
            return False
        for relative, expected_sha in runtime_hashes.items():
            candidate = (path / relative).resolve()
            try:
                candidate.relative_to(path.resolve())
            except ValueError:
                return False
            if not candidate.is_file() or sha256_file(candidate) != expected_sha:
                return False
        nnunet_marker = path / "nnunet" / "NNUNET_COMPLETE.json"
        if (
            nnunet_marker.is_symlink()
            or not nnunet_marker.is_file()
            or payload.get("nnunet_completion_sha256")
            != sha256_file(nnunet_marker)
        ):
            return False
        nnunet_valid, _, checkpoint_sha256 = nnunet_completion_valid(
            path / "nnunet",
            dataset_id=(
                int(expected_spec["nnunet_dataset_base_id"])
                + int(expected_spec["outer_fold"])
            ),
            configuration=str(expected_spec["nnunet_configuration"]),
            trainer=str(expected_spec["nnunet_trainer"]),
            fold=int(expected_spec["outer_fold"]),
            seed=int(expected_spec["seed"]),
            config_sha256=str(expected_spec["config_sha256"]),
            expected_image_ids=split["evaluation_image_ids"],
            expected_training_image_ids=split["train_image_ids"],
            expected_training_patient_ids=split["train_patient_ids"],
            expected_evaluation_patient_ids=split["evaluation_patient_ids"],
        )
        if (
            not nnunet_valid
            or checkpoint_sha256 is None
            or payload.get("nnunet_checkpoint_sha256") != checkpoint_sha256
            or not _candidate_valid(
                path / "nnunet" / "candidates.jsonl", checkpoint_sha256
            )
        ):
            return False
        return (
            payload.get("efficiency_status")
            == "COMPLETE_PREDICTED_ONLY_END_TO_END_REQUIRED_METHODS"
        )
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError):
        return False


def run_full(config_path: Path) -> dict[str, Any]:
    root_from_env = Path(os.environ.get("SCREENBUS_ROOT", "")).resolve()
    config_path = require_canonical_config(config_path, root_from_env, "phase2")
    env = resolve_environment()
    root = env["SCREENBUS_ROOT"]
    if root != root_from_env:
        raise RuntimeError("FULL_FORBIDDEN_SCREENBUS_ROOT_ENV_DRIFT")
    cfg = load_config(config_path)
    g3 = _authorized_g3(root, live_authorization="perform")
    full_root = env["SCREENBUS_OUTPUT_ROOT"] / "phase2"
    manifest_path = resolve_project_path(root, cfg["manifest"])
    code_files = [
        path
        for path in (root / "server_bundle" / "screenbus_a0_v2").rglob("*")
        if path.is_file() and path.suffix in {".py", ".yaml", ".yml"}
    ]
    invariant_spec = {
        "schema_version": 1,
        "mode": "phase2",
        "config_sha256": cfg["_config_sha256"],
        "manifest_sha256": sha256_file(manifest_path),
        "git_commit": git_commit(root),
        "code_tree_sha256": sha256_tree(code_files),
        "g3_decision": g3["decision"],
        "g3_gate_sha256": sha256_file(root / "gates" / "G3_A0_DECISION.json"),
        "g3_status_run_id": g3["status_run_id"],
        "g3_attempt": g3["g3_attempt"],
        "nnunet_dataset_base_id": int(cfg["nnunet"]["dataset_id"]),
        "nnunet_configuration": cfg["nnunet"]["configuration"],
        "nnunet_trainer": cfg["nnunet"]["trainer"],
    }
    tasks: list[GPUTask] = []
    expected_task_ids: list[str] = []
    precompleted_task_ids: list[str] = []
    for seed in cfg["seeds"]:
        for fold in cfg["outer_folds"]:
            run_dir = full_root / f"seed_{seed}" / f"fold_{fold}"
            task_id = f"phase2_seed{seed}_fold{fold}"
            expected_task_ids.append(task_id)
            expected_spec = {
                **invariant_spec,
                "seed": seed,
                "outer_fold": fold,
                "pythonhashseed_at_process_start": str(seed),
            }
            if _fold_complete(run_dir, expected_spec):
                precompleted_task_ids.append(task_id)
            else:
                tasks.append(
                    GPUTask(
                        task_id,
                        [
                            sys.executable,
                            "-m",
                            "screenbus_a0_v2.cli",
                            "phase2-fold",
                            "--config",
                            str(config_path),
                            "--seed",
                            str(seed),
                            "--outer-fold",
                            str(fold),
                            "--run-dir",
                            str(run_dir),
                        ],
                        "heavy",
                        {"seed": seed, "outer_fold": fold},
                        {
                            "PYTHONHASHSEED": str(seed),
                            "SCREENBUS_SEED": str(seed),
                        },
                    )
                )
    ResourceAwareScheduler(cfg, env["SCREENBUS_OUTPUT_ROOT"]).run(
        tasks,
        expected_task_ids=expected_task_ids,
        precompleted_task_ids=precompleted_task_ids,
    )
    import csv

    combined_results: list[dict[str, Any]] = []
    combined_robustness: list[dict[str, Any]] = []
    combined_failure_sensitivity: list[dict[str, Any]] = []
    combined_risk: list[dict[str, Any]] = []
    combined_efficiency: list[dict[str, Any]] = []
    combined_multi: list[dict[str, Any]] = []
    combined_detection: list[dict[str, Any]] = []
    combined_system: list[dict[str, Any]] = []
    for seed in cfg["seeds"]:
        for fold in cfg["outer_folds"]:
            run_dir = full_root / f"seed_{seed}" / f"fold_{fold}"
            expected_spec = {
                **invariant_spec,
                "seed": seed,
                "outer_fold": fold,
                "pythonhashseed_at_process_start": str(seed),
            }
            if not _fold_complete(run_dir, expected_spec):
                raise RuntimeError(f"Full fold is incomplete after scheduler: seed={seed}, fold={fold}")
            for target, filename in [
                (combined_results, "results.csv"),
                (combined_robustness, "robustness.csv"),
                (combined_failure_sensitivity, "failure_threshold_sensitivity.csv"),
                (combined_risk, "risk_coverage.csv"),
                (combined_efficiency, "efficiency.csv"),
                (combined_multi, "multicomponent_cases.csv"),
                (combined_detection, "detection_froc.csv"),
                (combined_system, "system_operating_point.csv"),
            ]:
                with (run_dir / filename).open("r", encoding="utf-8", newline="") as handle:
                    target.extend(csv.DictReader(handle))
    b5_efficiency_name = "B5_OOF_Verifier"
    required_efficiency_methods = {
        "nnUNet_v2_2D",
        "B1_DeepLabV3Plus_HardGate",
        "MaskRCNN_R50_FPN",
        "AutoBUSAM_adapted_YOLOv8s_SAMLoRA",
        "B3_FPN_MedSAM",
        b5_efficiency_name,
    }
    if g3["decision"] == "GO_EXPAND_TO_PHASE2":
        required_efficiency_methods.add("B4_OriginalPointRend_Diagnostic")
    expected_runs = len(cfg["seeds"]) * len(cfg["outer_folds"])
    for method in required_efficiency_methods:
        rows = [row for row in combined_efficiency if row.get("method") == method]
        if len(rows) != expected_runs:
            raise RuntimeError(
                f"FULL_EFFICIENCY_INCOMPLETE for {method}: expected {expected_runs}, got {len(rows)}"
            )
        for row in rows:
            if row.get("measurement_status") != "MEASURED_PREDICTED_ONLY_END_TO_END":
                raise RuntimeError(f"FULL_EFFICIENCY_NOT_PREDICTED_ONLY for {method}")
            for key in (
                "seconds_per_image",
                "throughput_images_per_second",
                "peak_vram_gib",
                "total_system_parameter_count",
            ):
                try:
                    value = float(row[key])
                except (KeyError, TypeError, ValueError) as exc:
                    raise RuntimeError(f"FULL_EFFICIENCY_INVALID {method}.{key}") from exc
                if not np.isfinite(value) or value <= 0:
                    raise RuntimeError(f"FULL_EFFICIENCY_INVALID {method}.{key}={value}")
    reports = root / "reports"
    atomic_csv(reports / "full_results.csv", combined_results)
    atomic_csv(reports / "full_robustness.csv", combined_robustness)
    atomic_csv(
        reports / "full_failure_threshold_sensitivity.csv",
        combined_failure_sensitivity,
    )
    atomic_csv(reports / "full_risk_coverage.csv", combined_risk)
    atomic_csv(reports / "full_efficiency.csv", combined_efficiency)
    atomic_csv(reports / "full_multicomponent_cases.csv", combined_multi)
    atomic_csv(reports / "full_detection_froc.csv", combined_detection)
    atomic_csv(reports / "full_system_operating_point.csv", combined_system)
    # Merge the five disjoint outer-test folds within each seed before
    # bootstrapping. The clean primary cohort has 31 patients; the 32-patient
    # all-view cohort remains a preregistered robustness analysis only.
    # rather than incorrectly bootstrapping six-patient fold summaries.
    patient_bootstrap_rows: list[dict[str, Any]] = []
    paired_comparison_rows: list[dict[str, Any]] = []
    include_pointrend_main = g3["decision"] == "GO_EXPAND_TO_PHASE2"
    for seed in cfg["seeds"]:
        per_method: dict[str, dict[str, list[Any]]] = defaultdict(lambda: {"rows": [], "scores": []})

        def add(method: str, rows: list[dict[str, Any]], scores: list[float], threshold: float):
            per_method[method]["rows"].extend(rows)
            per_method[method]["scores"].extend(
                [1.0 if (not row.get("is_sentinel") and score >= threshold) else -1e9 for row, score in zip(rows, scores)]
            )

        for fold in cfg["outer_folds"]:
            run_dir = full_root / f"seed_{seed}" / f"fold_{fold}"
            for method, path in [
                ("nnUNet_v2_2D", run_dir / "nnunet" / "candidates.jsonl"),
                ("B1_DeepLabV3Plus_HardGate", run_dir / "baselines" / "b1" / "candidates.jsonl"),
                ("MaskRCNN_R50_FPN", run_dir / "baselines" / "mask_rcnn" / "candidates.jsonl"),
                ("AutoBUSAM_adapted_YOLOv8s_SAMLoRA", run_dir / "baselines" / "autobusam_style" / "candidates.jsonl"),
            ]:
                rows = [
                    row
                    for row in load_candidate_rows(path)
                    if bool(int(row.get("is_clean", 0)))
                ]
                add(method, rows, _scores_all(rows), 0.0)
            raw = load_candidate_rows(run_dir / "candidates" / "evaluation" / "candidates.jsonl")
            predicted = [
                row
                for row in raw
                if row["condition"] == "predicted_box"
                and bool(int(row.get("is_clean", 0)))
            ]
            b3_thresholds = json.loads(
                (run_dir / "verifier_b3" / "thresholds.json").read_text(encoding="utf-8")
            )
            detector_scores = [
                -1e9 if row.get("is_sentinel") else row["feature_map"]["detector_score"]
                for row in predicted
            ]
            add(
                "B3_FPN_MedSAM",
                predicted,
                detector_scores,
                float(b3_thresholds["detector_score"]["threshold"]),
            )
            verifier_label = "b3"
            verifier_rows_all = [
                row for row in raw if row["condition"] == "predicted_box"
            ]
            verifier_clean_indices = [
                index
                for index, row in enumerate(verifier_rows_all)
                if bool(int(row.get("is_clean", 0)))
            ]
            verifier_rows = [verifier_rows_all[index] for index in verifier_clean_indices]
            verifier_thresholds = json.loads(
                (run_dir / f"verifier_{verifier_label}" / "thresholds.json").read_text(encoding="utf-8")
            )
            verifier_score_payload = json.loads(
                (run_dir / f"verifier_{verifier_label}" / "evaluation_scores.json").read_text(encoding="utf-8")
            )
            add(
                "B5_OOF_Verifier",
                verifier_rows,
                [
                    1.0
                    if existence >= float(verifier_thresholds["verifier"]["existence_threshold"])
                    and quality >= float(verifier_thresholds["verifier"]["quality_threshold"])
                    else -1e9
                    for existence, quality in zip(
                        [
                            verifier_score_payload["verifier_existence"][index]
                            for index in verifier_clean_indices
                        ],
                        [
                            verifier_score_payload["verifier_quality"][index]
                            for index in verifier_clean_indices
                        ],
                    )
                ],
                0.5,
            )
            strongest_name = str(
                verifier_thresholds["strongest_simple_control"]["name"]
            )
            if strongest_name not in SIMPLE_CONTROLS:
                raise RuntimeError("STRONGEST_SIMPLE_CONTROL_NOT_REGISTERED")
            add(
                "Strongest_Simple_Control_Frozen_Inner_Meta_OOF",
                verifier_rows,
                [
                    verifier_score_payload[strongest_name][index]
                    for index in verifier_clean_indices
                ],
                float(verifier_thresholds[strongest_name]["threshold"]),
            )
            if include_pointrend_main:
                fold_pointrend_status = json.loads(
                    (run_dir / "pointrend_diagnostic_status.json").read_text(
                        encoding="utf-8"
                    )
                )
                refined_rows_all = load_candidate_rows(
                    Path(fold_pointrend_status["selected_evaluation_candidates"])
                )
                refined_rows = [
                    row
                    for row in refined_rows_all
                    if bool(int(row.get("is_clean", 0)))
                ]
                refined_scores = [
                    -1e9 if row.get("is_sentinel") else row["feature_map"]["detector_score"]
                    for row in refined_rows
                ]
                add(
                    "B4_OriginalPointRend_Diagnostic",
                    refined_rows,
                    refined_scores,
                    float(b3_thresholds["detector_score"]["threshold"]),
                )
        for method, payload in per_method.items():
            patient_ids = {row["patient_id"] for row in payload["rows"]}
            if len(patient_ids) != 31:
                raise RuntimeError(
                    f"Patient-bootstrap clean merge expected 31 patients for seed={seed}, method={method}; got {len(patient_ids)}"
                )
            metrics, intervals = evaluate_candidate_method(
                payload["rows"], payload["scores"], 0.5, cfg["bootstrap_replicates"], int(seed)
            )
            row = {"seed": seed, "method": method, "patient_count": len(patient_ids)}
            bootstrap_metrics = {
                "lesion_sensitivity",
                "patient_macro_dice",
                "hd95",
                "boundary_f1",
                "normal_fp_masks_per_image",
                "normal_image_fp_rate",
                "normal_fp_area_per_image",
            }
            row.update({key: value for key, value in metrics.items() if key in bootstrap_metrics})
            for metric, interval in intervals.items():
                if metric not in bootstrap_metrics:
                    continue
                row[f"{metric}_ci_low"] = interval[0]
                row[f"{metric}_ci_high"] = interval[1]
            patient_bootstrap_rows.append(row)
        b5_method = "B5_OOF_Verifier"
        reference_method = "Strongest_Simple_Control_Frozen_Inner_Meta_OOF"
        comparisons = [(b5_method, reference_method, "PRIMARY_B5_VS_FROZEN_STRONGEST_SIMPLE_CONTROL")]
        if include_pointrend_main:
            comparisons.append(("B4_OriginalPointRend_Diagnostic", "B3_FPN_MedSAM", "OPTIONAL_BOUNDARY_ABLATION_B4_VS_B3"))
        for treatment_method, comparator_method, role in comparisons:
            treatment = per_method[treatment_method]
            comparator = per_method[comparator_method]
            paired = paired_patient_bootstrap(
                comparator["rows"],
                comparator["scores"],
                0.5,
                treatment["rows"],
                treatment["scores"],
                0.5,
                cfg["bootstrap_replicates"],
                int(seed),
            )
            for metric, interval in paired.items():
                paired_comparison_rows.append(
                    {
                        "seed": seed,
                        "role": role,
                        "treatment": treatment_method,
                        "comparator": comparator_method,
                        "metric": metric,
                        **interval,
                        "bootstrap_unit": "patient_cluster_paired",
                        "replicates": cfg["bootstrap_replicates"],
                        "analysis_cohort": "BUS_UCLM_clean_outer_OOF",
                    }
                )
    atomic_csv(reports / "full_patient_bootstrap.csv", patient_bootstrap_rows)
    atomic_csv(reports / "full_paired_comparisons.csv", paired_comparison_rows)
    if include_pointrend_main:
        pointrend_by_seed: dict[int, dict[str, dict[str, Any]]] = defaultdict(dict)
        for row in paired_comparison_rows:
            if row["role"] == "OPTIONAL_BOUNDARY_ABLATION_B4_VS_B3":
                pointrend_by_seed[int(row["seed"])][str(row["metric"])] = row
        expected_seeds = {int(seed) for seed in cfg["seeds"]}
        if set(pointrend_by_seed) != expected_seeds or any(
            {"boundary_f1_delta", "hd95_delta"} - set(metrics)
            for metrics in pointrend_by_seed.values()
        ):
            raise RuntimeError("POINTREND_ABLATION_COMPARISON_INCOMPLETE")
        pointrend_kept = all(
            metrics["boundary_f1_delta"]["ci_low"] > 0.0
            and metrics["hd95_delta"]["ci_high"] <= 0.0
            for metrics in pointrend_by_seed.values()
        )
        pointrend_ablation = {
            "status": (
                "KEEP_ORIGINAL_POINTREND_STABLE_BOUNDARY_GAIN_NO_HD95_WORSENING"
                if pointrend_kept
                else "DELETE_POINTREND_NO_STABLE_BOUNDARY_GAIN_OR_HD95_WORSENING"
            ),
            "reported_as_main_route": False,
            "b3_b5_route_affected": False,
            "per_seed": pointrend_by_seed,
        }
    else:
        pointrend_ablation = {
            "status": "NOT_RUN_OR_DROPPED_OPTIONAL_ABLATION",
            "reported_as_main_route": False,
            "b3_b5_route_affected": False,
        }
    metric_names = [
        "lesion_sensitivity",
        "patient_macro_dice",
        "hd95",
        "boundary_f1",
        "normal_fp_masks_per_image",
        "normal_image_fp_rate",
        "failure_auprc",
        "failure_ece_10bin",
        "failure_brier",
        "failure_nll",
    ]
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in combined_results:
        grouped[(row["method"], row["box_condition"])].append(row)
    aggregate_rows = []
    for (method, condition), rows in grouped.items():
        table_roles = {row.get("table_role") for row in rows}
        if len(table_roles) != 1:
            raise RuntimeError(
                f"Inconsistent table roles across fold/seed runs for {method}: {table_roles}"
            )
        aggregate = {
            "method": method,
            "box_condition": condition,
            "fold_seed_runs": len(rows),
            "table_role": next(iter(table_roles)),
        }
        if method == LEAKAGE_ABLATION_LABEL:
            if aggregate["table_role"] != "ABLATION":
                raise RuntimeError("Leakage demonstration entered a non-ablation aggregate")
            aggregate["valid_method"] = False
            aggregate["claim_status"] = LEAKAGE_ABLATION_LABEL
        for metric in metric_names:
            values = [float(row[metric]) for row in rows if row.get(metric) not in {None, "", "nan", "NaN"}]
            aggregate[f"{metric}_mean"] = float(np.mean(values)) if values else None
            aggregate[f"{metric}_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else None
            aggregate[f"{metric}_min"] = min(values) if values else None
            aggregate[f"{metric}_max"] = max(values) if values else None
        aggregate_rows.append(aggregate)
    unique_multi_by_seed = {
        str(seed): sorted(
            {
                row["image_id"]
                for row in combined_multi
                if int(row["seed"]) == int(seed)
            }
        )
        for seed in cfg["seeds"]
    }
    for seed, image_ids in unique_multi_by_seed.items():
        if len(image_ids) != 11:
            raise RuntimeError(f"Expected 11 multi-component cases for seed {seed}, observed {len(image_ids)}")
    immutable_prediction_paths = sorted(
        {
            path
            for pattern in (
                "**/candidates.jsonl",
                "**/evaluation_scores.json",
                "**/training_scores.json",
                "**/masks/*.npz",
                "**/candidate_masks/*.npz",
                "**/predictions/*.png",
            )
            for path in full_root.glob(pattern)
            if path.is_file()
        }
    )
    if not immutable_prediction_paths:
        raise RuntimeError("FULL_IMMUTABLE_PREDICTION_SET_EMPTY")
    prediction_manifest_entries = []
    for path in immutable_prediction_paths:
        path.chmod(0o444)
        prediction_manifest_entries.append(
            {
                "path": str(path.relative_to(root)),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
                "mode": "0444",
            }
        )
    prediction_manifest_path = reports / "full_prediction_manifest.json"
    atomic_json(
        prediction_manifest_path,
        {
            "schema_version": 1,
            "status": "FROZEN_READ_ONLY",
            "analysis_cohort": "BUS_UCLM_clean_outer_OOF_primary_with_registered_secondary_predictions",
            "entry_count": len(prediction_manifest_entries),
            "entries": prediction_manifest_entries,
        },
    )
    prediction_manifest_path.chmod(0o444)
    aggregate_payload = {
        "schema_version": 1,
        "protocol_version": "2.3",
        "status": "PHASE2_COMPLETE",
        "evidence_semantics": "SAME_COHORT_MULTI_SEED_AND_FULL_BASELINE_SENSITIVITY",
        "independent_confirmation": False,
        "external_validation": False,
        "phase1_selection_bias_removed": False,
        "sealed_patients_in_primary_results": False,
        "sealed_patients_support_normal_population_inference": False,
        "completed_at": utc_now(),
        "g3_decision": g3["decision"],
        "seeds": cfg["seeds"],
        "outer_folds": cfg["outer_folds"],
        "pointrend_ablation": pointrend_ablation,
        "efficiency_gate": {
            "status": "PASS_PREDICTED_ONLY_END_TO_END_REQUIRED_METHODS",
            "required_methods": sorted(required_efficiency_methods),
            "fold_seed_runs_per_method": expected_runs,
            "required_fields": [
                "seconds_per_image",
                "throughput_images_per_second",
                "peak_vram_gib",
                "total_system_parameter_count",
            ],
            "ground_truth_pixels_read": False,
        },
        "aggregate": aggregate_rows,
        "uncertainty": {
            "unit": "patient",
            "per_seed_clean_31_patient_bootstrap_replicates": cfg["bootstrap_replicates"],
            "patient_bootstrap_report": str(reports / "full_patient_bootstrap.csv"),
            "paired_comparison_report": str(reports / "full_paired_comparisons.csv"),
            "immutable_prediction_manifest": str(prediction_manifest_path),
            "aggregate_across_seed_fold": "mean_std_min_max_descriptive_only_plus_per_seed_clean_31_patient_cluster_CI",
            "warning": "Do not interpret 32-patient small differences as stable clinical superiority.",
        },
        "multi_component": {
            "n_images_per_seed": 11,
            "role": "DESCRIPTIVE_STRESS_TEST_ONLY_NO_GENERALIZATION_CLAIM",
            "image_ids_by_seed": unique_multi_by_seed,
        },
        "reports": {
            "results": str(reports / "full_results.csv"),
            "robustness": str(reports / "full_robustness.csv"),
            "failure_threshold_sensitivity": str(
                reports / "full_failure_threshold_sensitivity.csv"
            ),
            "risk_coverage": str(reports / "full_risk_coverage.csv"),
            "efficiency": str(reports / "full_efficiency.csv"),
            "multi_component": str(reports / "full_multicomponent_cases.csv"),
            "detection_froc": str(reports / "full_detection_froc.csv"),
            "system_operating_point": str(reports / "full_system_operating_point.csv"),
        },
    }
    atomic_json(reports / "full_aggregate.json", aggregate_payload)
    return aggregate_payload
