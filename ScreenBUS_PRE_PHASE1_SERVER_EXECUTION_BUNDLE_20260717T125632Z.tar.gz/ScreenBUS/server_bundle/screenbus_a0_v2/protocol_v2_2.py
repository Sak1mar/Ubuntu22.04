"""Read-only ScreenBUS v2.2 historical marker.

The executable v2.2 protocol was retired by P0_V2_3_PROTOCOL_AND_SOURCE_REPAIR.
Active code must import :mod:`protocol_v2_3`.  This module deliberately exposes
no execution or decision helpers so an old import fails closed.
"""

PROTOCOL_VERSION = "2.2"
ACTIVE = False
HISTORICAL_STATUS = "READ_ONLY_RETIRED_PROTOCOL"


def __getattr__(name: str):
    raise RuntimeError(
        f"SCREENBUS_PROTOCOL_V2_2_RETIRED: {name}; active protocol is v2.3"
    )


__all__ = ["ACTIVE", "HISTORICAL_STATUS", "PROTOCOL_VERSION"]
