"""ScreenBUS server A0 and conditional full-CV experiment runner.

This package intentionally contains only executable research code.  It does not
claim that an experiment has run until the corresponding provenance records and
result files have been written by :mod:`screenbus_a0_v2.pipeline`.
"""

__version__ = "2.1.0"
