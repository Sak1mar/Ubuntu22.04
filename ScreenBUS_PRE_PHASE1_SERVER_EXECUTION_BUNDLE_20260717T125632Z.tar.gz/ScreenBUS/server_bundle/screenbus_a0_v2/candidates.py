from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import torch
from PIL import Image
from scipy import ndimage
from scipy.optimize import linear_sum_assignment
from torchvision.transforms import functional as TF

from .data import ManifestRecord, connected_instances, instance_boxes, mask_binary
from .models import MedSAMAdapter
from .util import sha256_file, utc_now


FEATURE_NAMES = [
    "detector_score",
    "detector_rank_inverse",
    "image_presence_probability",
    "sam_predicted_iou",
    "jitter_iou_mean",
    "jitter_iou_variance_inverse",
    "jitter_iou_worst",
    "area_ratio",
    "component_count_log",
    "compactness",
    "box_mask_coverage",
    "box_area_ratio",
    "box_aspect_log",
    "border_touch",
    "refiner_area_change_abs",
    "refiner_boundary_change",
    "refiner_component_change_abs",
]


def binary_iou(first: np.ndarray, second: np.ndarray) -> float:
    intersection = np.logical_and(first, second).sum()
    union = np.logical_or(first, second).sum()
    return float(intersection / union) if union else 1.0


def binary_dice(first: np.ndarray, second: np.ndarray) -> float:
    intersection = np.logical_and(first, second).sum()
    total = first.sum() + second.sum()
    return float(2 * intersection / total) if total else 1.0


def box_iou(first: np.ndarray, second: np.ndarray) -> float:
    x1, y1 = np.maximum(first[:2], second[:2])
    x2, y2 = np.minimum(first[2:], second[2:])
    intersection = max(0.0, float(x2 - x1)) * max(0.0, float(y2 - y1))
    first_area = max(0.0, float(first[2] - first[0])) * max(0.0, float(first[3] - first[1]))
    second_area = max(0.0, float(second[2] - second[0])) * max(0.0, float(second[3] - second[1]))
    union = first_area + second_area - intersection
    return intersection / union if union else 0.0


def _box_center_in_mask(box: np.ndarray, mask: np.ndarray) -> bool:
    x = int(np.clip(np.floor((float(box[0]) + float(box[2])) / 2.0), 0, mask.shape[1] - 1))
    y = int(np.clip(np.floor((float(box[1]) + float(box[3])) / 2.0), 0, mask.shape[0] - 1))
    return bool(mask[y, x])


def _one_to_one_matches(
    candidate_boxes: np.ndarray,
    candidate_scores: Sequence[float],
    gt_instances: Sequence[np.ndarray],
    eligible,
) -> list[int]:
    matches = [-1] * len(candidate_boxes)
    unmatched = set(range(len(gt_instances)))
    order = sorted(range(len(candidate_boxes)), key=lambda index: (-float(candidate_scores[index]), index))
    for candidate_index in order:
        eligible_targets = [target for target in sorted(unmatched) if eligible(candidate_index, target)]
        if not eligible_targets:
            continue
        target = eligible_targets[0]
        matches[candidate_index] = target
        unmatched.remove(target)
    return matches


def primary_candidate_matches(
    candidate_boxes: np.ndarray,
    candidate_scores: Sequence[float],
    gt_instances: Sequence[np.ndarray],
) -> list[int]:
    """Primary PDF match: box centre in component, confidence-ordered 1:1."""
    boxes = np.asarray(candidate_boxes, dtype=np.float32).reshape(-1, 4)
    if len(boxes) != len(candidate_scores):
        raise ValueError("candidate boxes and scores must align")
    return _one_to_one_matches(
        boxes,
        candidate_scores,
        gt_instances,
        lambda candidate, target: _box_center_in_mask(boxes[candidate], gt_instances[target]),
    )


def sensitivity_candidate_matches(
    candidate_boxes: np.ndarray,
    candidate_scores: Sequence[float],
    gt_instances: Sequence[np.ndarray],
    iou_threshold: float = 0.3,
) -> list[int]:
    """Frozen box-IoU sensitivity match; never used as the primary label."""
    boxes = np.asarray(candidate_boxes, dtype=np.float32).reshape(-1, 4)
    gt_boxes = instance_boxes(gt_instances)
    if len(boxes) != len(candidate_scores):
        raise ValueError("candidate boxes and scores must align")
    if not 0.0 <= float(iou_threshold) <= 1.0:
        raise ValueError("sensitivity IoU threshold must be in [0, 1]")
    return _one_to_one_matches(
        boxes,
        candidate_scores,
        gt_instances,
        lambda candidate, target: box_iou(boxes[candidate], gt_boxes[target]) >= iou_threshold,
    )


def hungarian_mask_matches(
    predicted_masks: Sequence[np.ndarray], gt_instances: Sequence[np.ndarray]
) -> list[int]:
    """One-to-one segmentation matching with cost 1-mask IoU."""
    matches = [-1] * len(predicted_masks)
    if not predicted_masks or not gt_instances:
        return matches
    similarities = np.asarray(
        [[binary_iou(prediction, target) for target in gt_instances] for prediction in predicted_masks],
        dtype=float,
    )
    predicted_indices, target_indices = linear_sum_assignment(1.0 - similarities)
    for predicted_index, target_index in zip(predicted_indices, target_indices):
        matches[int(predicted_index)] = int(target_index)
    return matches


def jitter_box(box: np.ndarray, width: int, height: int, fraction: float, rng: np.random.Generator) -> np.ndarray:
    box = box.astype(np.float32).copy()
    size = np.asarray([box[2] - box[0], box[3] - box[1]], dtype=np.float32)
    noise = rng.uniform(-fraction, fraction, size=4) * np.asarray([size[0], size[1], size[0], size[1]])
    box += noise
    box[[0, 2]] = np.clip(box[[0, 2]], 0, width)
    box[[1, 3]] = np.clip(box[[1, 3]], 0, height)
    if box[2] <= box[0] + 1:
        box[2] = min(width, box[0] + 2)
    if box[3] <= box[1] + 1:
        box[3] = min(height, box[1] + 2)
    return box


def _candidate_features(
    mask: np.ndarray,
    box: np.ndarray,
    detector_score: float,
    sam_iou: float,
    jitter_masks: list[np.ndarray],
    *,
    detector_rank: int = 0,
    image_presence_probability: float = 0.0,
) -> dict[str, float]:
    height, width = mask.shape
    area_ratio = float(mask.mean())
    components = int(ndimage.label(mask, structure=np.ones((3, 3), dtype=np.uint8))[1])
    jitter_ious = [binary_iou(mask, candidate) for candidate in jitter_masks]
    stability = float(np.mean(jitter_ious)) if jitter_ious else 1.0
    jitter_variance = float(np.var(jitter_ious)) if jitter_ious else 0.0
    jitter_worst = float(min(jitter_ious)) if jitter_ious else 1.0
    box_width, box_height = max(float(box[2] - box[0]), 1.0), max(float(box[3] - box[1]), 1.0)
    boundary = np.logical_xor(mask.astype(bool), ndimage.binary_erosion(mask.astype(bool)))
    perimeter = float(boundary.sum())
    compactness = float(4.0 * np.pi * mask.sum() / max(perimeter * perimeter, 1.0))
    x1, y1 = int(max(0, np.floor(box[0]))), int(max(0, np.floor(box[1])))
    x2, y2 = int(min(width, np.ceil(box[2]))), int(min(height, np.ceil(box[3])))
    inside = float(mask[y1:y2, x1:x2].sum()) if x2 > x1 and y2 > y1 else 0.0
    border_touch = float(
        bool(mask[0].any() or mask[-1].any() or mask[:, 0].any() or mask[:, -1].any())
    )
    return {
        "detector_score": float(detector_score),
        "detector_rank_inverse": 1.0 / float(detector_rank + 1),
        "image_presence_probability": float(image_presence_probability),
        "sam_predicted_iou": float(sam_iou),
        "jitter_iou_mean": stability,
        "jitter_iou_variance_inverse": 1.0 - jitter_variance,
        "jitter_iou_worst": jitter_worst,
        "area_ratio": area_ratio,
        "component_count_log": math.log1p(components),
        "compactness": compactness,
        "box_mask_coverage": inside / max(float(mask.sum()), 1.0),
        "box_area_ratio": box_width * box_height / (width * height),
        "box_aspect_log": abs(math.log(box_width / box_height)),
        "border_touch": border_touch,
        "refiner_area_change_abs": 0.0,
        "refiner_boundary_change": 0.0,
        "refiner_component_change_abs": 0.0,
    }


def _label_candidate(
    mask: np.ndarray,
    gt_instances: list[np.ndarray],
    matched_lesion: int,
    sensitivity_matched_lesion: int = -1,
) -> dict[str, Any]:
    if matched_lesion < 0 or not gt_instances:
        return {
            "candidate_valid": 0,
            "matched_lesion": -1,
            "sensitivity_matched_lesion": int(sensitivity_matched_lesion),
            "mask_iou": 0.0,
            "mask_dice": 0.0,
        }
    target = gt_instances[int(matched_lesion)]
    return {
        "candidate_valid": 1,
        "matched_lesion": int(matched_lesion),
        "sensitivity_matched_lesion": int(sensitivity_matched_lesion),
        "mask_iou": binary_iou(mask, target),
        "mask_dice": binary_dice(mask, target),
    }


def _write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".{os.getpid()}.partial")
    with temporary.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
    os.replace(temporary, path)


def load_candidate_rows(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def load_candidate_mask(row: dict[str, Any]) -> np.ndarray:
    with np.load(row["mask_file"], allow_pickle=False) as payload:
        return payload[row["mask_key"]].astype(np.uint8)


@torch.inference_mode()
def generate_candidates(
    records: Sequence[ManifestRecord],
    detector: torch.nn.Module,
    medsam: MedSAMAdapter,
    output_dir: Path,
    cfg: dict,
    seed: int,
    provenance: dict[str, Any],
    include_diagnostics: bool,
    label_candidates: bool = True,
    compute_jitter_features: bool = True,
) -> Path:
    if include_diagnostics and not label_candidates:
        raise ValueError("GT-box diagnostics require candidate labels")
    output_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    rng = np.random.default_rng(seed)
    top_k = int(cfg["detector_top_k"])
    score_floor = float(cfg["detector_score_floor"])
    for record in records:
        image_rgb = np.asarray(Image.open(record.image_path).convert("RGB"))
        height, width = image_rgb.shape[:2]
        image_tensor = TF.to_tensor(Image.fromarray(image_rgb)).to(medsam.device)
        prediction = detector([image_tensor])[0]
        scores = prediction["scores"].detach().float().cpu().numpy()
        boxes = prediction["boxes"].detach().float().cpu().numpy()
        keep = np.flatnonzero(scores >= score_floor)[:top_k]
        predicted_boxes = boxes[keep]
        predicted_scores = scores[keep]
        # Deployment-efficiency benchmarks must not read ground-truth pixels.
        gt_instances = (
            connected_instances(mask_binary(record.mask_path)) if label_candidates else []
        )
        gt_boxes = instance_boxes(gt_instances)
        conditions: list[tuple[str, np.ndarray, np.ndarray, int]] = [
            ("predicted_box", predicted_boxes, predicted_scores, 1024)
        ]
        if include_diagnostics:
            conditions.append(("gt_box_upper_bound", gt_boxes, np.ones(len(gt_boxes), dtype=np.float32), 1024))
            jittered = np.asarray(
                [jitter_box(box, width, height, cfg["medsam"]["jitter_fraction"], rng) for box in gt_boxes],
                dtype=np.float32,
            ).reshape(-1, 4)
            conditions.append(("jittered_gt_box_robustness", jittered, np.ones(len(jittered), dtype=np.float32), 1024))
            sensitivity_fraction = float(cfg["medsam"]["jitter_sensitivity_fractions"][0])
            jittered_sensitivity = np.asarray(
                [jitter_box(box, width, height, sensitivity_fraction, rng) for box in gt_boxes],
                dtype=np.float32,
            ).reshape(-1, 4)
            conditions.append(
                (
                    "jittered_gt_box_10pct_sensitivity_only",
                    jittered_sensitivity,
                    np.ones(len(jittered_sensitivity), dtype=np.float32),
                    1024,
                )
            )
            conditions.append(
                (
                    "predicted_box_medsam_512_sensitivity_only",
                    predicted_boxes,
                    predicted_scores,
                    int(cfg["medsam"]["resolution_sensitivity_input_sizes"][0]),
                )
            )
        embeddings: dict[int, torch.Tensor] = {}
        arrays: dict[str, np.ndarray] = {}
        image_rows: list[dict[str, Any]] = []
        for condition, condition_boxes, condition_scores, medsam_input_size in conditions:
            if medsam_input_size not in embeddings:
                embeddings[medsam_input_size] = medsam.encode(
                    image_rgb, input_size=medsam_input_size
                )
            embedding = embeddings[medsam_input_size]
            if not len(condition_boxes):
                image_rows.append(
                    {
                        "image_id": record.image_id,
                        "patient_id": record.patient_id,
                        "is_positive_image": int(record.is_positive),
                        "is_clean": int(record.is_clean),
                        "has_mark": int(record.has_mark),
                        "has_doppler": int(record.has_doppler),
                        "has_combined": int(record.has_combined),
                        "gt_lesion_count": len(gt_instances) if label_candidates else -1,
                        "ground_truth_mask_file": str(record.mask_path.resolve()),
                        "ground_truth_mask_sha256": record.mask_sha256,
                        "image_file": str(record.image_path.resolve()),
                        "image_sha256": record.image_sha256,
                        "condition": condition,
                        "medsam_input_size": medsam_input_size,
                        "candidate_index": -1,
                        "is_sentinel": 1,
                        "box_xyxy": [],
                        "features": [0.0] * len(FEATURE_NAMES),
                        "feature_map": {name: 0.0 for name in FEATURE_NAMES},
                        "candidate_valid": 0 if label_candidates else -1,
                        "matched_lesion": -1,
                        "mask_iou": 0.0 if label_candidates else None,
                        "mask_dice": 0.0 if label_candidates else None,
                        "failure": 1 if label_candidates else -1,
                        "mask_key": "",
                        **provenance,
                    }
                )
                continue
            primary_matches = primary_candidate_matches(condition_boxes, condition_scores, gt_instances)
            sensitivity_matches = sensitivity_candidate_matches(
                condition_boxes,
                condition_scores,
                gt_instances,
                float(cfg["matching"]["sensitivity_box_iou_threshold"]),
            )
            masks, sam_ious = medsam.decode(
                embedding,
                condition_boxes,
                (height, width),
                input_size=medsam_input_size,
            )
            for candidate_index, (box, score, mask, sam_iou) in enumerate(
                zip(condition_boxes, condition_scores, masks, sam_ious)
            ):
                if compute_jitter_features:
                    jitter_boxes = np.asarray(
                        [
                            jitter_box(box, width, height, cfg["medsam"]["jitter_fraction"], rng)
                            for _ in range(cfg["medsam"]["jitter_repeats"])
                        ]
                    )
                    jitter_masks, _ = medsam.decode(
                        embedding,
                        jitter_boxes,
                        (height, width),
                        input_size=medsam_input_size,
                    )
                else:
                    jitter_masks = []
                key = f"{condition}_{candidate_index}"
                arrays[key] = mask.astype(np.uint8)
                labels = (
                    _label_candidate(
                        mask,
                        gt_instances,
                        primary_matches[candidate_index],
                        sensitivity_matches[candidate_index],
                    )
                    if label_candidates
                    else {
                        "candidate_valid": -1,
                        "matched_lesion": -1,
                        "mask_iou": None,
                        "mask_dice": None,
                    }
                )
                feature_map = _candidate_features(
                    mask,
                    box,
                    float(score),
                    sam_iou,
                    jitter_masks,
                    detector_rank=candidate_index,
                )
                image_rows.append(
                    {
                        "image_id": record.image_id,
                        "patient_id": record.patient_id,
                        "is_positive_image": int(record.is_positive),
                        "is_clean": int(record.is_clean),
                        "has_mark": int(record.has_mark),
                        "has_doppler": int(record.has_doppler),
                        "has_combined": int(record.has_combined),
                        "gt_lesion_count": len(gt_instances) if label_candidates else -1,
                        "ground_truth_mask_file": str(record.mask_path.resolve()),
                        "ground_truth_mask_sha256": record.mask_sha256,
                        "image_file": str(record.image_path.resolve()),
                        "image_sha256": record.image_sha256,
                        "condition": condition,
                        "medsam_input_size": medsam_input_size,
                        "candidate_index": candidate_index,
                        "is_sentinel": 0,
                        "box_xyxy": [float(value) for value in box],
                        "features": [feature_map[name] for name in FEATURE_NAMES],
                        "feature_map": feature_map,
                        **labels,
                        "failure": (
                            int(
                                labels["candidate_valid"] == 0
                                or labels["mask_dice"] < cfg["failure_dice_threshold"]
                            )
                            if label_candidates
                            else -1
                        ),
                        "mask_key": key,
                        **provenance,
                    }
                )
        mask_path = output_dir / "masks" / f"{record.image_id}.npz"
        mask_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = mask_path.with_suffix(f".{os.getpid()}.partial.npz")
        np.savez_compressed(temporary, **arrays)
        os.replace(temporary, mask_path)
        for row in image_rows:
            row["mask_file"] = str(mask_path.resolve())
            row["mask_file_sha256"] = sha256_file(mask_path)
            rows.append(row)
        del embeddings
    output = output_dir / "candidates.jsonl"
    _write_jsonl(output, rows)
    metadata = {
        "created_at": utc_now(),
        "candidate_count": len(rows),
        "image_count": len(records),
        "patient_count": len({record.patient_id for record in records}),
        "feature_names": FEATURE_NAMES,
        "ground_truth_labels_computed": label_candidates,
        "jitter_features_computed": compute_jitter_features,
        "primary_candidate_matching": "box_center_in_reference_component_confidence_ordered_one_to_one",
        "sensitivity_candidate_matching": "box_iou_ge_0.3_confidence_ordered_one_to_one",
        "candidate_jsonl_sha256": sha256_file(output),
        "provenance": provenance,
    }
    (output_dir / "metadata.json").write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return output
