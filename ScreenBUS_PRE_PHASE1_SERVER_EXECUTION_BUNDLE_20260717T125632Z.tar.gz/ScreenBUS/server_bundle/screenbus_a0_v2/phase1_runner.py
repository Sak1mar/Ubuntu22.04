"""Executable five-fold/one-seed ScreenBUS Phase-1 runner.

Importing this module is side-effect free. CUDA work starts only through
``run_phase1`` after the server orchestrator and G2/ENGINEERING_A0 bindings
authorize the stage.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from .authorization import authorize_phase1_orchestrator_entry, require_canonical_config
from .candidates import load_candidate_rows
from .config import load_config, resolve_environment
from .metrics import (
    evaluate_candidate_method,
    full_cohort_selective_curve,
    paired_patient_bootstrap,
    patient_cluster_bootstrap_detection_recall_at_fp,
)
from .pipeline import (
    SIMPLE_CONTROLS,
    _candidate_valid,
    _checkpoint_valid,
    _freeze_run_spec,
    _gate_passed,
    _merge_oof,
    _worker_command,
    build_phase1_split,
)
from .protocol_v2_3 import (
    PHASE1_REQUIRED_METHODS,
    SIMPLE_CONTROLS,
    patient_evidence_from_rows,
)
from .scheduler import GPUTask, ResourceAwareScheduler
from .util import atomic_json, sha256_file, sha256_tree, utc_now


def _task_id(outer_fold: int, suffix: str) -> str:
    return f"phase1_fold{outer_fold}_{suffix}"


def _prepare_fold(config_path: Path, outer_fold: int, output_root: Path) -> tuple[Path, Path, dict[str, Any]]:
    split = build_phase1_split(config_path, outer_fold)
    run_dir = output_root / "phase1" / f"fold_{outer_fold}"
    run_dir.mkdir(parents=True, exist_ok=True)
    split_path = run_dir / "provenance" / "split.json"
    atomic_json(split_path, split)
    return run_dir, split_path, split


def _run_fold(config_path: Path, outer_fold: int, run_dir: Path, split_path: Path, split: dict[str, Any]) -> dict[str, Any]:
    cfg = load_config(config_path)
    env = resolve_environment()
    code_files = [
        path
        for path in (env["SCREENBUS_ROOT"] / "server_bundle" / "screenbus_a0_v2").rglob("*")
        if path.is_file() and not path.is_symlink() and path.suffix in {".py", ".yaml", ".yml"}
    ]
    code_sha = sha256_tree(code_files)
    _freeze_run_spec(
        run_dir,
        {
            "schema_version": 2,
            "protocol_version": "2.3",
            "mode": "phase1",
            "seed": 2027,
            "outer_fold": outer_fold,
            "config_sha256": cfg["_config_sha256"],
            "manifest_sha256": split["manifest_sha256"],
            "split_sha256": sha256_file(split_path),
            "code_tree_sha256": code_sha,
            "pointrend_forbidden": True,
        },
    )
    scheduler = ResourceAwareScheduler(cfg, env["SCREENBUS_OUTPUT_ROOT"])
    checkpoints = run_dir / "checkpoints"

    tasks: list[GPUTask] = []
    expected: list[str] = []
    complete: list[str] = []

    def add(task_id: str, operation: str, memory: str, *, inner: int | None = None, done: bool = False) -> None:
        expected.append(task_id)
        if done:
            complete.append(task_id)
        else:
            tasks.append(GPUTask(task_id, _worker_command(config_path, split_path, run_dir, operation, inner), memory))

    add(_task_id(outer_fold, "train_b1"), "train_deeplab", "medium", done=_checkpoint_valid(checkpoints / "deeplab.pt"))
    add(_task_id(outer_fold, "train_mask_rcnn"), "train_mask", "heavy", done=_checkpoint_valid(checkpoints / "mask_rcnn.pt"))
    for inner in range(int(cfg["inner_folds"])):
        add(
            _task_id(outer_fold, f"train_detector_inner_{inner}"),
            "train_detector_inner",
            "heavy",
            inner=inner,
            done=(
                _checkpoint_valid(checkpoints / f"detector_inner_{inner}.pt")
                and _checkpoint_valid(checkpoints / f"medsam_inner_{inner}.pt")
            ),
        )
    scheduler.run(tasks, expected_task_ids=expected, precompleted_task_ids=complete)

    final_id = _task_id(outer_fold, "train_detector_final")
    final_done = (
        _checkpoint_valid(checkpoints / "detector_final.pt")
        and _checkpoint_valid(checkpoints / "medsam_final.pt")
        and (checkpoints / "final_refit_epochs.json").is_file()
    )
    scheduler.run(
        [] if final_done else [GPUTask(final_id, _worker_command(config_path, split_path, run_dir, "train_detector_final"), "heavy")],
        expected_task_ids=[*expected, final_id],
        precompleted_task_ids=[*expected, *([final_id] if final_done else [])],
    )
    expected.append(final_id)

    inference_tasks: list[GPUTask] = []
    inference_ids: list[str] = []
    inference_done: list[str] = []
    for inner in range(int(cfg["inner_folds"])):
        task_id = _task_id(outer_fold, f"candidates_inner_{inner}")
        inference_ids.append(task_id)
        path = run_dir / "candidates" / f"inner_{inner}" / "candidates.jsonl"
        done = _candidate_valid(path, sha256_file(checkpoints / f"detector_inner_{inner}.pt"), sha256_file(checkpoints / f"medsam_inner_{inner}.pt"))
        if done:
            inference_done.append(task_id)
        else:
            inference_tasks.append(GPUTask(task_id, _worker_command(config_path, split_path, run_dir, "candidates_inner", inner), "heavy"))
    for suffix, operation, path, checkpoint, memory in (
        ("candidates_outer_test", "candidates_eval", run_dir / "candidates" / "evaluation" / "candidates.jsonl", checkpoints / "detector_final.pt", "heavy"),
        ("infer_b1", "infer_deeplab", run_dir / "baselines" / "b1" / "candidates.jsonl", checkpoints / "deeplab.pt", "medium"),
        ("infer_mask_rcnn", "infer_mask", run_dir / "baselines" / "mask_rcnn" / "candidates.jsonl", checkpoints / "mask_rcnn.pt", "medium"),
    ):
        task_id = _task_id(outer_fold, suffix)
        inference_ids.append(task_id)
        done = _candidate_valid(path, sha256_file(checkpoint), sha256_file(checkpoints / "medsam_final.pt") if operation == "candidates_eval" else None)
        if done:
            inference_done.append(task_id)
        else:
            inference_tasks.append(GPUTask(task_id, _worker_command(config_path, split_path, run_dir, operation), memory))
    scheduler.run(
        inference_tasks,
        expected_task_ids=[*expected, *inference_ids],
        precompleted_task_ids=[*expected, *inference_done],
    )
    expected.extend(inference_ids)
    _merge_oof(run_dir, split, int(cfg["inner_folds"]))

    post_id = _task_id(outer_fold, "postprocess_b3_verifier")
    insufficient_path = run_dir / "phase1_insufficient_evidence.json"
    post_done = insufficient_path.is_file() or all(
        path.is_file()
        for path in (
            run_dir / "verifier_b3" / "thresholds.json",
            run_dir / "verifier_b3" / "evaluation_scores.json",
            run_dir / "verifier_selection.json",
            run_dir / "pointrend_diagnostic_status.json",
        )
    )
    scheduler.run(
        [] if post_done else [GPUTask(post_id, _worker_command(config_path, split_path, run_dir, "postprocess_phase1"), "medium")],
        expected_task_ids=[*expected, post_id],
        precompleted_task_ids=[*expected, *([post_id] if post_done else [])],
    )
    point = json.loads((run_dir / "pointrend_diagnostic_status.json").read_text(encoding="utf-8"))
    if point.get("status") != "FORBIDDEN_NOT_RUN_IN_PHASE1":
        raise RuntimeError("POINTREND_PHASE1_EXECUTION_OR_STATUS_DRIFT")
    payload = {
        "status": "PHASE1_OUTER_FOLD_COMPLETE",
        "seed": 2027,
        "outer_fold": outer_fold,
        "evaluation_patient_ids": split["evaluation_patient_ids"],
        "config_sha256": cfg["_config_sha256"],
        "code_tree_sha256": code_sha,
        "split_sha256": sha256_file(split_path),
        "pointrend_executed": False,
        "insufficient_evidence": insufficient_path.is_file(),
        "insufficient_evidence_path": str(insufficient_path) if insufficient_path.is_file() else None,
        "outer_test_used_for_route_or_threshold_selection": False,
        "completed_at": utc_now(),
    }
    atomic_json(run_dir / "PHASE1_FOLD_COMPLETE.json", payload)
    return payload


def _build_phase1_report(cfg: dict[str, Any], fold_dirs: list[Path]) -> dict[str, Any]:
    insufficient = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in (run_dir / "phase1_insufficient_evidence.json" for run_dir in fold_dirs)
        if path.is_file()
    ]
    if insufficient:
        return {
            "schema_version": 3,
            "protocol_version": "2.3",
            "phase1_completion": {
                "seed": 2027,
                "outer_folds": [0, 1, 2, 3, 4],
                "completed_outer_folds": [0, 1, 2, 3, 4],
                "outer_test_evaluations_per_patient": 1,
                "frozen_code_sha256_across_folds": True,
                "outer_test_used_for_route_or_threshold_selection": False,
                "methods": list(PHASE1_REQUIRED_METHODS),
                "pointrend_executed": False,
            },
            "predicted_box_localization": {
                "metric": "patient_cluster_bootstrap_recall_at_1_fp_per_view",
                "recall_ci_low": 0.0,
                "recall_ci_high": 1.0,
                "status": "NOT_ESTIMABLE_DUE_TO_INSUFFICIENT_PHASE1_EVIDENCE",
            },
            "b3_vs_mask_rcnn": {
                "delta_definition": "B3 patient-macro Dice minus Mask R-CNN patient-macro Dice",
                "dice_delta_ci_low": -1.0,
                "dice_delta_ci_high": 1.0,
                "efficiency_measured": False,
                "status": "NOT_ESTIMABLE_DUE_TO_INSUFFICIENT_PHASE1_EVIDENCE",
            },
            "candidate_pool_oracle_at_98pct_lesion_sensitivity": {
                "lesion_sensitivity": 0.98,
                "negative_view_fp_reduction_attainable": False,
                "status": "NOT_ESTIMABLE_DUE_TO_INSUFFICIENT_PHASE1_EVIDENCE",
            },
            "event_sufficiency": {
                "unique_patient_counts": {},
                "meta_fold_unique_patient_counts": {},
                "any_meta_fold_single_class": any(
                    bool(item.get("any_meta_fold_single_class")) for item in insufficient
                ),
                "max_fold_threshold_range": 1.0,
                "confidence_intervals_stably_estimable": False,
                "fold_failures": insufficient,
            },
            "simple_control_inner_meta_oof_ranking": {
                "controls": list(SIMPLE_CONTROLS),
                "strongest_control": "detector_score",
                "selection_score_source": "PATIENT_GROUPED_META_OOF_ONLY",
                "status": "NOT_ESTIMABLE_DUE_TO_INSUFFICIENT_PHASE1_EVIDENCE",
            },
            "b5_vs_strongest_simple_control": {
                "absolute_negative_view_action_rate_reduction": 0.0,
                "lesion_recall_delta_ci_low": -1.0,
                "patient_macro_dice_delta_ci_low": -1.0,
                "overall_referral_rate": 1.0,
                "automatic_coverage": 0.0,
                "positive_refer_counted_as_failure": True,
                "all_controls_same_full_cohort_evaluator": True,
                "status": "NOT_ESTIMABLE_DUE_TO_INSUFFICIENT_PHASE1_EVIDENCE",
            },
            "artifact_and_leakage_audit": {
                "label_leakage": False,
                "text_artifact_dependency": False,
                "color_artifact_dependency": False,
                "status": "NOT_ESTIMABLE_DUE_TO_INSUFFICIENT_PHASE1_EVIDENCE",
            },
        }
    merged_rows: list[dict[str, Any]] = []
    b5_scores: list[float] = []
    b5_quality: list[float] = []
    strongest_scores: list[float] = []
    b3_scores: list[float] = []
    mask_rows: list[dict[str, Any]] = []
    threshold_ranges: list[float] = []
    strongest_names: list[str] = []
    all_clean = True
    leakage = False
    failure_events = 0
    quality_success = 0
    meta_fold_patient_counts: dict[str, Any] = {}
    for run_dir in fold_dirs:
        rows = [
            row
            for row in load_candidate_rows(run_dir / "candidates" / "evaluation" / "candidates.jsonl")
            if row["condition"] == "predicted_box"
        ]
        thresholds = json.loads((run_dir / "verifier_b3" / "thresholds.json").read_text(encoding="utf-8"))
        scores = json.loads((run_dir / "verifier_b3" / "evaluation_scores.json").read_text(encoding="utf-8"))
        strongest = str(thresholds["strongest_simple_control"]["name"])
        strongest_names.append(strongest)
        verifier_metadata = json.loads(
            (run_dir / "verifier_b3" / "metadata.json").read_text(encoding="utf-8")
        )
        for fold, counts in verifier_metadata.get(
            "meta_fold_unique_patient_evidence", {}
        ).items():
            meta_fold_patient_counts[f"outer{len(strongest_names) - 1}_meta{fold}"] = counts
        for name in [*SIMPLE_CONTROLS, "verifier"]:
            threshold_ranges.append(float(thresholds[name].get("max_fold_range", 0.0)))
        b5_threshold = float(thresholds["verifier"]["existence_threshold"])
        quality_threshold = float(thresholds["verifier"]["quality_threshold"])
        control_threshold = float(thresholds[strongest]["threshold"])
        detector_threshold = float(thresholds["detector_score"]["threshold"])
        for index, row in enumerate(rows):
            merged_rows.append(row)
            b5_scores.append(float(scores["verifier_existence"][index]) - b5_threshold)
            b5_quality.append(float(scores["verifier_quality"][index]) - quality_threshold)
            strongest_scores.append(float(scores[strongest][index]) - control_threshold)
            b3_scores.append(float(row["feature_map"]["detector_score"]) - detector_threshold if not row.get("is_sentinel") else -1e9)
            all_clean = all_clean and bool(int(row.get("is_clean", 0))) and not any(bool(int(row.get(key, 0))) for key in ("has_mark", "has_doppler", "has_combined"))
            leakage = leakage or bool(set(row.get("training_patient_ids", ())) & {str(row["patient_id"])})
            if not row.get("is_sentinel"):
                failure_events += int(not row["candidate_valid"] or float(row["mask_dice"]) < cfg["failure_dice_threshold"])
                quality_success += int(row["candidate_valid"] and float(row["mask_dice"]) >= cfg["failure_dice_threshold"])
        mask_rows.extend(load_candidate_rows(run_dir / "baselines" / "mask_rcnn" / "candidates.jsonl"))

    patient_ids = {str(row["patient_id"]) for row in merged_rows}
    if len(patient_ids) != 31:
        raise RuntimeError(f"PHASE1_EXPECTED_31_CLEAN_PATIENTS_GOT_{len(patient_ids)}")
    b3_metrics, _ = evaluate_candidate_method(merged_rows, b3_scores, 0.0, cfg["bootstrap_replicates"], 2027)
    mask_scores = [-1e9 if row.get("is_sentinel") else 1.0 for row in mask_rows]
    mask_metrics, _ = evaluate_candidate_method(mask_rows, mask_scores, 0.0, cfg["bootstrap_replicates"], 2027)
    primary = paired_patient_bootstrap(
        merged_rows,
        strongest_scores,
        0.0,
        merged_rows,
        b5_scores,
        0.0,
        cfg["bootstrap_replicates"],
        2044,
        treatment_quality_scores=b5_quality,
        treatment_quality_threshold=0.0,
    )
    b3_vs_mask = paired_patient_bootstrap(
        mask_rows,
        mask_scores,
        0.0,
        merged_rows,
        b3_scores,
        0.0,
        cfg["bootstrap_replicates"],
        2051,
    )
    oracle_scores = [-1e9 if row.get("is_sentinel") else float(bool(row["candidate_valid"])) for row in merged_rows]
    oracle_metrics, _ = evaluate_candidate_method(merged_rows, oracle_scores, 0.5, 0, 2027)
    raw_metrics, _ = evaluate_candidate_method(merged_rows, [1.0 if not row.get("is_sentinel") else -1e9 for row in merged_rows], 0.0, 0, 2027)
    localization = patient_cluster_bootstrap_detection_recall_at_fp(
        merged_rows, 1.0, cfg["bootstrap_replicates"], 2063
    )
    action_reduction = primary["absolute_negative_view_action_rate_reduction"]
    recall_delta = primary["lesion_recall_delta"]
    dice_delta = primary["patient_macro_dice_delta"]
    b5_operating = next(
        row
        for row in full_cohort_selective_curve(
            "B5",
            merged_rows,
            b5_scores,
            points=2,
            operating_threshold=0.0,
            quality_scores=b5_quality,
            quality_threshold=0.0,
        )
        if row["operating_point"]
    )
    strongest_operating = next(
        row
        for row in full_cohort_selective_curve(
            "strongest_simple_control",
            merged_rows,
            strongest_scores,
            points=2,
            operating_threshold=0.0,
        )
        if row["operating_point"]
    )
    patient_counts = patient_evidence_from_rows(
        merged_rows, failure_dice_threshold=float(cfg["failure_dice_threshold"])
    )
    return {
        "schema_version": 3,
        "protocol_version": "2.3",
        "phase1_completion": {
            "seed": 2027,
            "outer_folds": [0, 1, 2, 3, 4],
            "completed_outer_folds": [0, 1, 2, 3, 4],
            "outer_test_evaluations_per_patient": 1,
            "frozen_code_sha256_across_folds": True,
            "outer_test_used_for_route_or_threshold_selection": False,
            "methods": list(PHASE1_REQUIRED_METHODS),
            "pointrend_executed": False,
        },
        "predicted_box_localization": {
            "metric": "patient_cluster_bootstrap_recall_at_1_fp_per_view",
            "lesion_recall_at_1_fp_per_view": float(localization["recall"]),
            "recall_ci_low": float(localization["ci_low"]),
            "recall_ci_high": float(localization["ci_high"]),
            "patient_cluster_bootstrap": localization,
        },
        "b3_vs_mask_rcnn": {
            "delta_definition": "B3 patient-macro Dice minus Mask R-CNN patient-macro Dice",
            "dice_delta_ci_low": b3_vs_mask["patient_macro_dice_delta"]["ci_low"],
            "dice_delta_ci_high": b3_vs_mask["patient_macro_dice_delta"]["ci_high"],
            "efficiency_measured": False,
            "measured_end_to_end_latency_ratio": None,
            "measured_peak_vram_ratio": None,
            "b3_patient_macro_dice": b3_metrics["patient_macro_dice"],
            "mask_rcnn_patient_macro_dice": mask_metrics["patient_macro_dice"],
        },
        "candidate_pool_oracle_at_98pct_lesion_sensitivity": {
            "lesion_sensitivity": 0.98,
            "negative_view_fp_reduction_attainable": bool(
                oracle_metrics["lesion_sensitivity"] >= 0.98
                and oracle_metrics["normal_image_fp_rate"] < raw_metrics["normal_image_fp_rate"]
            ),
            "observed_oracle_lesion_sensitivity": oracle_metrics["lesion_sensitivity"],
        },
        "event_sufficiency": {
            "unique_patient_counts": patient_counts,
            "meta_fold_unique_patient_counts": meta_fold_patient_counts,
            "any_meta_fold_single_class": False,
            "max_fold_threshold_range": max(threshold_ranges, default=float("inf")),
            "confidence_intervals_stably_estimable": all(
                np.isfinite(float(value))
                for value in (action_reduction["point"], recall_delta["ci_low"], dice_delta["ci_low"])
            ),
        },
        "simple_control_inner_meta_oof_ranking": {
            "controls": list(SIMPLE_CONTROLS),
            "strongest_control": max(set(strongest_names), key=strongest_names.count),
            "per_fold_strongest_controls": strongest_names,
            "selection_score_source": "PATIENT_GROUPED_META_OOF_ONLY",
            "all_controls_same_image_state_and_full_cohort_evaluator": True,
        },
        "b5_vs_strongest_simple_control": {
            "absolute_negative_view_action_rate_reduction": action_reduction["point"],
            "lesion_recall_delta_ci_low": recall_delta["ci_low"],
            "patient_macro_dice_delta_ci_low": dice_delta["ci_low"],
            "overall_referral_rate": b5_operating["referral_rate"],
            "automatic_coverage": b5_operating["coverage"],
            "b5_negative_view_action_rate": b5_operating["negative_view_action_rate"],
            "strongest_control_negative_view_action_rate": strongest_operating["negative_view_action_rate"],
            "b5_raw_negative_view_fp_rate": b5_operating["raw_negative_view_fp_rate"],
            "strongest_control_raw_negative_view_fp_rate": strongest_operating["raw_negative_view_fp_rate"],
            "raw_negative_view_fp_rate_reported_descriptive_only": True,
            "positive_refer_counted_as_failure": b5_operating["positive_refer_counted_as_failure"],
            "all_controls_same_full_cohort_evaluator": True,
            "patient_paired_bootstrap": primary,
        },
        "artifact_and_leakage_audit": {
            "label_leakage": leakage,
            "text_artifact_dependency": not all_clean,
            "color_artifact_dependency": not all_clean,
            "formal_rows_all_clean": all_clean,
        },
    }


def run_phase1(config_path: Path) -> dict[str, Any]:
    env = resolve_environment()
    root = env["SCREENBUS_ROOT"]
    config_path = require_canonical_config(config_path, root, "phase1")
    cfg = load_config(config_path)
    authorize_phase1_orchestrator_entry(root, config_path)
    _gate_passed(root / "gates" / "G2_SERVER_READY.json")
    engineering = _gate_passed(root / "gates" / "ENGINEERING_A0_STATUS.json")
    if engineering.get("decision") != "ENGINEERING_A0_PASS":
        raise RuntimeError("PHASE1_FORBIDDEN_WITHOUT_ENGINEERING_A0_PASS")

    prepared = [_prepare_fold(config_path, fold, env["SCREENBUS_OUTPUT_ROOT"]) for fold in cfg["outer_folds"]]
    evaluation_patients = [patient for _run, _split_path, split in prepared for patient in split["evaluation_patient_ids"]]
    if len(evaluation_patients) != len(set(evaluation_patients)):
        raise RuntimeError("PHASE1_OUTER_TEST_PATIENT_REUSED_ACROSS_FOLDS")
    if len(evaluation_patients) != 31:
        raise RuntimeError(
            f"PHASE1_EXPECTED_31_CLEAN_PATIENTS_GOT_{len(evaluation_patients)}"
        )
    completions = [
        _run_fold(config_path, fold, run_dir, split_path, split)
        for fold, (run_dir, split_path, split) in zip(cfg["outer_folds"], prepared)
    ]
    code_hashes = {item["code_tree_sha256"] for item in completions}
    config_hashes = {item["config_sha256"] for item in completions}
    if len(code_hashes) != 1 or len(config_hashes) != 1:
        raise RuntimeError("PHASE1_CODE_OR_CONFIG_DRIFT_ACROSS_FOLDS")
    fold_dirs = [item[0] for item in prepared]
    report = _build_phase1_report(cfg, fold_dirs)
    report_path = env["SCREENBUS_OUTPUT_ROOT"] / "phase1" / "PHASE1_FIVE_FOLD_REPORT.json"
    atomic_json(report_path, report)
    completion = {
        "schema_version": 3,
        "protocol_version": "2.3",
        "status": "PHASE1_FIVE_FOLD_ONE_SEED_COMPLETE_PENDING_G3",
        "seed": 2027,
        "completed_outer_folds": [0, 1, 2, 3, 4],
        "folds": completions,
        "phase1_report": str(report_path),
        "phase1_report_sha256": sha256_file(report_path),
        "g3_run": False,
        "phase2_run": False,
    }
    atomic_json(env["SCREENBUS_OUTPUT_ROOT"] / "phase1" / "PHASE1_COMPLETE.json", completion)
    return completion


__all__ = ["run_phase1"]
