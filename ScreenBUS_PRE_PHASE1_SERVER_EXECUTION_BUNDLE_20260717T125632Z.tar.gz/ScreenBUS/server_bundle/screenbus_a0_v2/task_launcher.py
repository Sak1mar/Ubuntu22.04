from __future__ import annotations

import argparse
import json
import os
import re
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


LEASE_TOKEN_ENV = "SCREENBUS_TASK_RUN_TOKEN"
LEASE_PATH_ENV = "SCREENBUS_TASK_LEASE"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name, suffix=".partial", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(
            path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        )
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def _boot_id(proc_root: Path = Path("/proc")) -> str | None:
    try:
        value = (proc_root / "sys" / "kernel" / "random" / "boot_id").read_text(
            encoding="utf-8"
        ).strip()
    except OSError:
        return None
    return value or None


def _proc_identity(pid: int, proc_root: Path = Path("/proc")) -> dict[str, Any] | None:
    try:
        raw = (proc_root / str(int(pid)) / "stat").read_text(encoding="utf-8")
    except (OSError, ValueError):
        return None
    closing = raw.rfind(")")
    if closing < 0:
        return None
    fields = raw[closing + 1 :].split()
    if len(fields) <= 19:
        return None
    try:
        return {
            "pid": int(pid),
            "pgid": int(fields[2]),
            "state": fields[0],
            "proc_start_ticks": int(fields[19]),
        }
    except ValueError:
        return None


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="screenbus-task-launcher")
    parser.add_argument("--lease", required=True, type=Path)
    parser.add_argument("--run-token", required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        raise RuntimeError("Task launcher received no worker command")
    if args.lease.is_symlink() or not args.lease.is_file():
        raise RuntimeError(f"Task launcher lease is missing or unsafe: {args.lease}")
    try:
        lease = json.loads(args.lease.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Task launcher cannot read launch intent: {exc}") from exc
    task_id = lease.get("task_id") if isinstance(lease, dict) else None
    attempt = lease.get("attempt") if isinstance(lease, dict) else None
    expected_lease_name = (
        f"{task_id}.attempt{attempt}.json"
        if isinstance(task_id, str) and isinstance(attempt, int)
        else None
    )
    if (
        not isinstance(lease, dict)
        or lease.get("state") != "LAUNCH_INTENT"
        or lease.get("run_token") != args.run_token
        or lease.get("command") != command
        or not isinstance(task_id, str)
        or not re.fullmatch(r"[A-Za-z0-9_.-]+", task_id)
        or isinstance(attempt, bool)
        or not isinstance(attempt, int)
        or attempt < 0
        or args.lease.name != expected_lease_name
        or lease.get("parent_pid") != os.getppid()
        or lease.get("memory_class") not in {"light", "medium", "heavy"}
    ):
        raise RuntimeError("Task launcher intent/token/command mismatch")
    if lease.get("scheduler_scope") not in {"phase1", "phase2"}:
        raise RuntimeError("Task launcher scheduler scope mismatch")

    pid = os.getpid()
    identity = _proc_identity(pid)
    pgid = os.getpgrp()
    if identity is not None and identity["pgid"] != pgid:
        raise RuntimeError("Task launcher process-group identity mismatch")
    lease.update(
        {
            "state": "CHILD_REGISTERED",
            "pid": pid,
            "pgid": pgid,
            "proc_start_ticks": (
                identity["proc_start_ticks"] if identity is not None else None
            ),
            "boot_id": _boot_id(),
            "child_registered_at": utc_now(),
        }
    )
    atomic_json(args.lease, lease)
    # Do not exec the scientific worker until the scheduler parent has
    # observed this exact PID/PGID registration and atomically confirmed it.
    # This closes the child-start/parent-death window and makes a bare forged
    # LAUNCH_INTENT insufficient to enter a worker.
    deadline = time.monotonic() + 10.0
    confirmed: dict[str, Any] | None = None
    while time.monotonic() < deadline:
        if os.getppid() != lease["parent_pid"]:
            raise RuntimeError("Task launcher scheduler parent exited before confirmation")
        try:
            observed = json.loads(args.lease.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(
                f"Task launcher cannot read parent confirmation: {exc}"
            ) from exc
        if (
            isinstance(observed, dict)
            and observed.get("state") == "PARENT_CONFIRMED"
            and observed.get("run_token") == args.run_token
            and observed.get("command") == command
            and observed.get("pid") == pid
            and observed.get("pgid") == pgid
            and observed.get("parent_pid") == os.getppid()
            and observed.get("parent_observed_pid") == pid
        ):
            confirmed = observed
            break
        time.sleep(0.01)
    if confirmed is None:
        raise RuntimeError("Task launcher did not receive scheduler parent confirmation")
    environment = os.environ.copy()
    environment[LEASE_TOKEN_ENV] = args.run_token
    environment[LEASE_PATH_ENV] = str(args.lease.resolve())
    os.execvpe(command[0], command, environment)
    raise AssertionError("os.execvpe returned unexpectedly")


if __name__ == "__main__":
    raise SystemExit(main())
