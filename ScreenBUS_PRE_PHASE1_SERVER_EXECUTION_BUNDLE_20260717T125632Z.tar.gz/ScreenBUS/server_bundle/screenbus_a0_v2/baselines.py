from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch
from PIL import Image
from scipy import ndimage
from torchvision.transforms import functional as TF

from .candidates import (
    FEATURE_NAMES,
    _candidate_features,
    _label_candidate,
    primary_candidate_matches,
    sensitivity_candidate_matches,
)
from .data import ManifestRecord, connected_instances, instance_boxes, mask_binary
from .models import DeepLabV3PlusHardGate
from .util import sha256_file, utc_now


def _base_row(record: ManifestRecord, lesion_count: int, condition: str) -> dict[str, Any]:
    return {
        "image_id": record.image_id,
        "patient_id": record.patient_id,
        "is_positive_image": int(record.is_positive),
        "is_clean": int(record.is_clean),
        "has_mark": int(record.has_mark),
        "has_doppler": int(record.has_doppler),
        "has_combined": int(record.has_combined),
        "gt_lesion_count": lesion_count,
        "ground_truth_mask_file": str(record.mask_path.resolve()),
        "ground_truth_mask_sha256": record.mask_sha256,
        "image_file": str(record.image_path.resolve()),
        "image_sha256": record.image_sha256,
        "condition": condition,
    }


def _sentinel(record: ManifestRecord, lesion_count: int, condition: str) -> dict[str, Any]:
    return {
        **_base_row(record, lesion_count, condition),
        "candidate_index": -1,
        "is_sentinel": 1,
        "box_xyxy": [],
        "features": [0.0] * len(FEATURE_NAMES),
        "feature_map": {name: 0.0 for name in FEATURE_NAMES},
        "candidate_valid": 0,
        "matched_lesion": -1,
        "mask_iou": 0.0,
        "mask_dice": 0.0,
        "failure": 1,
        "mask_key": "",
    }


def _save_rows(output_dir: Path, rows: list[dict[str, Any]], metadata: dict[str, Any]) -> Path:
    output = output_dir / "candidates.jsonl"
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(f".{os.getpid()}.partial")
    with temporary.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
    os.replace(temporary, output)
    (output_dir / "metadata.json").write_text(
        json.dumps({**metadata, "candidate_jsonl_sha256": sha256_file(output)}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return output


@torch.inference_mode()
def infer_deeplab(
    model: DeepLabV3PlusHardGate,
    records: Sequence[ManifestRecord],
    output_dir: Path,
    cfg: dict,
    hard_gate: bool,
    device: torch.device,
    upstream_checkpoint_sha256: str,
) -> Path:
    rows: list[dict[str, Any]] = []
    mask_dir = output_dir / "masks"
    mask_dir.mkdir(parents=True, exist_ok=True)
    condition = "full_image_hard_gate" if hard_gate else "full_image_no_gate"
    for record in records:
        image = Image.open(record.image_path).convert("RGB")
        original_shape = (record.height, record.width)
        resized = TF.to_tensor(TF.resize(image, [cfg["image_size"], cfg["image_size"]], antialias=True))
        with torch.autocast("cuda", torch.float16, enabled=cfg["amp"]):
            output = model(resized.unsqueeze(0).to(device))
        probability = torch.sigmoid(output["segmentation_logits"])[0, 0]
        presence = float(torch.sigmoid(output["presence_logits"])[0])
        predicted = probability > 0.5
        if hard_gate and presence < 0.5:
            predicted.zero_()
        predicted = np.asarray(
            TF.resize(
                Image.fromarray(predicted.cpu().numpy().astype(np.uint8) * 255),
                list(original_shape),
                interpolation=TF.InterpolationMode.NEAREST,
            )
        ) > 0
        components = connected_instances(predicted)
        gt = connected_instances(mask_binary(record.mask_path))
        arrays: dict[str, np.ndarray] = {}
        image_rows: list[dict[str, Any]] = []
        boxes = instance_boxes(components)
        component_scores = [presence] * len(boxes)
        primary_matches = primary_candidate_matches(boxes, component_scores, gt)
        sensitivity_matches = sensitivity_candidate_matches(
            boxes, component_scores, gt, cfg["matching"]["sensitivity_box_iou_threshold"]
        )
        for index, (component, box) in enumerate(zip(components, boxes)):
            key = f"mask_{index}"
            arrays[key] = component
            labels = _label_candidate(
                component, gt, primary_matches[index], sensitivity_matches[index]
            )
            feature_map = _candidate_features(
                component,
                box,
                presence,
                0.0,
                [],
                detector_rank=index,
                image_presence_probability=presence,
            )
            image_rows.append(
                {
                    **_base_row(record, len(gt), condition),
                    "candidate_index": index,
                    "is_sentinel": 0,
                    "box_xyxy": box.tolist(),
                    "features": [feature_map[name] for name in FEATURE_NAMES],
                    "feature_map": feature_map,
                    **labels,
                    "failure": int(
                        labels["candidate_valid"] == 0 or labels["mask_dice"] < cfg["failure_dice_threshold"]
                    ),
                    "mask_key": key,
                    "presence_probability": presence,
                }
            )
        mask_path = mask_dir / f"{record.image_id}.npz"
        np.savez_compressed(mask_path, **arrays)
        if not image_rows:
            image_rows = [_sentinel(record, len(gt), condition)]
        for row in image_rows:
            row["mask_file"] = str(mask_path.resolve())
            row["mask_file_sha256"] = sha256_file(mask_path)
            rows.append(row)
    for row in rows:
        row["upstream_checkpoint_sha256"] = upstream_checkpoint_sha256
    return _save_rows(
        output_dir,
        rows,
        {"created_at": utc_now(), "method": "B1" if hard_gate else "B0", "hard_gate": hard_gate},
    )


@torch.inference_mode()
def infer_mask_rcnn(
    model: torch.nn.Module,
    records: Sequence[ManifestRecord],
    output_dir: Path,
    cfg: dict,
    device: torch.device,
    upstream_checkpoint_sha256: str,
) -> Path:
    rows: list[dict[str, Any]] = []
    mask_dir = output_dir / "masks"
    mask_dir.mkdir(parents=True, exist_ok=True)
    for record in records:
        image = Image.open(record.image_path).convert("RGB")
        prediction = model([TF.to_tensor(image).to(device)])[0]
        keep = torch.flatnonzero(prediction["scores"] >= cfg["detector_score_floor"])[: cfg["detector_top_k"]]
        masks = (prediction["masks"][keep, 0] > 0.5).cpu().numpy().astype(np.uint8)
        boxes = prediction["boxes"][keep].cpu().numpy()
        scores = prediction["scores"][keep].cpu().numpy()
        gt = connected_instances(mask_binary(record.mask_path))
        primary_matches = primary_candidate_matches(boxes, scores, gt)
        sensitivity_matches = sensitivity_candidate_matches(
            boxes, scores, gt, cfg["matching"]["sensitivity_box_iou_threshold"]
        )
        arrays: dict[str, np.ndarray] = {}
        image_rows: list[dict[str, Any]] = []
        for index, (mask, box, score) in enumerate(zip(masks, boxes, scores)):
            key = f"mask_{index}"
            arrays[key] = mask
            labels = _label_candidate(mask, gt, primary_matches[index], sensitivity_matches[index])
            feature_map = _candidate_features(
                mask, box, float(score), 0.0, [], detector_rank=index
            )
            image_rows.append(
                {
                    **_base_row(record, len(gt), "predicted_instance"),
                    "candidate_index": index,
                    "is_sentinel": 0,
                    "box_xyxy": box.tolist(),
                    "features": [feature_map[name] for name in FEATURE_NAMES],
                    "feature_map": feature_map,
                    **labels,
                    "failure": int(
                        labels["candidate_valid"] == 0 or labels["mask_dice"] < cfg["failure_dice_threshold"]
                    ),
                    "mask_key": key,
                }
            )
        mask_path = mask_dir / f"{record.image_id}.npz"
        np.savez_compressed(mask_path, **arrays)
        if not image_rows:
            image_rows = [_sentinel(record, len(gt), "predicted_instance")]
        for row in image_rows:
            row["mask_file"] = str(mask_path.resolve())
            row["mask_file_sha256"] = sha256_file(mask_path)
            rows.append(row)
    for row in rows:
        row["upstream_checkpoint_sha256"] = upstream_checkpoint_sha256
    return _save_rows(output_dir, rows, {"created_at": utc_now(), "method": "MaskRCNN_R50_FPN"})
