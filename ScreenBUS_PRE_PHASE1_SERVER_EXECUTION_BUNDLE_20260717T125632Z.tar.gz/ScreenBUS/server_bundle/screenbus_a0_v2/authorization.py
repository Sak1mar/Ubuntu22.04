from __future__ import annotations

import json
import hashlib
import os
import re
import secrets
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

try:
    from server_bundle.ops.orchestrator import validate_g2_payload
    from server_bundle.ops.status_store import load_status
except ImportError:  # ``server_bundle`` itself is on PYTHONPATH on the server.
    from ops.orchestrator import validate_g2_payload
    from ops.status_store import load_status

LEASE_TOKEN_ENV = "SCREENBUS_TASK_RUN_TOKEN"
LEASE_PATH_ENV = "SCREENBUS_TASK_LEASE"
FULL_LIVE_ATTESTATION_MAX_AGE_SECONDS = 7 * 24 * 60 * 60
FULL_LIVE_ATTESTATION_FILENAME = "FULL_LIVE_AUTHORIZATION.json"
FULL_AUTH_TOKEN_ENV = "SCREENBUS_FULL_AUTH_TOKEN"
PATH_ENV_KEYS = (
    "SCREENBUS_RUNTIME_ROOT",
    "SCREENBUS_DATA_ROOT",
    "SCREENBUS_CACHE_ROOT",
    "SCREENBUS_OUTPUT_ROOT",
    "SCREENBUS_WEIGHT_ROOT",
    "SCREENBUS_ENV_DIR",
    "MEDSAM_CKPT",
    "TORCH_HOME",
    "YOLO_CONFIG_DIR",
)
CONTROL_ENV_KEYS = (
    "GPU_IDS",
    "SCREENBUS_PER_GPU_CONCURRENCY",
    "SCREENBUS_MIN_FREE_VRAM_GIB",
    "SCREENBUS_OOM_MAX_RETRIES",
)
EXPECTED_RESOURCE_POLICY = {
    "gpu_ids": ["0", "1", "2"],
    "per_gpu_concurrency": 2,
    "min_free_vram_gib": 3.0,
    "heavy_exclusive": True,
    "oom_max_retries": 0,
    "resource_aware_required": True,
    "memory_gib": {"light": 4.0, "medium": 10.0, "heavy": 20.0},
    "admission_rule": (
        "estimated_gib + min_free_vram_gib must fit; heavy jobs are exclusive"
    ),
}


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_tree(paths: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: str(item)):
        digest.update(str(path).encode())
        digest.update(sha256_file(path).encode())
    return digest.hexdigest()


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".partial", dir=path.parent
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _proc_identity(pid: int, proc_root: Path = Path("/proc")) -> dict[str, Any] | None:
    try:
        raw = (proc_root / str(int(pid)) / "stat").read_text(encoding="utf-8")
    except (OSError, ValueError):
        return None
    closing = raw.rfind(")")
    if closing < 0:
        return None
    fields = raw[closing + 1 :].split()
    if len(fields) <= 19:
        return None
    try:
        return {
            "pid": int(pid),
            "pgid": int(fields[2]),
            "state": fields[0],
            "proc_start_ticks": int(fields[19]),
        }
    except ValueError:
        return None


def canonical_config_path(root: Path, mode: str) -> Path:
    names = {
        "engineering_a0": "engineering_a0.yaml",
        "phase1": "server_a0.yaml",
        "phase2": "full_cv.yaml",
    }
    try:
        name = names[mode]
    except KeyError as exc:
        raise ValueError(f"Unknown execution mode: {mode!r}") from exc
    return (root.resolve() / "server_bundle" / "screenbus_a0_v2" / "configs" / name)


def require_canonical_config(config_path: Path, root: Path, mode: str) -> Path:
    canonical = canonical_config_path(root, mode)
    try:
        observed = config_path.resolve(strict=True)
        expected = canonical.resolve(strict=True)
    except OSError as exc:
        raise RuntimeError(f"{mode.upper()}_FORBIDDEN_CONFIG_UNAVAILABLE: {exc}") from exc
    if observed != expected:
        raise RuntimeError(
            f"{mode.upper()}_FORBIDDEN_NONCANONICAL_CONFIG: "
            f"expected={expected}, observed={observed}"
        )
    if canonical.is_symlink() or not canonical.is_file():
        raise RuntimeError(f"{mode.upper()}_FORBIDDEN_UNSAFE_CANONICAL_CONFIG: {canonical}")
    return canonical


def _normalized_current_runtime(root: Path) -> dict[str, str]:
    missing = [key for key in (*PATH_ENV_KEYS, *CONTROL_ENV_KEYS) if not os.environ.get(key)]
    if missing:
        raise RuntimeError(
            "FULL_FORBIDDEN_RUNTIME_CONTEXT_MISSING: " + ", ".join(missing)
        )
    current = {
        key: str(Path(os.environ[key]).expanduser().resolve()) for key in PATH_ENV_KEYS
    }
    current.update({key: os.environ[key] for key in CONTROL_ENV_KEYS})
    if str(root.resolve()) != str(Path(os.environ.get("SCREENBUS_ROOT", "")).resolve()):
        raise RuntimeError("FULL_FORBIDDEN_SCREENBUS_ROOT_ENV_DRIFT")
    if current["GPU_IDS"] != "0,1,2":
        raise RuntimeError("FULL_FORBIDDEN_GPU_IDS_NOT_EXACTLY_0_1_2")
    try:
        controls = (
            int(current["SCREENBUS_PER_GPU_CONCURRENCY"]),
            float(current["SCREENBUS_MIN_FREE_VRAM_GIB"]),
            int(current["SCREENBUS_OOM_MAX_RETRIES"]),
        )
    except ValueError as exc:
        raise RuntimeError("FULL_FORBIDDEN_INVALID_RESOURCE_CONTROLS") from exc
    if controls != (2, 3.0, 0):
        raise RuntimeError(
            "FULL_FORBIDDEN_RESOURCE_CONTROLS_DRIFT: "
            f"observed={controls}, expected=(2, 3.0, 0)"
        )
    return current


def _g2_input_fingerprints(root: Path) -> dict[str, str]:
    paths = {
        "g2_doctor_sha256": root / "server_bundle" / "g2" / "g2_doctor.py",
        "requirements_sha256": (
            root / "server_bundle" / "env" / "requirements-cuda121.lock.txt"
        ),
        "portable_evidence_manifest_sha256": (
            root / "bootstrap" / "evidence" / "MANIFEST.sha256"
        ),
        "prepare_manifest_sha256": (
            root / "server_bundle" / "artifacts" / "data" / "prepare_manifest.json"
        ),
        "weight_manifest_sha256": (
            root / "server_bundle" / "artifacts" / "weights" / "weight_manifest.json"
        ),
    }
    return {
        key: sha256_file(path) if path.is_file() and not path.is_symlink() else "MISSING"
        for key, path in paths.items()
    }


def validate_server_execution_context(
    root: Path,
    status: dict[str, Any],
    g2: dict[str, Any],
    *,
    g2_sha256: str,
    g3_sha256: str,
    g3_decision: str,
    authorization_stage_attempt: int,
) -> dict[str, Any]:
    """Validate the immutable server/G2 context and return its attestation binding."""
    root = root.resolve()
    # Re-read through the schema validator. A caller-supplied dictionary must
    # never substitute for the exact STATUS bytes on disk.
    status_path = root / "server_bundle" / "STATUS.json"
    observed_status = load_status(status_path)
    if observed_status != status:
        raise RuntimeError("FULL_FORBIDDEN_STATUS_REREAD_DRIFT")
    if status.get("root") != str(root):
        raise RuntimeError("FULL_FORBIDDEN_STATUS_ROOT_DRIFT")
    if status.get("profile") != "server_rtx3090_linux":
        raise RuntimeError("FULL_FORBIDDEN_STATUS_PROFILE_NOT_SERVER_RTX3090_LINUX")

    current_runtime = _normalized_current_runtime(root)
    frozen_runtime = status.get("runtime_paths")
    if not isinstance(frozen_runtime, dict) or set(frozen_runtime) != set(current_runtime):
        raise RuntimeError("FULL_FORBIDDEN_FROZEN_RUNTIME_PATH_SET_DRIFT")
    runtime_drift = {
        key: {"frozen": frozen_runtime.get(key), "current": value}
        for key, value in current_runtime.items()
        if frozen_runtime.get(key) != value
    }
    if runtime_drift:
        raise RuntimeError(f"FULL_FORBIDDEN_FROZEN_RUNTIME_DRIFT: {runtime_drift}")
    if status.get("resource_policy") != EXPECTED_RESOURCE_POLICY:
        raise RuntimeError("FULL_FORBIDDEN_STATUS_RESOURCE_POLICY_DRIFT")

    valid_g2, g2_reason = validate_g2_payload(g2, str(g2.get("decision", "")))
    if not valid_g2:
        raise RuntimeError(f"FULL_FORBIDDEN_G2_SEMANTIC_INVALID: {g2_reason}")
    recorded_inputs = g2.get("input_fingerprints")
    observed_inputs = _g2_input_fingerprints(root)
    if not isinstance(recorded_inputs, dict) or set(recorded_inputs) != set(observed_inputs):
        raise RuntimeError("FULL_FORBIDDEN_G2_INPUT_FINGERPRINT_SET_DRIFT")
    input_drift = {
        key: {"recorded": recorded_inputs.get(key), "observed": value}
        for key, value in observed_inputs.items()
        if recorded_inputs.get(key) != value
    }
    if input_drift:
        raise RuntimeError(f"FULL_FORBIDDEN_G2_INPUT_FINGERPRINT_DRIFT: {input_drift}")

    code_files = [
        path
        for path in (root / "server_bundle" / "screenbus_a0_v2").rglob("*")
        if path.is_file() and not path.is_symlink() and path.suffix in {".py", ".yaml", ".yml"}
    ]
    if not code_files:
        raise RuntimeError("FULL_FORBIDDEN_EMPTY_RUNTIME_CODE_TREE")
    return {
        "root": str(root),
        "status_path": str(status_path.resolve()),
        "status_sha256": sha256_file(status_path),
        "status_run_id": status.get("run_id"),
        "runtime_paths": current_runtime,
        "resource_policy": EXPECTED_RESOURCE_POLICY,
        "g2_sha256": g2_sha256,
        "g2_input_fingerprints": observed_inputs,
        "g3_sha256": g3_sha256,
        "g3_decision": g3_decision,
        "authorization_stage_attempt": authorization_stage_attempt,
        "code_tree_sha256": sha256_tree(code_files),
    }


def _active_phase1_g2_context(root: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    root = root.resolve()
    status_path = root / "server_bundle" / "STATUS.json"
    status = load_status(status_path)
    stage = status.get("stages", {}).get("PHASE1_FIVE_FOLD_ONE_SEED", {})
    g2_stage = status.get("stages", {}).get("G2_SERVER_ENGINEERING", {})
    engineering_stage = status.get("stages", {}).get("ENGINEERING_A0", {})
    if (
        status.get("state") != "RUNNING"
        or status.get("current_stage") != "PHASE1_FIVE_FOLD_ONE_SEED"
        or stage.get("state") != "RUNNING"
        or isinstance(stage.get("attempt"), bool)
        or not isinstance(stage.get("attempt"), int)
        or stage["attempt"] <= 0
        or engineering_stage.get("state") != "PASSED"
        or status.get("decisions", {}).get("engineering_a0") != "ENGINEERING_A0_PASS"
    ):
        raise RuntimeError("PHASE1_FORBIDDEN_OUTSIDE_ACTIVE_ORCHESTRATOR_STAGE")
    g2_path = root / "gates" / "G2_SERVER_READY.json"
    try:
        g2 = json.loads(g2_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"PHASE1_FORBIDDEN_WITHOUT_READABLE_G2: {exc}") from exc
    g2_sha = sha256_file(g2_path)
    g2_key = str(g2_path.resolve())
    output_bindings = g2_stage.get("output_bindings")
    bound = output_bindings.get(g2_key) if isinstance(output_bindings, dict) else None
    if (
        g2_stage.get("state") != "PASSED"
        or not isinstance(output_bindings, dict)
        or set(output_bindings) != {g2_key}
        or not isinstance(bound, dict)
        or bound.get("sha256") != g2_sha
        or bound.get("bytes") != g2_path.stat().st_size
        or status.get("decisions", {}).get("g2") != "SERVER_READY"
        or g2.get("decision") != "SERVER_READY"
        or g2.get("status") != "PASS"
        or g2.get("engineering_a0_authorized") is not True
    ):
        raise RuntimeError("PHASE1_FORBIDDEN_G2_STATUS_BINDING_DRIFT")
    context = validate_server_execution_context(
        root,
        status,
        g2,
        g2_sha256=g2_sha,
        g3_sha256="G3_NOT_YET_RUN",
        g3_decision="G3_NOT_YET_RUN",
        authorization_stage_attempt=int(stage["attempt"]),
    )
    return status, context


def authorize_phase1_orchestrator_entry(root: Path, config_path: Path) -> dict[str, Any]:
    """Authorize Phase-1 only as the active child after G2 and ENGINEERING_A0.

    A canonical config and a standalone G2 JSON are insufficient: the exact G2
    bytes must be bound by the current STATUS run, the A0 stage must already be
    RUNNING, and this process must be the command child recorded by that
    orchestrator.  The orchestrator performs the live G2 recheck immediately
    before entering this stage.
    """
    root = root.resolve()
    canonical = require_canonical_config(config_path, root, "phase1")
    status, context = _active_phase1_g2_context(root)
    stage = status["stages"]["PHASE1_FIVE_FOLD_ONE_SEED"]
    raw_env_dir = os.environ.get("SCREENBUS_ENV_DIR")
    if not raw_env_dir:
        raise RuntimeError("PHASE1_FORBIDDEN_ENV_DIR_MISSING")
    env_python = Path(raw_env_dir).resolve() / "bin" / "python"
    expected_command = [
        [
            str(env_python),
            "-m",
            "screenbus_a0_v2.cli",
            "phase1",
            "--config",
            str(canonical),
        ]
    ]
    if status.get("pid") != os.getppid() or stage.get("command") != expected_command:
        raise RuntimeError("PHASE1_FORBIDDEN_OUTSIDE_ACTIVE_ORCHESTRATOR_STAGE")
    return context


def authorize_phase1_worker_context(root: Path, config_path: Path) -> dict[str, Any]:
    """Recheck active Phase-1/G2 provenance for every scheduler worker."""
    canonical = require_canonical_config(config_path, root.resolve(), "phase1")
    if canonical != config_path.resolve():
        raise RuntimeError("PHASE1_WORKER_FORBIDDEN_NONCANONICAL_CONFIG")
    _, context = _active_phase1_g2_context(root.resolve())
    return context


def _parse_last_json(stdout: str, label: str) -> dict[str, Any]:
    for line in reversed(stdout.splitlines()):
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            return payload
    raise RuntimeError(f"FULL_LIVE_REVALIDATION_{label}_OUTPUT_INVALID")


def run_full_live_revalidation(root: Path) -> dict[str, Any]:
    """Run the existing read-only asset check and all-three-GPU CUDA/AMP probe."""
    try:
        try:
            from server_bundle.data.official_assets import verify_runtime_assets
        except ImportError:
            from data.official_assets import verify_runtime_assets

        assets = verify_runtime_assets()
    except Exception as exc:
        raise RuntimeError(f"FULL_LIVE_ASSET_REVALIDATION_FAILED: {exc}") from exc
    if not isinstance(assets, dict) or assets.get("status") != "PASS":
        raise RuntimeError("FULL_LIVE_ASSET_REVALIDATION_NOT_PASS")

    env_dir = Path(os.environ["SCREENBUS_ENV_DIR"]).resolve()
    python = env_dir / "bin" / "python"
    if python.is_symlink() or not python.is_file():
        # A venv interpreter is normally a symlink on Linux. It is still safe
        # here because SCREENBUS_ENV_DIR itself is frozen in STATUS; resolve it
        # and require the target to be a regular executable file.
        resolved = python.resolve()
        if not resolved.is_file():
            raise RuntimeError(f"FULL_LIVE_ENV_PYTHON_UNAVAILABLE: {python}")
    command = [
        str(python),
        str(root / "server_bundle" / "g2" / "g2_doctor.py"),
        "live-hardware",
    ]
    environment = os.environ.copy()
    environment["CUDA_VISIBLE_DEVICES"] = "0,1,2"
    completed = subprocess.run(
        command,
        cwd=root,
        env=environment,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            "FULL_LIVE_HARDWARE_REVALIDATION_FAILED: "
            f"exit={completed.returncode}: {completed.stdout.strip()}"
        )
    hardware_wrapper = _parse_last_json(completed.stdout, "HARDWARE")
    hardware = hardware_wrapper.get("hardware")
    if (
        hardware_wrapper.get("status") != "PASS"
        or not isinstance(hardware, dict)
        or hardware.get("status") != "PASS"
        or hardware.get("profile") != "server_rtx3090_linux"
    ):
        raise RuntimeError("FULL_LIVE_HARDWARE_REVALIDATION_NOT_PASS")
    devices = hardware.get("devices")
    if not isinstance(devices, list) or {device.get("id") for device in devices} != {0, 1, 2}:
        raise RuntimeError("FULL_LIVE_HARDWARE_DEVICE_SET_DRIFT")
    if any(
        not isinstance(device, dict)
        or "RTX 3090" not in str(device.get("name", ""))
        or device.get("cuda_smoke") != "PASS"
        or device.get("amp_fp16_smoke") != "PASS"
        for device in devices
    ):
        raise RuntimeError("FULL_LIVE_HARDWARE_CUDA_AMP_DRIFT")
    return {
        "status": "PASS",
        "mode": "READ_ONLY_PRE_FULL_LIVE_REVALIDATION",
        "assets": assets,
        "hardware": hardware,
    }


def full_live_attestation_path(root: Path) -> Path:
    output_root = Path(os.environ["SCREENBUS_OUTPUT_ROOT"]).resolve()
    return output_root / "full" / FULL_LIVE_ATTESTATION_FILENAME


def write_full_live_attestation(
    root: Path,
    binding: dict[str, Any],
) -> dict[str, Any]:
    # Keep the live probe non-injectable on the production entry point. Tests
    # may patch ``run_full_live_revalidation`` itself, but callers cannot pass
    # an arbitrary PASS-producing callback to mint an authorization artifact.
    live = run_full_live_revalidation(root.resolve())
    if not isinstance(live, dict) or live.get("status") != "PASS":
        raise RuntimeError("FULL_LIVE_REVALIDATION_DID_NOT_PASS")
    authorization_token = secrets.token_hex(32)
    payload = {
        "schema_version": 1,
        "kind": "SCREENBUS_FULL_LIVE_AUTHORIZATION",
        "status": "PASS",
        "created_at": utc_now(),
        "max_age_seconds": FULL_LIVE_ATTESTATION_MAX_AGE_SECONDS,
        "authorization_token_sha256": hashlib.sha256(
            authorization_token.encode("ascii")
        ).hexdigest(),
        "binding": binding,
        "live_revalidation": live,
    }
    path = full_live_attestation_path(root)
    if path.is_symlink():
        raise RuntimeError(f"FULL_LIVE_ATTESTATION_UNSAFE_PATH: {path}")
    atomic_json(path, payload)
    # This raw nonce is deliberately process-local. Scheduled descendants
    # inherit it, while the attestation and scheduler evidence retain only its
    # digest. A separately invoked full-fold cannot mint an attestation.
    os.environ[FULL_AUTH_TOKEN_ENV] = authorization_token
    return {
        "path": str(path.resolve()),
        "sha256": sha256_file(path),
        "created_at": payload["created_at"],
    }


def validate_full_live_attestation(root: Path, binding: dict[str, Any]) -> dict[str, Any]:
    path = full_live_attestation_path(root)
    if path.is_symlink() or not path.is_file():
        raise RuntimeError("FULL_FORBIDDEN_WITHOUT_LIVE_ATTESTATION")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"FULL_LIVE_ATTESTATION_INVALID: {exc}") from exc
    authorization_token = os.environ.get(FULL_AUTH_TOKEN_ENV, "")
    token_sha256 = (
        hashlib.sha256(authorization_token.encode("ascii")).hexdigest()
        if re.fullmatch(r"[0-9a-f]{64}", authorization_token)
        else None
    )
    if (
        not isinstance(payload, dict)
        or payload.get("schema_version") != 1
        or payload.get("kind") != "SCREENBUS_FULL_LIVE_AUTHORIZATION"
        or payload.get("status") != "PASS"
        or payload.get("max_age_seconds") != FULL_LIVE_ATTESTATION_MAX_AGE_SECONDS
        or payload.get("authorization_token_sha256") != token_sha256
        or payload.get("binding") != binding
        or not isinstance(payload.get("live_revalidation"), dict)
        or payload["live_revalidation"].get("status") != "PASS"
    ):
        raise RuntimeError("FULL_LIVE_ATTESTATION_BINDING_DRIFT")
    try:
        created = datetime.fromisoformat(str(payload["created_at"]))
    except (KeyError, TypeError, ValueError) as exc:
        raise RuntimeError("FULL_LIVE_ATTESTATION_TIMESTAMP_INVALID") from exc
    if created.tzinfo is None:
        raise RuntimeError("FULL_LIVE_ATTESTATION_TIMESTAMP_NOT_UTC_AWARE")
    age = (datetime.now(timezone.utc) - created.astimezone(timezone.utc)).total_seconds()
    if age < -60 or age > FULL_LIVE_ATTESTATION_MAX_AGE_SECONDS:
        raise RuntimeError(f"FULL_LIVE_ATTESTATION_STALE: age_seconds={age}")
    return {
        "path": str(path.resolve()),
        "sha256": sha256_file(path),
        "created_at": payload["created_at"],
    }


def require_scheduler_lease(
    root: Path,
    config_path: Path,
    *,
    expected_scope: str,
    expected_command: list[str] | None = None,
    proc_identity: Callable[[int], dict[str, Any] | None] = _proc_identity,
) -> dict[str, Any]:
    token = os.environ.get(LEASE_TOKEN_ENV, "")
    raw_path = os.environ.get(LEASE_PATH_ENV, "")
    if not re.fullmatch(r"[0-9a-f]{32}", token) or not raw_path:
        raise RuntimeError("SCHEDULER_LEASE_REQUIRED_FOR_DIRECT_ENTRY")
    lease_path = Path(raw_path)
    output_root = Path(os.environ.get("SCREENBUS_OUTPUT_ROOT", "")).resolve()
    lease_root = (output_root / "scheduler" / "leases").resolve()
    try:
        lease_path.resolve().relative_to(lease_root)
    except (OSError, ValueError) as exc:
        raise RuntimeError("SCHEDULER_LEASE_PATH_OUTSIDE_FROZEN_OUTPUT") from exc
    if lease_path.is_symlink() or not lease_path.is_file():
        raise RuntimeError("SCHEDULER_LEASE_FILE_UNSAFE_OR_MISSING")
    try:
        lease = json.loads(lease_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"SCHEDULER_LEASE_INVALID_JSON: {exc}") from exc
    assigned = os.environ.get("SCREENBUS_ASSIGNED_GPU")
    visible = os.environ.get("CUDA_VISIBLE_DEVICES")
    config_sha = sha256_file(config_path)
    task_id = lease.get("task_id") if isinstance(lease, dict) else None
    attempt = lease.get("attempt") if isinstance(lease, dict) else None
    expected_lease_name = (
        f"{task_id}.attempt{attempt}.json"
        if isinstance(task_id, str)
        and isinstance(attempt, int)
        and not isinstance(attempt, bool)
        else None
    )
    if (
        not isinstance(lease, dict)
        or lease.get("schema_version") != 1
        or lease.get("state") != "PARENT_CONFIRMED"
        or lease.get("run_token") != token
        or lease.get("scheduler_scope") != expected_scope
        or lease.get("config_sha256") != config_sha
        or assigned not in {"0", "1", "2"}
        or visible != assigned
        or lease.get("gpu_id") != int(assigned)
        or not isinstance(task_id, str)
        or not re.fullmatch(r"[A-Za-z0-9_.-]+", task_id)
        or isinstance(attempt, bool)
        or not isinstance(attempt, int)
        or attempt < 0
        or lease_path.name != expected_lease_name
        or lease.get("parent_pid") != os.getppid()
        or lease.get("parent_observed_pid") != os.getpid()
        or lease.get("memory_class") not in {"light", "medium", "heavy"}
    ):
        raise RuntimeError("SCHEDULER_LEASE_CONTEXT_MISMATCH")
    if expected_scope == "phase1" and not lease["task_id"].startswith("phase1_"):
        raise RuntimeError("SCHEDULER_LEASE_TASK_SCOPE_MISMATCH")
    if expected_scope == "phase2" and not lease["task_id"].startswith("phase2_seed"):
        raise RuntimeError("SCHEDULER_LEASE_TASK_SCOPE_MISMATCH")
    if expected_command is not None and lease.get("command") != expected_command:
        raise RuntimeError("SCHEDULER_LEASE_COMMAND_MISMATCH")
    log_path = Path(str(lease.get("log", "")))
    expected_log = output_root / "scheduler" / "logs" / f"{task_id}.attempt{attempt}.log"
    if (
        not str(lease.get("log", ""))
        or log_path.resolve() != expected_log.resolve()
        or log_path.is_symlink()
        or not log_path.is_file()
    ):
        raise RuntimeError("SCHEDULER_LEASE_LOG_BINDING_MISMATCH")
    identity = proc_identity(os.getpid())
    if (
        not isinstance(identity, dict)
        or identity.get("pid") != os.getpid()
        or identity.get("pgid") != os.getpgrp()
        or lease.get("pid") != os.getpid()
        or lease.get("pgid") != os.getpgrp()
        or lease.get("proc_start_ticks") != identity.get("proc_start_ticks")
    ):
        raise RuntimeError("SCHEDULER_LEASE_PROCESS_IDENTITY_MISMATCH")
    return lease


def read_worker_split(split_path: Path, run_dir: Path) -> dict[str, Any]:
    if split_path.is_symlink() or not split_path.is_file():
        raise RuntimeError("WORKER_SPLIT_UNSAFE_OR_MISSING")
    try:
        split = json.loads(split_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"WORKER_SPLIT_INVALID: {exc}") from exc
    if not isinstance(split, dict) or split.get("mode") not in {"phase1", "phase2"}:
        raise RuntimeError("WORKER_SPLIT_MODE_INVALID")
    output_root = Path(os.environ.get("SCREENBUS_OUTPUT_ROOT", "")).resolve()
    try:
        run_dir.resolve().relative_to(output_root)
        split_path.resolve().relative_to(run_dir.resolve())
    except (OSError, ValueError) as exc:
        raise RuntimeError("WORKER_SPLIT_OR_RUN_DIR_OUTSIDE_FROZEN_OUTPUT") from exc
    if split_path.resolve() != (run_dir.resolve() / "provenance" / "split.json"):
        raise RuntimeError("WORKER_SPLIT_NOT_CANONICAL_FOR_RUN_DIR")
    return split
