from __future__ import annotations

import json
import gc
import os
import shutil
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image
from torchvision.transforms import functional as TF

from .autobusam_baseline import (
    AUTOBUSAM_METHOD,
    infer_autobusam_adapted,
    load_autobusam_sam_adapter,
    load_autobusam_yolo,
    train_autobusam_adapted,
    validate_autobusam_checkpoint,
)
from .baselines import infer_deeplab, infer_mask_rcnn
from .authorization import (
    authorize_phase1_worker_context,
    read_worker_split,
    require_canonical_config,
    require_scheduler_lease,
)
from .candidates import FEATURE_NAMES, generate_candidates, load_candidate_rows
from .config import load_config, resolve_environment, resolve_project_path
from .data import FrozenManifest, InsufficientEvents
from .leakage_ablation import (
    LEAKAGE_ABLATION_LABEL,
    leakage_ablation_paths,
    validate_self_generated_training_candidates,
)
from .metrics import (
    evaluate_candidate_method,
    full_cohort_selective_curve,
    paired_patient_bootstrap,
    select_fold_stable_dual_thresholds_for_sensitivity,
    select_fold_stable_threshold_for_sensitivity,
    select_dual_thresholds_for_sensitivity,
    select_threshold_for_sensitivity,
    verifier_component_metrics,
)
from .models import CandidateVerifier, MedSAMAdapter, verify_torchvision_weight_cache
from .nnunet_baseline import run_nnunet_baseline
from .refine_verify import (
    apply_pointrend,
    assert_threshold_selection_scores_are_meta_oof,
    build_pointrend_crossfit_plan,
    score_methods,
    load_pointrend,
    train_pointrend,
    train_verifier_and_controls,
    validate_refiner_crossfit_provenance,
)
from .training import (
    derive_inner_oof_detector_prompt_errors,
    load_deeplab,
    load_detector,
    load_mask_rcnn,
    train_deeplab,
    train_detector,
    train_mask_rcnn,
    train_medsam_decoder,
)
from .util import atomic_json, require_cuda, seed_everything, sha256_file


_PHASE1_WORKER_MEMORY_CLASS: dict[str, str] = {
    "train_deeplab": "medium",
    "train_mask": "heavy",
    "train_detector_final": "heavy",
    "candidates_eval": "heavy",
    "infer_deeplab": "medium",
    "infer_mask": "medium",
    "postprocess_phase1": "medium",
}


def _authorize_worker_entry(
    operation: str,
    config_path: Path,
    split_path: Path,
    run_dir: Path,
    inner_fold: int | None,
) -> None:
    """Fail closed when the Python worker API is called outside its scheduler."""
    env = resolve_environment()
    root = env["SCREENBUS_ROOT"]
    split = read_worker_split(split_path.resolve(), run_dir.resolve())
    mode = str(split["mode"])
    canonical = require_canonical_config(config_path, root, mode)
    if not os.environ.get("SCREENBUS_TASK_RUN_TOKEN") or not os.environ.get(
        "SCREENBUS_TASK_LEASE"
    ):
        raise RuntimeError("SCHEDULER_LEASE_REQUIRED")
    cfg = load_config(canonical)
    if cfg.get("mode") != mode or split.get("config_sha256") != sha256_file(canonical):
        raise RuntimeError("WORKER_CONFIG_OR_SPLIT_MODE_BINDING_DRIFT")

    if mode == "phase2":
        seed = int(split["seed"])
        fold = int(split["outer_fold"])
        if seed not in {int(value) for value in cfg["seeds"]} or fold not in {
            int(value) for value in cfg["outer_folds"]
        }:
            raise RuntimeError("FULL_WORKER_SPLIT_OUTSIDE_CANONICAL_GRID")
        canonical_run_dir = (
            env["SCREENBUS_OUTPUT_ROOT"]
            / "phase2"
            / f"seed_{seed}"
            / f"fold_{fold}"
        ).resolve()
        if run_dir.is_symlink() or run_dir.resolve() != canonical_run_dir:
            raise RuntimeError("FULL_WORKER_NONCANONICAL_RUN_DIR")
        expected_command = [
            sys.executable,
            "-m",
            "screenbus_a0_v2.cli",
            "phase2-fold",
            "--config",
            str(canonical),
            "--seed",
            str(seed),
            "--outer-fold",
            str(fold),
            "--run-dir",
            str(canonical_run_dir),
        ]
        lease = require_scheduler_lease(
            root,
            canonical,
            expected_scope="phase2",
            expected_command=expected_command,
        )
        if (
            lease.get("task_id") != f"phase2_seed{seed}_fold{fold}"
            or lease.get("memory_class") != "heavy"
        ):
            raise RuntimeError("FULL_WORKER_HEAVY_LEASE_BINDING_DRIFT")
        from .full_runner import _authorized_g3

        _authorized_g3(root, live_authorization="attestation")
        return

    if mode != "phase1":
        raise RuntimeError(f"WORKER_UNSUPPORTED_MODE: {mode}")
    outer_fold = int(split["outer_fold"])
    canonical_phase1_dir = (
        env["SCREENBUS_OUTPUT_ROOT"] / "phase1" / f"fold_{outer_fold}"
    ).resolve()
    if run_dir.is_symlink() or run_dir.resolve() != canonical_phase1_dir:
        raise RuntimeError("PHASE1_WORKER_NONCANONICAL_RUN_DIR")
    expected_command = [
        sys.executable,
        "-m",
        "screenbus_a0_v2.cli",
        "worker",
        "--config",
        str(canonical),
        "--split",
        str(split_path.resolve()),
        "--run-dir",
        str(run_dir.resolve()),
        "--operation",
        operation,
    ]
    if inner_fold is not None:
        expected_command.extend(["--inner-fold", str(inner_fold)])
    lease = require_scheduler_lease(
        root,
        canonical,
        expected_scope="phase1",
        expected_command=expected_command,
    )
    if operation in {"train_detector_inner", "candidates_inner"}:
        if inner_fold is None or inner_fold not in range(int(cfg["inner_folds"])):
            raise RuntimeError("PHASE1_WORKER_INNER_FOLD_OUTSIDE_CANONICAL_GRID")
        expected_task_id = (
            f"phase1_fold{outer_fold}_train_detector_inner_{inner_fold}"
            if operation == "train_detector_inner"
            else f"phase1_fold{outer_fold}_candidates_inner_{inner_fold}"
        )
        expected_memory_class = "heavy"
    else:
        try:
            expected_memory_class = _PHASE1_WORKER_MEMORY_CLASS[operation]
            phase1_suffix = {
                "train_deeplab": "train_b1",
                "train_mask": "train_mask_rcnn",
                "train_detector_final": "train_detector_final",
                "candidates_eval": "candidates_outer_test",
                "infer_deeplab": "infer_b1",
                "infer_mask": "infer_mask_rcnn",
                "postprocess_phase1": "postprocess_b3_verifier",
            }[operation]
            expected_task_id = f"phase1_fold{outer_fold}_{phase1_suffix}"
        except KeyError as exc:
            raise RuntimeError(f"PHASE1_WORKER_OPERATION_NOT_REGISTERED: {operation}") from exc
    if (
        lease.get("task_id") != expected_task_id
        or lease.get("memory_class") != expected_memory_class
    ):
        raise RuntimeError("PHASE1_WORKER_TASK_LEASE_BINDING_DRIFT")
    authorize_phase1_worker_context(root, canonical)


def _measure_loaded_cuda_chain(operation, image_count: int, limit_gib: float) -> tuple[Any, dict[str, Any]]:
    if image_count <= 0:
        raise RuntimeError("Predicted-only efficiency benchmark has no images")
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    result = operation()
    torch.cuda.synchronize()
    seconds = time.perf_counter() - started
    peak_allocated = torch.cuda.max_memory_allocated() / (1024**3)
    peak_reserved = torch.cuda.max_memory_reserved() / (1024**3)
    if peak_reserved >= limit_gib:
        raise RuntimeError(
            f"VRAM_LIMIT_EXCEEDED: predicted-only chain reserved {peak_reserved:.3f} GiB "
            f">= {limit_gib} GiB"
        )
    return result, {
        "seconds": seconds,
        "image_count": image_count,
        "seconds_per_image": seconds / image_count,
        "throughput_images_per_second": image_count / seconds,
        "peak_vram_gib": peak_reserved,
        "peak_allocated_gib": peak_allocated,
        "measurement": "predicted_only_end_to_end_wall_clock_with_cuda_synchronize",
        "measurement_status": "MEASURED_PREDICTED_ONLY_END_TO_END",
        "ground_truth_pixels_read": False,
    }


def _context(
    config_path: Path,
    split_path: Path,
    needs_evaluation_pixels: bool = False,
    forbid_ground_truth_pixels: bool = False,
):
    cfg = load_config(config_path)
    env = resolve_environment()
    split = json.loads(split_path.read_text(encoding="utf-8"))
    seed_everything(int(split["seed"]), cfg["deterministic"])
    device = require_cuda(cfg["device"])
    # Phase-1/2 evaluation opens only the frozen outer-test assigned in the
    # immutable split. Selection remains confined to outer-train inner/meta.
    excluded = (
        set()
        if needs_evaluation_pixels and split.get("mode") in {"phase1", "phase2"}
        else {int(split["outer_fold"])}
    )
    manifest = FrozenManifest.load(
        resolve_project_path(env["SCREENBUS_ROOT"], cfg["manifest"]),
        env["SCREENBUS_DATA_ROOT"],
        env["SCREENBUS_ROOT"],
        cfg["strict_hash_audit"],
        pixel_excluded_folds=excluded,
        mask_access_excluded_folds=(
            set(range(5)) if forbid_ground_truth_pixels else set()
        ),
    )
    by_id = {record.image_id: record for record in manifest.records}
    return cfg, env, split, by_id, device


def _records(by_id, image_ids):
    missing = set(image_ids) - set(by_id)
    if missing:
        raise RuntimeError(f"Split references unknown image ids: {sorted(missing)}")
    return [by_id[image_id] for image_id in image_ids]


def _validate_medsam_decoder_provenance(
    checkpoint: Path,
    *,
    expected_training_patients: set[str],
    heldout_patients: set[str],
) -> set[str]:
    """Bind the trainable MedSAM decoder to the same legal patient exposure."""
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if payload.get("architecture") != (
        "MedSAM_official_1024_frozen_image_encoder_trainable_mask_decoder"
    ):
        raise RuntimeError("MEDSAM_DECODER_ARCHITECTURE_PROTOCOL_DRIFT")
    training_patients = {str(value) for value in payload.get("training_patient_ids", [])}
    if training_patients != {str(value) for value in expected_training_patients}:
        raise RuntimeError("MEDSAM_DECODER_TRAINING_PATIENT_SET_MISMATCH")
    if training_patients & {str(value) for value in heldout_patients}:
        raise RuntimeError("PATIENT_LEAKAGE: MedSAM decoder includes held-out patient")
    return training_patients


def _validate_model_patient_exposure(
    checkpoint: Path,
    *,
    expected_training_patients: set[str],
    heldout_patients: set[str],
    label: str,
) -> set[str]:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    training_patients = {str(value) for value in payload.get("training_patient_ids", [])}
    if training_patients != {str(value) for value in expected_training_patients}:
        raise RuntimeError(f"{label}_TRAINING_PATIENT_SET_MISMATCH")
    if training_patients & {str(value) for value in heldout_patients}:
        raise RuntimeError(f"PATIENT_LEAKAGE: {label} includes held-out patient")
    return training_patients


def _median_inner_best_epoch_count(
    checkpoints: Path,
    stem: str,
    folds: int,
    maximum: int,
) -> tuple[int, list[int], float]:
    counts: list[int] = []
    for fold in range(int(folds)):
        path = checkpoints / f"{stem}_inner_{fold}.pt"
        if not path.is_file():
            raise RuntimeError(f"INNER_BEST_EPOCH_MISSING: {path}")
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("checkpoint_selection_source") != "inner_validation_only":
            raise RuntimeError(f"INNER_BEST_EPOCH_PROVENANCE_INVALID: {path}")
        count = int(payload.get("best_epoch_count", 0))
        if count <= 0:
            raise RuntimeError(f"INNER_BEST_EPOCH_INVALID: {path}")
        counts.append(count)
    raw_median = float(np.median(np.asarray(counts, dtype=float)))
    selected = min(int(np.floor(raw_median + 0.5)), int(maximum))
    return max(selected, 1), counts, raw_median


def run_worker(
    operation: str,
    config_path: Path,
    split_path: Path,
    run_dir: Path,
    inner_fold: int | None = None,
) -> None:
    _authorize_worker_entry(
        operation,
        config_path.resolve(),
        split_path.resolve(),
        run_dir.resolve(),
        inner_fold,
    )
    benchmark_operations = {
        "benchmark_baseline_chains",
        "benchmark_predicted_chains",
        "benchmark_nnunet_predict_only",
    }
    evaluation_operations = {
        "candidates_eval",
        "infer_deeplab",
        "infer_mask",
        "infer_autobusam",
        "nnunet",
        "postprocess_phase1",
    } | benchmark_operations
    cfg, env, split, by_id, device = _context(
        config_path,
        split_path,
        needs_evaluation_pixels=operation in evaluation_operations,
        forbid_ground_truth_pixels=operation in benchmark_operations,
    )
    seed = int(split["seed"])
    train_records = _records(by_id, split["train_image_ids"])
    eval_records = _records(by_id, split["evaluation_image_ids"])
    checkpoints = run_dir / "checkpoints"
    if operation == "train_deeplab":
        verified = verify_torchvision_weight_cache(cfg, ["resnet18"])
        train_deeplab(train_records, checkpoints / "deeplab.pt", cfg, seed, device)
        atomic_json(checkpoints / "deeplab.weights.json", verified)
    elif operation == "train_mask":
        verified = verify_torchvision_weight_cache(cfg, ["mask_rcnn"])
        train_mask_rcnn(train_records, checkpoints / "mask_rcnn.pt", cfg, seed, device)
        atomic_json(checkpoints / "mask_rcnn.weights.json", verified)
    elif operation == "train_detector_final":
        verified = verify_torchvision_weight_cache(cfg, ["faster_rcnn"])
        detector_epochs, detector_inner_epochs, detector_median = _median_inner_best_epoch_count(
            checkpoints,
            "detector",
            int(cfg["inner_folds"]),
            int(cfg["epochs"]["detector_final_refit_cap"]),
        )
        medsam_epochs, medsam_inner_epochs, medsam_median = _median_inner_best_epoch_count(
            checkpoints,
            "medsam",
            int(cfg["inner_folds"]),
            int(cfg["epochs"]["medsam_final_refit_cap"]),
        )
        train_detector(
            train_records,
            checkpoints / "detector_final.pt",
            cfg,
            seed,
            device,
            epochs=detector_epochs,
        )
        train_medsam_decoder(
            train_records,
            checkpoints / "medsam_final.pt",
            cfg,
            seed + 500,
            device,
            env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
            env["MEDSAM_CKPT"],
            epochs=medsam_epochs,
            use_prompt_error_curriculum=False,
        )
        atomic_json(
            checkpoints / "final_refit_epochs.json",
            {
                "selection_source": "inner_fold_best_epochs_only",
                "rounding": "nearest_integer_half_up",
                "detector_inner_best_epoch_counts": detector_inner_epochs,
                "detector_raw_median": detector_median,
                "detector_final_refit_epochs": detector_epochs,
                "medsam_inner_best_epoch_counts": medsam_inner_epochs,
                "medsam_raw_median": medsam_median,
                "medsam_final_refit_epochs": medsam_epochs,
                "phase1_outer_test_used_for_epoch_selection": False,
                "outer_or_test_used": False,
            },
        )
        atomic_json(checkpoints / "detector_final.weights.json", verified)
    elif operation == "train_autobusam":
        train_autobusam_adapted(
            train_records,
            checkpoints / "autobusam_yolo.pt",
            checkpoints / "autobusam_sam_lora.pt",
            cfg,
            seed + 900,
            device,
            env["SCREENBUS_WEIGHT_ROOT"] / cfg["autobusam"]["pretrained_weight_file"],
            env["SCREENBUS_WEIGHT_ROOT"] / cfg["autobusam"]["sam_checkpoint_file"],
            env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
            run_dir / "autobusam_training",
        )
    elif operation == "train_detector_inner":
        if inner_fold is None:
            raise ValueError("inner_fold is required")
        assignment = split["inner_assignment"]
        fold_train = [record for record in train_records if int(assignment[record.patient_id]) != inner_fold]
        fold_validation = [
            record
            for record in train_records
            if int(assignment[record.patient_id]) == inner_fold
        ]
        heldout_patients = {patient for patient, fold in assignment.items() if int(fold) == inner_fold}
        if {record.patient_id for record in fold_train} & heldout_patients:
            raise RuntimeError("PATIENT_LEAKAGE before inner detector training")
        verified = verify_torchvision_weight_cache(cfg, ["faster_rcnn"])
        train_detector(
            fold_train,
            checkpoints / f"detector_inner_{inner_fold}.pt",
            cfg,
            seed + inner_fold,
            device,
            epochs=cfg["epochs"]["detector_inner_max"],
            validation_records=fold_validation,
        )
        prompt_error_profile = derive_inner_oof_detector_prompt_errors(
            fold_validation,
            checkpoints / f"detector_inner_{inner_fold}.pt",
            cfg,
            device,
        )
        atomic_json(
            checkpoints / f"prompt_error_profile_inner_{inner_fold}.json",
            prompt_error_profile,
        )
        train_medsam_decoder(
            fold_train,
            checkpoints / f"medsam_inner_{inner_fold}.pt",
            cfg,
            seed + 500 + inner_fold,
            device,
            env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
            env["MEDSAM_CKPT"],
            epochs=cfg["epochs"]["medsam_inner_max"],
            validation_records=fold_validation,
            prompt_error_profile=prompt_error_profile,
            use_prompt_error_curriculum=True,
        )
        atomic_json(checkpoints / f"detector_inner_{inner_fold}.weights.json", verified)
    elif operation in {
        "candidates_inner",
        "candidates_eval",
        "candidates_non_oof_leakage_train",
    }:
        if operation == "candidates_inner":
            if inner_fold is None:
                raise ValueError("inner_fold is required")
            checkpoint = checkpoints / f"detector_inner_{inner_fold}.pt"
            medsam_checkpoint = checkpoints / f"medsam_inner_{inner_fold}.pt"
            heldout = [
                record
                for record in train_records
                if int(split["inner_assignment"][record.patient_id]) == inner_fold
            ]
            payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
            training_patients = set(payload["training_patient_ids"])
            heldout_patients = {record.patient_id for record in heldout}
            if training_patients & heldout_patients:
                raise RuntimeError("PATIENT_LEAKAGE: inner detector checkpoint includes held-out patient")
            _validate_medsam_decoder_provenance(
                medsam_checkpoint,
                expected_training_patients=training_patients,
                heldout_patients=heldout_patients,
            )
            provenance = {
                "candidate_source": "patient_level_inner_fold_oof",
                "inner_fold": inner_fold,
                "checkpoint_sha256": sha256_file(checkpoint),
                "medsam_decoder_checkpoint_sha256": sha256_file(medsam_checkpoint),
                "training_patient_ids": sorted(training_patients),
                "heldout_patient_ids": sorted(heldout_patients),
            }
            medsam = MedSAMAdapter(
                env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
                env["MEDSAM_CKPT"],
                cfg["medsam"]["expected_sha256"],
                cfg["medsam"]["expected_commit"],
                device,
                medsam_checkpoint,
            )
            model = load_detector(checkpoint, cfg, device)
            generate_candidates(
                heldout,
                model,
                medsam,
                run_dir / "candidates" / f"inner_{inner_fold}",
                cfg,
                seed + 100 + inner_fold,
                provenance,
                include_diagnostics=False,
            )
        elif operation == "candidates_eval":
            checkpoint = checkpoints / "detector_final.pt"
            medsam_checkpoint = checkpoints / "medsam_final.pt"
            payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
            training_patients = set(payload["training_patient_ids"])
            evaluation_patients = {record.patient_id for record in eval_records}
            if training_patients & evaluation_patients:
                raise RuntimeError("PATIENT_LEAKAGE: final detector checkpoint includes evaluation patient")
            _validate_medsam_decoder_provenance(
                medsam_checkpoint,
                expected_training_patients=training_patients,
                heldout_patients=evaluation_patients,
            )
            provenance = {
                "candidate_source": "heldout_final_detector",
                "inner_fold": None,
                "checkpoint_sha256": sha256_file(checkpoint),
                "medsam_decoder_checkpoint_sha256": sha256_file(medsam_checkpoint),
                "training_patient_ids": sorted(training_patients),
                "heldout_patient_ids": sorted(evaluation_patients),
            }
            medsam = MedSAMAdapter(
                env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
                env["MEDSAM_CKPT"],
                cfg["medsam"]["expected_sha256"],
                cfg["medsam"]["expected_commit"],
                device,
                medsam_checkpoint,
            )
            model = load_detector(checkpoint, cfg, device)
            generate_candidates(
                eval_records,
                model,
                medsam,
                run_dir / "candidates" / "evaluation",
                cfg,
                seed + 200,
                provenance,
                include_diagnostics=True,
            )
        else:
            if split.get("mode") != "phase2":
                raise RuntimeError("The non-OOF leakage demonstration is full-stage only")
            checkpoint = checkpoints / "detector_final.pt"
            medsam_checkpoint = checkpoints / "medsam_final.pt"
            payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
            training_patients = set(payload["training_patient_ids"])
            generation_patients = {record.patient_id for record in train_records}
            if training_patients != generation_patients:
                raise RuntimeError(
                    "Leakage demonstration requires the final detector's own complete outer-train set"
                )
            _validate_medsam_decoder_provenance(
                medsam_checkpoint,
                expected_training_patients=training_patients,
                heldout_patients=set(),
            )
            paths = leakage_ablation_paths(run_dir)
            provenance = {
                "candidate_source": "final_detector_on_its_own_outer_train_images",
                "protocol_label": LEAKAGE_ABLATION_LABEL,
                "valid_method": False,
                "inner_fold": None,
                "checkpoint_sha256": sha256_file(checkpoint),
                "medsam_decoder_checkpoint_sha256": sha256_file(medsam_checkpoint),
                "training_patient_ids": sorted(training_patients),
                "candidate_generation_patient_ids": sorted(generation_patients),
                "training_generation_patient_overlap_ids": sorted(
                    training_patients & generation_patients
                ),
                "known_patient_leakage_for_demonstration": True,
                "outer_test_used_for_candidate_generation": False,
            }
            medsam = MedSAMAdapter(
                env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
                env["MEDSAM_CKPT"],
                cfg["medsam"]["expected_sha256"],
                cfg["medsam"]["expected_commit"],
                device,
                medsam_checkpoint,
            )
            model = load_detector(checkpoint, cfg, device)
            generate_candidates(
                train_records,
                model,
                medsam,
                paths["training_candidates_dir"],
                cfg,
                seed + 700,
                provenance,
                include_diagnostics=False,
            )
    elif operation == "infer_deeplab":
        _validate_model_patient_exposure(
            checkpoints / "deeplab.pt",
            expected_training_patients={record.patient_id for record in train_records},
            heldout_patients={record.patient_id for record in eval_records},
            label="DEEPLAB",
        )
        model = load_deeplab(checkpoints / "deeplab.pt", cfg, device)
        checkpoint_hash = sha256_file(checkpoints / "deeplab.pt")
        infer_deeplab(
            model, eval_records, run_dir / "baselines" / "b0", cfg, False, device, checkpoint_hash
        )
        infer_deeplab(
            model, eval_records, run_dir / "baselines" / "b1", cfg, True, device, checkpoint_hash
        )
    elif operation == "infer_mask":
        _validate_model_patient_exposure(
            checkpoints / "mask_rcnn.pt",
            expected_training_patients={record.patient_id for record in train_records},
            heldout_patients={record.patient_id for record in eval_records},
            label="MASK_RCNN",
        )
        model = load_mask_rcnn(checkpoints / "mask_rcnn.pt", cfg, device)
        infer_mask_rcnn(
            model,
            eval_records,
            run_dir / "baselines" / "mask_rcnn",
            cfg,
            device,
            sha256_file(checkpoints / "mask_rcnn.pt"),
        )
    elif operation == "infer_autobusam":
        legal_patients = {record.patient_id for record in train_records}
        heldout_patients = {record.patient_id for record in eval_records}
        validate_autobusam_checkpoint(
            checkpoints / "autobusam_yolo.pt",
            checkpoints / "autobusam_sam_lora.pt",
            legal_patients,
            heldout_patients,
            cfg,
        )
        yolo = load_autobusam_yolo(checkpoints / "autobusam_yolo.pt")
        sam_adapter = load_autobusam_sam_adapter(
            cfg,
            env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
            env["SCREENBUS_WEIGHT_ROOT"] / cfg["autobusam"]["sam_checkpoint_file"],
            checkpoints / "autobusam_sam_lora.pt",
            device,
        )
        infer_autobusam_adapted(
            yolo,
            sam_adapter,
            eval_records,
            run_dir / "baselines" / "autobusam_style",
            cfg,
            sha256_file(checkpoints / "autobusam_yolo.pt"),
        )
    elif operation == "benchmark_baseline_chains":
        if split.get("mode") != "phase2":
            raise RuntimeError("Predicted-only baseline benchmarks are full-stage only")
        legal_patients = {record.patient_id for record in train_records}
        heldout_patients = {record.patient_id for record in eval_records}
        _validate_model_patient_exposure(
            checkpoints / "deeplab.pt",
            expected_training_patients=legal_patients,
            heldout_patients=heldout_patients,
            label="DEEPLAB_BENCHMARK",
        )
        _validate_model_patient_exposure(
            checkpoints / "mask_rcnn.pt",
            expected_training_patients=legal_patients,
            heldout_patients=heldout_patients,
            label="MASK_RCNN_BENCHMARK",
        )
        validate_autobusam_checkpoint(
            checkpoints / "autobusam_yolo.pt",
            checkpoints / "autobusam_sam_lora.pt",
            legal_patients,
            heldout_patients,
            cfg,
        )
        deeplab = load_deeplab(checkpoints / "deeplab.pt", cfg, device)
        mask_rcnn = load_mask_rcnn(checkpoints / "mask_rcnn.pt", cfg, device)
        autobusam_yolo = load_autobusam_yolo(checkpoints / "autobusam_yolo.pt")
        autobusam_sam = load_autobusam_sam_adapter(
            cfg,
            env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
            env["SCREENBUS_WEIGHT_ROOT"] / cfg["autobusam"]["sam_checkpoint_file"],
            checkpoints / "autobusam_sam_lora.pt",
            device,
        )
        def save_benchmark(method: str, filename: str, models, inference) -> None:
            _summary, measured = _measure_loaded_cuda_chain(
                inference, len(eval_records), float(cfg["runtime"]["max_peak_vram_gib"])
            )
            total_parameters = sum(
                parameter.numel() for model in models for parameter in model.parameters()
            )
            atomic_json(
                run_dir / "runtime" / filename,
                {
                    "schema_version": 1,
                    "method": method,
                    "box_condition": "predicted_only",
                    "ground_truth_pixels_read": False,
                    "measurement_status": "MEASURED_PREDICTED_ONLY_END_TO_END",
                    "parameter_scope": "total_deployed_system",
                    "total_system_parameter_count": total_parameters,
                    **measured,
                },
            )

        def deeplab_inference():
            accepted = 0
            for record in eval_records:
                image = Image.open(record.image_path).convert("RGB")
                tensor = TF.to_tensor(
                    TF.resize(image, [cfg["image_size"], cfg["image_size"]], antialias=True)
                ).unsqueeze(0).to(device)
                with torch.inference_mode(), torch.autocast("cuda", torch.float16, enabled=cfg["amp"]):
                    output = deeplab(tensor)
                accepted += int(torch.sigmoid(output["presence_logits"])[0] >= 0.5)
            return {"accepted_images": accepted}

        def mask_inference():
            candidates = 0
            for record in eval_records:
                tensor = TF.to_tensor(Image.open(record.image_path).convert("RGB")).to(device)
                with torch.inference_mode(), torch.autocast("cuda", torch.float16, enabled=cfg["amp"]):
                    output = mask_rcnn([tensor])[0]
                candidates += min(int(len(output["scores"])), int(cfg["detector_top_k"]))
            return {"candidate_count": candidates}

        def autobusam_inference():
            candidates = 0
            for record in eval_records:
                pil_image = Image.open(record.image_path).convert("RGB")
                image_rgb = np.asarray(pil_image)
                result = autobusam_yolo.predict(
                    source=image_rgb,
                    imgsz=int(cfg["autobusam"]["image_size"]),
                    conf=float(cfg["autobusam"]["confidence"]),
                    iou=float(cfg["autobusam"]["nms_iou"]),
                    max_det=int(cfg["detector_top_k"]),
                    verbose=False,
                )[0]
                boxes = result.boxes.xyxy.detach().float().cpu().numpy()
                if len(boxes):
                    autobusam_sam.segment(image_rgb, boxes)
                candidates += len(boxes)
            return {"candidate_count": candidates}

        save_benchmark("B1_DeepLabV3Plus_HardGate", "b1_predicted_only.json", [deeplab], deeplab_inference)
        save_benchmark("MaskRCNN_R50_FPN", "mask_rcnn_predicted_only.json", [mask_rcnn], mask_inference)
        save_benchmark(
            AUTOBUSAM_METHOD,
            "autobusam_predicted_only.json",
            [autobusam_yolo.model, autobusam_sam.model],
            autobusam_inference,
        )
    elif operation == "nnunet":
        run_nnunet_baseline(
            train_records, eval_records, run_dir, cfg, int(split["outer_fold"]), int(split["seed"])
        )
    elif operation in {"postprocess", "postprocess_phase1"}:
        oof_rows = load_candidate_rows(run_dir / "candidates" / "oof_merged.jsonl")
        eval_rows = load_candidate_rows(run_dir / "candidates" / "evaluation" / "candidates.jsonl")
        eval_predicted = [row for row in eval_rows if row["condition"] == "predicted_box"]

        def build_verifier(
            label, verifier_train_rows, verifier_eval_rows, verifier_input: str
        ):
            verifier_dir = run_dir / f"verifier_{label}"
            train_verifier_and_controls(verifier_train_rows, verifier_dir, cfg, seed, device)
            meta_oof_payload = json.loads(
                (verifier_dir / "training_scores.json").read_text(encoding="utf-8")
            )
            score_names = (
                "meta_fold",
                "verifier",
                "verifier_existence",
                "verifier_quality",
                "detector_score",
                "sam_predicted_iou",
                "sam_stability",
                "jitter_variance",
                "area_component_rule",
                "lightweight_quality_regressor",
            )
            assert_threshold_selection_scores_are_meta_oof(
                meta_oof_payload,
                [
                    "verifier_existence",
                    "verifier_quality",
                    "detector_score",
                    "sam_predicted_iou",
                    "sam_stability",
                    "jitter_variance",
                    "area_component_rule",
                    "lightweight_quality_regressor",
                ],
            )
            keyed_meta_oof = {
                key: {
                    name: meta_oof_payload[name][index] for name in score_names
                }
                for index, key in enumerate(meta_oof_payload["image_candidate_keys"])
            }
            oof_scores = {name: [] for name in score_names}
            for row in verifier_train_rows:
                key = f"{row['image_id']}:{row['candidate_index']}:{row['condition']}"
                if row.get("is_sentinel"):
                    for name, values in oof_scores.items():
                        values.append(
                            int(split["inner_assignment"][str(row["patient_id"])])
                            if name == "meta_fold"
                            else float("-inf")
                        )
                    continue
                if key not in keyed_meta_oof:
                    raise RuntimeError(f"VERIFIER_META_OOF_ALIGNMENT_MISSING: {key}")
                for name, values in oof_scores.items():
                    values.append(float(keyed_meta_oof[key][name]))
            eval_scores = score_methods(verifier_eval_rows, verifier_dir, device)
            verifier_payload = torch.load(
                verifier_dir / "oof_verifier.pt", map_location="cpu", weights_only=False
            )
            calibration_patients = set(verifier_payload["calibration"]["calibration_patient_ids"])
            calibration_rows = [
                row for row in verifier_train_rows if row["patient_id"] in calibration_patients
            ]
            calibration_meta_folds = [
                int(value)
                for row, value in zip(verifier_train_rows, oof_scores["meta_fold"])
                if row["patient_id"] in calibration_patients
            ]
            thresholds: dict[str, Any] = {}
            operating_points: dict[str, Any] = {}
            threshold_methods = (
                "detector_score",
                "sam_predicted_iou",
                "sam_stability",
                "jitter_variance",
                "area_component_rule",
                "lightweight_quality_regressor",
                "verifier",
            )
            for method in threshold_methods:
                # Only the existence head selects the verifier operating point.
                # The joint score remains a failure-ranking diagnostic and may
                # never lower the normal-FP count by converting refer to empty.
                score_key = "verifier_existence" if method == "verifier" else method
                values = oof_scores[score_key]
                calibration_values = [
                    value
                    for row, value in zip(verifier_train_rows, values)
                    if row["patient_id"] in calibration_patients
                ]
                stability_limit = float(
                    cfg["verifier"]["threshold_stability"]["max_fold_threshold_range"]
                )
                if method == "verifier":
                    quality_values = [
                        value
                        for row, value in zip(
                            verifier_train_rows, oof_scores["verifier_quality"]
                        )
                        if row["patient_id"] in calibration_patients
                    ]
                    selected_thresholds = select_fold_stable_dual_thresholds_for_sensitivity(
                        calibration_rows,
                        calibration_values,
                        quality_values,
                        calibration_meta_folds,
                        cfg["target_lesion_sensitivity"],
                        stability_limit,
                    )
                else:
                    selected_thresholds = select_fold_stable_threshold_for_sensitivity(
                        calibration_rows,
                        calibration_values,
                        calibration_meta_folds,
                        cfg["target_lesion_sensitivity"],
                        stability_limit,
                    )
                if selected_thresholds.get("status") != "STABLE_THRESHOLD":
                    raise InsufficientEvents(
                        "UNSTABLE_THRESHOLD / NO_DECISION: "
                        f"{method}: {selected_thresholds}"
                    )
                thresholds[method] = {
                    **selected_thresholds,
                    "calibration_patient_ids": sorted(calibration_patients),
                    "verifier_input": verifier_input,
                    "operating_score": score_key,
                }
                if method == "verifier":
                    thresholds[method].update(
                        quality_threshold_source="fold_stable_patient_grouped_meta_oof_probability_threshold",
                        frozen_quality_label_dice_threshold=float(cfg["failure_dice_threshold"]),
                        failure_ranking_score="verifier_joint_existence_times_conditional_quality",
                        decision_states=(
                            "empty_if_no_existence;refer_if_exists_but_quality_low;"
                            "accept_if_both_pass"
                        ),
                    )
                operating_curve = full_cohort_selective_curve(
                    method,
                    calibration_rows,
                    calibration_values,
                    points=2,
                    operating_threshold=float(thresholds[method]["threshold"]),
                    quality_scores=(quality_values if method == "verifier" else None),
                    quality_threshold=(
                        float(thresholds[method]["quality_threshold"])
                        if method == "verifier"
                        else None
                    ),
                )
                operating_points[method] = next(
                    row for row in operating_curve if row["operating_point"]
                )
                thresholds[method]["full_cohort_operating_point"] = operating_points[
                    method
                ]
            simple_controls = list(threshold_methods[:-1])
            eligible_controls = [
                name
                for name in simple_controls
                if thresholds[name]["target_attainable"]
                and float(thresholds[name]["oof_lesion_sensitivity"])
                >= float(cfg["target_lesion_sensitivity"])
            ]
            if eligible_controls:
                strongest_control = min(
                    eligible_controls,
                    key=lambda name: (
                        float(operating_points[name]["negative_view_action_rate"]),
                        name,
                    ),
                )
                strongest_status = "SELECTED_AT_TARGET_SENSITIVITY"
            else:
                strongest_control = min(
                    simple_controls,
                    key=lambda name: (
                        -float(thresholds[name]["oof_lesion_sensitivity"]),
                        float(operating_points[name]["negative_view_action_rate"]),
                        name,
                    ),
                )
                strongest_status = "SELECTED_MAX_ATTAINABLE_SENSITIVITY_TARGET_NOT_MET"
            thresholds["strongest_simple_control"] = {
                "name": strongest_control,
                "status": strongest_status,
                "selection_source": "inner_meta_oof_only",
                "selection_metric": "minimum_negative_view_action_rate_at_target_sensitivity",
                "target_lesion_sensitivity": float(cfg["target_lesion_sensitivity"]),
                "outer_or_test_used": False,
                "all_controls_same_image_state_and_full_cohort_evaluator": True,
            }
            atomic_json(verifier_dir / "thresholds.json", thresholds)
            atomic_json(
                verifier_dir / "strongest_simple_control.json",
                thresholds["strongest_simple_control"],
            )
            atomic_json(verifier_dir / "control_operating_points.json", operating_points)
            atomic_json(
                verifier_dir / "input_policy.json",
                {
                    "verifier_input": verifier_input,
                    "candidate_generation": "patient_level_inner_fold_oof",
                    "existence_task": "all_real_candidates",
                    "quality_task": "candidate_valid_only_binary_dice_at_0.75",
                    "model": "two_head_l2_logistic_regression",
                    "patient_weighting": "equal_total_weight_per_patient_all_legal_inner_oof_candidates",
                    "hard_negative_mining": "disabled",
                    "threshold_selection": "leave_one_meta_fold_out_then_fold_median",
                    "strongest_simple_control": strongest_control,
                    "normal_fp_gate_component": "verifier_existence",
                    "failure_ranking_component": "verifier_joint_existence_times_conditional_quality",
                },
            )
            atomic_json(
                verifier_dir / "evaluation_scores.json",
                {
                    name: [(-1e9 if not torch.isfinite(torch.tensor(value)) else value) for value in values]
                    for name, values in eval_scores.items()
                },
            )
            atomic_json(
                verifier_dir / "evaluation_component_metrics.json",
                verifier_component_metrics(
                    verifier_eval_rows,
                    eval_scores["verifier_existence"],
                    eval_scores["verifier_quality"],
                ),
            )

        # The raw B3 verifier is the mandatory fallback and is built before any
        # optional PointRend diagnostic work. Phase-1 insufficiency is an
        # evidence outcome for G3, not permission to stop before the other
        # outer folds have been evaluated.
        try:
            build_verifier("b3", oof_rows, eval_predicted, "B3_raw_medsam")
        except InsufficientEvents as error:
            if operation != "postprocess_phase1":
                raise
            reason = str(error)
            atomic_json(
                run_dir / "phase1_insufficient_evidence.json",
                {
                    "status": "NO_DECISION_INSUFFICIENT_EVIDENCE_PENDING_COMPLETE_FIVE_FOLDS",
                    "reason": reason,
                    "any_meta_fold_single_class": "single-class" in reason or "single class" in reason,
                    "threshold_unstable": "UNSTABLE_THRESHOLD" in reason,
                    "effective_failure_events_sufficient": False,
                },
            )
            atomic_json(
                run_dir / "pointrend_diagnostic_status.json",
                {
                    "status": "FORBIDDEN_NOT_RUN_IN_PHASE1",
                    "training_run": False,
                    "main_route": "B3_MedSAM_plus_B5_verifier",
                },
            )
            atomic_json(
                run_dir / "verifier_selection.json",
                {
                    "selected": None,
                    "status": "NOT_ESTIMABLE_INSUFFICIENT_EVIDENCE",
                    "b5_default_upstream": "B3_FPN_MedSAM",
                    "pointrend_role": "FORBIDDEN_IN_PHASE1",
                },
            )
            return
        if operation == "postprocess_phase1":
            atomic_json(
                run_dir / "pointrend_diagnostic_status.json",
                {
                    "status": "FORBIDDEN_NOT_RUN_IN_PHASE1",
                    "training_run": False,
                    "main_route": "B3_MedSAM_plus_B5_verifier",
                },
            )
            atomic_json(
                run_dir / "verifier_selection.json",
                {
                    "selected": "verifier_b3",
                    "b5_default_upstream": "B3_FPN_MedSAM",
                    "b4_reportable_as_key_secondary": False,
                    "requested_pointrend_main": False,
                    "pointrend_role": "FORBIDDEN_IN_PHASE1",
                },
            )
            return
        use_pointrend_main = bool(split.get("include_pointrend_main", True))
        pointrend_status: dict[str, Any]
        try:
            assignment = {patient: int(fold) for patient, fold in split["inner_assignment"].items()}
            crossfit_plan = build_pointrend_crossfit_plan(
                oof_rows, assignment, int(cfg["inner_folds"])
            )
            oof_patients = sorted({str(row["patient_id"]) for row in oof_rows})
            evaluation_patients = sorted({str(row["patient_id"]) for row in eval_predicted})
            if set(oof_patients) & set(evaluation_patients):
                raise RuntimeError("PATIENT_LEAKAGE: final PointRend train/evaluation overlap")

            def run_refiner_variant(variant: str) -> dict[str, Any]:
                if variant != "generic":
                    raise RuntimeError("ONLY_ORIGINAL_POINTREND_IS_AUTHORIZED")
                slug = "generic"
                refined_oof: list[dict[str, Any]] = []
                fold_provenance: list[dict[str, Any]] = []
                for fold_plan in crossfit_plan:
                    fold = int(fold_plan["inner_fold"])
                    point_checkpoint = checkpoints / f"pointrend_{slug}_inner_{fold}.pt"
                    train_pointrend(
                        fold_plan["training_rows"],
                        point_checkpoint,
                        cfg,
                        seed + 300 + fold,
                        device,
                        variant=variant,
                    )
                    refined_fold_path = apply_pointrend(
                        fold_plan["heldout_rows"],
                        point_checkpoint,
                        run_dir / "refined" / slug / "oof" / f"inner_{fold}",
                        cfg,
                        device,
                        training_patient_ids=fold_plan["training_patient_ids"],
                        heldout_patient_ids=fold_plan["heldout_patient_ids"],
                        refiner_protocol=f"patient_level_inner_fold_crossfit_{variant}",
                        refiner_inner_fold=fold,
                    )
                    refined_oof.extend(load_candidate_rows(refined_fold_path))
                    fold_provenance.append(
                        {
                            "inner_fold": fold,
                            "variant": variant,
                            "training_patient_ids": fold_plan["training_patient_ids"],
                            "heldout_patient_ids": fold_plan["heldout_patient_ids"],
                            "checkpoint": str(point_checkpoint),
                            "checkpoint_sha256": sha256_file(point_checkpoint),
                            "refined_jsonl": str(refined_fold_path),
                            "refined_jsonl_sha256": sha256_file(refined_fold_path),
                        }
                    )
                audit = validate_refiner_crossfit_provenance(refined_oof, assignment)
                refined_oof_path = run_dir / "refined" / slug / "oof" / "candidates.jsonl"
                refined_oof_path.parent.mkdir(parents=True, exist_ok=True)
                partial = refined_oof_path.with_suffix(".partial")
                with partial.open("w", encoding="utf-8") as handle:
                    for row in refined_oof:
                        handle.write(json.dumps(row, sort_keys=True) + "\n")
                partial.replace(refined_oof_path)
                atomic_json(
                    refined_oof_path.parent / "metadata.json",
                    {
                        "status": "PASS_PATIENT_LEVEL_CROSSFIT",
                        "variant": variant,
                        "fold_count": len(fold_provenance),
                        "folds": fold_provenance,
                        "audit": audit,
                        "candidate_jsonl_sha256": sha256_file(refined_oof_path),
                        "single_model_self_inference_forbidden": True,
                    },
                )
                final_checkpoint = checkpoints / f"pointrend_{slug}.pt"
                train_pointrend(
                    oof_rows,
                    final_checkpoint,
                    cfg,
                    seed + 399,
                    device,
                    variant=variant,
                )
                refined_eval_path = apply_pointrend(
                    eval_predicted,
                    final_checkpoint,
                    run_dir / "refined" / slug / "evaluation",
                    cfg,
                    device,
                    training_patient_ids=oof_patients,
                    heldout_patient_ids=evaluation_patients,
                    refiner_protocol=f"final_refiner_fit_legal_detector_oof_{variant}",
                    refiner_inner_fold=None,
                )
                return {
                    "variant": variant,
                    "oof_rows": refined_oof,
                    "eval_rows": load_candidate_rows(refined_eval_path),
                    "oof_candidates": str(refined_oof_path),
                    "evaluation_candidates": str(refined_eval_path),
                    "crossfit_audit": audit,
                    "folds": fold_provenance,
                    "final_checkpoint": str(final_checkpoint),
                    "final_checkpoint_sha256": sha256_file(final_checkpoint),
                }

            requested_variants = ["generic"]
            variants = {variant: run_refiner_variant(variant) for variant in requested_variants}
            selected_variant = "generic"
            selection_source = "V2_3_OPTIONAL_ORIGINAL_POINTREND_AFTER_G3"
            selected = variants[selected_variant]
            build_verifier(
                "b4",
                selected["oof_rows"],
                selected["eval_rows"],
                "B4_selected_pointrend",
            )
            pointrend_status = {
                "status": "COMPLETE",
                "error": None,
                "b4_oof_protocol": "patient_level_inner_fold_crossfit",
                "variants_executed": requested_variants,
                "variant_outputs": {
                    variant: {key: value for key, value in payload.items() if key not in {"oof_rows", "eval_rows"}}
                    for variant, payload in variants.items()
                },
                "selected_variant": selected_variant,
                "reported_name": "Original PointRend",
                "selection_source": selection_source,
                "selected_oof_candidates": selected["oof_candidates"],
                "selected_evaluation_candidates": selected["evaluation_candidates"],
                "selected_final_checkpoint": selected["final_checkpoint"],
                "selected_final_checkpoint_sha256": selected["final_checkpoint_sha256"],
                "final_training_patient_ids": oof_patients,
                "final_heldout_patient_ids": evaluation_patients,
                "single_model_self_inference_forbidden": True,
            }
        except Exception as error:
            pointrend_status = {
                "status": "OPTIONAL_ORIGINAL_POINTREND_FAILED_ROUTE_DROPPED",
                "error": str(error),
                "traceback": traceback.format_exc(),
                "main_route_preserved": "B3_MedSAM_plus_B5_verifier",
                "point_rend_features_entered_main_verifier": False,
            }
        atomic_json(run_dir / "pointrend_diagnostic_status.json", pointrend_status)
        selected_b4 = use_pointrend_main and pointrend_status["status"] == "COMPLETE"
        atomic_json(
            run_dir / "verifier_selection.json",
            {
                "selected": "verifier_b3",
                "b5_default_upstream": "B3_FPN_MedSAM",
                "b4_completed_pending_boundary_hd95_keep_rule": selected_b4,
                "b4_reportable_as_main_route": False,
                "requested_pointrend_main": use_pointrend_main,
                "pointrend_role": "optional_boundary_ablation_not_b5_default",
            },
        )
    elif operation == "benchmark_predicted_chains":
        if split.get("mode") != "phase2":
            raise RuntimeError("Predicted-only efficiency benchmarks are full-stage only")
        include_pointrend_main = bool(split.get("include_pointrend_main", True))
        benchmark_root = run_dir / "runtime" / "efficiency_benchmark"
        benchmark_root.mkdir(parents=True, exist_ok=True)
        detector_checkpoint = checkpoints / "detector_final.pt"
        detector_payload = torch.load(
            detector_checkpoint, map_location="cpu", weights_only=False
        )
        training_patients = {str(value) for value in detector_payload["training_patient_ids"]}
        evaluation_patients = {record.patient_id for record in eval_records}
        if training_patients & evaluation_patients:
            raise RuntimeError("PATIENT_LEAKAGE in predicted-only efficiency benchmark")
        _validate_medsam_decoder_provenance(
            checkpoints / "medsam_final.pt",
            expected_training_patients=training_patients,
            heldout_patients=evaluation_patients,
        )

        def benchmark_chain(
            method: str,
            slug: str,
            *,
            with_pointrend: bool,
            with_verifier: bool,
        ) -> None:
            output_dir = benchmark_root / slug
            if output_dir.exists():
                shutil.rmtree(output_dir)
            detector = load_detector(detector_checkpoint, cfg, device)
            medsam = MedSAMAdapter(
                env["SCREENBUS_CACHE_ROOT"] / cfg["medsam"]["repository_under_cache"],
                env["MEDSAM_CKPT"],
                cfg["medsam"]["expected_sha256"],
                cfg["medsam"]["expected_commit"],
                device,
                checkpoints / "medsam_final.pt",
            )
            deployed_models: list[torch.nn.Module] = [detector, medsam.model]
            point_model = None
            point_payload = None
            point_checkpoint = checkpoints / "pointrend_generic.pt"
            if with_pointrend:
                point_status = json.loads(
                    (run_dir / "pointrend_diagnostic_status.json").read_text(
                        encoding="utf-8"
                    )
                )
                point_checkpoint = Path(point_status["selected_final_checkpoint"])
                point_payload = torch.load(
                    point_checkpoint, map_location="cpu", weights_only=False
                )
                point_model = load_pointrend(point_checkpoint, device)
                deployed_models.append(point_model)
            verifier_payload = None
            verifier_dir = run_dir / ("verifier_b4" if with_pointrend else "verifier_b3")
            thresholds = None
            if with_verifier:
                verifier_payload = torch.load(
                    verifier_dir / "oof_verifier.pt",
                    map_location="cpu",
                    weights_only=False,
                )
                if verifier_payload.get("model_type") != "two_head_l2_logistic_regression":
                    raise RuntimeError("EFFICIENCY_VERIFIER_IS_NOT_L2_LOGISTIC")
                thresholds = json.loads(
                    (verifier_dir / "thresholds.json").read_text(encoding="utf-8")
                )["verifier"]
            total_parameters = sum(
                parameter.numel()
                for model in deployed_models
                for parameter in model.parameters()
            ) + (int(verifier_payload["parameter_count"]) if verifier_payload else 0)
            if total_parameters <= 0:
                raise RuntimeError(f"Invalid total deployed parameter count for {method}")

            def inference() -> dict[str, Any]:
                generated_path = generate_candidates(
                    eval_records,
                    detector,
                    medsam,
                    output_dir / "b3",
                    cfg,
                    seed + 900,
                    {
                        "candidate_source": "predicted_only_efficiency_benchmark",
                        "checkpoint_sha256": sha256_file(detector_checkpoint),
                        "training_patient_ids": sorted(training_patients),
                        "heldout_patient_ids": sorted(evaluation_patients),
                    },
                    include_diagnostics=False,
                    label_candidates=False,
                    compute_jitter_features=with_verifier,
                )
                rows = load_candidate_rows(generated_path)
                if with_pointrend:
                    assert point_model is not None and point_payload is not None
                    refined_path = apply_pointrend(
                        rows,
                        point_checkpoint,
                        output_dir / "b4",
                        cfg,
                        device,
                        training_patient_ids=point_payload["training_patient_ids"],
                        heldout_patient_ids=sorted(evaluation_patients),
                        refiner_protocol="predicted_only_efficiency_benchmark",
                        refiner_inner_fold=None,
                        label_candidates=False,
                        preloaded_model=point_model,
                        checkpoint_payload=point_payload,
                    )
                    rows = load_candidate_rows(refined_path)
                state_counts = None
                if with_verifier:
                    assert verifier_payload is not None
                    assert thresholds is not None
                    real_rows = [row for row in rows if not row.get("is_sentinel")]
                    features = torch.tensor(
                        [row["features"] for row in real_rows],
                        dtype=torch.float32,
                        device=device,
                    )
                    with torch.inference_mode():
                        if len(real_rows):
                            mean = torch.tensor(verifier_payload["normalizer_mean"], device=device)
                            scale = torch.tensor(verifier_payload["normalizer_scale"], device=device)
                            normalized = (features - mean) / scale
                            existence = torch.sigmoid(
                                normalized @ torch.tensor(verifier_payload["existence_coef"], device=device)
                                + float(verifier_payload["existence_intercept"])
                            )
                            quality = torch.sigmoid(
                                normalized @ torch.tensor(verifier_payload["quality_coef"], device=device)
                                + float(verifier_payload["quality_intercept"])
                            )
                            accepted = int(
                                ((existence >= float(thresholds["existence_threshold"]))
                                & (quality >= float(thresholds["quality_threshold"]))).sum().item()
                            )
                            referred = int(
                                ((existence >= float(thresholds["existence_threshold"]))
                                & (quality < float(thresholds["quality_threshold"]))).sum().item()
                            )
                        else:
                            accepted = 0
                            referred = 0
                    state_counts = {
                        "candidate_count": len(real_rows),
                        "accepted_candidate_count": accepted,
                        "referred_candidate_count": referred,
                    }
                return {
                    "candidate_rows": len(rows),
                    "decision_state_counts": state_counts,
                }

            summary, measured = _measure_loaded_cuda_chain(
                inference, len(eval_records), float(cfg["runtime"]["max_peak_vram_gib"])
            )
            atomic_json(
                run_dir / "runtime" / f"{slug}_predicted_only.json",
                {
                    "schema_version": 1,
                    "method": method,
                    **measured,
                    **summary,
                    "total_system_parameter_count": int(total_parameters),
                    "parameter_scope": "all_neural_parameters_loaded_for_deployed_system",
                    "box_condition": "predicted_box_only",
                    "includes_detector": True,
                    "includes_medsam": True,
                    "includes_pointrend": with_pointrend,
                    "includes_dual_head_verifier": with_verifier,
                    "jitter_features_computed": with_verifier,
                },
            )
            del detector, medsam, deployed_models, point_model, verifier_model
            gc.collect()
            torch.cuda.empty_cache()

        benchmark_chain(
            "B3_FPN_MedSAM", "b3", with_pointrend=False, with_verifier=False
        )
        if include_pointrend_main:
            benchmark_chain(
                "B4_OriginalPointRend_Diagnostic",
                "b4",
                with_pointrend=True,
                with_verifier=False,
            )
        benchmark_chain(
            "B5_OOF_Verifier",
            "b5",
            with_pointrend=False,
            with_verifier=True,
        )
    elif operation == "benchmark_nnunet_predict_only":
        if split.get("mode") != "phase2":
            raise RuntimeError("nnU-Net efficiency benchmark is full-stage only")
        from .nnunet_baseline import benchmark_nnunet_predict_only

        benchmark_nnunet_predict_only(
            eval_records,
            run_dir,
            cfg,
            int(split["outer_fold"]),
            int(split["seed"]),
        )
    elif operation == "fit_non_oof_leakage_verifier":
        if split.get("mode") != "phase2":
            raise RuntimeError("The non-OOF leakage demonstration is full-stage only")
        paths = leakage_ablation_paths(run_dir)
        training_rows = load_candidate_rows(paths["training_candidates"])
        detector_checkpoint = checkpoints / "detector_final.pt"
        detector_payload = torch.load(
            detector_checkpoint, map_location="cpu", weights_only=False
        )
        overlap = validate_self_generated_training_candidates(
            training_rows,
            split,
            set(detector_payload["training_patient_ids"]),
        )
        eval_rows = load_candidate_rows(
            run_dir / "candidates" / "evaluation" / "candidates.jsonl"
        )
        eval_predicted = [row for row in eval_rows if row["condition"] == "predicted_box"]
        if {row["patient_id"] for row in eval_predicted} != set(
            split["evaluation_patient_ids"]
        ):
            raise RuntimeError("Leakage demonstration outer-test candidate coverage mismatch")

        legal_files = [
            path
            for label in ("verifier_b3", "verifier_b4")
            for path in (run_dir / label).rglob("*")
            if path.is_file()
        ]
        legal_before = {
            str(path.relative_to(run_dir)): sha256_file(path) for path in sorted(legal_files)
        }
        train_verifier_and_controls(
            training_rows,
            paths["verifier_dir"],
            cfg,
            seed + 701,
            device,
            verifier_filename=paths["verifier_checkpoint"].name,
            protocol_label=LEAKAGE_ABLATION_LABEL,
        )
        training_score_payload = score_methods(
            training_rows,
            paths["verifier_dir"],
            device,
            verifier_filename=paths["verifier_checkpoint"].name,
        )
        evaluation_score_payload = score_methods(
            eval_predicted,
            paths["verifier_dir"],
            device,
            verifier_filename=paths["verifier_checkpoint"].name,
        )
        for score_name in ("verifier", "verifier_existence", "verifier_quality"):
            evaluation_score_payload[score_name] = [
                float(value) if torch.isfinite(torch.tensor(value)) else -1e9
                for value in evaluation_score_payload[score_name]
            ]
        verifier_payload = torch.load(
            paths["verifier_checkpoint"], map_location="cpu", weights_only=False
        )
        if verifier_payload.get("protocol_label") != LEAKAGE_ABLATION_LABEL:
            raise RuntimeError("Leakage verifier checkpoint lacks the mandatory invalid-method label")
        calibration_patients = set(
            verifier_payload["calibration"]["calibration_patient_ids"]
        )
        calibration_rows = [
            row for row in training_rows if row["patient_id"] in calibration_patients
        ]
        calibration_scores = [
            score
            for row, score in zip(
                training_rows, training_score_payload["verifier_existence"]
            )
            if row["patient_id"] in calibration_patients
        ]
        threshold, sensitivity, attainable = select_threshold_for_sensitivity(
            calibration_rows,
            calibration_scores,
            cfg["target_lesion_sensitivity"],
        )
        threshold_payload = {
            "schema_version": 1,
            "protocol_label": LEAKAGE_ABLATION_LABEL,
            "table_role": "ABLATION",
            "valid_method": False,
            "verifier": {
                "threshold": threshold,
                "existence_threshold": threshold,
                "quality_threshold": float(cfg["failure_dice_threshold"]),
                "quality_threshold_source": (
                    "preregistered_failure_dice_threshold_on_calibrated_predicted_dice"
                ),
                "operating_score": "verifier_existence",
                "failure_ranking_score": (
                    "verifier_joint_existence_times_conditional_quality"
                ),
                "decision_states": (
                    "empty_if_no_existence;refer_if_exists_but_quality_low;"
                    "accept_if_both_pass"
                ),
                "training_calibration_lesion_sensitivity": sensitivity,
                "target_attainable": attainable,
                "selection_source": (
                    "patient_disjoint_verifier_calibration_subset_but_candidates_from_"
                    "final_detector_on_its_own_training_images_INVALID"
                ),
                "calibration_patient_ids": sorted(calibration_patients),
                "outer_test_used_for_threshold_selection": False,
            },
        }
        atomic_json(paths["thresholds"], threshold_payload)
        atomic_json(
            paths["evaluation_scores"],
            {
                "schema_version": 1,
                "protocol_label": LEAKAGE_ABLATION_LABEL,
                "table_role": "ABLATION",
                "valid_method": False,
                "image_candidate_keys": [
                    f"{row['image_id']}:{row['candidate_index']}:{row['condition']}"
                    for row in eval_predicted
                ],
                "verifier": evaluation_score_payload["verifier"],
                "verifier_existence": evaluation_score_payload[
                    "verifier_existence"
                ],
                "verifier_quality": evaluation_score_payload["verifier_quality"],
                "outer_test_role": "EVALUATION_ONLY_AFTER_MODEL_AND_THRESHOLD_FREEZE",
            },
        )
        legal_after_files = [
            path
            for label in ("verifier_b3", "verifier_b4")
            for path in (run_dir / label).rglob("*")
            if path.is_file()
        ]
        legal_after = {
            str(path.relative_to(run_dir)): sha256_file(path)
            for path in sorted(legal_after_files)
        }
        if legal_before != legal_after:
            raise RuntimeError("Non-OOF leakage ablation modified a legal OOF verifier artifact")
        atomic_json(
            paths["provenance"],
            {
                "schema_version": 1,
                "protocol_label": LEAKAGE_ABLATION_LABEL,
                "table_role": "ABLATION",
                "valid_method": False,
                "g3_eligible": False,
                "main_table_eligible": False,
                "reason_invalid": (
                    "final detector generated verifier-training candidates on the same outer-train patients"
                ),
                "candidate_provenance": overlap,
                "candidate_jsonl": str(paths["training_candidates"]),
                "candidate_jsonl_sha256": sha256_file(paths["training_candidates"]),
                "candidate_metadata_sha256": sha256_file(
                    paths["training_candidates_dir"] / "metadata.json"
                ),
                "final_detector_checkpoint": str(detector_checkpoint),
                "final_detector_checkpoint_sha256": sha256_file(detector_checkpoint),
                "verifier_checkpoint": str(paths["verifier_checkpoint"]),
                "verifier_checkpoint_sha256": sha256_file(paths["verifier_checkpoint"]),
                "thresholds": str(paths["thresholds"]),
                "thresholds_sha256": sha256_file(paths["thresholds"]),
                "evaluation_scores": str(paths["evaluation_scores"]),
                "evaluation_scores_sha256": sha256_file(paths["evaluation_scores"]),
                "outer_test_used_for_verifier_training_or_threshold_selection": False,
                "outer_test_used_for_final_evaluation": True,
                "legal_oof_verifier_artifacts_unchanged": True,
                "legal_oof_verifier_artifact_hashes": legal_after,
                "artifact_namespace": str(paths["root"]),
            },
        )
    else:
        raise ValueError(f"Unknown worker operation: {operation}")
