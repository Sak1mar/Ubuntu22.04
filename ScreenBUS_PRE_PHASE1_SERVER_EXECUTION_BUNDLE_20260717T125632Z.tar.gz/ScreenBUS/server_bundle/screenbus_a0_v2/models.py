from __future__ import annotations

import contextlib
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models import ResNet18_Weights, resnet18
from torchvision.models.detection import (
    FasterRCNN_ResNet50_FPN_Weights,
    MaskRCNN_ResNet50_FPN_Weights,
    fasterrcnn_resnet50_fpn,
    maskrcnn_resnet50_fpn,
)
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.models.detection.mask_rcnn import MaskRCNNPredictor

from .util import sha256_file


def verify_torchvision_weight_cache(cfg: dict, required: list[str]) -> dict[str, str]:
    if not cfg.get("torchvision_pretrained"):
        return {}
    checkpoint_dir = Path(torch.hub.get_dir()) / "checkpoints"
    verified: dict[str, str] = {}
    for name in required:
        specification = cfg["torchvision_weights"][name]
        path = checkpoint_dir / specification["file"]
        if not path.is_file():
            raise FileNotFoundError(
                f"Required offline torchvision weight is absent: {path}. Fetch it before the network is disabled."
            )
        digest = sha256_file(path)
        if digest != specification["sha256"]:
            raise RuntimeError(f"Torchvision weight SHA-256 mismatch for {name}: {digest}")
        verified[name] = digest
    return verified


class SeparableConv(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int, dilation: int = 1):
        super().__init__(
            nn.Conv2d(
                in_channels,
                in_channels,
                3,
                padding=dilation,
                dilation=dilation,
                groups=in_channels,
                bias=False,
            ),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )


class ASPP(nn.Module):
    def __init__(self, in_channels: int, out_channels: int = 256):
        super().__init__()
        self.branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, 1, bias=False),
                    nn.BatchNorm2d(out_channels),
                    nn.ReLU(inplace=True),
                ),
                SeparableConv(in_channels, out_channels, dilation=6),
                SeparableConv(in_channels, out_channels, dilation=12),
                SeparableConv(in_channels, out_channels, dilation=18),
            ]
        )
        self.project = nn.Sequential(
            nn.Conv2d(out_channels * len(self.branches), out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
        )

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.project(torch.cat([branch(inputs) for branch in self.branches], dim=1))


class DeepLabV3PlusHardGate(nn.Module):
    """Executable DeepLabV3+ with a separate image-presence head.

    B0 uses ``segmentation_logits`` directly. B1 applies the presence output as
    a hard gate at inference.  The two outputs are trained with separate losses.
    """

    def __init__(self, pretrained_backbone: bool = True):
        super().__init__()
        weights = ResNet18_Weights.DEFAULT if pretrained_backbone else None
        encoder = resnet18(weights=weights)
        self.stem = nn.Sequential(encoder.conv1, encoder.bn1, encoder.relu, encoder.maxpool)
        self.layer1 = encoder.layer1
        self.layer2 = encoder.layer2
        self.layer3 = encoder.layer3
        self.layer4 = encoder.layer4
        self.aspp = ASPP(512, 256)
        self.low_project = nn.Sequential(
            nn.Conv2d(64, 48, 1, bias=False), nn.BatchNorm2d(48), nn.ReLU(inplace=True)
        )
        self.decoder = nn.Sequential(
            SeparableConv(304, 256),
            SeparableConv(256, 256),
            nn.Conv2d(256, 1, 1),
        )
        self.presence = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(512, 1))

    def forward(self, inputs: torch.Tensor) -> dict[str, torch.Tensor]:
        output_size = inputs.shape[-2:]
        x = self.stem(inputs)
        low = self.layer1(x)
        x = self.layer2(low)
        x = self.layer3(x)
        high = self.layer4(x)
        context = self.aspp(high)
        context = F.interpolate(context, size=low.shape[-2:], mode="bilinear", align_corners=False)
        decoded = self.decoder(torch.cat([self.low_project(low), context], dim=1))
        return {
            "segmentation_logits": F.interpolate(decoded, size=output_size, mode="bilinear", align_corners=False),
            "presence_logits": self.presence(high).squeeze(1),
        }


def dice_loss(logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    probability = torch.sigmoid(logits)
    numerator = 2 * (probability * target).flatten(1).sum(1) + 1.0
    denominator = probability.flatten(1).sum(1) + target.flatten(1).sum(1) + 1.0
    return 1.0 - (numerator / denominator).mean()


def semantic_loss(outputs: dict[str, torch.Tensor], mask: torch.Tensor, presence: torch.Tensor) -> dict[str, torch.Tensor]:
    segmentation_bce = F.binary_cross_entropy_with_logits(outputs["segmentation_logits"], mask)
    segmentation_dice = dice_loss(outputs["segmentation_logits"], mask)
    presence_bce = F.binary_cross_entropy_with_logits(outputs["presence_logits"], presence)
    return {
        "segmentation_bce": segmentation_bce,
        "segmentation_dice": segmentation_dice,
        "presence_bce": presence_bce,
        "total": segmentation_bce + segmentation_dice + 0.5 * presence_bce,
    }


def build_faster_rcnn(
    pretrained: bool,
    min_size: int,
    max_size: int,
    trainable_backbone_layers: int = 3,
) -> nn.Module:
    weights = FasterRCNN_ResNet50_FPN_Weights.DEFAULT if pretrained else None
    model = fasterrcnn_resnet50_fpn(
        weights=weights,
        weights_backbone=None if not pretrained else None,
        min_size=min_size,
        max_size=max_size,
        trainable_backbone_layers=trainable_backbone_layers if pretrained else 5,
        box_score_thresh=0.0,
        box_detections_per_img=100,
    )
    in_features = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_features, 2)
    return model


def build_mask_rcnn(
    pretrained: bool,
    min_size: int,
    max_size: int,
    trainable_backbone_layers: int = 3,
) -> nn.Module:
    weights = MaskRCNN_ResNet50_FPN_Weights.DEFAULT if pretrained else None
    model = maskrcnn_resnet50_fpn(
        weights=weights,
        weights_backbone=None if not pretrained else None,
        min_size=min_size,
        max_size=max_size,
        trainable_backbone_layers=trainable_backbone_layers if pretrained else 5,
        box_score_thresh=0.0,
        box_detections_per_img=100,
    )
    box_features = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(box_features, 2)
    mask_features = model.roi_heads.mask_predictor.conv5_mask.in_channels
    model.roi_heads.mask_predictor = MaskRCNNPredictor(mask_features, 256, 2)
    return model


class MedSAMAdapter:
    def __init__(
        self,
        repository: Path,
        checkpoint: Path,
        expected_sha256: str,
        expected_commit: str,
        device: torch.device,
        decoder_checkpoint: Path | None = None,
    ):
        if sha256_file(checkpoint) != expected_sha256:
            raise RuntimeError("MedSAM checkpoint SHA-256 does not match the frozen value")
        if not repository.is_dir():
            raise FileNotFoundError(f"MedSAM repository not found: {repository}")
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=repository, text=True, capture_output=True, check=False
        )
        if result.returncode != 0 or result.stdout.strip() != expected_commit:
            raise RuntimeError(
                f"MedSAM repository commit mismatch: expected {expected_commit}, got {result.stdout.strip() or 'UNKNOWN'}"
            )
        sys.path.insert(0, str(repository))
        try:
            from segment_anything import sam_model_registry
        finally:
            with contextlib.suppress(ValueError):
                sys.path.remove(str(repository))
        self.model = sam_model_registry["vit_b"](checkpoint=str(checkpoint)).to(device).eval()
        self.device = device
        self.checkpoint_sha256 = expected_sha256
        self.decoder_checkpoint_sha256 = None
        if decoder_checkpoint is not None:
            payload = torch.load(decoder_checkpoint, map_location="cpu", weights_only=False)
            if payload.get("architecture") != "MedSAM_official_1024_frozen_image_encoder_trainable_mask_decoder":
                raise RuntimeError("MedSAM decoder checkpoint architecture is not protocol-compliant")
            self.model.mask_decoder.load_state_dict(payload["mask_decoder"], strict=True)
            self.decoder_checkpoint_sha256 = sha256_file(decoder_checkpoint)
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)

    @torch.inference_mode()
    def encode(self, image_rgb: np.ndarray, input_size: int = 1024) -> torch.Tensor:
        if input_size not in {512, 1024}:
            raise ValueError(f"Unsupported frozen MedSAM input size: {input_size}")
        resized = np.asarray(
            __import__("PIL.Image", fromlist=["Image"]).fromarray(image_rgb).resize(
                (input_size, input_size)
            )
        ).astype(np.float32)
        minimum, maximum = float(resized.min()), float(resized.max())
        resized = (resized - minimum) / max(maximum - minimum, 1e-8)
        tensor = torch.from_numpy(resized).permute(2, 0, 1).unsqueeze(0).to(self.device)
        if input_size == 1024:
            return self.model.image_encoder(tensor)
        # The official ViT-B weights are retained. For the registered 512-only
        # sensitivity control, interpolate the frozen absolute positional
        # embedding and execute the official encoder blocks at a 32x32 token
        # grid. No encoder parameter is trained or replaced.
        encoder = self.model.image_encoder
        tokens = encoder.patch_embed(tensor)
        if encoder.pos_embed is not None:
            positional = F.interpolate(
                encoder.pos_embed.permute(0, 3, 1, 2),
                size=tokens.shape[1:3],
                mode="bicubic",
                align_corners=False,
            ).permute(0, 2, 3, 1)
            tokens = tokens + positional
        for block in encoder.blocks:
            tokens = block(tokens)
        return encoder.neck(tokens.permute(0, 3, 1, 2))

    @torch.inference_mode()
    def decode(
        self,
        embedding: torch.Tensor,
        boxes_xyxy: np.ndarray,
        original_shape: tuple[int, int],
        input_size: int = 1024,
    ) -> tuple[list[np.ndarray], list[float]]:
        if input_size not in {512, 1024}:
            raise ValueError(f"Unsupported frozen MedSAM input size: {input_size}")
        height, width = original_shape
        masks: list[np.ndarray] = []
        iou_scores: list[float] = []
        for box in boxes_xyxy:
            scaled = np.asarray(box, dtype=np.float32).copy()
            # PromptEncoder normalizes against its frozen official 1024 canvas.
            # Keeping normalized coordinates identical isolates only the image
            # encoder resolution in the 512 sensitivity condition.
            scaled[[0, 2]] *= 1024.0 / width
            scaled[[1, 3]] *= 1024.0 / height
            box_tensor = torch.as_tensor(scaled, dtype=torch.float32, device=self.device)[None, None]
            sparse, dense = self.model.prompt_encoder(points=None, boxes=box_tensor, masks=None)
            embedding_size = tuple(int(value) for value in embedding.shape[-2:])
            if tuple(dense.shape[-2:]) != embedding_size:
                dense = F.interpolate(dense, size=embedding_size, mode="bilinear", align_corners=False)
                image_pe = self.model.prompt_encoder.pe_layer(embedding_size).unsqueeze(0)
            else:
                image_pe = self.model.prompt_encoder.get_dense_pe()
            low_resolution, predicted_iou = self.model.mask_decoder(
                image_embeddings=embedding,
                image_pe=image_pe,
                sparse_prompt_embeddings=sparse,
                dense_prompt_embeddings=dense,
                multimask_output=False,
            )
            probability = torch.sigmoid(low_resolution)
            probability = F.interpolate(probability, size=(height, width), mode="bilinear", align_corners=False)
            masks.append((probability[0, 0] > 0.5).cpu().numpy().astype(np.uint8))
            iou_scores.append(float(predicted_iou.flatten()[0].cpu()))
        return masks, iou_scores


class VanillaPointRend(nn.Module):
    """Pure-PyTorch uncertainty-point refinement over an image/coarse-mask pair."""

    def __init__(self, feature_channels: int = 32):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, feature_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(feature_channels, feature_channels, 3, padding=1),
            nn.ReLU(inplace=True),
        )
        self.point_head = nn.Sequential(
            nn.Conv1d(feature_channels + 1, 64, 1),
            nn.ReLU(inplace=True),
            nn.Conv1d(64, 64, 1),
            nn.ReLU(inplace=True),
            nn.Conv1d(64, 1, 1),
        )

    @staticmethod
    def _coords_from_indices(indices: torch.Tensor, height: int, width: int) -> torch.Tensor:
        y = torch.div(indices, width, rounding_mode="floor").float()
        x = (indices % width).float()
        x = x / max(width - 1, 1) * 2 - 1
        y = y / max(height - 1, 1) * 2 - 1
        return torch.stack([x, y], dim=-1)

    def _point_logits(self, image: torch.Tensor, coarse_logits: torch.Tensor, indices: torch.Tensor) -> torch.Tensor:
        features = self.features(image)
        if features.shape[-2:] != coarse_logits.shape[-2:]:
            raise RuntimeError(
                "Deterministic integer PointRend sampling requires feature/coarse grids to match"
            )
        # All selected coordinates are exact pixels on the common feature grid.
        # Direct gather is therefore equivalent to align-corners sampling at
        # those integer locations, while avoiding CUDA grid_sample backward,
        # which is incompatible with strict deterministic-algorithm mode.
        sampled_features = features.flatten(2).gather(
            2, indices.unsqueeze(1).expand(-1, features.shape[1], -1)
        )
        sampled_coarse = coarse_logits.flatten(2).gather(2, indices.unsqueeze(1))
        return self.point_head(torch.cat([sampled_features, sampled_coarse], dim=1)).squeeze(1)

    def training_loss(
        self,
        image: torch.Tensor,
        coarse_mask: torch.Tensor,
        target: torch.Tensor,
        points: int,
        uncertainty_fraction: float,
        oversample_ratio: float = 3.0,
    ) -> torch.Tensor:
        coarse_logits = torch.logit(coarse_mask.clamp(1e-4, 1 - 1e-4))
        batch, _, height, width = coarse_logits.shape
        total = height * width
        selected_points = min(total, points)
        uncertain_count = min(selected_points, int(selected_points * uncertainty_fraction))
        random_count = min(total - uncertain_count, max(0, selected_points - uncertain_count))
        uncertainty = -coarse_logits.detach().abs().flatten(1)
        oversample_count = min(total, max(selected_points, int(round(points * oversample_ratio))))
        oversample_priority = torch.rand((batch, total), device=image.device)
        oversampled = oversample_priority.topk(oversample_count, dim=1).indices
        sampled_uncertainty = uncertainty.gather(1, oversampled)
        uncertain_positions = sampled_uncertainty.topk(uncertain_count, dim=1).indices
        uncertain = oversampled.gather(1, uncertain_positions)
        # Sample without replacement and exclude uncertainty-selected pixels so
        # gather backward never has duplicate destinations. This preserves the
        # random PointRend component under the registered seed and remains
        # compatible with strict CUDA determinism.
        random_priority = torch.rand((batch, total), device=image.device)
        if uncertain_count:
            random_priority.scatter_(1, uncertain, -1.0)
        random_indices = random_priority.topk(random_count, dim=1).indices
        indices = torch.cat([uncertain, random_indices], dim=1)
        logits = self._point_logits(image, coarse_logits, indices)
        target_values = target.flatten(1).gather(1, indices)
        return F.binary_cross_entropy_with_logits(logits, target_values)

    @torch.inference_mode()
    def refine(self, image: torch.Tensor, coarse_mask: torch.Tensor, points: int) -> torch.Tensor:
        coarse_logits = torch.logit(coarse_mask.clamp(1e-4, 1 - 1e-4))
        batch, _, height, width = coarse_logits.shape
        count = min(points, height * width)
        indices = (-coarse_logits.abs().flatten(1)).topk(count, dim=1).indices
        point_logits = self._point_logits(image, coarse_logits, indices)
        dense = coarse_logits.flatten(1)
        dense.scatter_(1, indices, point_logits)
        return (torch.sigmoid(dense.view(batch, 1, height, width)) > 0.5).float()


class CandidateVerifier(nn.Module):
    """Two-head standardized L2-logistic verifier used by the G2 contract.

    Formal fitting is performed with scikit-learn so the regularization grid,
    patient grouping and inverse-candidate weights are explicit.  This module
    intentionally has no hidden layers and mirrors the deployed equations.
    """

    def __init__(self, feature_count: int):
        super().__init__()
        self.normalizer_mean = nn.Parameter(torch.zeros(feature_count), requires_grad=False)
        self.normalizer_scale = nn.Parameter(torch.ones(feature_count), requires_grad=False)
        self.existence_head = nn.Linear(feature_count, 1)
        self.quality_head = nn.Linear(feature_count, 1)

    def set_normalizer(self, features: torch.Tensor) -> None:
        self.normalizer_mean.copy_(features.mean(0))
        self.normalizer_scale.copy_(features.std(0).clamp_min(1e-6))

    def forward(self, features: torch.Tensor) -> dict[str, torch.Tensor]:
        normalized = (features - self.normalizer_mean) / self.normalizer_scale
        return {
            "existence_logits": self.existence_head(normalized).squeeze(1),
            "quality_logits": self.quality_head(normalized).squeeze(1),
        }


class LightweightQualityRegressor(nn.Module):
    def __init__(self, feature_count: int):
        super().__init__()
        self.linear = nn.Linear(feature_count, 1)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(self.linear(features)).squeeze(1)
