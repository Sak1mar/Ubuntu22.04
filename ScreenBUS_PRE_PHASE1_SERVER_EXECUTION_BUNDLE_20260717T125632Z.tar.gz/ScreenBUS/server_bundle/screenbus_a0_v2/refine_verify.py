from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch
from PIL import Image
from scipy import ndimage
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset
from torchvision.transforms import functional as TF

from .candidates import FEATURE_NAMES, binary_dice, binary_iou, load_candidate_mask
from .data import InsufficientEvents, connected_instances, mask_binary
from .metrics import verifier_component_metrics
from .models import VanillaPointRend
from .protocol_v2_3 import (
    PATIENT_EVIDENCE_MINIMUMS,
    meta_fold_patient_evidence,
    patient_evidence_from_rows,
    patient_evidence_is_sufficient,
)
from .util import Timer, atomic_json, sha256_file, utc_now


EXISTENCE_BASE_FEATURES = [
    "detector_score",
    "detector_rank_inverse",
    "image_presence_probability",
    "box_area_ratio",
    "box_aspect_log",
    "border_touch",
]
QUALITY_BASE_FEATURES = [
    "sam_predicted_iou",
    "jitter_iou_mean",
    "jitter_iou_variance_inverse",
    "jitter_iou_worst",
    "box_mask_coverage",
    "area_ratio",
    "component_count_log",
    "compactness",
]
EXISTENCE_INTERACTIONS = ["detector_score_x_image_presence_probability"]
QUALITY_INTERACTIONS = [
    "sam_predicted_iou_x_jitter_iou_variance_inverse",
    "box_mask_coverage_x_area_plausibility",
]


def _atomic_save(payload: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".{os.getpid()}.partial")
    torch.save(payload, temporary)
    os.replace(temporary, path)


class PointDataset(Dataset):
    def __init__(self, rows: Sequence[dict[str, Any]], size: int):
        self.rows = [row for row in rows if not row.get("is_sentinel") and row["candidate_valid"]]
        self.size = size

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        image = Image.open(row["image_file"]).convert("RGB")
        candidate = Image.fromarray(load_candidate_mask(row) * 255)
        instances = connected_instances(mask_binary(Path(row["ground_truth_mask_file"])))
        target = Image.fromarray(instances[int(row["matched_lesion"])] * 255)
        image_tensor = TF.to_tensor(TF.resize(image, [self.size, self.size], antialias=True))
        candidate_tensor = (
            TF.pil_to_tensor(TF.resize(candidate, [self.size, self.size], interpolation=TF.InterpolationMode.NEAREST))[0]
            > 0
        ).float()
        target_tensor = (
            TF.pil_to_tensor(TF.resize(target, [self.size, self.size], interpolation=TF.InterpolationMode.NEAREST))[0]
            > 0
        ).float()
        return image_tensor, candidate_tensor.unsqueeze(0), target_tensor.unsqueeze(0)


def train_pointrend(
    rows: Sequence[dict[str, Any]],
    checkpoint: Path,
    cfg: dict,
    seed: int,
    device: torch.device,
    *,
    variant: str = "generic",
) -> dict[str, Any]:
    training_patient_ids = sorted({str(row["patient_id"]) for row in rows})
    if not training_patient_ids:
        raise InsufficientEvents("INSUFFICIENT_PHASE2_EVENTS: PointRend has no training patients")
    dataset = PointDataset(rows, cfg["pointrend"]["crop_size"])
    if len(dataset) < 20:
        raise InsufficientEvents(f"INSUFFICIENT_PHASE2_EVENTS: only {len(dataset)} valid OOF candidates for PointRend")
    loader = DataLoader(
        dataset,
        batch_size=cfg["batch_size"]["pointrend"],
        shuffle=True,
        num_workers=cfg["num_workers"],
        pin_memory=True,
        generator=torch.Generator().manual_seed(seed),
    )
    if variant != "generic":
        raise ValueError("ONLY_ORIGINAL_POINTREND_IS_AUTHORIZED")
    model = VanillaPointRend().to(device)
    architecture = "VanillaPointRend_Generic_PurePyTorch_NotUSSpecific_NotOfficialDetectron2Reproduction"
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=cfg["learning_rate"]["pointrend"], weight_decay=cfg["weight_decay"]
    )
    scaler = torch.amp.GradScaler("cuda", enabled=cfg["amp"])
    history: list[dict[str, float]] = []
    with Timer() as timer:
        for epoch in range(cfg["epochs"]["pointrend"]):
            model.train()
            total, examples = 0.0, 0
            for image, coarse, target in loader:
                image, coarse, target = image.to(device), coarse.to(device), target.to(device)
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast("cuda", torch.float16, enabled=cfg["amp"]):
                    loss = model.training_loss(
                        image,
                        coarse,
                        target,
                        cfg["pointrend"]["points_train"],
                        cfg["pointrend"]["uncertainty_fraction"],
                        cfg["pointrend"]["oversample_ratio"],
                    )
                if not torch.isfinite(loss):
                    raise RuntimeError("Non-finite PointRend loss")
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
                total += float(loss.detach()) * len(image)
                examples += len(image)
            history.append({"epoch": epoch, "point_loss": total / examples})
    if timer.peak_vram_gib >= cfg["runtime"]["max_peak_vram_gib"]:
        raise RuntimeError(
            f"VRAM_LIMIT_EXCEEDED: {timer.peak_vram_gib:.3f} GiB >= {cfg['runtime']['max_peak_vram_gib']} GiB"
        )
    _atomic_save(
        {
            "model": model.state_dict(),
            "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
            "architecture": architecture,
            "variant": variant,
            "seed": seed,
            "history": history,
            "candidate_count": len(dataset),
            "training_patient_ids": training_patient_ids,
        },
        checkpoint,
    )
    metadata = {
        "checkpoint_sha256": sha256_file(checkpoint),
        "seconds": timer.seconds,
        "peak_vram_gib": timer.peak_vram_gib,
        "history": history,
        "candidate_count": len(dataset),
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "training_patient_ids": training_patient_ids,
        "variant": variant,
        "architecture": architecture,
    }
    atomic_json(checkpoint.with_suffix(".json"), metadata)
    return metadata


def load_pointrend(
    checkpoint: Path, device: torch.device
) -> VanillaPointRend:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    variant = payload.get("variant", "generic")
    if variant != "generic":
        raise RuntimeError("ONLY_ORIGINAL_POINTREND_CHECKPOINTS_ARE_AUTHORIZED")
    model = VanillaPointRend()
    model.load_state_dict(payload["model"], strict=True)
    return model.to(device).eval()


def apply_pointrend(
    rows: Sequence[dict[str, Any]],
    checkpoint: Path,
    output_dir: Path,
    cfg: dict,
    device: torch.device,
    *,
    training_patient_ids: Sequence[str],
    heldout_patient_ids: Sequence[str],
    refiner_protocol: str,
    refiner_inner_fold: int | None,
    label_candidates: bool = True,
    preloaded_model: VanillaPointRend | None = None,
    checkpoint_payload: dict[str, Any] | None = None,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    mask_dir = output_dir / "masks"
    mask_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_payload = checkpoint_payload or torch.load(
        checkpoint, map_location="cpu", weights_only=False
    )
    checkpoint_training = {str(value) for value in checkpoint_payload.get("training_patient_ids", [])}
    declared_training = {str(value) for value in training_patient_ids}
    heldout = {str(value) for value in heldout_patient_ids}
    row_patients = {str(row["patient_id"]) for row in rows}
    if checkpoint_training != declared_training:
        raise RuntimeError("REFINER_PROVENANCE_MISMATCH: checkpoint training patients differ from declaration")
    if declared_training & heldout:
        raise RuntimeError("PATIENT_LEAKAGE: PointRend training and heldout patients overlap")
    if row_patients != heldout:
        raise RuntimeError(
            "REFINER_HELDOUT_COVERAGE_MISMATCH: rows must exactly match declared heldout patients"
        )
    checkpoint_sha256 = sha256_file(checkpoint)
    variant = str(checkpoint_payload.get("variant", "generic"))
    model = preloaded_model or load_pointrend(checkpoint, device)
    refined_rows: list[dict[str, Any]] = []
    size = cfg["pointrend"]["crop_size"]
    for sequence, row in enumerate(rows):
        copied = dict(row)
        copied.update(
            refiner_protocol=refiner_protocol,
            refiner_inner_fold=refiner_inner_fold,
            refiner_training_patient_ids=sorted(declared_training),
            refiner_heldout_patient_ids=sorted(heldout),
            refiner_checkpoint_sha256=checkpoint_sha256,
        )
        if str(row["patient_id"]) in declared_training or str(row["patient_id"]) not in heldout:
            raise RuntimeError(f"PATIENT_LEAKAGE in refined row {row['image_id']}")
        if row.get("is_sentinel"):
            refined_rows.append(copied)
            continue
        image = Image.open(row["image_file"]).convert("RGB")
        original = load_candidate_mask(row)
        candidate = Image.fromarray(original * 255)
        image_tensor = TF.to_tensor(TF.resize(image, [size, size], antialias=True)).unsqueeze(0).to(device)
        coarse = (
            TF.pil_to_tensor(TF.resize(candidate, [size, size], interpolation=TF.InterpolationMode.NEAREST))[0]
            > 0
        ).float()[None, None].to(device)
        with torch.autocast("cuda", torch.float16, enabled=cfg["amp"]):
            refined_small = model.refine(image_tensor, coarse, cfg["pointrend"]["points_inference"])[0, 0]
        refined = np.asarray(
            TF.resize(
                Image.fromarray((refined_small.cpu().numpy() > 0).astype(np.uint8) * 255),
                list(original.shape),
                interpolation=TF.InterpolationMode.NEAREST,
            )
        ) > 0
        mask_path = mask_dir / f"{row['image_id']}_{row['condition']}_{row['candidate_index']}_{sequence}.npz"
        np.savez_compressed(mask_path, mask=refined.astype(np.uint8))
        copied["mask_file"] = str(mask_path.resolve())
        copied["mask_key"] = "mask"
        copied["mask_file_sha256"] = sha256_file(mask_path)
        if label_candidates:
            instances = connected_instances(mask_binary(Path(row["ground_truth_mask_file"])))
            matched = int(row.get("matched_lesion", -1))
            # Candidate existence is frozen by the PDF primary box-centre
            # match. PointRend may alter mask quality, never candidate identity.
            if bool(row.get("candidate_valid")) and 0 <= matched < len(instances):
                copied["candidate_valid"] = 1
                copied["matched_lesion"] = matched
                copied["mask_iou"] = binary_iou(refined, instances[matched])
                copied["mask_dice"] = binary_dice(refined, instances[matched])
            else:
                copied.update(candidate_valid=0, matched_lesion=-1, mask_iou=0.0, mask_dice=0.0)
            copied["failure"] = int(
                copied["candidate_valid"] == 0
                or copied["mask_dice"] < cfg["failure_dice_threshold"]
            )
        else:
            copied.update(
                candidate_valid=-1,
                matched_lesion=-1,
                mask_iou=None,
                mask_dice=None,
                failure=-1,
            )
        copied["feature_map"] = dict(copied["feature_map"])
        old_area = float(original.mean())
        old_components = ndimage.label(original, structure=np.ones((3, 3), dtype=np.uint8))[1]
        old_boundary = np.logical_xor(original.astype(bool), ndimage.binary_erosion(original.astype(bool)))
        new_boundary = np.logical_xor(refined.astype(bool), ndimage.binary_erosion(refined.astype(bool)))
        copied["feature_map"]["area_ratio"] = float(refined.mean())
        component_count = ndimage.label(refined, structure=np.ones((3, 3), dtype=np.uint8))[1]
        copied["feature_map"]["component_count_log"] = float(np.log1p(component_count))
        copied["feature_map"]["refiner_area_change_abs"] = abs(float(refined.mean()) - old_area)
        copied["feature_map"]["refiner_boundary_change"] = 1.0 - binary_iou(
            new_boundary, old_boundary
        )
        copied["feature_map"]["refiner_component_change_abs"] = float(
            abs(component_count - old_components)
        )
        copied["features"] = [copied["feature_map"][name] for name in FEATURE_NAMES]
        copied["refiner"] = "VanillaPointRendMechanism_Adapted_PurePyTorch"
        copied["refiner_variant"] = variant
        refined_rows.append(copied)
    output = output_dir / "candidates.jsonl"
    temporary = output.with_suffix(f".{os.getpid()}.partial")
    with temporary.open("w", encoding="utf-8") as handle:
        for row in refined_rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
    os.replace(temporary, output)
    atomic_json(
        output_dir / "metadata.json",
        {
            "created_at": utc_now(),
            "candidate_count": len(refined_rows),
            "checkpoint_sha256": checkpoint_sha256,
            "refiner_protocol": refiner_protocol,
            "refiner_inner_fold": refiner_inner_fold,
            "training_patient_ids": sorted(declared_training),
            "heldout_patient_ids": sorted(heldout),
            "patient_overlap": [],
            "ground_truth_labels_computed": label_candidates,
            "candidate_jsonl_sha256": sha256_file(output),
        },
    )
    return output


def build_pointrend_crossfit_plan(
    rows: Sequence[dict[str, Any]], assignment: dict[str, int], folds: int
) -> list[dict[str, Any]]:
    """Build the only legal B4 OOF plan: patient-level train/heldout folds.

    Detector-OOF rows may be used to fit a refiner, but a row may only be
    refined by a PointRend checkpoint that did not see that row's patient.
    """
    patients = {str(row["patient_id"]) for row in rows}
    normalized_assignment = {str(patient): int(fold) for patient, fold in assignment.items()}
    if set(normalized_assignment) != patients:
        raise RuntimeError("REFINER_CROSSFIT_ASSIGNMENT_MISMATCH")
    if set(normalized_assignment.values()) != set(range(folds)):
        raise RuntimeError("REFINER_CROSSFIT_FOLDS_INCOMPLETE")
    plan: list[dict[str, Any]] = []
    for fold in range(folds):
        heldout_patients = {patient for patient, value in normalized_assignment.items() if value == fold}
        training_patients = patients - heldout_patients
        training_rows = [row for row in rows if str(row["patient_id"]) in training_patients]
        heldout_rows = [row for row in rows if str(row["patient_id"]) in heldout_patients]
        if not training_rows or not heldout_rows or training_patients & heldout_patients:
            raise RuntimeError(f"REFINER_CROSSFIT_INVALID_FOLD_{fold}")
        plan.append(
            {
                "inner_fold": fold,
                "training_patient_ids": sorted(training_patients),
                "heldout_patient_ids": sorted(heldout_patients),
                "training_rows": training_rows,
                "heldout_rows": heldout_rows,
            }
        )
    return plan


def validate_refiner_crossfit_provenance(
    rows: Sequence[dict[str, Any]], assignment: dict[str, int]
) -> dict[str, Any]:
    """Fail closed if any B4 OOF row was inferred by a patient-seeing refiner."""
    checkpoint_hashes: set[str] = set()
    observed_patients: set[str] = set()
    for row in rows:
        patient = str(row["patient_id"])
        training = {str(value) for value in row.get("refiner_training_patient_ids", [])}
        heldout = {str(value) for value in row.get("refiner_heldout_patient_ids", [])}
        fold = row.get("refiner_inner_fold")
        digest = row.get("refiner_checkpoint_sha256")
        if row.get("refiner_protocol") != "patient_level_inner_fold_crossfit":
            raise RuntimeError("REFINER_CROSSFIT_PROTOCOL_MISSING")
        if patient in training or patient not in heldout or training & heldout:
            raise RuntimeError(f"PATIENT_LEAKAGE in B4 crossfit row {row.get('image_id')}")
        if patient not in assignment or int(assignment[patient]) != int(fold):
            raise RuntimeError(f"REFINER_CROSSFIT_FOLD_MISMATCH for {row.get('image_id')}")
        if not isinstance(digest, str) or len(digest) != 64:
            raise RuntimeError("REFINER_CHECKPOINT_HASH_MISSING")
        checkpoint_hashes.add(digest)
        observed_patients.add(patient)
    expected_patients = {str(patient) for patient in assignment}
    if observed_patients != expected_patients:
        raise RuntimeError("REFINER_CROSSFIT_PATIENT_COVERAGE_MISMATCH")
    return {
        "status": "PASS_NO_PATIENT_LEAKAGE",
        "patient_count": len(observed_patients),
        "checkpoint_count": len(checkpoint_hashes),
        "checkpoint_sha256s": sorted(checkpoint_hashes),
    }


def _area_plausibility(area_ratio: float) -> float:
    penalty = min(abs(np.log(max(float(area_ratio), 1e-6) / 0.03)) / 6.0, 1.0)
    return float(1.0 - penalty)


def _feature_matrices(
    rows: Sequence[dict[str, Any]],
) -> tuple[list[dict[str, Any]], np.ndarray, np.ndarray, np.ndarray]:
    real = [row for row in rows if not row.get("is_sentinel")]
    existence_rows: list[list[float]] = []
    quality_rows: list[list[float]] = []
    quality_control_rows: list[list[float]] = []
    for row in real:
        feature_map = row["feature_map"]
        existence_base = [float(feature_map[name]) for name in EXISTENCE_BASE_FEATURES]
        quality_base = [float(feature_map[name]) for name in QUALITY_BASE_FEATURES]
        existence_rows.append(
            existence_base
            + [
                float(feature_map["detector_score"])
                * float(feature_map["image_presence_probability"])
            ]
        )
        quality_rows.append(
            quality_base
            + [
                float(feature_map["sam_predicted_iou"])
                * float(feature_map["jitter_iou_variance_inverse"]),
                float(feature_map["box_mask_coverage"])
                * _area_plausibility(float(feature_map["area_ratio"])),
            ]
        )
        quality_control_rows.append(quality_base)
    return (
        real,
        np.asarray(existence_rows, dtype=np.float64),
        np.asarray(quality_rows, dtype=np.float64),
        np.asarray(quality_control_rows, dtype=np.float64),
    )


def _no_decision(reason: str) -> None:
    raise InsufficientEvents(f"NO_DECISION: {reason}")


def _assert_legal_inner_oof_training_rows(
    rows: Sequence[dict[str, Any]], protocol_label: str
) -> None:
    if protocol_label != "LEGAL_INNER_OOF_VERIFIER":
        raise RuntimeError("VERIFIER_TRAINING_PROTOCOL_MUST_BE_LEGAL_INNER_OOF")
    for row in rows:
        if str(row.get("split_role", "")).lower() in {
            "outer_test",
            "evaluation",
            "test",
        }:
            raise RuntimeError("OUTER_TEST_CANDIDATE_FORBIDDEN_IN_VERIFIER_TRAINING")
        patient = str(row.get("patient_id"))
        if patient in {str(value) for value in row.get("training_patient_ids", ())}:
            raise RuntimeError("PATIENT_LEAKAGE_IN_INNER_OOF_CANDIDATE")


def assert_threshold_selection_scores_are_meta_oof(
    payload: dict[str, Any], methods: Sequence[str]
) -> None:
    sources = payload.get("score_source")
    if not isinstance(sources, dict):
        raise RuntimeError("THRESHOLD_SELECTION_SCORE_PROVENANCE_MISSING")
    for method in methods:
        if sources.get(method) != "PATIENT_GROUPED_META_OOF":
            raise RuntimeError(
                f"THRESHOLD_SELECTION_REQUIRES_META_OOF_SCORE: {method}"
            )
    provenance = payload.get("lightweight_quality_provenance")
    if "lightweight_quality_regressor" in methods:
        if not isinstance(provenance, list) or len(provenance) != len(
            payload.get("image_candidate_keys", ())
        ):
            raise RuntimeError("LIGHTWEIGHT_QUALITY_META_OOF_PROVENANCE_MISSING")
        for item in provenance:
            training = {str(value) for value in item.get("training_patient_ids", ())}
            heldout = {str(value) for value in item.get("heldout_patient_ids", ())}
            patient = str(item.get("patient_id"))
            if patient in training or patient not in heldout or training & heldout:
                raise RuntimeError("LIGHTWEIGHT_QUALITY_PATIENT_LEAKAGE")
            digest = item.get("checkpoint_sha256")
            if not isinstance(digest, str) or len(digest) != 64:
                raise RuntimeError("LIGHTWEIGHT_QUALITY_CHECKPOINT_HASH_MISSING")


def _balanced_training_indices(
    real: Sequence[dict[str, Any]],
    candidate_indices: np.ndarray,
    cfg: dict,
    *,
    task: str,
) -> np.ndarray:
    policy = cfg["verifier"]["hard_negative_mining"]
    if policy.get("enabled") is not False:
        raise RuntimeError("PREFERENTIAL_HARD_NEGATIVE_MINING_FORBIDDEN")
    # Every legal inner-OOF candidate is retained. Candidate score, label and
    # multiplicity never change membership in the training pool.
    return np.asarray(sorted(int(index) for index in candidate_indices.tolist()), dtype=int)


def _balanced_weights(
    real: Sequence[dict[str, Any]],
    selected: np.ndarray,
    cfg: dict,
    *,
    task: str,
) -> np.ndarray:
    weights = np.zeros(len(selected), dtype=float)
    positions: dict[str, list[int]] = {}
    for position, index in enumerate(selected.tolist()):
        positions.setdefault(str(real[index]["patient_id"]), []).append(position)
    for patient_positions in positions.values():
        factors = np.ones(len(patient_positions), dtype=float)
        factors /= factors.sum()
        for local, position in enumerate(patient_positions):
            weights[position] = factors[local]
    if weights.sum() <= 0:
        _no_decision(f"{task} patient-balanced weights are empty")
    weights *= len(weights) / weights.sum()
    return weights


def train_verifier_and_controls(
    rows: Sequence[dict[str, Any]],
    output_dir: Path,
    cfg: dict,
    seed: int,
    device: torch.device,
    verifier_filename: str = "oof_verifier.pt",
    protocol_label: str = "LEGAL_INNER_OOF_VERIFIER",
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    _assert_legal_inner_oof_training_rows(rows, protocol_label)
    real, existence_features, quality_features, quality_control_features = _feature_matrices(rows)
    valid = np.asarray([int(row["candidate_valid"]) for row in real], dtype=int)
    quality = np.asarray(
        [int(row["candidate_valid"] and float(row["mask_dice"]) >= cfg["failure_dice_threshold"]) for row in real],
        dtype=int,
    )
    failures = np.asarray([int(row["failure"]) for row in real], dtype=int)
    patients = np.asarray([str(row["patient_id"]) for row in real])
    unique_patients = sorted(set(patients))
    quality_success = int(quality[valid == 1].sum())
    quality_failure = int(np.sum(quality[valid == 1] == 0))
    event_counts = {
        "valid_candidates": int(valid.sum()),
        "invalid_candidates": int((1 - valid).sum()),
        "quality_success": quality_success,
        "quality_failure": quality_failure,
    }
    patient_evidence = patient_evidence_from_rows(
        real, failure_dice_threshold=float(cfg["failure_dice_threshold"])
    )
    for name, minimum in PATIENT_EVIDENCE_MINIMUMS.items():
        if int(patient_evidence[name]) < int(minimum):
            _no_decision(f"{name}={patient_evidence[name]} < {minimum}")
    if len(unique_patients) < 4:
        _no_decision("fewer than four verifier patients")
    patient_counts = {patient: int(np.sum(patients == patient)) for patient in unique_patients}
    weights = np.asarray([1.0 / patient_counts[patient] for patient in patients], dtype=float)
    weights *= len(weights) / weights.sum()
    c_grid = [0.1, 1.0, 10.0]
    splitter = GroupKFold(n_splits=min(4, len(unique_patients)))
    splits = list(splitter.split(existence_features, valid, groups=patients))
    meta_fold = np.full(len(real), -1, dtype=int)
    for fold, (_train_index, heldout_index) in enumerate(splits):
        meta_fold[heldout_index] = fold
    fold_patient_evidence = meta_fold_patient_evidence(
        real,
        meta_fold.tolist(),
        failure_dice_threshold=float(cfg["failure_dice_threshold"]),
    )
    if not patient_evidence_is_sufficient(patient_evidence, fold_patient_evidence):
        _no_decision("each held-out meta fold requires all four classes from independent patients")
    selection_rows: list[dict[str, float]] = []
    selected: tuple[float, float, np.ndarray, np.ndarray] | None = None

    def fit_head(x: np.ndarray, y: np.ndarray, sample_weight: np.ndarray, c_value: float) -> LogisticRegression:
        if len(np.unique(y)) != 2:
            _no_decision("meta fold has a single class label")
        model = LogisticRegression(
            C=c_value,
            penalty="l2",
            solver="lbfgs",
            max_iter=2000,
            random_state=seed,
        )
        model.fit(x, y, sample_weight=sample_weight)
        return model

    with Timer() as timer:
        for c_value in c_grid:
            existence_oof = np.full(len(real), np.nan, dtype=float)
            quality_oof = np.full(len(real), np.nan, dtype=float)
            for fold, (train_index, heldout_index) in enumerate(splits):
                heldout_quality = heldout_index[valid[heldout_index] == 1]
                if len(np.unique(valid[heldout_index])) != 2:
                    _no_decision(f"meta fold {fold} existence labels are single-class")
                if not len(heldout_quality) or len(np.unique(quality[heldout_quality])) != 2:
                    _no_decision(f"meta fold {fold} quality labels are single-class")
                existence_train = _balanced_training_indices(
                    real, train_index, cfg, task="existence"
                )
                existence_weights = _balanced_weights(
                    real, existence_train, cfg, task="existence"
                )
                existence_scaler = StandardScaler().fit(existence_features[existence_train])
                existence_model = fit_head(
                    existence_scaler.transform(existence_features[existence_train]),
                    valid[existence_train],
                    existence_weights,
                    c_value,
                )
                existence_oof[heldout_index] = existence_model.predict_proba(
                    existence_scaler.transform(existence_features[heldout_index])
                )[:, 1]
                quality_train_pool = train_index[valid[train_index] == 1]
                quality_train = _balanced_training_indices(
                    real, quality_train_pool, cfg, task="quality"
                )
                quality_weights = _balanced_weights(
                    real, quality_train, cfg, task="quality"
                )
                quality_scaler = StandardScaler().fit(quality_features[quality_train])
                quality_model = fit_head(
                    quality_scaler.transform(quality_features[quality_train]),
                    quality[quality_train],
                    quality_weights,
                    c_value,
                )
                quality_oof[heldout_index] = quality_model.predict_proba(
                    quality_scaler.transform(quality_features[heldout_index])
                )[:, 1]
            valid_quality = valid == 1
            existence_brier = float(np.average((existence_oof - valid) ** 2, weights=weights))
            quality_brier = float(
                np.average(
                    (quality_oof[valid_quality] - quality[valid_quality]) ** 2,
                    weights=weights[valid_quality],
                )
            )
            objective = existence_brier + quality_brier
            selection_rows.append(
                {
                    "C": c_value,
                    "meta_oof_existence_brier": existence_brier,
                    "meta_oof_conditional_quality_brier": quality_brier,
                    "selection_objective": objective,
                }
            )
            if selected is None or objective < selected[0]:
                selected = (objective, c_value, existence_oof, quality_oof)
    assert selected is not None
    _, selected_c, existence_score, quality_score = selected
    all_indices = np.arange(len(real), dtype=int)
    existence_train = _balanced_training_indices(real, all_indices, cfg, task="existence")
    existence_weights = _balanced_weights(real, existence_train, cfg, task="existence")
    existence_scaler = StandardScaler().fit(existence_features[existence_train])
    existence_model = fit_head(
        existence_scaler.transform(existence_features[existence_train]),
        valid[existence_train],
        existence_weights,
        selected_c,
    )
    valid_indices = np.flatnonzero(valid == 1)
    quality_train = _balanced_training_indices(real, valid_indices, cfg, task="quality")
    quality_weights = _balanced_weights(real, quality_train, cfg, task="quality")
    quality_scaler = StandardScaler().fit(quality_features[quality_train])
    quality_model = fit_head(
        quality_scaler.transform(quality_features[quality_train]),
        quality[quality_train],
        quality_weights,
        selected_c,
    )
    joint_score = existence_score * quality_score
    verifier_path = output_dir / verifier_filename
    _atomic_save(
        {
            "model_type": "two_head_l2_logistic_regression",
            "parameter_count": int(
                existence_features.shape[1] + 1 + quality_features.shape[1] + 1
            ),
            "existence_feature_names": EXISTENCE_BASE_FEATURES + EXISTENCE_INTERACTIONS,
            "quality_feature_names": QUALITY_BASE_FEATURES + QUALITY_INTERACTIONS,
            "interaction_definitions": {
                "detector_score_x_image_presence_probability": "detector_score * image_presence_probability",
                "sam_predicted_iou_x_jitter_iou_variance_inverse": "sam_predicted_iou * jitter_iou_variance_inverse",
                "box_mask_coverage_x_area_plausibility": "box_mask_coverage * clip(1 - abs(log(area_ratio/0.03))/6, 0, 1)",
            },
            "seed": seed,
            "protocol_label": protocol_label,
            "regularization": {"penalty": "l2", "c_grid": c_grid, "selected_C": selected_c},
            "selection": selection_rows,
            "existence_normalizer_mean": existence_scaler.mean_.tolist(),
            "existence_normalizer_scale": existence_scaler.scale_.tolist(),
            "quality_normalizer_mean": quality_scaler.mean_.tolist(),
            "quality_normalizer_scale": quality_scaler.scale_.tolist(),
            "existence_coef": existence_model.coef_[0].tolist(),
            "existence_intercept": float(existence_model.intercept_[0]),
            "quality_coef": quality_model.coef_[0].tolist(),
            "quality_intercept": float(quality_model.intercept_[0]),
            "training_candidate_count": len(real),
            "training_patient_ids": unique_patients,
            "patient_weighting": "equal_total_weight_per_patient_all_legal_inner_oof_candidates",
            "hard_negative_mining": {
                **cfg["verifier"]["hard_negative_mining"],
                "existence_training_candidate_count": int(len(existence_train)),
                "quality_training_candidate_count": int(len(quality_train)),
                "evaluation_candidate_count": int(len(real)),
            },
            "calibration": {
                "status": "NATIVE_LOGISTIC_PROBABILITIES_META_OOF_FOR_SELECTION",
                "calibration_patient_ids": unique_patients,
                "existence_task": "candidate_existence_all_real_candidates",
                "quality_task": "conditional_binary_dice_at_failure_threshold_valid_candidates_only",
            },
        },
        verifier_path,
    )
    # The lightweight quality control is scored by patient GroupKFold. Its
    # meta-OOF scores are the only scores allowed for threshold selection and
    # strongest-control ranking. The final all-outer-train model is separate
    # and is used only by score_methods on outer-test candidates.
    quality_scores = np.full(len(real), np.nan, dtype=float)
    quality_provenance: list[dict[str, Any] | None] = [None] * len(real)
    for fold, (train_index, heldout_index) in enumerate(splits):
        training_patients = sorted({str(patients[index]) for index in train_index})
        heldout_patients = sorted({str(patients[index]) for index in heldout_index})
        if set(training_patients) & set(heldout_patients):
            raise RuntimeError("LIGHTWEIGHT_QUALITY_PATIENT_LEAKAGE")
        fold_quality_train = train_index[valid[train_index] == 1]
        fold_quality_weights = _balanced_weights(
            real, fold_quality_train, cfg, task="quality_control"
        )
        fold_scaler = StandardScaler().fit(
            quality_control_features[fold_quality_train]
        )
        fold_model = fit_head(
            fold_scaler.transform(quality_control_features[fold_quality_train]),
            quality[fold_quality_train],
            fold_quality_weights,
            selected_c,
        )
        fold_path = output_dir / f"lightweight_quality_meta_fold_{fold}.pt"
        _atomic_save(
            {
                "model_type": "lightweight_quality_l2_logistic_control_meta_oof",
                "fold": fold,
                "training_patient_ids": training_patients,
                "heldout_patient_ids": heldout_patients,
                "feature_names": QUALITY_BASE_FEATURES,
                "normalizer_mean": fold_scaler.mean_.tolist(),
                "normalizer_scale": fold_scaler.scale_.tolist(),
                "coef": fold_model.coef_[0].tolist(),
                "intercept": float(fold_model.intercept_[0]),
                "seed": seed,
            },
            fold_path,
        )
        fold_hash = sha256_file(fold_path)
        quality_scores[heldout_index] = fold_model.predict_proba(
            fold_scaler.transform(quality_control_features[heldout_index])
        )[:, 1]
        for index in heldout_index.tolist():
            patient = str(patients[index])
            if patient in training_patients or patient not in heldout_patients:
                raise RuntimeError("LIGHTWEIGHT_QUALITY_PATIENT_LEAKAGE")
            quality_provenance[index] = {
                "patient_id": patient,
                "training_patient_ids": training_patients,
                "heldout_patient_ids": heldout_patients,
                "fold": fold,
                "checkpoint_sha256": fold_hash,
            }
    if np.isnan(quality_scores).any() or any(item is None for item in quality_provenance):
        raise RuntimeError("LIGHTWEIGHT_QUALITY_META_OOF_COVERAGE_INCOMPLETE")

    quality_control_scaler = StandardScaler().fit(quality_control_features[quality_train])
    quality_control = fit_head(
        quality_control_scaler.transform(quality_control_features[quality_train]),
        quality[quality_train],
        quality_weights,
        selected_c,
    )
    quality_path = output_dir / "lightweight_quality_regressor.pt"
    _atomic_save(
        {
            "model_type": "lightweight_quality_l2_logistic_control",
            "feature_names": QUALITY_BASE_FEATURES,
            "normalizer_mean": quality_control_scaler.mean_.tolist(),
            "normalizer_scale": quality_control_scaler.scale_.tolist(),
            "coef": quality_control.coef_[0].tolist(),
            "intercept": float(quality_control.intercept_[0]),
            "seed": seed,
            "role": "FINAL_OUTER_TRAIN_MODEL_FOR_OUTER_TEST_INFERENCE_ONLY",
            "training_patient_ids": unique_patients,
        },
        quality_path,
    )
    score_payload = {
        "image_candidate_keys": [f"{row['image_id']}:{row['candidate_index']}:{row['condition']}" for row in real],
        "meta_fold": meta_fold.tolist(),
        "verifier": joint_score.tolist(),
        "verifier_existence": existence_score.tolist(),
        "verifier_quality": quality_score.tolist(),
        "lightweight_quality_regressor": quality_scores.tolist(),
        "detector_score": [row["feature_map"]["detector_score"] for row in real],
        "sam_predicted_iou": [row["feature_map"]["sam_predicted_iou"] for row in real],
        "sam_stability": [row["feature_map"]["jitter_iou_mean"] for row in real],
        "jitter_variance": [row["feature_map"]["jitter_iou_variance_inverse"] for row in real],
        "area_component_rule": [area_component_rule(row) for row in real],
        "score_source": {
            "verifier": "PATIENT_GROUPED_META_OOF",
            "verifier_existence": "PATIENT_GROUPED_META_OOF",
            "verifier_quality": "PATIENT_GROUPED_META_OOF",
            "lightweight_quality_regressor": "PATIENT_GROUPED_META_OOF",
            "detector_score": "PATIENT_GROUPED_META_OOF",
            "sam_predicted_iou": "PATIENT_GROUPED_META_OOF",
            "sam_stability": "PATIENT_GROUPED_META_OOF",
            "jitter_variance": "PATIENT_GROUPED_META_OOF",
            "area_component_rule": "PATIENT_GROUPED_META_OOF",
        },
        "lightweight_quality_provenance": quality_provenance,
    }
    assert_threshold_selection_scores_are_meta_oof(
        score_payload, ["lightweight_quality_regressor"]
    )
    atomic_json(output_dir / "training_scores.json", score_payload)
    calibration_component_metrics = verifier_component_metrics(
        real,
        existence_score.tolist(),
        quality_score.tolist(),
    )
    atomic_json(
        output_dir / "calibration_component_metrics.json",
        {
            "status": "COMPLETE_PATIENT_GROUPED_META_OOF",
            "patient_ids": unique_patients,
            **calibration_component_metrics,
        },
    )
    metadata = {
        "verifier_checkpoint": str(verifier_path),
        "verifier_checkpoint_sha256": sha256_file(verifier_path),
        "quality_checkpoint": str(quality_path),
        "quality_checkpoint_sha256": sha256_file(quality_path),
        "seconds": timer.seconds,
        "peak_vram_gib": timer.peak_vram_gib,
        "candidate_count": len(real),
        "valid_count": int(valid.sum()),
        "failure_count": int(failures.sum()),
        "event_counts": event_counts,
        "unique_patient_evidence": patient_evidence,
        "meta_fold_unique_patient_evidence": fold_patient_evidence,
        "calibration_status": "COMPLETE_PATIENT_GROUPED_META_OOF",
        "calibration_patient_count": len(unique_patients),
        "calibration_candidate_count": len(real),
        "calibration_valid_quality_candidate_count": int(valid.sum()),
        "selected_C": selected_c,
        "selection": selection_rows,
        "protocol_label": protocol_label,
        "hard_negative_mining_enabled": False,
        "all_legal_inner_oof_candidates_used": True,
        "evaluation_pool_unchanged": True,
    }
    atomic_json(output_dir / "metadata.json", metadata)
    return metadata


def area_component_rule(row: dict[str, Any]) -> float:
    features = row["feature_map"]
    area = features["area_ratio"]
    area_penalty = min(abs(np.log(max(area, 1e-6) / 0.03)) / 6.0, 1.0)
    component_penalty = min(features["component_count_log"] / np.log(6.0), 1.0)
    border_penalty = features["border_touch"]
    return float(np.clip(1.0 - 0.5 * area_penalty - 0.3 * component_penalty - 0.2 * border_penalty, 0, 1))


def score_methods(
    rows: Sequence[dict[str, Any]],
    verifier_dir: Path,
    device: torch.device,
    verifier_filename: str = "oof_verifier.pt",
) -> dict[str, list[float]]:
    real, existence_features, quality_features, quality_control_features = _feature_matrices(rows)
    verifier_payload = torch.load(
        verifier_dir / verifier_filename, map_location="cpu", weights_only=False
    )
    quality_payload = torch.load(
        verifier_dir / "lightweight_quality_regressor.pt", map_location="cpu", weights_only=False
    )
    if verifier_payload.get("model_type") != "two_head_l2_logistic_regression":
        raise RuntimeError("VERIFIER_IS_NOT_FROZEN_L2_LOGISTIC_REGRESSION")
    existence_normalized = (
        existence_features - np.asarray(verifier_payload["existence_normalizer_mean"])
    ) / np.asarray(verifier_payload["existence_normalizer_scale"])
    quality_normalized = (
        quality_features - np.asarray(verifier_payload["quality_normalizer_mean"])
    ) / np.asarray(verifier_payload["quality_normalizer_scale"])

    def logistic(values: np.ndarray) -> np.ndarray:
        return 1.0 / (1.0 + np.exp(-np.clip(values, -40.0, 40.0)))

    existence_scores = logistic(
        existence_normalized @ np.asarray(verifier_payload["existence_coef"])
        + float(verifier_payload["existence_intercept"])
    )
    quality_scores = logistic(
        quality_normalized @ np.asarray(verifier_payload["quality_coef"])
        + float(verifier_payload["quality_intercept"])
    )
    verifier_scores = existence_scores * quality_scores
    quality_control_normalized = (
        quality_control_features - np.asarray(quality_payload["normalizer_mean"])
    ) / np.asarray(quality_payload["normalizer_scale"])
    lightweight_quality_scores = logistic(
        quality_control_normalized @ np.asarray(quality_payload["coef"])
        + float(quality_payload["intercept"])
    )
    real_scores = {
        "verifier": verifier_scores.tolist(),
        "verifier_existence": existence_scores.tolist(),
        "verifier_quality": quality_scores.tolist(),
        "lightweight_quality_regressor": lightweight_quality_scores.tolist(),
        "detector_score": [row["feature_map"]["detector_score"] for row in real],
        "sam_predicted_iou": [row["feature_map"]["sam_predicted_iou"] for row in real],
        "sam_stability": [row["feature_map"]["jitter_iou_mean"] for row in real],
        "jitter_variance": [row["feature_map"]["jitter_iou_variance_inverse"] for row in real],
        "area_component_rule": [area_component_rule(row) for row in real],
    }
    result = {name: [] for name in real_scores}
    cursor = 0
    for row in rows:
        if row.get("is_sentinel"):
            for name in result:
                result[name].append(float("-inf"))
        else:
            for name in result:
                result[name].append(float(real_scores[name][cursor]))
            cursor += 1
    return result
