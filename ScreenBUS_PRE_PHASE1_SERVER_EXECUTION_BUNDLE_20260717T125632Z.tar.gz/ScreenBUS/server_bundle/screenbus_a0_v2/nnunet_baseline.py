from __future__ import annotations

import json
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch
from PIL import Image

from .baselines import _base_row, _save_rows, _sentinel
from .candidates import (
    FEATURE_NAMES,
    _candidate_features,
    _label_candidate,
    primary_candidate_matches,
    sensitivity_candidate_matches,
)
from .data import ManifestRecord, connected_instances, instance_boxes, mask_binary
from .util import atomic_csv, atomic_json, sha256_file, utc_now


NNUNET_FINAL_EPOCHS = 1000
NNUNET_PLANS_IDENTIFIER = "nnUNetPlans"
NNUNET_PREPROCESS_MARKER = "PREPROCESS_COMPLETE.json"
NNUNET_SEED_INJECTION = (
    "nnUNetTrainer.initialize_and_on_train_start_pre_and_post_hooks"
)


def canonical_nnunet_checkpoint_path(
    nn_root: Path,
    dataset_name: str,
    trainer: str,
    configuration: str,
    filename: str,
) -> Path:
    if filename not in {"checkpoint_latest.pth", "checkpoint_final.pth"}:
        raise ValueError(f"Unsupported nnU-Net checkpoint filename: {filename}")
    return (
        nn_root
        / "results"
        / dataset_name
        / f"{trainer}__{NNUNET_PLANS_IDENTIFIER}__{configuration}"
        / "fold_all"
        / filename
    )


def _validate_nnunet_resume_sidecar(
    checkpoint: Path,
    training_spec_path: Path,
    expected: dict[str, Any],
) -> None:
    sidecar = checkpoint.with_suffix(".screenbus_resume.json")
    try:
        if sidecar.is_symlink() or not sidecar.is_file():
            raise RuntimeError("resume sidecar is missing, non-regular, or a symlink")
        payload = json.loads(sidecar.read_text(encoding="utf-8"))
        required = {
            "schema_version": 1,
            "status": "BOUND_FOR_RESUME",
            "checkpoint_filename": checkpoint.name,
            "checkpoint_sha256": sha256_file(checkpoint),
            "training_spec_sha256": sha256_file(training_spec_path),
            "effective_seed": int(expected["seed"]),
            "configuration": expected["configuration"],
            "fold": str(expected["fold"]),
            "trainer": expected["trainer"],
            "dataset_id": int(expected["dataset_id"]),
            "dataset_name": expected["dataset_name"],
            "plans_identifier": NNUNET_PLANS_IDENTIFIER,
            "plans_sha256": expected["plans_sha256"],
            "dataset_json_sha256": expected["dataset_json_sha256"],
            "preprocess_marker_sha256": expected["preprocess_marker_sha256"],
            "preprocessed_tree_sha256": expected["preprocessed_tree_sha256"],
            "config_sha256": expected["config_sha256"],
            "checkpoint_save_every_epochs": int(
                expected["checkpoint_save_every_epochs"]
            ),
            "seed_injection": NNUNET_SEED_INJECTION,
            "deterministic_algorithms": True,
        }
        drift = {
            key: {"expected": value, "observed": payload.get(key)}
            for key, value in required.items()
            if payload.get(key) != value
        }
        if drift:
            raise RuntimeError(f"resume sidecar binding drift: {drift}")
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError, RuntimeError) as exc:
        raise RuntimeError(
            f"NNUNET_CHECKPOINT_INVALID: {checkpoint}: "
            f"NNUNET_RESUME_SIDECAR_INVALID: {exc}"
        ) from exc


def _link(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() or destination.is_symlink():
        if destination.resolve() != source.resolve():
            raise RuntimeError(f"nnU-Net link collision: {destination}")
        return
    destination.symlink_to(source.resolve())


def _atomic_png(array: np.ndarray, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=destination.name, suffix=".partial.png", dir=destination.parent)
    os.close(fd)
    try:
        Image.fromarray(array).save(temporary)
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def stage_case(record: ManifestRecord, image_destination: Path, label_destination: Path | None) -> dict[str, Any]:
    # BUS-UCLM stores visually grayscale ultrasound and masks as RGB PNGs. The
    # nnU-Net staging contract is explicitly one grayscale image channel and a
    # single-channel label map whose only values are 0 and 1.
    grayscale = np.asarray(Image.open(record.image_path).convert("L"), dtype=np.uint8)
    _atomic_png(grayscale, image_destination)
    row: dict[str, Any] = {
        "image_id": record.image_id,
        "source_image": str(record.image_path),
        "source_image_sha256": record.image_sha256,
        "staged_image": str(image_destination),
        "staged_image_sha256": sha256_file(image_destination),
        "staged_image_channels": 1,
    }
    if label_destination is not None:
        label = mask_binary(record.mask_path).astype(np.uint8)
        if not set(np.unique(label)).issubset({0, 1}):
            raise RuntimeError(f"nnU-Net staged label is not binary for {record.image_id}")
        _atomic_png(label, label_destination)
        staged = np.asarray(Image.open(label_destination))
        if staged.ndim != 2 or not set(np.unique(staged)).issubset({0, 1}):
            raise RuntimeError(f"nnU-Net label round-trip failed for {record.image_id}")
        row.update(
            source_mask=str(record.mask_path),
            source_mask_sha256=record.mask_sha256,
            staged_label=str(label_destination),
            staged_label_sha256=sha256_file(label_destination),
            staged_label_values=sorted(int(value) for value in np.unique(staged)),
        )
    return row


def freeze_nnunet_training_spec(
    path: Path,
    expected: dict[str, Any],
    partial_checkpoints: Sequence[Path],
) -> bool:
    """Freeze the exact training identity and authorize only matching resume."""
    if path.is_file():
        try:
            observed = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"nnU-Net training run spec is invalid: {path}") from exc
        drift = {
            key: {"expected": value, "observed": observed.get(key)}
            for key, value in expected.items()
            if observed.get(key) != value
        }
        if drift:
            raise RuntimeError(f"NNUNET_RESUME_FINGERPRINT_DRIFT: {drift}")
        for checkpoint in partial_checkpoints:
            validate_nnunet_checkpoint(
                checkpoint,
                str(expected["trainer"]),
                require_optimizer=True,
                expected_configuration=expected.get("configuration"),
                expected_fold=expected.get("fold"),
                expected_dataset_name=expected.get("dataset_name"),
                expected_dataset_json=expected.get("dataset_json"),
                checkpoint_cadence=expected.get("checkpoint_save_every_epochs"),
                maximum_epoch_exclusive=expected.get("num_epochs"),
            )
            _validate_nnunet_resume_sidecar(checkpoint, path, expected)
        return bool(partial_checkpoints)
    if partial_checkpoints:
        raise RuntimeError("NNUNET_PARTIAL_CHECKPOINT_WITHOUT_FROZEN_RUN_SPEC")
    atomic_json(path, expected)
    return False


def validate_nnunet_checkpoint(
    checkpoint: Path,
    trainer: str,
    *,
    require_optimizer: bool,
    expected_configuration: str | None = None,
    expected_fold: str | None = None,
    expected_dataset_name: str | None = None,
    expected_dataset_json: dict[str, Any] | None = None,
    checkpoint_cadence: int | None = None,
    expected_epoch: int | None = None,
    maximum_epoch_exclusive: int | None = None,
) -> str:
    """Validate the minimum nnU-Net state required for safe reuse/resume."""
    try:
        if checkpoint.is_symlink() or not checkpoint.is_file():
            raise RuntimeError("checkpoint is missing, non-regular, or a symlink")
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        if not isinstance(payload, dict):
            raise RuntimeError("checkpoint payload is not a mapping")
        state = payload.get("network_weights")
        if not isinstance(state, dict) or not state:
            raise RuntimeError("network_weights is absent or empty")
        tensors = [value for value in state.values() if isinstance(value, torch.Tensor)]
        if not tensors or any(value.numel() <= 0 for value in tensors):
            raise RuntimeError("network_weights contains no non-empty tensors")
        epoch = payload.get("current_epoch")
        if isinstance(epoch, bool) or not isinstance(epoch, int) or epoch <= 0:
            raise RuntimeError("current_epoch is not a positive integer")
        if payload.get("trainer_name") != trainer:
            raise RuntimeError(
                f"trainer_name mismatch: expected={trainer!r}, observed={payload.get('trainer_name')!r}"
            )
        init_args = payload.get("init_args")
        if not isinstance(init_args, dict):
            raise RuntimeError("init_args is absent or invalid")
        if (
            expected_configuration is not None
            and init_args.get("configuration") != expected_configuration
        ):
            raise RuntimeError("init_args.configuration mismatch")
        if expected_fold is not None and str(init_args.get("fold")) != str(
            expected_fold
        ):
            raise RuntimeError("init_args.fold mismatch")
        if expected_dataset_name is not None:
            plans = init_args.get("plans")
            if (
                not isinstance(plans, dict)
                or plans.get("dataset_name") != expected_dataset_name
            ):
                raise RuntimeError("init_args.plans.dataset_name mismatch")
        if (
            expected_dataset_json is not None
            and init_args.get("dataset_json") != expected_dataset_json
        ):
            raise RuntimeError("init_args.dataset_json mismatch")
        optimizer_state = payload.get("optimizer_state")
        if not isinstance(optimizer_state, dict):
            raise RuntimeError("optimizer_state is absent or invalid")
        if require_optimizer and (
            not isinstance(optimizer_state.get("state"), dict)
            or not isinstance(optimizer_state.get("param_groups"), list)
            or not optimizer_state["param_groups"]
        ):
            raise RuntimeError(
                "optimizer_state lacks state/param_groups required for resume"
            )
        if not isinstance(payload.get("logging"), dict):
            raise RuntimeError("logging state is absent or invalid")
        if "_best_ema" not in payload:
            raise RuntimeError("_best_ema state is absent")
        if "grad_scaler_state" not in payload or (
            payload["grad_scaler_state"] is not None
            and not isinstance(payload["grad_scaler_state"], dict)
        ):
            raise RuntimeError("grad_scaler_state is absent or invalid")
        if "inference_allowed_mirroring_axes" not in payload:
            raise RuntimeError("inference_allowed_mirroring_axes is absent")
        if expected_epoch is not None and epoch != expected_epoch:
            raise RuntimeError(
                f"current_epoch mismatch: expected={expected_epoch}, observed={epoch}"
            )
        if checkpoint_cadence is not None and (
            isinstance(checkpoint_cadence, bool)
            or not isinstance(checkpoint_cadence, int)
            or checkpoint_cadence <= 0
            or epoch % checkpoint_cadence != 0
        ):
            raise RuntimeError(
                f"current_epoch does not match checkpoint cadence: epoch={epoch}, cadence={checkpoint_cadence}"
            )
        if maximum_epoch_exclusive is not None and epoch >= maximum_epoch_exclusive:
            raise RuntimeError(
                f"partial checkpoint epoch is not resumable: {epoch} >= {maximum_epoch_exclusive}"
            )
    except RuntimeError as exc:
        if str(exc).startswith("NNUNET_CHECKPOINT_INVALID"):
            raise
        raise RuntimeError(f"NNUNET_CHECKPOINT_INVALID: {checkpoint}: {exc}") from exc
    except Exception as exc:
        raise RuntimeError(f"NNUNET_CHECKPOINT_INVALID: {checkpoint}: {exc}") from exc
    return sha256_file(checkpoint)


def _completion_file(nn_root: Path, relative: Any) -> Path:
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise RuntimeError(f"NNUNET_COMPLETION_INVALID_PATH: {relative!r}")
    raw_candidate = nn_root / relative
    if raw_candidate.is_symlink():
        raise RuntimeError(f"NNUNET_COMPLETION_SYMLINK_FORBIDDEN: {relative}")
    candidate = raw_candidate.resolve()
    try:
        candidate.relative_to(nn_root.resolve())
    except ValueError as exc:
        raise RuntimeError(f"NNUNET_COMPLETION_PATH_ESCAPE: {relative!r}") from exc
    if not candidate.is_file():
        raise RuntimeError(f"NNUNET_COMPLETION_FILE_MISSING_OR_NONREGULAR: {relative}")
    return candidate


def _completion_hash(nn_root: Path, relative: Any, expected_sha256: Any) -> Path:
    candidate = _completion_file(nn_root, relative)
    if not isinstance(expected_sha256, str) or sha256_file(candidate) != expected_sha256:
        raise RuntimeError(f"NNUNET_COMPLETION_HASH_DRIFT: {relative}")
    return candidate


def _preprocessed_tree_snapshot(dataset_root: Path) -> tuple[list[dict[str, Any]], str]:
    """Hash every regular file and its canonical relative path without following links."""
    if dataset_root.is_symlink() or not dataset_root.is_dir():
        raise RuntimeError("NNUNET_PREPROCESS_DATASET_ROOT_MISSING_OR_UNSAFE")
    files: list[dict[str, Any]] = []
    for path in sorted(dataset_root.rglob("*"), key=lambda item: item.relative_to(dataset_root).as_posix()):
        relative = path.relative_to(dataset_root).as_posix()
        if path.is_symlink():
            raise RuntimeError(f"NNUNET_PREPROCESS_TREE_SYMLINK_FORBIDDEN: {relative}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise RuntimeError(f"NNUNET_PREPROCESS_TREE_NONREGULAR_FORBIDDEN: {relative}")
        stat = path.stat()
        files.append(
            {
                "path": relative,
                "sha256": sha256_file(path),
                "size_bytes": int(stat.st_size),
            }
        )
    if not files or not any(
        entry["path"] == f"{NNUNET_PLANS_IDENTIFIER}.json" for entry in files
    ):
        raise RuntimeError("NNUNET_PREPROCESS_TREE_INCOMPLETE_OR_PLANS_MISSING")
    canonical = json.dumps(
        files,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return files, hashlib.sha256(canonical).hexdigest()


def validate_nnunet_preprocess_completion(
    nn_root: Path,
    *,
    dataset_id: int,
    dataset_name: str,
    configuration: str,
) -> dict[str, Any]:
    """Return the current preprocessing binding or raise on any provenance/tree drift."""
    marker = nn_root / NNUNET_PREPROCESS_MARKER
    if marker.is_symlink() or not marker.is_file():
        raise RuntimeError("NNUNET_PREPROCESS_COMPLETION_MARKER_MISSING_OR_UNSAFE")
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError("NNUNET_PREPROCESS_COMPLETION_MARKER_INVALID") from exc
    expected_context = {
        "schema_version": 1,
        "status": "COMPLETE",
        "dataset_id": int(dataset_id),
        "dataset_name": dataset_name,
        "configuration": configuration,
        "dataset_json_path": f"raw/{dataset_name}/dataset.json",
        "staging_manifest_path": "staging_manifest.csv",
        "preprocessed_dataset_path": f"preprocessed/{dataset_name}",
        "plans_path": f"preprocessed/{dataset_name}/{NNUNET_PLANS_IDENTIFIER}.json",
    }
    drift = {
        key: {"expected": value, "observed": payload.get(key)}
        for key, value in expected_context.items()
        if payload.get(key) != value
    }
    if drift:
        raise RuntimeError(f"NNUNET_PREPROCESS_COMPLETION_CONTEXT_DRIFT: {drift}")
    dataset_json = _completion_hash(
        nn_root,
        payload.get("dataset_json_path"),
        payload.get("dataset_json_sha256"),
    )
    staging_manifest = _completion_hash(
        nn_root,
        payload.get("staging_manifest_path"),
        payload.get("staging_manifest_sha256"),
    )
    plans = _completion_hash(
        nn_root,
        payload.get("plans_path"),
        payload.get("plans_sha256"),
    )
    dataset_root = nn_root / "preprocessed" / dataset_name
    files, tree_sha256 = _preprocessed_tree_snapshot(dataset_root)
    if payload.get("preprocessed_files") != files:
        raise RuntimeError("NNUNET_PREPROCESS_FILE_MANIFEST_DRIFT")
    if payload.get("preprocessed_file_count") != len(files):
        raise RuntimeError("NNUNET_PREPROCESS_FILE_COUNT_DRIFT")
    if payload.get("preprocessed_tree_sha256") != tree_sha256:
        raise RuntimeError("NNUNET_PREPROCESS_TREE_HASH_DRIFT")
    return {
        "marker_path": NNUNET_PREPROCESS_MARKER,
        "marker_sha256": sha256_file(marker),
        "tree_sha256": tree_sha256,
        "file_count": len(files),
        "dataset_json_sha256": sha256_file(dataset_json),
        "staging_manifest_sha256": sha256_file(staging_manifest),
        "plans_sha256": sha256_file(plans),
    }


def write_nnunet_preprocess_completion_marker(
    nn_root: Path,
    *,
    dataset_id: int,
    dataset_name: str,
    configuration: str,
) -> dict[str, Any]:
    """Atomically seal the exact preprocessing inputs and complete output tree."""
    dataset_json = nn_root / "raw" / dataset_name / "dataset.json"
    staging_manifest = nn_root / "staging_manifest.csv"
    plans = (
        nn_root
        / "preprocessed"
        / dataset_name
        / f"{NNUNET_PLANS_IDENTIFIER}.json"
    )
    for path, label in (
        (dataset_json, "DATASET_JSON"),
        (staging_manifest, "STAGING_MANIFEST"),
        (plans, "PLANS"),
    ):
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f"NNUNET_PREPROCESS_{label}_MISSING_OR_UNSAFE")
    files, tree_sha256 = _preprocessed_tree_snapshot(
        nn_root / "preprocessed" / dataset_name
    )
    atomic_json(
        nn_root / NNUNET_PREPROCESS_MARKER,
        {
            "schema_version": 1,
            "status": "COMPLETE",
            "dataset_id": int(dataset_id),
            "dataset_name": dataset_name,
            "configuration": configuration,
            "dataset_json_path": f"raw/{dataset_name}/dataset.json",
            "dataset_json_sha256": sha256_file(dataset_json),
            "staging_manifest_path": "staging_manifest.csv",
            "staging_manifest_sha256": sha256_file(staging_manifest),
            "preprocessed_dataset_path": f"preprocessed/{dataset_name}",
            "plans_path": f"preprocessed/{dataset_name}/{NNUNET_PLANS_IDENTIFIER}.json",
            "plans_sha256": sha256_file(plans),
            "preprocessed_files": files,
            "preprocessed_file_count": len(files),
            "preprocessed_tree_sha256": tree_sha256,
            "completed_at": utc_now(),
        },
    )
    return validate_nnunet_preprocess_completion(
        nn_root,
        dataset_id=dataset_id,
        dataset_name=dataset_name,
        configuration=configuration,
    )


def _clean_preprocessed_dataset(nn_root: Path, dataset_name: str) -> None:
    """Delete only the fixed dataset subtree, never a linked parent/target."""
    preprocessed_root = nn_root / "preprocessed"
    if preprocessed_root.is_symlink():
        raise RuntimeError("NNUNET_PREPROCESSED_ROOT_SYMLINK_FORBIDDEN")
    preprocessed_root.mkdir(parents=True, exist_ok=True)
    dataset_root = preprocessed_root / dataset_name
    if dataset_root.is_symlink() or dataset_root.is_file():
        dataset_root.unlink()
    elif dataset_root.exists():
        if not dataset_root.is_dir():
            raise RuntimeError("NNUNET_PREPROCESS_DATASET_ROOT_NONREGULAR")
        shutil.rmtree(dataset_root)
    marker = nn_root / NNUNET_PREPROCESS_MARKER
    if marker.is_symlink() or marker.is_file():
        marker.unlink()
    elif marker.exists():
        raise RuntimeError("NNUNET_PREPROCESS_MARKER_NONREGULAR")


def ensure_nnunet_preprocessed(
    nn_root: Path,
    *,
    dataset_id: int,
    dataset_name: str,
    configuration: str,
    environment: dict[str, str],
    log_path: Path,
) -> dict[str, Any]:
    """Reuse only a sealed tree; otherwise clean it and rebuild preprocessing."""
    try:
        return validate_nnunet_preprocess_completion(
            nn_root,
            dataset_id=dataset_id,
            dataset_name=dataset_name,
            configuration=configuration,
        )
    except RuntimeError as exc:
        reason = str(exc)
    state_names = (
        "TRAIN_RUN_SPEC.json",
        "results",
        "predictions",
        "benchmark_predictions_predicted_only",
        "candidate_masks",
        "candidates.jsonl",
        "metadata.json",
        "provenance.json",
        "NNUNET_COMPLETE.json",
        NNUNET_PREPROCESS_MARKER,
    )
    if any((nn_root / name).exists() or (nn_root / name).is_symlink() for name in state_names):
        quarantine_nnunet_outputs(
            nn_root,
            f"NNUNET_PREPROCESS_REBUILD_REQUIRED: {reason}",
            include_training_spec=True,
            include_preprocess_marker=True,
        )
    _clean_preprocessed_dataset(nn_root, dataset_name)
    _run(
        [
            "nnUNetv2_plan_and_preprocess",
            "-d",
            str(dataset_id),
            "-c",
            configuration,
            "--verify_dataset_integrity",
        ],
        environment,
        log_path,
    )
    return write_nnunet_preprocess_completion_marker(
        nn_root,
        dataset_id=dataset_id,
        dataset_name=dataset_name,
        configuration=configuration,
    )


def _candidate_outputs_valid(
    nn_root: Path,
    candidates: Path,
    metadata: Path,
    checkpoint_sha256: str,
    expected_image_ids: set[str],
    prediction_sha256s: dict[str, str],
    *,
    trainer: str,
    dataset_id: int,
    fold: int,
    seed: int,
) -> bool:
    try:
        metadata_payload = json.loads(metadata.read_text(encoding="utf-8"))
        if (
            metadata_payload.get("candidate_jsonl_sha256") != sha256_file(candidates)
            or metadata_payload.get("checkpoint_sha256") != checkpoint_sha256
            or metadata_payload.get("method") != "nnUNet_v2_2d"
            or metadata_payload.get("trainer") != trainer
            or metadata_payload.get("dataset_id") != dataset_id
            or metadata_payload.get("fold") != fold
            or metadata_payload.get("seed") != seed
        ):
            return False
        observed_rows = 0
        observed_image_ids: set[str] = set()
        with candidates.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                row = json.loads(line)
                observed_rows += 1
                image_id = row.get("image_id")
                if not isinstance(image_id, str) or image_id not in expected_image_ids:
                    return False
                observed_image_ids.add(image_id)
                if row.get("nnunet_prediction_sha256") != prediction_sha256s.get(
                    f"predictions/{image_id}.png"
                ):
                    return False
                if row.get("checkpoint_sha256") != checkpoint_sha256:
                    return False
                mask_file = Path(row["mask_file"])
                try:
                    mask_file.resolve().relative_to(
                        (nn_root / "candidate_masks").resolve()
                    )
                except ValueError:
                    return False
                if (
                    mask_file.is_symlink()
                    or not mask_file.is_file()
                    or row.get("mask_file_sha256") != sha256_file(mask_file)
                ):
                    return False
        return observed_rows > 0 and observed_image_ids == expected_image_ids
    except (OSError, json.JSONDecodeError, KeyError, TypeError):
        return False


def nnunet_completion_valid(
    nn_root: Path,
    *,
    dataset_id: int,
    configuration: str,
    trainer: str,
    fold: int,
    seed: int,
    config_sha256: str,
    expected_image_ids: Sequence[str] | None = None,
    expected_training_image_ids: Sequence[str] | None = None,
    expected_training_patient_ids: Sequence[str] | None = None,
    expected_evaluation_patient_ids: Sequence[str] | None = None,
) -> tuple[bool, str, str | None]:
    """Validate the complete nnU-Net output chain and return its checkpoint hash."""
    marker = nn_root / "NNUNET_COMPLETE.json"
    try:
        if marker.is_symlink() or not marker.is_file():
            raise RuntimeError("NNUNET_COMPLETION_MARKER_MISSING")
        payload = json.loads(marker.read_text(encoding="utf-8"))
        expected = {
            "schema_version": 1,
            "status": "COMPLETE",
            "dataset_id": int(dataset_id),
            "configuration": configuration,
            "trainer": trainer,
            "fold": int(fold),
            "seed": int(seed),
            "config_sha256": config_sha256,
        }
        drift = {
            key: {"expected": value, "observed": payload.get(key)}
            for key, value in expected.items()
            if payload.get(key) != value
        }
        if drift:
            raise RuntimeError(f"NNUNET_COMPLETION_CONTEXT_DRIFT: {drift}")
        canonical_paths = {
            "preprocess_marker_path": NNUNET_PREPROCESS_MARKER,
            "training_spec_path": "TRAIN_RUN_SPEC.json",
            "candidates_path": "candidates.jsonl",
            "metadata_path": "metadata.json",
            "provenance_path": "provenance.json",
        }
        if any(payload.get(key) != value for key, value in canonical_paths.items()):
            raise RuntimeError("NNUNET_COMPLETION_NONCANONICAL_CORE_PATH")
        training_spec = _completion_hash(
            nn_root,
            payload.get("training_spec_path"),
            payload.get("training_spec_sha256"),
        )
        observed_spec = json.loads(training_spec.read_text(encoding="utf-8"))
        dataset_name = f"Dataset{int(dataset_id):03d}_ScreenBUSFold{int(fold)}"
        preprocess_binding = validate_nnunet_preprocess_completion(
            nn_root,
            dataset_id=int(dataset_id),
            dataset_name=dataset_name,
            configuration=configuration,
        )
        if (
            payload.get("preprocess_marker_sha256")
            != preprocess_binding["marker_sha256"]
            or payload.get("preprocessed_tree_sha256")
            != preprocess_binding["tree_sha256"]
        ):
            raise RuntimeError("NNUNET_COMPLETION_PREPROCESS_BINDING_DRIFT")
        dataset_json_path = nn_root / "raw" / dataset_name / "dataset.json"
        plans_path = nn_root / "preprocessed" / dataset_name / "nnUNetPlans.json"
        staging_path = nn_root / "staging_manifest.csv"
        for current_path, label in (
            (dataset_json_path, "dataset_json"),
            (plans_path, "plans"),
            (staging_path, "staging_manifest"),
        ):
            if current_path.is_symlink() or not current_path.is_file():
                raise RuntimeError(f"NNUNET_CURRENT_{label.upper()}_MISSING")
        current_dataset_json = json.loads(dataset_json_path.read_text(encoding="utf-8"))
        for key, value in {
            "dataset_id": int(dataset_id),
            "dataset_name": dataset_name,
            "configuration": configuration,
            "trainer": trainer,
            "fold": "all",
            "seed": int(seed),
            "config_sha256": config_sha256,
            "checkpoint_save_every_epochs": 5,
            "num_epochs": NNUNET_FINAL_EPOCHS,
            "dataset_json": current_dataset_json,
            "preprocess_marker_path": NNUNET_PREPROCESS_MARKER,
        }.items():
            if observed_spec.get(key) != value:
                raise RuntimeError(f"NNUNET_TRAINING_SPEC_DRIFT: {key}")
        current_hashes = {
            "plans_sha256": sha256_file(plans_path),
            "dataset_json_sha256": sha256_file(dataset_json_path),
            "staging_manifest_sha256": sha256_file(staging_path),
            "preprocess_marker_sha256": preprocess_binding["marker_sha256"],
            "preprocessed_tree_sha256": preprocess_binding["tree_sha256"],
        }
        for key, value in current_hashes.items():
            if observed_spec.get(key) != value:
                raise RuntimeError(f"NNUNET_TRAINING_SPEC_FILE_HASH_DRIFT: {key}")
        if expected_training_patient_ids is not None and observed_spec.get(
            "training_patient_ids"
        ) != sorted(set(expected_training_patient_ids)):
            raise RuntimeError("NNUNET_TRAINING_SPEC_PATIENT_SET_DRIFT")
        if expected_training_image_ids is not None and observed_spec.get(
            "training_image_ids"
        ) != sorted(set(expected_training_image_ids)):
            raise RuntimeError("NNUNET_TRAINING_SPEC_IMAGE_SET_DRIFT")
        checkpoint = _completion_hash(
            nn_root,
            payload.get("checkpoint_path"),
            payload.get("checkpoint_sha256"),
        )
        canonical_final = canonical_nnunet_checkpoint_path(
            nn_root,
            dataset_name,
            trainer,
            configuration,
            "checkpoint_final.pth",
        )
        if (
            payload.get("checkpoint_path")
            != str(canonical_final.relative_to(nn_root))
            or checkpoint.resolve() != canonical_final.resolve()
        ):
            raise RuntimeError("NNUNET_COMPLETION_NONCANONICAL_FINAL_CHECKPOINT")
        checkpoint_sha256 = validate_nnunet_checkpoint(
            checkpoint,
            trainer,
            require_optimizer=False,
            expected_configuration=configuration,
            expected_fold="all",
            expected_dataset_name=dataset_name,
            expected_dataset_json=current_dataset_json,
            expected_epoch=NNUNET_FINAL_EPOCHS,
        )
        finals = sorted((nn_root / "results").rglob("checkpoint_final.pth"))
        if len(finals) != 1 or finals[0].resolve() != checkpoint.resolve():
            raise RuntimeError("NNUNET_COMPLETION_AMBIGUOUS_FINAL_CHECKPOINT")
        sidecar = _completion_hash(
            nn_root,
            payload.get("seed_sidecar_path"),
            payload.get("seed_sidecar_sha256"),
        )
        if sidecar != checkpoint.with_suffix(".screenbus_seed.json"):
            raise RuntimeError("NNUNET_COMPLETION_SEED_SIDECAR_PATH_DRIFT")
        if not nnunet_seed_sidecar_valid(checkpoint, seed):
            raise RuntimeError("NNUNET_COMPLETION_SEED_SIDECAR_INVALID")
        sidecar_payload = json.loads(sidecar.read_text(encoding="utf-8"))
        if (
            sidecar_payload.get("seed_injection") != NNUNET_SEED_INJECTION
            or sidecar_payload.get("deterministic_algorithms") is not True
            or sidecar_payload.get("checkpoint_save_every_epochs") != 5
        ):
            raise RuntimeError("NNUNET_COMPLETION_SEED_SIDECAR_SEMANTIC_DRIFT")
        candidates = _completion_hash(
            nn_root,
            payload.get("candidates_path"),
            payload.get("candidates_sha256"),
        )
        metadata = _completion_hash(
            nn_root,
            payload.get("metadata_path"),
            payload.get("metadata_sha256"),
        )
        provenance = _completion_hash(
            nn_root,
            payload.get("provenance_path"),
            payload.get("provenance_sha256"),
        )
        provenance_payload = json.loads(provenance.read_text(encoding="utf-8"))
        expected_provenance = {
            "dataset_json_sha256": current_hashes["dataset_json_sha256"],
            "plans_sha256": current_hashes["plans_sha256"],
            "staging_manifest_sha256": current_hashes["staging_manifest_sha256"],
            "preprocess_marker_sha256": current_hashes[
                "preprocess_marker_sha256"
            ],
            "preprocessed_tree_sha256": current_hashes[
                "preprocessed_tree_sha256"
            ],
            "checkpoint_sha256": checkpoint_sha256,
            "seed": int(seed),
            "patient_overlap": [],
        }
        if any(
            provenance_payload.get(key) != value
            for key, value in expected_provenance.items()
        ):
            raise RuntimeError("NNUNET_COMPLETION_PROVENANCE_CHECKPOINT_DRIFT")
        if expected_training_patient_ids is not None and provenance_payload.get(
            "training_patient_ids"
        ) != sorted(set(expected_training_patient_ids)):
            raise RuntimeError("NNUNET_COMPLETION_PROVENANCE_TRAIN_PATIENT_DRIFT")
        if expected_evaluation_patient_ids is not None and provenance_payload.get(
            "evaluation_patient_ids"
        ) != sorted(set(expected_evaluation_patient_ids)):
            raise RuntimeError("NNUNET_COMPLETION_PROVENANCE_EVAL_PATIENT_DRIFT")
        if expected_training_image_ids is not None and provenance_payload.get(
            "training_image_ids"
        ) != sorted(set(expected_training_image_ids)):
            raise RuntimeError("NNUNET_COMPLETION_PROVENANCE_TRAIN_IMAGE_DRIFT")
        if expected_image_ids is not None and provenance_payload.get(
            "evaluation_image_ids"
        ) != sorted(set(expected_image_ids)):
            raise RuntimeError("NNUNET_COMPLETION_PROVENANCE_EVAL_IMAGE_DRIFT")
        prediction_hashes = payload.get("prediction_sha256s")
        if not isinstance(prediction_hashes, dict) or not prediction_hashes:
            raise RuntimeError("NNUNET_COMPLETION_PREDICTION_SET_MISSING")
        if expected_image_ids is not None and len(set(expected_image_ids)) != len(
            expected_image_ids
        ):
            raise RuntimeError("NNUNET_COMPLETION_DUPLICATE_EXPECTED_IMAGE_IDS")
        expected_image_id_set = (
            set(expected_image_ids)
            if expected_image_ids is not None
            else {Path(relative).stem for relative in prediction_hashes}
        )
        expected_relatives = {
            f"predictions/{image_id}.png" for image_id in expected_image_id_set
        }
        if set(prediction_hashes) != expected_relatives:
            raise RuntimeError("NNUNET_COMPLETION_PREDICTION_SET_DRIFT")
        observed_prediction_files = {
            str(path.relative_to(nn_root)) for path in (nn_root / "predictions").glob("*.png")
        }
        if observed_prediction_files != expected_relatives:
            raise RuntimeError("NNUNET_COMPLETION_PREDICTION_FILES_DRIFT")
        for relative, expected_sha256 in prediction_hashes.items():
            _completion_hash(nn_root, relative, expected_sha256)
        if not _candidate_outputs_valid(
            nn_root,
            candidates,
            metadata,
            checkpoint_sha256,
            expected_image_id_set,
            prediction_hashes,
            trainer=trainer,
            dataset_id=int(dataset_id),
            fold=int(fold),
            seed=int(seed),
        ):
            raise RuntimeError("NNUNET_COMPLETION_CANDIDATE_BINDING_INVALID")
        return True, "ok", checkpoint_sha256
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError, RuntimeError) as exc:
        return False, str(exc), None


def nnunet_training_command(
    dataset_id: int,
    configuration: str,
    trainer: str,
    seed: int,
    checkpoint_save_every: int,
    training_spec_path: Path,
    *,
    continue_training: bool,
) -> list[str]:
    command = [
        sys.executable,
        "-m",
        "screenbus_a0_v2.nnunet_seeded_launcher",
        "--dataset-id",
        str(dataset_id),
        "--configuration",
        configuration,
        "--fold",
        "all",
        "--trainer",
        trainer,
        "--seed",
        str(seed),
        "--checkpoint-save-every",
        str(checkpoint_save_every),
        "--training-spec",
        str(training_spec_path),
    ]
    if continue_training:
        command.append("--continue-training")
    return command


def nnunet_seed_sidecar_valid(checkpoint: Path, seed: int) -> bool:
    sidecar = checkpoint.with_suffix(".screenbus_seed.json")
    try:
        evidence = json.loads(sidecar.read_text(encoding="utf-8"))
        observed_checkpoint_sha256 = sha256_file(checkpoint)
    except (OSError, json.JSONDecodeError):
        return False
    return (
        isinstance(evidence, dict)
        and int(evidence.get("effective_seed", -1)) == int(seed)
        and evidence.get("checkpoint_sha256") == observed_checkpoint_sha256
    )


def quarantine_nnunet_outputs(
    nn_root: Path,
    reason: str,
    *,
    include_training_spec: bool = False,
    include_preprocess_marker: bool = False,
) -> Path:
    """Move unverifiable final outputs aside before a clean deterministic rebuild."""
    quarantine = nn_root / "quarantine" / f"{int(time.time_ns())}"
    quarantine.mkdir(parents=True, exist_ok=False)
    moved = []
    names = [
        "results",
        "predictions",
        "benchmark_predictions_predicted_only",
        "candidate_masks",
        "candidates.jsonl",
        "metadata.json",
        "provenance.json",
        "NNUNET_COMPLETE.json",
    ]
    if include_training_spec:
        names.append("TRAIN_RUN_SPEC.json")
    if include_preprocess_marker:
        names.append(NNUNET_PREPROCESS_MARKER)
    for name in names:
        source = nn_root / name
        if source.exists() or source.is_symlink():
            destination = quarantine / name
            os.replace(source, destination)
            moved.append(name)
    atomic_json(
        quarantine / "QUARANTINE.json",
        {
            "status": "UNVERIFIED_NNUNET_OUTPUTS_QUARANTINED",
            "reason": reason,
            "moved": moved,
            "at": utc_now(),
        },
    )
    return quarantine


def _run(command: list[str], environment: dict[str, str], log_path: Path) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as log:
        log.write("COMMAND: " + " ".join(command) + "\n")
        result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, check=False)
    if result.returncode != 0:
        raise RuntimeError(f"nnU-Net command failed ({result.returncode}); see {log_path}")


def _visible_gpu_used_mib() -> float:
    physical = os.environ.get("SCREENBUS_ASSIGNED_GPU")
    if physical is None:
        visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
        physical = visible.split(",", 1)[0].strip()
    if not physical or not physical.isdigit():
        raise RuntimeError("nnU-Net benchmark requires one numeric assigned physical GPU")
    result = subprocess.run(
        [
            "nvidia-smi",
            "--id",
            physical,
            "--query-compute-apps=used_memory",
            "--format=csv,noheader,nounits",
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(f"nvidia-smi process-memory query failed: {result.stderr.strip()}")
    values = []
    for line in result.stdout.splitlines():
        token = line.strip().split()[0] if line.strip() else ""
        try:
            values.append(float(token))
        except ValueError:
            continue
    return sum(values)


def _run_measured_external(
    command: list[str], environment: dict[str, str], log_path: Path
) -> tuple[float, float]:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    peak_mib = 0.0
    started = time.perf_counter()
    with log_path.open("a", encoding="utf-8") as log:
        log.write("MEASURED_PREDICT_COMMAND: " + " ".join(command) + "\n")
        process = subprocess.Popen(
            command,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            text=True,
        )
        while process.poll() is None:
            peak_mib = max(peak_mib, _visible_gpu_used_mib())
            time.sleep(0.1)
        peak_mib = max(peak_mib, _visible_gpu_used_mib())
        return_code = process.wait()
    if return_code != 0:
        raise RuntimeError(f"nnU-Net measured predict failed ({return_code}); see {log_path}")
    return time.perf_counter() - started, peak_mib / 1024


def _checkpoint_parameter_count(checkpoint: Path) -> int:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    state = payload.get("network_weights", payload.get("model"))
    if not isinstance(state, dict):
        raise RuntimeError(f"nnU-Net checkpoint has no countable network state: {checkpoint}")
    count = int(sum(value.numel() for value in state.values() if isinstance(value, torch.Tensor)))
    if count <= 0:
        raise RuntimeError(f"nnU-Net parameter count is invalid: {checkpoint}")
    return count


def benchmark_nnunet_predict_only(
    evaluation_records: Sequence[ManifestRecord],
    run_dir: Path,
    cfg: dict,
    fold: int,
    seed: int,
) -> Path:
    """Measure deployed nnU-Net predict + instance conversion, never training/GT."""
    if not evaluation_records:
        raise RuntimeError("nnU-Net predicted-only benchmark has no evaluation images")
    dataset_id = int(cfg["nnunet"]["dataset_id"]) + fold
    dataset_name = f"Dataset{dataset_id:03d}_ScreenBUSFold{fold}"
    nn_root = run_dir / "nnunet"
    raw_root = nn_root / "raw"
    results_root = nn_root / "results"
    dataset_root = raw_root / dataset_name
    complete, reason, checkpoint_sha256 = nnunet_completion_valid(
        nn_root,
        dataset_id=dataset_id,
        configuration=cfg["nnunet"]["configuration"],
        trainer=cfg["nnunet"]["trainer"],
        fold=fold,
        seed=seed,
        config_sha256=cfg["_config_sha256"],
        expected_image_ids=[record.image_id for record in evaluation_records],
        expected_evaluation_patient_ids=[
            record.patient_id for record in evaluation_records
        ],
    )
    if not complete or checkpoint_sha256 is None:
        raise RuntimeError(f"NNUNET_BENCHMARK_FORBIDDEN_INCOMPLETE_OUTPUT: {reason}")
    checkpoint_relative = json.loads(
        (nn_root / "NNUNET_COMPLETE.json").read_text(encoding="utf-8")
    )["checkpoint_path"]
    checkpoint = _completion_file(nn_root, checkpoint_relative)
    parameter_count = _checkpoint_parameter_count(checkpoint)
    predictions = nn_root / "benchmark_predictions_predicted_only"
    if predictions.exists():
        shutil.rmtree(predictions)
    environment = os.environ.copy()
    environment.update(
        nnUNet_raw=str(raw_root),
        nnUNet_preprocessed=str(nn_root / "preprocessed"),
        nnUNet_results=str(results_root),
    )
    overall_started = time.perf_counter()
    _, peak_vram_gib = _run_measured_external(
        [
            "nnUNetv2_predict",
            "-i",
            str(dataset_root / "imagesTs"),
            "-o",
            str(predictions),
            "-d",
            str(dataset_id),
            "-c",
            cfg["nnunet"]["configuration"],
            "-f",
            "all",
            "-tr",
            cfg["nnunet"]["trainer"],
        ],
        environment,
        nn_root / "nnunet_efficiency.log",
    )
    predicted_components = 0
    for record in evaluation_records:
        path = predictions / f"{record.image_id}.png"
        if not path.is_file():
            raise RuntimeError(f"nnU-Net benchmark prediction missing: {path}")
        prediction = np.asarray(Image.open(path)) > 0
        predicted_components += len(connected_instances(prediction))
    seconds = time.perf_counter() - overall_started
    limit = float(cfg["runtime"]["max_peak_vram_gib"])
    if peak_vram_gib <= 0 or peak_vram_gib >= limit:
        raise RuntimeError(
            f"nnU-Net predicted-only peak VRAM is invalid/out of bounds: {peak_vram_gib:.3f} GiB"
        )
    output = run_dir / "runtime" / "nnunet_predicted_only.json"
    atomic_json(
        output,
        {
            "schema_version": 1,
            "method": "nnUNet_v2_2D",
            "measurement_status": "MEASURED_PREDICTED_ONLY_END_TO_END",
            "measurement": "external_predict_wall_clock_plus_instance_conversion_with_nvidia_smi_sampling",
            "box_condition": "full_image_predicted_output_only",
            "ground_truth_pixels_read": False,
            "image_count": len(evaluation_records),
            "predicted_component_count": predicted_components,
            "seconds": seconds,
            "seconds_per_image": seconds / len(evaluation_records),
            "throughput_images_per_second": len(evaluation_records) / seconds,
            "peak_vram_gib": peak_vram_gib,
            "total_system_parameter_count": parameter_count,
            "parameter_scope": "complete_deployed_nnunet_network",
            "checkpoint": str(checkpoint),
            "checkpoint_sha256": checkpoint_sha256,
        },
    )
    return output


def run_nnunet_baseline(
    train_records: Sequence[ManifestRecord],
    evaluation_records: Sequence[ManifestRecord],
    run_dir: Path,
    cfg: dict,
    fold: int,
    seed: int,
) -> Path:
    if not cfg["nnunet"]["enabled"]:
        raise RuntimeError("nnU-Net is registered but disabled; refusing an incomplete full protocol")
    overlap = {record.patient_id for record in train_records} & {
        record.patient_id for record in evaluation_records
    }
    if overlap:
        raise RuntimeError(f"PATIENT_LEAKAGE in nnU-Net split: {sorted(overlap)}")
    dataset_id = int(cfg["nnunet"]["dataset_id"]) + fold
    dataset_name = f"Dataset{dataset_id:03d}_ScreenBUSFold{fold}"
    nn_root = run_dir / "nnunet"
    raw_root = nn_root / "raw"
    preprocessed_root = nn_root / "preprocessed"
    results_root = nn_root / "results"
    dataset_root = raw_root / dataset_name
    staging_rows = []
    for record in train_records:
        staging_rows.append(
            stage_case(
                record,
                dataset_root / "imagesTr" / f"{record.image_id}_0000.png",
                dataset_root / "labelsTr" / f"{record.image_id}.png",
            )
        )
    for record in evaluation_records:
        staging_rows.append(
            stage_case(record, dataset_root / "imagesTs" / f"{record.image_id}_0000.png", None)
        )
    atomic_csv(nn_root / "staging_manifest.csv", staging_rows)
    dataset_json = {
        "channel_names": {"0": "ultrasound"},
        "labels": {"background": 0, "lesion": 1},
        "numTraining": len(train_records),
        "file_ending": ".png",
        "overwrite_image_reader_writer": "NaturalImage2DIO",
    }
    atomic_json(dataset_root / "dataset.json", dataset_json)
    environment = os.environ.copy()
    environment.update(
        nnUNet_raw=str(raw_root),
        nnUNet_preprocessed=str(preprocessed_root),
        nnUNet_results=str(results_root),
    )
    log = nn_root / "nnunet.log"
    plans = preprocessed_root / dataset_name / "nnUNetPlans.json"
    preprocess_binding = ensure_nnunet_preprocessed(
        nn_root,
        dataset_id=dataset_id,
        dataset_name=dataset_name,
        configuration=cfg["nnunet"]["configuration"],
        environment=environment,
        log_path=log,
    )
    trainer = cfg["nnunet"]["trainer"]
    checkpoint_save_every = int(cfg["nnunet"]["checkpoint_save_every_epochs"])
    training_spec_path = nn_root / "TRAIN_RUN_SPEC.json"
    training_spec = {
        "schema_version": 1,
        "dataset_id": dataset_id,
        "dataset_name": dataset_name,
        "configuration": cfg["nnunet"]["configuration"],
        "fold": "all",
        "trainer": trainer,
        "seed": seed,
        "checkpoint_save_every_epochs": checkpoint_save_every,
        "num_epochs": NNUNET_FINAL_EPOCHS,
        "config_sha256": cfg["_config_sha256"],
        "preprocess_marker_path": preprocess_binding["marker_path"],
        "preprocess_marker_sha256": preprocess_binding["marker_sha256"],
        "preprocessed_tree_sha256": preprocess_binding["tree_sha256"],
        "plans_sha256": sha256_file(plans),
        "dataset_json_sha256": sha256_file(dataset_root / "dataset.json"),
        "dataset_json": dataset_json,
        "staging_manifest_sha256": sha256_file(nn_root / "staging_manifest.csv"),
        "training_image_ids": sorted(record.image_id for record in train_records),
        "training_patient_ids": sorted({record.patient_id for record in train_records}),
    }
    complete, _, _ = nnunet_completion_valid(
        nn_root,
        dataset_id=dataset_id,
        configuration=cfg["nnunet"]["configuration"],
        trainer=trainer,
        fold=fold,
        seed=seed,
        config_sha256=cfg["_config_sha256"],
        expected_image_ids=[record.image_id for record in evaluation_records],
        expected_training_image_ids=[record.image_id for record in train_records],
        expected_training_patient_ids=[record.patient_id for record in train_records],
        expected_evaluation_patient_ids=[
            record.patient_id for record in evaluation_records
        ],
    )
    if complete:
        freeze_nnunet_training_spec(training_spec_path, training_spec, [])
        return nn_root / "candidates.jsonl"
    canonical_final = canonical_nnunet_checkpoint_path(
        nn_root,
        dataset_name,
        trainer,
        cfg["nnunet"]["configuration"],
        "checkpoint_final.pth",
    )
    canonical_latest = canonical_nnunet_checkpoint_path(
        nn_root,
        dataset_name,
        trainer,
        cfg["nnunet"]["configuration"],
        "checkpoint_latest.pth",
    )
    checkpoint_candidates = sorted(results_root.rglob("checkpoint_final.pth"))
    partial_checkpoints = sorted(results_root.rglob("checkpoint_latest.pth"))
    if not training_spec_path.is_file() and (checkpoint_candidates or partial_checkpoints):
        quarantine_nnunet_outputs(
            nn_root,
            "NNUNET_CHECKPOINT_WITHOUT_FROZEN_RUN_SPEC",
        )
        results_root.mkdir(parents=True, exist_ok=True)
        checkpoint_candidates = []
        partial_checkpoints = []
    if len(checkpoint_candidates) > 1 or len(partial_checkpoints) > 1:
        quarantine_nnunet_outputs(
            nn_root,
            "NNUNET_AMBIGUOUS_CHECKPOINT_SET",
        )
        results_root.mkdir(parents=True, exist_ok=True)
        checkpoint_candidates = []
        partial_checkpoints = []
    if checkpoint_candidates and checkpoint_candidates != [canonical_final]:
        quarantine_nnunet_outputs(
            nn_root,
            "NNUNET_NONCANONICAL_FINAL_CHECKPOINT",
        )
        results_root.mkdir(parents=True, exist_ok=True)
        checkpoint_candidates = []
        partial_checkpoints = []
    if partial_checkpoints and partial_checkpoints != [canonical_latest]:
        quarantine_nnunet_outputs(
            nn_root,
            "NNUNET_NONCANONICAL_PARTIAL_CHECKPOINT",
        )
        results_root.mkdir(parents=True, exist_ok=True)
        checkpoint_candidates = []
        partial_checkpoints = []
    try:
        continue_training = freeze_nnunet_training_spec(
            training_spec_path,
            training_spec,
            partial_checkpoints if not checkpoint_candidates else [],
        )
    except RuntimeError as exc:
        if "NNUNET_CHECKPOINT_INVALID" not in str(exc):
            raise
        quarantine_nnunet_outputs(
            nn_root,
            str(exc),
        )
        results_root.mkdir(parents=True, exist_ok=True)
        checkpoint_candidates = []
        partial_checkpoints = []
        continue_training = False
    if checkpoint_candidates:
        try:
            validate_nnunet_checkpoint(
                checkpoint_candidates[0],
                trainer,
                require_optimizer=False,
                expected_configuration=cfg["nnunet"]["configuration"],
                expected_fold="all",
                expected_dataset_name=dataset_name,
                expected_dataset_json=dataset_json,
                expected_epoch=NNUNET_FINAL_EPOCHS,
            )
        except RuntimeError:
            pass
        quarantine_nnunet_outputs(
            nn_root,
            "NNUNET_UNBOUND_OR_INVALID_FINAL_OUTPUT_REQUIRES_CLEAN_REBUILD",
        )
        results_root.mkdir(parents=True, exist_ok=True)
        checkpoint_candidates = []
        partial_checkpoints = []
        continue_training = False
    if not checkpoint_candidates:
        _run(
            nnunet_training_command(
                dataset_id,
                cfg["nnunet"]["configuration"],
                trainer,
                seed,
                checkpoint_save_every,
                training_spec_path,
                continue_training=continue_training,
            ),
            environment,
            log,
        )
        # A prediction directory without a valid completion marker is not
        # bound to the checkpoint that has just been trained/resumed.  Never
        # relabel such stale bytes as output from the new final checkpoint.
        stale_predictions = nn_root / "predictions"
        if stale_predictions.exists() or stale_predictions.is_symlink():
            if stale_predictions.is_symlink() or not stale_predictions.is_dir():
                raise RuntimeError("NNUNET_PREDICTIONS_PATH_IS_NOT_A_DIRECTORY")
            shutil.rmtree(stale_predictions)
    checkpoint_candidates = sorted(results_root.rglob("checkpoint_final.pth"))
    final_valid = False
    if checkpoint_candidates == [canonical_final]:
        try:
            validate_nnunet_checkpoint(
                checkpoint_candidates[0],
                trainer,
                require_optimizer=False,
                expected_configuration=cfg["nnunet"]["configuration"],
                expected_fold="all",
                expected_dataset_name=dataset_name,
                expected_dataset_json=dataset_json,
                expected_epoch=NNUNET_FINAL_EPOCHS,
            )
            final_valid = nnunet_seed_sidecar_valid(checkpoint_candidates[0], seed)
        except RuntimeError:
            final_valid = False
    if not final_valid:
        quarantine_nnunet_outputs(
            nn_root,
            "NNUNET_TRAINING_FINISHED_WITHOUT_UNIQUE_VALID_FINAL_SEED_EVIDENCE",
        )
        results_root.mkdir(parents=True, exist_ok=True)
        raise RuntimeError(
            "nnU-Net final checkpoint/seed evidence is invalid; outputs were quarantined for a clean retry"
        )
    predictions = nn_root / "predictions"
    expected = [predictions / f"{record.image_id}.png" for record in evaluation_records]
    observed_prediction_names = (
        {path.name for path in predictions.glob("*.png")} if predictions.is_dir() else set()
    )
    expected_prediction_names = {path.name for path in expected}
    if (
        not all(path.is_file() and not path.is_symlink() for path in expected)
        or observed_prediction_names != expected_prediction_names
    ):
        if predictions.exists() or predictions.is_symlink():
            if predictions.is_symlink() or not predictions.is_dir():
                raise RuntimeError("NNUNET_PREDICTIONS_PATH_IS_NOT_A_DIRECTORY")
            shutil.rmtree(predictions)
        _run(
            [
                "nnUNetv2_predict",
                "-i",
                str(dataset_root / "imagesTs"),
                "-o",
                str(predictions),
                "-d",
                str(dataset_id),
                "-c",
                cfg["nnunet"]["configuration"],
                "-f",
                "all",
                "-tr",
                trainer,
            ],
            environment,
            log,
        )
    checkpoint = checkpoint_candidates[0]
    checkpoint_sha256 = validate_nnunet_checkpoint(
        checkpoint,
        trainer,
        require_optimizer=False,
        expected_configuration=cfg["nnunet"]["configuration"],
        expected_fold="all",
        expected_dataset_name=dataset_name,
        expected_dataset_json=dataset_json,
        expected_epoch=NNUNET_FINAL_EPOCHS,
    )
    seed_sidecar = checkpoint.with_suffix(".screenbus_seed.json")
    seed_sidecars = [str(seed_sidecar)]
    rows: list[dict[str, Any]] = []
    mask_dir = nn_root / "candidate_masks"
    mask_dir.mkdir(parents=True, exist_ok=True)
    for record, prediction_path in zip(evaluation_records, expected):
        if not prediction_path.is_file():
            raise RuntimeError(f"nnU-Net prediction missing: {prediction_path}")
        prediction = np.asarray(Image.open(prediction_path)) > 0
        components = connected_instances(prediction)
        boxes = instance_boxes(components)
        gt = connected_instances(mask_binary(record.mask_path))
        component_scores = [1.0] * len(boxes)
        primary_matches = primary_candidate_matches(boxes, component_scores, gt)
        sensitivity_matches = sensitivity_candidate_matches(
            boxes, component_scores, gt, cfg["matching"]["sensitivity_box_iou_threshold"]
        )
        arrays: dict[str, np.ndarray] = {}
        image_rows: list[dict[str, Any]] = []
        for index, (mask, box) in enumerate(zip(components, boxes)):
            key = f"mask_{index}"
            arrays[key] = mask
            labels = _label_candidate(mask, gt, primary_matches[index], sensitivity_matches[index])
            feature_map = _candidate_features(mask, box, 1.0, 0.0, [], detector_rank=index)
            image_rows.append(
                {
                    **_base_row(record, len(gt), "full_image_semantic"),
                    "candidate_index": index,
                    "is_sentinel": 0,
                    "box_xyxy": box.tolist(),
                    "features": [feature_map[name] for name in FEATURE_NAMES],
                    "feature_map": feature_map,
                    **labels,
                    "failure": int(
                        labels["candidate_valid"] == 0 or labels["mask_dice"] < cfg["failure_dice_threshold"]
                    ),
                    "mask_key": key,
                    "nnunet_prediction_sha256": sha256_file(prediction_path),
                }
            )
        mask_path = mask_dir / f"{record.image_id}.npz"
        np.savez_compressed(mask_path, **arrays)
        if not image_rows:
            image_rows = [_sentinel(record, len(gt), "full_image_semantic")]
        for row in image_rows:
            row["mask_file"] = str(mask_path.resolve())
            row["mask_file_sha256"] = sha256_file(mask_path)
            row["checkpoint_sha256"] = checkpoint_sha256
            row["nnunet_prediction_sha256"] = sha256_file(prediction_path)
            rows.append(row)
    output = _save_rows(
        nn_root,
        rows,
        {
            "created_at": utc_now(),
            "method": "nnUNet_v2_2d",
            "trainer": trainer,
            "dataset_id": dataset_id,
            "fold": fold,
            "seed": seed,
            "checkpoint_sha256": checkpoint_sha256,
        },
    )
    provenance_path = nn_root / "provenance.json"
    atomic_json(
        provenance_path,
        {
            "dataset_json_sha256": sha256_file(dataset_root / "dataset.json"),
            "plans_sha256": sha256_file(plans),
            "staging_manifest_sha256": sha256_file(nn_root / "staging_manifest.csv"),
            "preprocess_marker_sha256": preprocess_binding["marker_sha256"],
            "preprocessed_tree_sha256": preprocess_binding["tree_sha256"],
            "training_patient_ids": sorted({record.patient_id for record in train_records}),
            "evaluation_patient_ids": sorted({record.patient_id for record in evaluation_records}),
            "training_image_ids": sorted(record.image_id for record in train_records),
            "evaluation_image_ids": sorted(
                record.image_id for record in evaluation_records
            ),
            "patient_overlap": sorted(
                {record.patient_id for record in train_records}
                & {record.patient_id for record in evaluation_records}
            ),
            "seed": seed,
            "seed_controls": {
                "PYTHONHASHSEED": seed,
                "numpy": seed,
                "torch": seed,
                "torch_cuda": seed,
                "deterministic_algorithms": True,
            },
            "checkpoint_paths": [str(path) for path in results_root.rglob("checkpoint_final.pth")],
            "checkpoint_sha256": checkpoint_sha256,
            "seed_evidence_sidecars": seed_sidecars,
        },
    )
    metadata_path = nn_root / "metadata.json"
    prediction_sha256s = {
        str(path.relative_to(nn_root)): sha256_file(path) for path in expected
    }
    atomic_json(
        nn_root / "NNUNET_COMPLETE.json",
        {
            "schema_version": 1,
            "status": "COMPLETE",
            "dataset_id": dataset_id,
            "configuration": cfg["nnunet"]["configuration"],
            "trainer": trainer,
            "fold": fold,
            "seed": seed,
            "config_sha256": cfg["_config_sha256"],
            "preprocess_marker_path": preprocess_binding["marker_path"],
            "preprocess_marker_sha256": preprocess_binding["marker_sha256"],
            "preprocessed_tree_sha256": preprocess_binding["tree_sha256"],
            "training_spec_path": str(training_spec_path.relative_to(nn_root)),
            "training_spec_sha256": sha256_file(training_spec_path),
            "checkpoint_path": str(checkpoint.relative_to(nn_root)),
            "checkpoint_sha256": checkpoint_sha256,
            "seed_sidecar_path": str(seed_sidecar.relative_to(nn_root)),
            "seed_sidecar_sha256": sha256_file(seed_sidecar),
            "candidates_path": str(output.relative_to(nn_root)),
            "candidates_sha256": sha256_file(output),
            "metadata_path": str(metadata_path.relative_to(nn_root)),
            "metadata_sha256": sha256_file(metadata_path),
            "provenance_path": str(provenance_path.relative_to(nn_root)),
            "provenance_sha256": sha256_file(provenance_path),
            "prediction_sha256s": prediction_sha256s,
            "completed_at": utc_now(),
        },
    )
    valid, reason, observed_checkpoint_sha256 = nnunet_completion_valid(
        nn_root,
        dataset_id=dataset_id,
        configuration=cfg["nnunet"]["configuration"],
        trainer=trainer,
        fold=fold,
        seed=seed,
        config_sha256=cfg["_config_sha256"],
        expected_image_ids=[record.image_id for record in evaluation_records],
        expected_training_image_ids=[record.image_id for record in train_records],
        expected_training_patient_ids=[record.patient_id for record in train_records],
        expected_evaluation_patient_ids=[
            record.patient_id for record in evaluation_records
        ],
    )
    if not valid or observed_checkpoint_sha256 != checkpoint_sha256:
        quarantine_nnunet_outputs(nn_root, f"NNUNET_COMPLETION_SELF_CHECK_FAILED: {reason}")
        raise RuntimeError(f"NNUNET_COMPLETION_SELF_CHECK_FAILED: {reason}")
    return output
