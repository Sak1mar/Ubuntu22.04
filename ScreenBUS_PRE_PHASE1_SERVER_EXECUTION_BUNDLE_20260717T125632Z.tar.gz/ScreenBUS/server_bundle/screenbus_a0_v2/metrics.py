from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any, Callable, Sequence

import numpy as np
from scipy import ndimage
from sklearn.metrics import average_precision_score

from .candidates import load_candidate_mask, primary_candidate_matches
from .data import connected_instances, mask_binary


BOUNDARY_F1_MAIN_TOLERANCE_PX = 2
BOUNDARY_F1_SENSITIVITY_TOLERANCES_PX = (1, 2, 3)


def hd95(prediction: np.ndarray, target: np.ndarray) -> float:
    prediction, target = prediction.astype(bool), target.astype(bool)
    if not prediction.any() and not target.any():
        return 0.0
    if not prediction.any() or not target.any():
        return float(np.hypot(*prediction.shape))
    pred_boundary = np.logical_xor(prediction, ndimage.binary_erosion(prediction))
    target_boundary = np.logical_xor(target, ndimage.binary_erosion(target))
    target_distance = ndimage.distance_transform_edt(~target_boundary)
    pred_distance = ndimage.distance_transform_edt(~pred_boundary)
    distances = np.concatenate([target_distance[pred_boundary], pred_distance[target_boundary]])
    return float(np.percentile(distances, 95))


def boundary_f1(
    prediction: np.ndarray,
    target: np.ndarray,
    tolerance: int = BOUNDARY_F1_MAIN_TOLERANCE_PX,
) -> float:
    prediction, target = prediction.astype(bool), target.astype(bool)
    pred_boundary = np.logical_xor(prediction, ndimage.binary_erosion(prediction))
    target_boundary = np.logical_xor(target, ndimage.binary_erosion(target))
    if not pred_boundary.any() and not target_boundary.any():
        return 1.0
    if not pred_boundary.any() or not target_boundary.any():
        return 0.0
    structure = ndimage.generate_binary_structure(2, 2)
    pred_dilated = ndimage.binary_dilation(pred_boundary, structure=structure, iterations=tolerance)
    target_dilated = ndimage.binary_dilation(target_boundary, structure=structure, iterations=tolerance)
    precision = np.logical_and(pred_boundary, target_dilated).sum() / pred_boundary.sum()
    recall = np.logical_and(target_boundary, pred_dilated).sum() / target_boundary.sum()
    return float(2 * precision * recall / (precision + recall)) if precision + recall else 0.0


def _accepted(rows: Sequence[dict[str, Any]], scores: Sequence[float], threshold: float) -> list[dict[str, Any]]:
    result = []
    for row, score in zip(rows, scores):
        if not row.get("is_sentinel") and float(score) >= threshold:
            copied = dict(row)
            copied["acceptance_score"] = float(score)
            result.append(copied)
    return result


def _summaries(rows: Sequence[dict[str, Any]], accepted: Sequence[dict[str, Any]]) -> dict[str, dict[str, float]]:
    all_by_image: dict[str, list[dict[str, Any]]] = defaultdict(list)
    accepted_by_image: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        all_by_image[row["image_id"]].append(row)
    for row in accepted:
        accepted_by_image[row["image_id"]].append(row)
    patient: dict[str, dict[str, float]] = defaultdict(
        lambda: {
            "positive_images": 0,
            "normal_images": 0,
            "lesions": 0,
            "detected_lesions": 0,
            "segmentation_views": 0,
            "dice_sum": 0.0,
            "hd95_sum": 0.0,
            "boundary_f1_sum": 0.0,
            "boundary_f1_1px_sum": 0.0,
            "boundary_f1_2px_sum": 0.0,
            "boundary_f1_3px_sum": 0.0,
            "normal_fp_masks": 0,
            "normal_fp_images": 0,
            "normal_fp_area": 0.0,
        }
    )
    for image_id, image_rows in all_by_image.items():
        first = image_rows[0]
        summary = patient[first["patient_id"]]
        selected = accepted_by_image.get(image_id, [])
        lesion_count = int(first["gt_lesion_count"])
        if lesion_count == 0:
            summary["normal_images"] += 1
            summary["normal_fp_masks"] += len(selected)
            summary["normal_fp_images"] += int(bool(selected))
            summary["normal_fp_area"] += sum(load_candidate_mask(row).mean() for row in selected)
            continue
        summary["positive_images"] += 1
        summary["segmentation_views"] += 1
        summary["lesions"] += lesion_count
        target = mask_binary(Path(first["ground_truth_mask_file"])).astype(bool)
        prediction = np.zeros_like(target, dtype=bool)
        for row in selected:
            prediction |= load_candidate_mask(row).astype(bool)
        intersection = np.logical_and(prediction, target).sum()
        denominator = prediction.sum() + target.sum()
        summary["dice_sum"] += float(2 * intersection / denominator) if denominator else 1.0
        summary["hd95_sum"] += hd95(prediction, target)
        boundary_values = {
            tolerance: boundary_f1(prediction, target, tolerance)
            for tolerance in BOUNDARY_F1_SENSITIVITY_TOLERANCES_PX
        }
        summary["boundary_f1_sum"] += boundary_values[BOUNDARY_F1_MAIN_TOLERANCE_PX]
        for tolerance, value in boundary_values.items():
            summary[f"boundary_f1_{tolerance}px_sum"] += value
        summary["detected_lesions"] += len(
            {
                int(row["matched_lesion"])
                for row in selected
                if row.get("candidate_valid") and int(row.get("matched_lesion", -1)) >= 0
            }
        )
    return dict(patient)


def _metrics_from_patient_summaries(summaries: Sequence[dict[str, float]]) -> dict[str, float]:
    lesions = sum(row["lesions"] for row in summaries)
    normal_images = sum(row["normal_images"] for row in summaries)
    patient_dice = [
        row["dice_sum"] / row["segmentation_views"]
        for row in summaries
        if row["segmentation_views"]
    ]
    patient_hd95 = [
        row["hd95_sum"] / row["segmentation_views"]
        for row in summaries
        if row["segmentation_views"]
    ]
    patient_boundary_f1 = [
        row["boundary_f1_sum"] / row["segmentation_views"]
        for row in summaries
        if row["segmentation_views"]
    ]
    patient_boundary_sensitivity = {
        tolerance: [
            row[f"boundary_f1_{tolerance}px_sum"] / row["segmentation_views"]
            for row in summaries
            if row["segmentation_views"]
        ]
        for tolerance in BOUNDARY_F1_SENSITIVITY_TOLERANCES_PX
    }
    patient_normal_fp_masks = [
        row["normal_fp_masks"] / row["normal_images"]
        for row in summaries
        if row["normal_images"]
    ]
    patient_normal_fp_rate = [
        row["normal_fp_images"] / row["normal_images"]
        for row in summaries
        if row["normal_images"]
    ]
    patient_normal_fp_area = [
        row["normal_fp_area"] / row["normal_images"]
        for row in summaries
        if row["normal_images"]
    ]
    return {
        "lesion_sensitivity": sum(row["detected_lesions"] for row in summaries) / lesions if lesions else float("nan"),
        "patient_macro_dice": float(np.mean(patient_dice)) if patient_dice else float("nan"),
        "hd95": float(np.mean(patient_hd95)) if patient_hd95 else float("nan"),
        "boundary_f1": float(np.mean(patient_boundary_f1)) if patient_boundary_f1 else float("nan"),
        "boundary_f1_1px": (
            float(np.mean(patient_boundary_sensitivity[1]))
            if patient_boundary_sensitivity[1]
            else float("nan")
        ),
        "boundary_f1_2px": (
            float(np.mean(patient_boundary_sensitivity[2]))
            if patient_boundary_sensitivity[2]
            else float("nan")
        ),
        "boundary_f1_3px": (
            float(np.mean(patient_boundary_sensitivity[3]))
            if patient_boundary_sensitivity[3]
            else float("nan")
        ),
        "boundary_f1_primary_tolerance_px": BOUNDARY_F1_MAIN_TOLERANCE_PX,
        "normal_fp_masks_per_image": float(np.mean(patient_normal_fp_masks)) if patient_normal_fp_masks else float("nan"),
        "normal_image_fp_rate": float(np.mean(patient_normal_fp_rate)) if patient_normal_fp_rate else float("nan"),
        "normal_fp_area_per_image": float(np.mean(patient_normal_fp_area)) if patient_normal_fp_area else float("nan"),
        "lesion_events": lesions,
        "normal_images": normal_images,
    }


def _binary_calibration_metrics(labels: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    if len(labels) == 0:
        return {
            "auprc": float("nan"),
            "ece_10bin": float("nan"),
            "brier": float("nan"),
            "nll": float("nan"),
        }
    probabilities = np.clip(np.asarray(probabilities, dtype=float), 1e-6, 1 - 1e-6)
    labels = np.asarray(labels, dtype=int)
    ece = 0.0
    bins = np.linspace(0.0, 1.0, 11)
    for lower, upper in zip(bins[:-1], bins[1:]):
        member = (probabilities >= lower) & (
            probabilities < upper if upper < 1 else probabilities <= upper
        )
        if member.any():
            ece += member.mean() * abs(probabilities[member].mean() - labels[member].mean())
    return {
        "auprc": (
            float(average_precision_score(labels, probabilities))
            if len(np.unique(labels)) == 2
            else float("nan")
        ),
        "ece_10bin": float(ece),
        "brier": float(np.mean((probabilities - labels) ** 2)),
        "nll": float(
            -np.mean(labels * np.log(probabilities) + (1 - labels) * np.log(1 - probabilities))
        ),
    }


def verifier_component_metrics(
    rows: Sequence[dict[str, Any]],
    existence_scores: Sequence[float],
    quality_scores: Sequence[float],
) -> dict[str, Any]:
    """Evaluate the two frozen binary verifier tasks.

    This separation is deliberate: an invalid/unmatched candidate is a valid
    negative for the existence task, but it is not a zero-quality regression
    target. Treating it as one would conflate the two verifier heads.
    """
    if not (len(rows) == len(existence_scores) == len(quality_scores)):
        raise ValueError("Verifier component scores must align one-to-one with rows")
    real = [
        (row, float(existence), float(quality_score))
        for row, existence, quality_score in zip(rows, existence_scores, quality_scores)
        if not row.get("is_sentinel")
    ]
    existence_labels = np.asarray([int(row["candidate_valid"]) for row, _, _ in real])
    existence_probabilities = np.asarray([score for _, score, _ in real], dtype=float)
    existence = _binary_calibration_metrics(existence_labels, existence_probabilities)
    valid = [(row, quality_score) for row, _, quality_score in real if row["candidate_valid"]]
    quality_targets = np.asarray([int(row["failure"] == 0) for row, _ in valid], dtype=int)
    quality_predictions = np.asarray([score for _, score in valid], dtype=float)
    quality_metrics = _binary_calibration_metrics(quality_targets, quality_predictions)
    return {
        "existence_task_scope": "all_real_candidates",
        "existence_candidate_count": len(real),
        "existence_positive_count": int(existence_labels.sum()) if len(real) else 0,
        "existence_negative_count": int(len(real) - existence_labels.sum()) if len(real) else 0,
        "existence_auprc": existence["auprc"],
        "existence_ece_10bin": existence["ece_10bin"],
        "existence_brier": existence["brier"],
        "existence_nll": existence["nll"],
        "quality_task_scope": "candidate_valid_only_binary_dice_at_frozen_failure_threshold",
        "quality_valid_candidate_count": len(valid),
        "quality_auprc": quality_metrics["auprc"],
        "quality_ece_10bin": quality_metrics["ece_10bin"],
        "quality_brier": quality_metrics["brier"],
        "quality_nll": quality_metrics["nll"],
    }


def dual_threshold_states(
    rows: Sequence[dict[str, Any]],
    existence_scores: Sequence[float],
    existence_threshold: float,
    quality_scores: Sequence[float] | None = None,
    quality_threshold: float | None = None,
) -> list[str]:
    """Return explicit candidate states: empty, refer, or accept."""
    if len(rows) != len(existence_scores):
        raise ValueError("Existence scores must align one-to-one with rows")
    if quality_scores is not None and len(rows) != len(quality_scores):
        raise ValueError("Quality scores must align one-to-one with rows")
    if (quality_scores is None) != (quality_threshold is None):
        raise ValueError("Quality scores and quality threshold must be supplied together")
    states: list[str] = []
    for index, (row, existence) in enumerate(zip(rows, existence_scores)):
        if row.get("is_sentinel") or float(existence) < existence_threshold:
            states.append("empty")
        elif quality_scores is not None and float(quality_scores[index]) < float(quality_threshold):
            states.append("refer")
        else:
            states.append("accept")
    return states


def evaluate_candidate_method(
    rows: Sequence[dict[str, Any]],
    scores: Sequence[float],
    threshold: float,
    bootstrap_replicates: int,
    seed: int,
    quality_scores: Sequence[float] | None = None,
    quality_threshold: float | None = None,
    failure_ranking_scores: Sequence[float] | None = None,
) -> tuple[dict[str, float], dict[str, tuple[float, float]]]:
    states = dual_threshold_states(rows, scores, threshold, quality_scores, quality_threshold)
    accepted = [
        dict(row, acceptance_score=float(score))
        for row, score, state in zip(rows, scores, states)
        if state == "accept"
    ]
    patient_map = _summaries(rows, accepted)
    metrics = _metrics_from_patient_summaries(list(patient_map.values()))
    rng = np.random.default_rng(seed)
    patient_ids = sorted(patient_map)
    bootstrap: dict[str, list[float]] = defaultdict(list)
    for _ in range(bootstrap_replicates):
        sample = rng.choice(patient_ids, size=len(patient_ids), replace=True)
        replicate = _metrics_from_patient_summaries([patient_map[patient] for patient in sample])
        for key, value in replicate.items():
            if key not in {
                "lesion_events",
                "normal_images",
                "boundary_f1_primary_tolerance_px",
            } and np.isfinite(value):
                bootstrap[key].append(value)
    intervals = {
        key: (float(np.percentile(values, 2.5)), float(np.percentile(values, 97.5)))
        for key, values in bootstrap.items()
        if values
    }
    metrics["candidate_state_empty_count"] = int(sum(state == "empty" for state in states))
    metrics["candidate_state_refer_count"] = int(sum(state == "refer" for state in states))
    metrics["candidate_state_accept_count"] = int(sum(state == "accept" for state in states))
    by_image: dict[str, list[str]] = defaultdict(list)
    for row, state in zip(rows, states):
        by_image[row["image_id"]].append(state)
    metrics["image_state_accepted_count"] = int(
        sum(any(state == "accept" for state in image_states) for image_states in by_image.values())
    )
    metrics["image_state_refer_count"] = int(
        sum(
            not any(state == "accept" for state in image_states)
            and any(state == "refer" for state in image_states)
            for image_states in by_image.values()
        )
    )
    metrics["image_state_confident_empty_count"] = int(
        len(by_image) - metrics["image_state_accepted_count"] - metrics["image_state_refer_count"]
    )
    ranking_scores = scores if failure_ranking_scores is None else failure_ranking_scores
    if len(ranking_scores) != len(rows):
        raise ValueError("Failure-ranking scores must align one-to-one with rows")
    real = [
        (row, score)
        for row, score in zip(rows, ranking_scores)
        if not row.get("is_sentinel")
    ]
    failures = np.asarray([int(row["failure"]) for row, _score in real])
    failure_scores = 1.0 - np.asarray([score for _row, score in real], dtype=float)
    metrics["failure_auprc"] = (
        float(average_precision_score(failures, failure_scores)) if len(np.unique(failures)) == 2 else float("nan")
    )
    if len(failures):
        probability = np.clip(failure_scores, 1e-6, 1 - 1e-6)
        metrics["failure_brier"] = float(np.mean((probability - failures) ** 2))
        metrics["failure_nll"] = float(
            -np.mean(failures * np.log(probability) + (1 - failures) * np.log(1 - probability))
        )
        metrics["failure_ece_10bin"] = _binary_calibration_metrics(
            failures, probability
        )["ece_10bin"]
    else:
        metrics["failure_brier"] = float("nan")
        metrics["failure_nll"] = float("nan")
        metrics["failure_ece_10bin"] = float("nan")
    return metrics, intervals


def select_threshold_for_sensitivity(
    rows: Sequence[dict[str, Any]], scores: Sequence[float], target_sensitivity: float
) -> tuple[float, float, bool]:
    unique = sorted(
        {float(score) for row, score in zip(rows, scores) if not row.get("is_sentinel")}, reverse=True
    )
    if not unique:
        return float("inf"), 0.0, False
    best_threshold, achieved = min(unique) - 1e-12, 0.0
    for threshold in unique:
        metrics, _ = evaluate_candidate_method(rows, scores, threshold, 0, 0)
        sensitivity = float(metrics["lesion_sensitivity"])
        if sensitivity >= target_sensitivity:
            best_threshold, achieved = threshold, sensitivity
            break
        achieved = max(achieved, sensitivity)
    attainable = achieved >= target_sensitivity
    if not attainable:
        best_threshold = min(unique) - 1e-12
        metrics, _ = evaluate_candidate_method(rows, scores, best_threshold, 0, 0)
        achieved = float(metrics["lesion_sensitivity"])
    return float(best_threshold), achieved, attainable


def select_dual_thresholds_for_sensitivity(
    rows: Sequence[dict[str, Any]],
    existence_scores: Sequence[float],
    quality_scores: Sequence[float],
    target_sensitivity: float,
    grid_points: int = 51,
) -> tuple[float, float, float, float, bool]:
    """Select both B5 thresholds exclusively from patient-level inner OOF rows."""
    if not (len(rows) == len(existence_scores) == len(quality_scores)):
        raise ValueError("Dual threshold inputs must align")
    real_indices = [index for index, row in enumerate(rows) if not row.get("is_sentinel")]
    if not real_indices:
        return float("inf"), float("inf"), 0.0, float("nan"), False

    def grid(values: Sequence[float]) -> list[float]:
        array = np.asarray([values[index] for index in real_indices], dtype=float)
        quantiles = np.quantile(array, np.linspace(0.0, 1.0, min(grid_points, len(array))))
        return sorted({float(value) for value in quantiles}, reverse=True)

    existence_grid = grid(existence_scores)
    quality_grid = grid(quality_scores)
    lesion_total = 0
    by_image: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        by_image[row["image_id"]].append(index)
    for indices in by_image.values():
        lesion_total += int(rows[indices[0]]["gt_lesion_count"])

    def operating_metrics(existence_threshold: float, quality_threshold: float) -> tuple[float, float]:
        detected = 0
        normal_by_patient: dict[str, list[int]] = defaultdict(list)
        for indices in by_image.values():
            first = rows[indices[0]]
            accepted_indices = [
                index
                for index in indices
                if not rows[index].get("is_sentinel")
                and float(existence_scores[index]) >= existence_threshold
                and float(quality_scores[index]) >= quality_threshold
            ]
            if int(first["gt_lesion_count"]) == 0:
                normal_by_patient[str(first["patient_id"])].append(int(bool(accepted_indices)))
            else:
                detected += len(
                    {
                        int(rows[index]["matched_lesion"])
                        for index in accepted_indices
                        if rows[index].get("candidate_valid")
                        and int(rows[index].get("matched_lesion", -1)) >= 0
                    }
                )
        sensitivity = detected / lesion_total if lesion_total else float("nan")
        patient_rates = [float(np.mean(values)) for values in normal_by_patient.values() if values]
        normal_fp_rate = float(np.mean(patient_rates)) if patient_rates else float("nan")
        return sensitivity, normal_fp_rate

    best: tuple[float, float, float, float] | None = None
    maximum_sensitivity = 0.0
    for existence_threshold in existence_grid:
        for quality_threshold in quality_grid:
            sensitivity, normal_fp_rate = operating_metrics(existence_threshold, quality_threshold)
            if np.isfinite(sensitivity):
                maximum_sensitivity = max(maximum_sensitivity, sensitivity)
            if sensitivity < target_sensitivity:
                continue
            candidate = (normal_fp_rate, -existence_threshold - quality_threshold, existence_threshold, quality_threshold)
            if best is None or candidate[:2] < best[:2]:
                best = candidate
    if best is None:
        existence_threshold = min(existence_grid) - 1e-12
        quality_threshold = min(quality_grid) - 1e-12
        sensitivity, normal_fp_rate = operating_metrics(existence_threshold, quality_threshold)
        return existence_threshold, quality_threshold, sensitivity, normal_fp_rate, False
    normal_fp_rate, _tie, existence_threshold, quality_threshold = best
    sensitivity, _ = operating_metrics(existence_threshold, quality_threshold)
    return existence_threshold, quality_threshold, sensitivity, normal_fp_rate, True


def evaluate_dual_operating_point(
    rows: Sequence[dict[str, Any]],
    existence_scores: Sequence[float],
    quality_scores: Sequence[float],
    existence_threshold: float,
    quality_threshold: float,
) -> tuple[float, float]:
    if not (len(rows) == len(existence_scores) == len(quality_scores)):
        raise ValueError("Dual threshold inputs must align")
    by_image: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        by_image[str(row["image_id"])].append(index)
    lesion_total = 0
    detected = 0
    normal_by_patient: dict[str, list[int]] = defaultdict(list)
    for indices in by_image.values():
        first = rows[indices[0]]
        lesion_total += int(first["gt_lesion_count"])
        accepted = [
            index
            for index in indices
            if not rows[index].get("is_sentinel")
            and float(existence_scores[index]) >= float(existence_threshold)
            and float(quality_scores[index]) >= float(quality_threshold)
        ]
        if int(first["gt_lesion_count"]) == 0:
            normal_by_patient[str(first["patient_id"])].append(int(bool(accepted)))
        else:
            detected += len(
                {
                    int(rows[index]["matched_lesion"])
                    for index in accepted
                    if rows[index].get("candidate_valid")
                    and int(rows[index].get("matched_lesion", -1)) >= 0
                }
            )
    sensitivity = detected / lesion_total if lesion_total else float("nan")
    patient_rates = [float(np.mean(values)) for values in normal_by_patient.values() if values]
    normal_fp_rate = float(np.mean(patient_rates)) if patient_rates else float("nan")
    return sensitivity, normal_fp_rate


def select_fold_stable_threshold_for_sensitivity(
    rows: Sequence[dict[str, Any]],
    scores: Sequence[float],
    meta_folds: Sequence[int],
    target_sensitivity: float,
    max_fold_threshold_range: float,
) -> dict[str, Any]:
    if not (len(rows) == len(scores) == len(meta_folds)):
        raise ValueError("Fold-stable threshold inputs must align")
    folds = sorted({int(value) for value in meta_folds if int(value) >= 0})
    if len(folds) < 2:
        return {"status": "NO_DECISION", "reason": "fewer than two meta folds"}
    fold_rows: list[dict[str, Any]] = []
    thresholds: list[float] = []
    all_attainable = True
    for heldout_fold in folds:
        keep = [index for index, fold in enumerate(meta_folds) if int(fold) != heldout_fold]
        threshold, sensitivity, attainable = select_threshold_for_sensitivity(
            [rows[index] for index in keep],
            [scores[index] for index in keep],
            target_sensitivity,
        )
        thresholds.append(float(threshold))
        all_attainable = all_attainable and bool(attainable)
        fold_rows.append(
            {
                "heldout_meta_fold": heldout_fold,
                "threshold": float(threshold),
                "training_fold_sensitivity": float(sensitivity),
                "target_attainable": bool(attainable),
            }
        )
    threshold_range = float(max(thresholds) - min(thresholds))
    final_threshold = float(np.median(np.asarray(thresholds, dtype=float)))
    final_metrics, _ = evaluate_candidate_method(rows, scores, final_threshold, 0, 0)
    final_sensitivity = float(final_metrics["lesion_sensitivity"])
    stable = bool(threshold_range <= float(max_fold_threshold_range))
    return {
        "status": "STABLE_THRESHOLD" if stable else "UNSTABLE_THRESHOLD / NO_DECISION",
        "threshold": final_threshold,
        "fold_thresholds": fold_rows,
        "fold_threshold_range": threshold_range,
        "max_fold_threshold_range": float(max_fold_threshold_range),
        "oof_lesion_sensitivity": final_sensitivity,
        "oof_patient_macro_normal_fp_rate": float(final_metrics["normal_image_fp_rate"]),
        "target_attainable": bool(all_attainable and final_sensitivity >= target_sensitivity),
        "selection_source": "leave_one_meta_fold_out_then_median_inner_meta_oof_only",
    }


def select_fold_stable_dual_thresholds_for_sensitivity(
    rows: Sequence[dict[str, Any]],
    existence_scores: Sequence[float],
    quality_scores: Sequence[float],
    meta_folds: Sequence[int],
    target_sensitivity: float,
    max_fold_threshold_range: float,
) -> dict[str, Any]:
    if not (
        len(rows) == len(existence_scores) == len(quality_scores) == len(meta_folds)
    ):
        raise ValueError("Fold-stable dual threshold inputs must align")
    folds = sorted({int(value) for value in meta_folds if int(value) >= 0})
    if len(folds) < 2:
        return {"status": "NO_DECISION", "reason": "fewer than two meta folds"}
    fold_rows: list[dict[str, Any]] = []
    existence_thresholds: list[float] = []
    quality_thresholds: list[float] = []
    all_attainable = True
    for heldout_fold in folds:
        keep = [index for index, fold in enumerate(meta_folds) if int(fold) != heldout_fold]
        (
            existence_threshold,
            quality_threshold,
            sensitivity,
            normal_fp_rate,
            attainable,
        ) = select_dual_thresholds_for_sensitivity(
            [rows[index] for index in keep],
            [existence_scores[index] for index in keep],
            [quality_scores[index] for index in keep],
            target_sensitivity,
        )
        existence_thresholds.append(float(existence_threshold))
        quality_thresholds.append(float(quality_threshold))
        all_attainable = all_attainable and bool(attainable)
        fold_rows.append(
            {
                "heldout_meta_fold": heldout_fold,
                "existence_threshold": float(existence_threshold),
                "quality_threshold": float(quality_threshold),
                "training_fold_sensitivity": float(sensitivity),
                "training_fold_patient_macro_normal_fp_rate": float(normal_fp_rate),
                "target_attainable": bool(attainable),
            }
        )
    existence_range = float(max(existence_thresholds) - min(existence_thresholds))
    quality_range = float(max(quality_thresholds) - min(quality_thresholds))
    final_existence = float(np.median(np.asarray(existence_thresholds, dtype=float)))
    final_quality = float(np.median(np.asarray(quality_thresholds, dtype=float)))
    sensitivity, normal_fp_rate = evaluate_dual_operating_point(
        rows,
        existence_scores,
        quality_scores,
        final_existence,
        final_quality,
    )
    stable = bool(
        existence_range <= float(max_fold_threshold_range)
        and quality_range <= float(max_fold_threshold_range)
    )
    return {
        "status": "STABLE_THRESHOLD" if stable else "UNSTABLE_THRESHOLD / NO_DECISION",
        "threshold": final_existence,
        "existence_threshold": final_existence,
        "quality_threshold": final_quality,
        "fold_thresholds": fold_rows,
        "existence_fold_threshold_range": existence_range,
        "quality_fold_threshold_range": quality_range,
        "max_fold_threshold_range": float(max_fold_threshold_range),
        "oof_lesion_sensitivity": float(sensitivity),
        "oof_patient_macro_normal_fp_rate": float(normal_fp_rate),
        "target_attainable": bool(all_attainable and sensitivity >= target_sensitivity),
        "selection_source": "leave_one_meta_fold_out_then_median_inner_meta_oof_only",
    }


def detection_recall_at_fp_per_image(rows: Sequence[dict[str, Any]], target_fp: float) -> dict[str, float]:
    rows = [row for row in rows if row["condition"] == "predicted_box"]
    if not rows:
        return {"recall": 0.0, "fp_per_image": 0.0, "threshold": float("inf")}
    by_image: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_image[row["image_id"]].append(row)
    thresholds = sorted({float(row["feature_map"]["detector_score"]) for row in rows}, reverse=True)
    best = {"recall": 0.0, "fp_per_image": 0.0, "threshold": thresholds[-1]}
    total_lesions = sum(image_rows[0]["gt_lesion_count"] for image_rows in by_image.values())
    for threshold in thresholds:
        detected, false_positives = 0, 0
        for image_rows in by_image.values():
            first = image_rows[0]
            gt_instances = connected_instances(mask_binary(Path(first["ground_truth_mask_file"])))
            eligible = [
                row
                for row in image_rows
                if not row.get("is_sentinel")
                and row["feature_map"]["detector_score"] >= threshold
            ]
            matches = primary_candidate_matches(
                [np.asarray(row["box_xyxy"], dtype=float) for row in eligible],
                [float(row["feature_map"]["detector_score"]) for row in eligible],
                gt_instances,
            )
            matched = {index for index in matches if index >= 0}
            detected += len(matched)
            false_positives += sum(index < 0 for index in matches)
        fp_per_image = false_positives / len(by_image)
        recall = detected / total_lesions if total_lesions else 0.0
        if fp_per_image <= target_fp and recall >= best["recall"]:
            best = {"recall": recall, "fp_per_image": fp_per_image, "threshold": threshold}
    return best


def patient_cluster_bootstrap_detection_recall_at_fp(
    rows: Sequence[dict[str, Any]],
    target_fp: float,
    bootstrap_replicates: int,
    seed: int,
) -> dict[str, float]:
    """Patient-cluster bootstrap for recall at the frozen FP/view operating point."""

    selected = [row for row in rows if row["condition"] == "predicted_box"]
    if not selected:
        return {
            "recall": 0.0,
            "ci_low": 0.0,
            "ci_high": 0.0,
            "fp_per_view": 0.0,
            "threshold": float("inf"),
        }
    thresholds = sorted(
        {
            float(row["feature_map"]["detector_score"])
            for row in selected
            if not row.get("is_sentinel")
        },
        reverse=True,
    )
    if not thresholds:
        thresholds = [float("inf")]
    patients = sorted({str(row["patient_id"]) for row in selected})
    images: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in selected:
        images[(str(row["patient_id"]), str(row["image_id"]))].append(row)
    summaries: dict[str, list[tuple[int, int, int]]] = {}
    for patient in patients:
        patient_images = [value for (pid, _image), value in images.items() if pid == patient]
        rows_by_threshold: list[tuple[int, int, int]] = []
        for threshold in thresholds:
            lesions = 0
            detected = 0
            false_positives = 0
            for image_rows in patient_images:
                lesions += int(image_rows[0]["gt_lesion_count"])
                eligible = [
                    row
                    for row in image_rows
                    if not row.get("is_sentinel")
                    and float(row["feature_map"]["detector_score"]) >= threshold
                ]
                detected += len(
                    {
                        int(row["matched_lesion"])
                        for row in eligible
                        if row.get("candidate_valid")
                        and int(row.get("matched_lesion", -1)) >= 0
                    }
                )
                false_positives += sum(not bool(row.get("candidate_valid")) for row in eligible)
            rows_by_threshold.append((lesions, detected, false_positives))
        summaries[patient] = rows_by_threshold

    def operating(sample: Sequence[str]) -> tuple[float, float, float]:
        views = sum(
            1
            for patient in sample
            for pid, _image in images
            if pid == patient
        )
        best_recall, best_fp, best_threshold = 0.0, 0.0, thresholds[-1]
        for position, threshold in enumerate(thresholds):
            lesions = sum(summaries[patient][position][0] for patient in sample)
            detected = sum(summaries[patient][position][1] for patient in sample)
            false_positives = sum(summaries[patient][position][2] for patient in sample)
            fp_per_view = false_positives / views if views else 0.0
            recall = detected / lesions if lesions else 0.0
            if fp_per_view <= target_fp and recall >= best_recall:
                best_recall, best_fp, best_threshold = recall, fp_per_view, threshold
        return float(best_recall), float(best_fp), float(best_threshold)

    point, fp_per_view, threshold = operating(patients)
    rng = np.random.default_rng(seed)
    values = [
        operating(list(rng.choice(patients, size=len(patients), replace=True)))[0]
        for _ in range(bootstrap_replicates)
    ]
    return {
        "recall": point,
        "ci_low": float(np.percentile(values, 2.5)),
        "ci_high": float(np.percentile(values, 97.5)),
        "fp_per_view": fp_per_view,
        "threshold": threshold,
        "bootstrap_replicates": int(bootstrap_replicates),
    }


def paired_patient_bootstrap(
    comparator_rows: Sequence[dict[str, Any]],
    comparator_scores: Sequence[float],
    comparator_threshold: float,
    treatment_rows: Sequence[dict[str, Any]],
    treatment_scores: Sequence[float],
    treatment_threshold: float,
    bootstrap_replicates: int,
    seed: int,
    *,
    comparator_quality_scores: Sequence[float] | None = None,
    comparator_quality_threshold: float | None = None,
    treatment_quality_scores: Sequence[float] | None = None,
    treatment_quality_threshold: float | None = None,
) -> dict[str, dict[str, float]]:
    """Paired patient-cluster bootstrap preserving every row in each cluster.

    Deltas are treatment minus comparator, except normal-FP reduction which is
    comparator minus treatment so that a positive value is an improvement.
    """
    comparator_states = dual_threshold_states(
        comparator_rows,
        comparator_scores,
        comparator_threshold,
        comparator_quality_scores,
        comparator_quality_threshold,
    )
    treatment_states = dual_threshold_states(
        treatment_rows,
        treatment_scores,
        treatment_threshold,
        treatment_quality_scores,
        treatment_quality_threshold,
    )
    comparator_accepted = [row for row, state in zip(comparator_rows, comparator_states) if state == "accept"]
    treatment_accepted = [row for row, state in zip(treatment_rows, treatment_states) if state == "accept"]
    comparator_map = _summaries(comparator_rows, comparator_accepted)
    treatment_map = _summaries(treatment_rows, treatment_accepted)
    if set(comparator_map) != set(treatment_map):
        raise ValueError("Paired bootstrap requires identical patient clusters")
    patient_ids = sorted(comparator_map)
    if not patient_ids:
        raise ValueError("Paired bootstrap requires at least one patient")

    def negative_action_by_patient(
        rows: Sequence[dict[str, Any]], states: Sequence[str]
    ) -> dict[str, tuple[int, int]]:
        images: dict[tuple[str, str], dict[str, Any]] = defaultdict(
            lambda: {"negative": False, "action": False}
        )
        for row, state in zip(rows, states):
            key = (str(row["patient_id"]), str(row["image_id"]))
            images[key]["negative"] = int(row["gt_lesion_count"]) == 0
            images[key]["action"] = bool(images[key]["action"] or state in {"refer", "accept"})
        values: dict[str, list[int]] = defaultdict(list)
        for (patient, _image), item in images.items():
            if item["negative"]:
                values[patient].append(int(item["action"]))
        return {
            patient: (int(sum(actions)), len(actions))
            for patient, actions in values.items()
        }

    comparator_action = negative_action_by_patient(comparator_rows, comparator_states)
    treatment_action = negative_action_by_patient(treatment_rows, treatment_states)

    def sampled_action(
        mapping: dict[str, tuple[int, int]], sample: Sequence[str]
    ) -> float:
        # Resample patient clusters, then recompute the frozen view-level rate.
        # This preserves patients' negative-view multiplicities and matches
        # full_cohort_selective_curve exactly at the point estimate.
        values = [mapping[patient] for patient in sample if patient in mapping]
        actions = sum(value[0] for value in values)
        negative_views = sum(value[1] for value in values)
        return actions / negative_views if negative_views else float("nan")

    def deltas(patient_sample: Sequence[str]) -> dict[str, float]:
        comparator = _metrics_from_patient_summaries([comparator_map[patient] for patient in patient_sample])
        treatment = _metrics_from_patient_summaries([treatment_map[patient] for patient in patient_sample])
        return {
            "absolute_normal_fp_rate_reduction": comparator["normal_image_fp_rate"] - treatment["normal_image_fp_rate"],
            "absolute_negative_view_action_rate_reduction": sampled_action(
                comparator_action, patient_sample
            )
            - sampled_action(treatment_action, patient_sample),
            "lesion_recall_delta": treatment["lesion_sensitivity"] - comparator["lesion_sensitivity"],
            "patient_macro_dice_delta": treatment["patient_macro_dice"] - comparator["patient_macro_dice"],
            "boundary_f1_delta": treatment["boundary_f1"] - comparator["boundary_f1"],
            "hd95_delta": treatment["hd95"] - comparator["hd95"],
        }

    point = deltas(patient_ids)
    rng = np.random.default_rng(seed)
    distributions: dict[str, list[float]] = defaultdict(list)
    for _ in range(bootstrap_replicates):
        sampled = list(rng.choice(patient_ids, size=len(patient_ids), replace=True))
        for metric, value in deltas(sampled).items():
            if np.isfinite(value):
                distributions[metric].append(float(value))
    return {
        metric: {
            "point": float(value),
            "ci_low": float(np.percentile(distributions[metric], 2.5)),
            "ci_high": float(np.percentile(distributions[metric], 97.5)),
        }
        for metric, value in point.items()
        if distributions.get(metric)
    }


def risk_coverage_curve(
    method: str, rows: Sequence[dict[str, Any]], scores: Sequence[float], points: int = 101
) -> list[dict[str, float | str]]:
    real = [
        (row, float(score))
        for row, score in zip(rows, scores)
        if not row.get("is_sentinel")
    ]
    if not real:
        return []
    real.sort(key=lambda item: item[1], reverse=True)
    result: list[dict[str, float | str]] = []
    for coverage in np.linspace(0.0, 1.0, points):
        count = max(1, int(round(coverage * len(real))))
        selected = real[:count]
        # An unmatched/invalid candidate is a full-risk event. It is never
        # removed post hoc from risk-coverage.
        risk = float(
            np.mean(
                [1.0 if not row["candidate_valid"] else 1.0 - row["mask_dice"] for row, _ in selected]
            )
        )
        result.append({"method": method, "coverage": count / len(real), "risk": risk})
    return result


def full_cohort_selective_curve(
    method: str,
    rows: Sequence[dict[str, Any]],
    scores: Sequence[float],
    points: int = 101,
    operating_threshold: float | None = None,
    quality_scores: Sequence[float] | None = None,
    quality_threshold: float | None = None,
) -> list[dict[str, Any]]:
    """Image-level selective protocol with every image retained in a denominator.

    ``scores`` are existence probabilities. No existence-positive candidate is
    ``empty``; an existence-positive but quality-insufficient set is ``refer``.
    Referred positives remain conservative failures. Controls without a quality
    head pass ``quality_scores=None`` and therefore have only empty/accept states.
    """
    if (quality_scores is None) != (quality_threshold is None):
        raise ValueError("Quality scores and quality threshold must be supplied together")
    if len(rows) != len(scores) or (quality_scores is not None and len(rows) != len(quality_scores)):
        raise ValueError("Selective component scores must align one-to-one with rows")
    grouped: dict[str, list[tuple[dict[str, Any], float, float | None]]] = defaultdict(list)
    for index, (row, score) in enumerate(zip(rows, scores)):
        quality_score = None if quality_scores is None else float(quality_scores[index])
        grouped[row["image_id"]].append((row, float(score), quality_score))
    thresholds = list(np.linspace(1.0, 0.0, points))
    if operating_threshold is not None and not any(np.isclose(operating_threshold, value) for value in thresholds):
        thresholds.append(float(operating_threshold))
    thresholds = sorted(set(thresholds), reverse=True)
    curve: list[dict[str, Any]] = []
    for threshold in thresholds:
        automatic_images = 0
        referred_images = 0
        referred_positive_images = 0
        referred_normal_images = 0
        empty_images = 0
        accepted_images = 0
        total_lesions = 0
        detected_lesions = 0
        automatic_risks: list[float] = []
        full_cohort_risks: list[float] = []
        zero_candidate_positive_images = 0
        negative_views = 0
        negative_view_actions = 0
        negative_view_fp_images = 0
        for image_rows in grouped.values():
            first = image_rows[0][0]
            lesion_count = int(first["gt_lesion_count"])
            negative_views += int(lesion_count == 0)
            total_lesions += lesion_count
            real = [item for item in image_rows if not item[0].get("is_sentinel")]
            if not real:
                automatic_images += 1
                empty_images += 1
                risk = 1.0 if lesion_count else 0.0
                zero_candidate_positive_images += int(lesion_count > 0)
                automatic_risks.append(risk)
                full_cohort_risks.append(risk)
                continue
            existence_positive = [item for item in real if item[1] >= threshold]
            if not existence_positive:
                automatic_images += 1
                empty_images += 1
                risk = 1.0 if lesion_count else 0.0
                automatic_risks.append(risk)
                full_cohort_risks.append(risk)
                continue
            negative_view_actions += int(lesion_count == 0)
            accepted = (
                existence_positive
                if quality_scores is None
                else [item for item in existence_positive if float(item[2]) >= float(quality_threshold)]
            )
            if not accepted:
                referred_images += 1
                referred_positive_images += int(lesion_count > 0)
                referred_normal_images += int(lesion_count == 0)
                full_cohort_risks.append(1.0 if lesion_count else 0.0)
                continue
            automatic_images += 1
            accepted_images += 1
            if lesion_count == 0:
                negative_view_fp_images += 1
                automatic_risks.append(1.0)
                full_cohort_risks.append(1.0)
                continue
            per_lesion_dice = []
            for lesion_index in range(lesion_count):
                matching = [
                    row
                    for row, _existence, _quality in accepted
                    if row["candidate_valid"] and int(row["matched_lesion"]) == lesion_index
                ]
                if matching:
                    detected_lesions += 1
                    per_lesion_dice.append(max(float(row["mask_dice"]) for row in matching))
                else:
                    per_lesion_dice.append(0.0)
            risk = 1.0 - float(np.mean(per_lesion_dice))
            automatic_risks.append(risk)
            full_cohort_risks.append(risk)
        image_count = len(grouped)
        curve.append(
            {
                "method": method,
                "scope": "full_cohort_image_level",
                "threshold": threshold,
                "coverage": automatic_images / image_count if image_count else float("nan"),
                "referral_rate": referred_images / image_count if image_count else float("nan"),
                "negative_view_action_rate": (
                    negative_view_actions / negative_views
                    if negative_views
                    else float("nan")
                ),
                "raw_negative_view_fp_rate": (
                    negative_view_fp_images / negative_views
                    if negative_views
                    else float("nan")
                ),
                "raw_negative_view_fp_rate_role": "DESCRIPTIVE_ONLY_NOT_A_GO_GATE",
                "negative_view_action_definition": "at_least_one_accepted_mask_or_refer",
                "empty_images": empty_images,
                "accepted_images": accepted_images,
                "referred_positive_images": referred_positive_images,
                "referred_normal_images": referred_normal_images,
                "zero_candidate_positive_images": zero_candidate_positive_images,
                "automatic_risk": float(np.mean(automatic_risks)) if automatic_risks else float("nan"),
                "full_cohort_conservative_risk": float(np.mean(full_cohort_risks)) if full_cohort_risks else float("nan"),
                "conservative_lesion_sensitivity": detected_lesions / total_lesions if total_lesions else float("nan"),
                "total_images": image_count,
                "total_lesions": total_lesions,
                "operating_point": bool(
                    operating_threshold is not None and np.isclose(threshold, operating_threshold)
                ),
                "refer_is_not_normal": True,
                "positive_refer_counted_as_failure": True,
                "existence_threshold": threshold,
                "quality_threshold": quality_threshold,
                "decision_states": "empty_if_no_existence;refer_if_exists_but_quality_low;accept_if_both_pass",
            }
        )
    return curve


def aurc(curve: Sequence[dict[str, Any]]) -> float:
    if not curve:
        return float("nan")
    coverage = np.asarray([row["coverage"] for row in curve], dtype=float)
    risk = np.asarray([row["risk"] for row in curve], dtype=float)
    order = np.argsort(coverage)
    return float(np.trapz(risk[order], coverage[order]))
