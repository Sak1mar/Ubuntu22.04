from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch
from PIL import Image
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset

from .data import BUSDataset, ManifestRecord, connected_instances, detection_collate, instance_boxes, mask_binary
from .models import (
    DeepLabV3PlusHardGate,
    MedSAMAdapter,
    build_faster_rcnn,
    build_mask_rcnn,
    semantic_loss,
)
from .util import Timer, atomic_json, sha256_file, utc_now


def _autocast(enabled: bool):
    return torch.autocast(device_type="cuda", dtype=torch.float16, enabled=enabled)


def _atomic_torch_save(payload: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".{os.getpid()}.partial")
    torch.save(payload, temporary)
    os.replace(temporary, path)


class _MedSAMDecoderDataset(Dataset):
    """MedSAM component prompts with a deterministic inner-only error curriculum."""

    def __init__(
        self,
        records: Sequence[ManifestRecord],
        seed: int,
        *,
        curriculum_fractions: Sequence[float] = (),
        curriculum_epochs: int = 1,
        detector_error_profile: Sequence[dict[str, float]] = (),
    ):
        self.samples: list[tuple[ManifestRecord, np.ndarray, int]] = []
        self.seed = int(seed)
        self.epoch = 0
        self.curriculum_fractions = tuple(float(value) for value in curriculum_fractions)
        self.curriculum_epochs = max(int(curriculum_epochs), 1)
        self.detector_error_profile = [dict(value) for value in detector_error_profile]
        for record in records:
            instances = connected_instances(mask_binary(record.mask_path))
            for index, box in enumerate(instance_boxes(instances)):
                self.samples.append((record, box.astype(np.float32), index))

    def __len__(self) -> int:
        return len(self.samples)

    def set_epoch(self, epoch: int) -> None:
        self.epoch = int(epoch)

    def _prompt_box(self, box: np.ndarray, width: int, height: int, index: int) -> np.ndarray:
        if not self.curriculum_fractions:
            return box.astype(np.float32).copy()
        level_index = min(
            len(self.curriculum_fractions) - 1,
            self.epoch * len(self.curriculum_fractions) // self.curriculum_epochs,
        )
        fraction = self.curriculum_fractions[level_index]
        rng = np.random.default_rng(
            self.seed + self.epoch * max(len(self.samples), 1) + index
        )
        if self.detector_error_profile:
            error = self.detector_error_profile[
                int(rng.integers(0, len(self.detector_error_profile)))
            ]
            center_sign_x = np.sign(float(error.get("center_dx", 0.0))) or rng.choice([-1.0, 1.0])
            center_sign_y = np.sign(float(error.get("center_dy", 0.0))) or rng.choice([-1.0, 1.0])
            scale_sign_x = np.sign(float(error.get("scale_dw", 0.0))) or rng.choice([-1.0, 1.0])
            scale_sign_y = np.sign(float(error.get("scale_dh", 0.0))) or rng.choice([-1.0, 1.0])
        else:
            center_sign_x, center_sign_y, scale_sign_x, scale_sign_y = rng.choice(
                [-1.0, 1.0], size=4
            )
        magnitude = rng.uniform(0.5, 1.0, size=4) * fraction
        box_width = max(float(box[2] - box[0]), 2.0)
        box_height = max(float(box[3] - box[1]), 2.0)
        center_x = float(box[0] + box[2]) / 2.0 + center_sign_x * magnitude[0] * box_width
        center_y = float(box[1] + box[3]) / 2.0 + center_sign_y * magnitude[1] * box_height
        new_width = box_width * max(0.1, 1.0 + scale_sign_x * magnitude[2])
        new_height = box_height * max(0.1, 1.0 + scale_sign_y * magnitude[3])
        perturbed = np.asarray(
            [
                center_x - new_width / 2.0,
                center_y - new_height / 2.0,
                center_x + new_width / 2.0,
                center_y + new_height / 2.0,
            ],
            dtype=np.float32,
        )
        perturbed[[0, 2]] = np.clip(perturbed[[0, 2]], 0, width - 1)
        perturbed[[1, 3]] = np.clip(perturbed[[1, 3]], 0, height - 1)
        perturbed[2] = max(perturbed[2], perturbed[0] + 1)
        perturbed[3] = max(perturbed[3], perturbed[1] + 1)
        return perturbed

    def __getitem__(self, index: int):
        record, box, component_index = self.samples[index]
        image = np.asarray(Image.open(record.image_path).convert("RGB"))
        height, width = image.shape[:2]
        resized = np.asarray(Image.fromarray(image).resize((1024, 1024))).astype(np.float32)
        minimum, maximum = float(resized.min()), float(resized.max())
        resized = (resized - minimum) / max(maximum - minimum, 1e-8)
        image_tensor = torch.from_numpy(resized).permute(2, 0, 1)
        target = connected_instances(mask_binary(record.mask_path))[component_index]
        target_tensor = torch.from_numpy(
            (np.asarray(Image.fromarray(target.astype(np.uint8) * 255).resize((256, 256), Image.Resampling.NEAREST)) > 0).astype(np.float32)
        ).unsqueeze(0)
        jittered = self._prompt_box(box, width, height, index)
        jittered[[0, 2]] = np.clip(jittered[[0, 2]], 0, width - 1)
        jittered[[1, 3]] = np.clip(jittered[[1, 3]], 0, height - 1)
        jittered[2] = max(jittered[2], jittered[0] + 1)
        jittered[3] = max(jittered[3], jittered[1] + 1)
        jittered[[0, 2]] *= 1024.0 / width
        jittered[[1, 3]] *= 1024.0 / height
        return image_tensor, torch.from_numpy(jittered), target_tensor, record.patient_id


@torch.inference_mode()
def _evaluate_medsam_decoder(
    model: nn.Module,
    records: Sequence[ManifestRecord],
    cfg: dict,
    seed: int,
    device: torch.device,
) -> float:
    dataset = _MedSAMDecoderDataset(records, seed)
    if not dataset:
        raise RuntimeError("MEDSAM_INNER_VALIDATION_HAS_NO_POSITIVE_COMPONENTS")
    loader = DataLoader(
        dataset,
        batch_size=cfg["batch_size"]["medsam"],
        shuffle=False,
        num_workers=cfg["num_workers"],
        pin_memory=True,
    )
    model.eval()
    patient_dice: dict[str, list[float]] = {}
    for image, box, target, patient_ids in loader:
        image = image.to(device, non_blocking=True)
        box = box.to(device, non_blocking=True)[:, None]
        target = target.to(device, non_blocking=True)
        embedding = model.image_encoder(image)
        sparse, dense = model.prompt_encoder(points=None, boxes=box, masks=None)
        logits, _predicted_iou = model.mask_decoder(
            image_embeddings=embedding,
            image_pe=model.prompt_encoder.get_dense_pe(),
            sparse_prompt_embeddings=sparse,
            dense_prompt_embeddings=dense,
            multimask_output=False,
        )
        prediction = torch.sigmoid(logits) >= 0.5
        target_binary = target >= 0.5
        intersection = (prediction & target_binary).flatten(1).sum(1).float()
        denominator = prediction.flatten(1).sum(1).float() + target_binary.flatten(1).sum(1).float()
        dice = torch.where(denominator > 0, 2.0 * intersection / denominator, torch.ones_like(denominator))
        for patient_id, value in zip(patient_ids, dice.cpu().tolist()):
            patient_dice.setdefault(str(patient_id), []).append(float(value))
    model.mask_decoder.train()
    return float(np.mean([np.mean(values) for values in patient_dice.values()]))


def train_medsam_decoder(
    records: Sequence[ManifestRecord],
    checkpoint: Path,
    cfg: dict,
    seed: int,
    device: torch.device,
    repository: Path,
    official_checkpoint: Path,
    epochs: int | None = None,
    *,
    validation_records: Sequence[ManifestRecord] | None = None,
    prompt_error_profile: dict | None = None,
    use_prompt_error_curriculum: bool = False,
) -> dict:
    """Train only the official MedSAM mask decoder at 1024 input resolution."""
    training_epochs = int(cfg["epochs"]["medsam_final_refit_cap"] if epochs is None else epochs)
    curriculum = cfg["medsam"]["prompt_error_curriculum"]
    curriculum_fractions = curriculum["fractions"] if use_prompt_error_curriculum else []
    error_rows = list((prompt_error_profile or {}).get("errors", []))
    dataset = _MedSAMDecoderDataset(
        records,
        seed,
        curriculum_fractions=curriculum_fractions,
        curriculum_epochs=training_epochs,
        detector_error_profile=error_rows,
    )
    if not dataset:
        raise RuntimeError("MEDSAM_DECODER_HAS_NO_POSITIVE_TRAINING_COMPONENTS")
    loader = DataLoader(
        dataset,
        batch_size=cfg["batch_size"]["medsam"],
        shuffle=True,
        num_workers=cfg["num_workers"],
        pin_memory=True,
        generator=torch.Generator().manual_seed(seed),
    )
    adapter = MedSAMAdapter(
        repository,
        official_checkpoint,
        cfg["medsam"]["expected_sha256"],
        cfg["medsam"]["expected_commit"],
        device,
    )
    model = adapter.model
    model.mask_decoder.train()
    for parameter in model.mask_decoder.parameters():
        parameter.requires_grad_(True)
    optimizer = torch.optim.AdamW(
        model.mask_decoder.parameters(),
        lr=cfg["learning_rate"]["medsam"],
        weight_decay=cfg["weight_decay"],
    )
    scaler = torch.amp.GradScaler("cuda", enabled=cfg["amp"])
    history: list[dict[str, float]] = []
    best_epoch: int | None = None
    best_validation_metric = float("-inf")
    best_state: dict[str, torch.Tensor] | None = None
    with Timer() as timer:
        for epoch in range(training_epochs):
            dataset.set_epoch(epoch)
            total, examples = 0.0, 0
            for image, box, target, _patient in loader:
                image = image.to(device, non_blocking=True)
                box = box.to(device, non_blocking=True)[:, None]
                target = target.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                with torch.no_grad():
                    embedding = model.image_encoder(image)
                    sparse, dense = model.prompt_encoder(points=None, boxes=box, masks=None)
                with _autocast(cfg["amp"]):
                    logits, _predicted_iou = model.mask_decoder(
                        image_embeddings=embedding,
                        image_pe=model.prompt_encoder.get_dense_pe(),
                        sparse_prompt_embeddings=sparse,
                        dense_prompt_embeddings=dense,
                        multimask_output=False,
                    )
                    bce = F.binary_cross_entropy_with_logits(logits, target)
                    probability = torch.sigmoid(logits)
                    dice = 1.0 - (
                        2.0 * (probability * target).flatten(1).sum(1) + 1.0
                    ) / (
                        probability.flatten(1).sum(1) + target.flatten(1).sum(1) + 1.0
                    )
                    loss = bce + dice.mean()
                if not torch.isfinite(loss):
                    raise RuntimeError("Non-finite MedSAM decoder training loss")
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
                total += float(loss.detach()) * len(image)
                examples += len(image)
            epoch_row: dict[str, float | int] = {"epoch": epoch, "dice_bce": total / examples}
            if validation_records is not None:
                validation_metric = _evaluate_medsam_decoder(
                    model, validation_records, cfg, seed + 100_000, device
                )
                epoch_row["inner_validation_patient_macro_dice"] = validation_metric
                if validation_metric > best_validation_metric:
                    best_validation_metric = validation_metric
                    best_epoch = epoch
                    best_state = {
                        key: value.detach().cpu().clone()
                        for key, value in model.mask_decoder.state_dict().items()
                    }
            history.append(epoch_row)
    if timer.peak_vram_gib >= cfg["runtime"]["max_peak_vram_gib"]:
        raise RuntimeError(
            f"VRAM_LIMIT_EXCEEDED: {timer.peak_vram_gib:.3f} GiB >= {cfg['runtime']['max_peak_vram_gib']} GiB"
        )
    if validation_records is not None and best_state is None:
        raise RuntimeError("MEDSAM_INNER_VALIDATION_CHECKPOINT_SELECTION_FAILED")
    selected_state = best_state if best_state is not None else {
        key: value.detach().cpu() for key, value in model.mask_decoder.state_dict().items()
    }
    payload = {
        "mask_decoder": selected_state,
        "architecture": "MedSAM_official_1024_frozen_image_encoder_trainable_mask_decoder",
        "official_checkpoint_sha256": cfg["medsam"]["expected_sha256"],
        "repository_commit": cfg["medsam"]["expected_commit"],
        "image_encoder_frozen": True,
        "prompt_encoder_frozen": True,
        "input_size": 1024,
        "epochs": training_epochs,
        "best_epoch": best_epoch if best_epoch is not None else training_epochs - 1,
        "best_epoch_count": (best_epoch + 1) if best_epoch is not None else training_epochs,
        "checkpoint_selection_source": (
            "inner_validation_only" if validation_records is not None else "median_inner_best_epoch_final_refit"
        ),
        "best_validation_metric": (
            best_validation_metric if validation_records is not None else None
        ),
        "prompt_error_curriculum": {
            "enabled": bool(use_prompt_error_curriculum),
            "training_scope": "inner_only",
            "fractions": list(curriculum_fractions),
            "perturbations": ["center_shift", "scale"] if use_prompt_error_curriculum else [],
            "error_source": (prompt_error_profile or {}).get("source", "none"),
            "outer_or_test_error_used": False,
            "fixed_seed": seed,
        },
        "training_patient_ids": sorted({record.patient_id for record in records}),
        "history": history,
        "parameter_count": sum(parameter.numel() for parameter in model.mask_decoder.parameters()),
    }
    _atomic_torch_save(payload, checkpoint)
    metadata = {
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": sha256_file(checkpoint),
        "seconds": timer.seconds,
        "peak_vram_gib": timer.peak_vram_gib,
        "history": history,
        "best_epoch": payload["best_epoch"],
        "best_epoch_count": payload["best_epoch_count"],
        "checkpoint_selection_source": payload["checkpoint_selection_source"],
        "best_validation_metric": payload["best_validation_metric"],
        "prompt_error_curriculum": payload["prompt_error_curriculum"],
        "architecture": payload["architecture"],
        "training_patient_ids": payload["training_patient_ids"],
    }
    atomic_json(checkpoint.with_suffix(".json"), metadata)
    return metadata


def train_deeplab(
    records: Sequence[ManifestRecord],
    checkpoint: Path,
    cfg: dict,
    seed: int,
    device: torch.device,
) -> dict:
    dataset = BUSDataset(records, "semantic", cfg["image_size"], augment=True, seed=seed)
    loader = DataLoader(
        dataset,
        batch_size=cfg["batch_size"]["semantic"],
        shuffle=True,
        num_workers=cfg["num_workers"],
        pin_memory=True,
        generator=torch.Generator().manual_seed(seed),
    )
    model = DeepLabV3PlusHardGate(cfg["torchvision_pretrained"]).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=cfg["learning_rate"]["semantic"], weight_decay=cfg["weight_decay"]
    )
    scaler = torch.amp.GradScaler("cuda", enabled=cfg["amp"])
    history: list[dict] = []
    with Timer() as timer:
        for epoch in range(cfg["epochs"]["deeplab"]):
            dataset.set_epoch(epoch)
            model.train()
            sums = {"total": 0.0, "segmentation_bce": 0.0, "segmentation_dice": 0.0, "presence_bce": 0.0}
            examples = 0
            for batch in loader:
                image = batch["image"].to(device, non_blocking=True)
                mask = batch["mask"].to(device, non_blocking=True)
                presence = batch["presence"].to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                with _autocast(cfg["amp"]):
                    losses = semantic_loss(model(image), mask, presence)
                if not torch.isfinite(losses["total"]):
                    raise RuntimeError("Non-finite DeepLabV3+ training loss")
                scaler.scale(losses["total"]).backward()
                scaler.step(optimizer)
                scaler.update()
                batch_size = len(image)
                examples += batch_size
                for key in sums:
                    sums[key] += float(losses[key].detach()) * batch_size
            history.append({"epoch": epoch, **{key: value / examples for key, value in sums.items()}})
    if timer.peak_vram_gib >= cfg["runtime"]["max_peak_vram_gib"]:
        raise RuntimeError(
            f"VRAM_LIMIT_EXCEEDED: {timer.peak_vram_gib:.3f} GiB >= {cfg['runtime']['max_peak_vram_gib']} GiB"
        )
    payload = {
        "model": model.state_dict(),
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "seed": seed,
        "architecture": "DeepLabV3PlusHardGate_ResNet18",
        "history": history,
        "training_patient_ids": sorted({record.patient_id for record in records}),
        "completed_at": utc_now(),
    }
    _atomic_torch_save(payload, checkpoint)
    metadata = {
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": sha256_file(checkpoint),
        "seconds": timer.seconds,
        "peak_vram_gib": timer.peak_vram_gib,
        "history": history,
        "parameter_count": payload["parameter_count"],
    }
    atomic_json(checkpoint.with_suffix(".json"), metadata)
    return metadata


def load_deeplab(checkpoint: Path, cfg: dict, device: torch.device) -> DeepLabV3PlusHardGate:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    model = DeepLabV3PlusHardGate(False)
    model.load_state_dict(payload["model"], strict=True)
    return model.to(device).eval()


@torch.inference_mode()
def _evaluate_detector_inner(
    model: nn.Module,
    records: Sequence[ManifestRecord],
    cfg: dict,
    device: torch.device,
) -> dict[str, float]:
    from .candidates import primary_candidate_matches

    model.eval()
    lesions = 0
    detected = 0
    invalid = 0
    for record in records:
        image_array = np.asarray(Image.open(record.image_path).convert("RGB"))
        image_tensor = (
            torch.from_numpy(image_array.copy()).permute(2, 0, 1).float().div_(255.0).to(device)
        )
        prediction = model([image_tensor])[0]
        scores = prediction["scores"].detach().float().cpu().numpy()
        boxes = prediction["boxes"].detach().float().cpu().numpy()
        keep = np.flatnonzero(scores >= float(cfg["detector_score_floor"]))[
            : int(cfg["detector_top_k"])
        ]
        instances = connected_instances(mask_binary(record.mask_path))
        matches = primary_candidate_matches(boxes[keep], scores[keep], instances)
        lesions += len(instances)
        detected += len({match for match in matches if match >= 0})
        invalid += sum(match < 0 for match in matches)
    model.train()
    return {
        "lesion_recall": detected / lesions if lesions else 0.0,
        "invalid_candidates_per_image": invalid / max(len(records), 1),
        "lesion_events": float(lesions),
    }


def _train_detection_model(
    kind: str,
    records: Sequence[ManifestRecord],
    checkpoint: Path,
    cfg: dict,
    seed: int,
    device: torch.device,
    epochs: int,
    validation_records: Sequence[ManifestRecord] | None = None,
) -> dict:
    dataset = BUSDataset(records, "detection", augment=True, seed=seed)
    loader = DataLoader(
        dataset,
        batch_size=cfg["batch_size"]["detector"],
        shuffle=True,
        num_workers=cfg["num_workers"],
        pin_memory=True,
        collate_fn=detection_collate,
        generator=torch.Generator().manual_seed(seed),
    )
    trainable = 5 - int(cfg.get("freeze_detector_backbone_stages", 2))
    if kind == "faster_rcnn":
        model = build_faster_rcnn(
            cfg["torchvision_pretrained"], cfg["detector_min_size"], cfg["detector_max_size"], trainable
        )
        learning_rate = cfg["learning_rate"]["detector"]
    elif kind == "mask_rcnn":
        model = build_mask_rcnn(
            cfg["torchvision_pretrained"], cfg["detector_min_size"], cfg["detector_max_size"], trainable
        )
        learning_rate = cfg["learning_rate"]["mask_rcnn"]
    else:
        raise ValueError(kind)
    model.to(device).train()
    optimizer = torch.optim.AdamW(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=learning_rate,
        weight_decay=cfg["weight_decay"],
    )
    scaler = torch.amp.GradScaler("cuda", enabled=cfg["amp"])
    history: list[dict] = []
    best_epoch: int | None = None
    best_validation_objective: tuple[float, float] | None = None
    best_validation_metrics: dict[str, float] | None = None
    best_state: dict[str, torch.Tensor] | None = None
    with Timer() as timer:
        for epoch in range(epochs):
            dataset.set_epoch(epoch)
            total_loss, examples = 0.0, 0
            for images, targets, _records in loader:
                images = [image.to(device, non_blocking=True) for image in images]
                targets = [{key: value.to(device) for key, value in target.items()} for target in targets]
                optimizer.zero_grad(set_to_none=True)
                with _autocast(cfg["amp"]):
                    loss_dict = model(images, targets)
                    loss = sum(loss_dict.values())
                if not torch.isfinite(loss):
                    raise RuntimeError(f"Non-finite {kind} training loss")
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
                total_loss += float(loss.detach()) * len(images)
                examples += len(images)
            epoch_row: dict[str, Any] = {"epoch": epoch, "loss": total_loss / max(examples, 1)}
            if validation_records is not None:
                validation = _evaluate_detector_inner(model, validation_records, cfg, device)
                epoch_row.update(
                    inner_validation_lesion_recall=validation["lesion_recall"],
                    inner_validation_invalid_candidates_per_image=validation[
                        "invalid_candidates_per_image"
                    ],
                )
                objective = (
                    validation["lesion_recall"],
                    -validation["invalid_candidates_per_image"],
                )
                if best_validation_objective is None or objective > best_validation_objective:
                    best_validation_objective = objective
                    best_validation_metrics = validation
                    best_epoch = epoch
                    best_state = {
                        key: value.detach().cpu().clone()
                        for key, value in model.state_dict().items()
                    }
            history.append(epoch_row)
    if timer.peak_vram_gib >= cfg["runtime"]["max_peak_vram_gib"]:
        raise RuntimeError(
            f"VRAM_LIMIT_EXCEEDED: {timer.peak_vram_gib:.3f} GiB >= {cfg['runtime']['max_peak_vram_gib']} GiB"
        )
    if validation_records is not None and best_state is None:
        raise RuntimeError("DETECTOR_INNER_VALIDATION_CHECKPOINT_SELECTION_FAILED")
    selected_state = best_state if best_state is not None else {
        key: value.detach().cpu() for key, value in model.state_dict().items()
    }
    payload = {
        "model": selected_state,
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "kind": kind,
        "seed": seed,
        "history": history,
        "epochs": int(epochs),
        "best_epoch": best_epoch if best_epoch is not None else int(epochs) - 1,
        "best_epoch_count": (best_epoch + 1) if best_epoch is not None else int(epochs),
        "checkpoint_selection_source": (
            "inner_validation_only" if validation_records is not None else "median_inner_best_epoch_final_refit"
        ),
        "best_validation_metrics": best_validation_metrics,
        "training_patient_ids": sorted({record.patient_id for record in records}),
        "completed_at": utc_now(),
    }
    _atomic_torch_save(payload, checkpoint)
    metadata = {
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": sha256_file(checkpoint),
        "seconds": timer.seconds,
        "peak_vram_gib": timer.peak_vram_gib,
        "history": history,
        "best_epoch": payload["best_epoch"],
        "best_epoch_count": payload["best_epoch_count"],
        "checkpoint_selection_source": payload["checkpoint_selection_source"],
        "best_validation_metrics": best_validation_metrics,
        "parameter_count": payload["parameter_count"],
    }
    atomic_json(checkpoint.with_suffix(".json"), metadata)
    del model
    torch.cuda.empty_cache()
    return metadata


def train_detector(
    records,
    checkpoint,
    cfg,
    seed,
    device,
    epochs=None,
    *,
    validation_records: Sequence[ManifestRecord] | None = None,
):
    return _train_detection_model(
        "faster_rcnn",
        records,
        checkpoint,
        cfg,
        seed,
        device,
        cfg["epochs"]["detector_final_refit_cap"] if epochs is None else epochs,
        validation_records=validation_records,
    )


def train_mask_rcnn(records, checkpoint, cfg, seed, device):
    return _train_detection_model(
        "mask_rcnn", records, checkpoint, cfg, seed, device, cfg["epochs"]["mask_rcnn"]
    )


def load_detector(checkpoint: Path, cfg: dict, device: torch.device) -> nn.Module:
    model = build_faster_rcnn(False, cfg["detector_min_size"], cfg["detector_max_size"], 5)
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    model.load_state_dict(payload["model"], strict=True)
    return model.to(device).eval()


@torch.inference_mode()
def derive_inner_oof_detector_prompt_errors(
    records: Sequence[ManifestRecord],
    checkpoint: Path,
    cfg: dict,
    device: torch.device,
) -> dict[str, Any]:
    """Estimate prompt-error directions from inner-heldout boxes only."""
    from .candidates import primary_candidate_matches

    model = load_detector(checkpoint, cfg, device)
    errors: list[dict[str, float]] = []
    for record in records:
        image_array = np.asarray(Image.open(record.image_path).convert("RGB"))
        image_tensor = (
            torch.from_numpy(image_array.copy()).permute(2, 0, 1).float().div_(255.0).to(device)
        )
        prediction = model([image_tensor])[0]
        scores = prediction["scores"].detach().float().cpu().numpy()
        boxes = prediction["boxes"].detach().float().cpu().numpy()
        keep = np.flatnonzero(scores >= float(cfg["detector_score_floor"]))[
            : int(cfg["detector_top_k"])
        ]
        instances = connected_instances(mask_binary(record.mask_path))
        ground_truth_boxes = instance_boxes(instances)
        matches = primary_candidate_matches(boxes[keep], scores[keep], instances)
        for predicted_box, matched in zip(boxes[keep], matches):
            if matched < 0:
                continue
            target = ground_truth_boxes[int(matched)]
            target_width = max(float(target[2] - target[0]), 1.0)
            target_height = max(float(target[3] - target[1]), 1.0)
            predicted_width = max(float(predicted_box[2] - predicted_box[0]), 1.0)
            predicted_height = max(float(predicted_box[3] - predicted_box[1]), 1.0)
            errors.append(
                {
                    "center_dx": (
                        float(predicted_box[0] + predicted_box[2])
                        - float(target[0] + target[2])
                    )
                    / (2.0 * target_width),
                    "center_dy": (
                        float(predicted_box[1] + predicted_box[3])
                        - float(target[1] + target[3])
                    )
                    / (2.0 * target_height),
                    "scale_dw": predicted_width / target_width - 1.0,
                    "scale_dh": predicted_height / target_height - 1.0,
                }
            )
    del model
    torch.cuda.empty_cache()
    return {
        "source": "inner_oof_detector_boxes" if errors else "fixed_seed_uniform_fallback",
        "errors": errors,
        "matched_box_count": len(errors),
        "outer_or_test_error_used": False,
        "detector_checkpoint_sha256": sha256_file(checkpoint),
    }


def load_mask_rcnn(checkpoint: Path, cfg: dict, device: torch.device) -> nn.Module:
    model = build_mask_rcnn(False, cfg["detector_min_size"], cfg["detector_max_size"], 5)
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    model.load_state_dict(payload["model"], strict=True)
    return model.to(device).eval()
