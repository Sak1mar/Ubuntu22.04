from __future__ import annotations

import json
import os
import shutil
import contextlib
import sys
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch
import yaml
from PIL import Image
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset
from torchvision.transforms import functional as TF

from .baselines import _base_row, _save_rows, _sentinel
from .candidates import (
    FEATURE_NAMES,
    _candidate_features,
    _label_candidate,
    primary_candidate_matches,
    sensitivity_candidate_matches,
)
from .data import ManifestRecord, connected_instances, instance_boxes, mask_binary
from .util import Timer, atomic_json, sha256_file, sha256_tree, utc_now


AUTOBUSAM_METHOD = "AutoBUSAM_adapted_YOLOv8s_SAMLoRA"


class _LoRAProjection(nn.Module):
    def __init__(self, base: nn.Linear, rank: int, alpha: int):
        super().__init__()
        self.base = base
        for parameter in self.base.parameters():
            parameter.requires_grad_(False)
        self.a = nn.Linear(base.in_features, rank, bias=False)
        self.b = nn.Linear(rank, base.out_features, bias=False)
        self.scale = float(alpha) / float(rank)
        nn.init.kaiming_uniform_(self.a.weight, a=np.sqrt(5.0))
        nn.init.zeros_(self.b.weight)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.base(inputs) + self.b(self.a(inputs)) * self.scale


class AutoBUSAMSamAdapter:
    """Auto-BUSAM mask-decoder LoRA over the frozen public SAM ViT-B."""

    ARCHITECTURE = "AutoBUSAM_adapted_SAM_ViT_B_mask_decoder_attention_LoRA"

    def __init__(
        self,
        repository: Path,
        sam_checkpoint: Path,
        expected_sha256_prefix: str,
        rank: int,
        alpha: int,
        device: torch.device,
        adapter_checkpoint: Path | None = None,
    ):
        if not sha256_file(sam_checkpoint).startswith(expected_sha256_prefix):
            raise RuntimeError("AUTOBUSAM_SAM_CHECKPOINT_HASH_PREFIX_DRIFT")
        sys.path.insert(0, str(repository))
        try:
            from segment_anything import sam_model_registry
        finally:
            with contextlib.suppress(ValueError):
                sys.path.remove(str(repository))
        self.model = sam_model_registry["vit_b"](checkpoint=str(sam_checkpoint)).to(device)
        self.device = device
        self.rank = int(rank)
        self.alpha = int(alpha)
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        replaced = 0
        for module in self.model.mask_decoder.transformer.modules():
            for attribute in ("q_proj", "v_proj"):
                projection = getattr(module, attribute, None)
                if isinstance(projection, nn.Linear):
                    setattr(module, attribute, _LoRAProjection(projection, self.rank, self.alpha))
                    replaced += 1
        if replaced == 0:
            raise RuntimeError("AUTOBUSAM_LORA_INJECTION_FOUND_NO_DECODER_PROJECTIONS")
        for module in (
            self.model.mask_decoder.output_upscaling,
            self.model.mask_decoder.output_hypernetworks_mlps,
            self.model.mask_decoder.iou_prediction_head,
        ):
            for parameter in module.parameters():
                parameter.requires_grad_(True)
        self.model.prompt_encoder.no_mask_embed.weight.requires_grad_(True)
        self.adapter_checkpoint_sha256: str | None = None
        if adapter_checkpoint is not None:
            payload = torch.load(adapter_checkpoint, map_location="cpu", weights_only=False)
            if payload.get("architecture") != self.ARCHITECTURE:
                raise RuntimeError("AUTOBUSAM_SAM_LORA_ARCHITECTURE_DRIFT")
            self.model.mask_decoder.load_state_dict(payload["mask_decoder"], strict=True)
            self.model.prompt_encoder.no_mask_embed.load_state_dict(
                payload["no_mask_embed"], strict=True
            )
            self.adapter_checkpoint_sha256 = sha256_file(adapter_checkpoint)

    def trainable_parameters(self):
        return [parameter for parameter in self.model.parameters() if parameter.requires_grad]

    def forward(self, images_256: torch.Tensor, boxes_normalized: torch.Tensor) -> torch.Tensor:
        images_1024 = F.interpolate(
            images_256, size=(1024, 1024), mode="bilinear", align_corners=False
        )
        images_1024 = self.model.preprocess(images_1024 * 255.0)
        boxes = boxes_normalized[:, None] * 1024.0
        with torch.no_grad():
            embeddings = self.model.image_encoder(images_1024)
        sparse, dense = self.model.prompt_encoder(points=None, boxes=boxes, masks=None)
        logits, _iou = self.model.mask_decoder(
            image_embeddings=embeddings,
            image_pe=self.model.prompt_encoder.get_dense_pe(),
            sparse_prompt_embeddings=sparse,
            dense_prompt_embeddings=dense,
            multimask_output=False,
        )
        return logits

    @torch.inference_mode()
    def segment(
        self, image_rgb: np.ndarray, boxes_xyxy: np.ndarray
    ) -> tuple[list[np.ndarray], list[float]]:
        height, width = image_rgb.shape[:2]
        image = TF.to_tensor(Image.fromarray(image_rgb).resize((256, 256))).unsqueeze(0).to(
            self.device
        )
        masks: list[np.ndarray] = []
        scores: list[float] = []
        self.model.eval()
        for raw_box in boxes_xyxy:
            normalized = torch.tensor(
                [
                    raw_box[0] / width,
                    raw_box[1] / height,
                    raw_box[2] / width,
                    raw_box[3] / height,
                ],
                dtype=torch.float32,
                device=self.device,
            )[None]
            logits = self.forward(image, normalized)
            probability = F.interpolate(
                torch.sigmoid(logits), size=(height, width), mode="bilinear", align_corners=False
            )
            masks.append((probability[0, 0] > 0.5).cpu().numpy().astype(np.uint8))
            scores.append(float(probability.mean().cpu()))
        return masks, scores


class _AutoBUSAMLoRADataset(Dataset):
    def __init__(self, samples: list[tuple[Path, np.ndarray, np.ndarray]]):
        self.samples = samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int):
        image_path, box_normalized, target = self.samples[index]
        image = TF.to_tensor(Image.open(image_path).convert("RGB").resize((256, 256)))
        target_256 = np.asarray(
            Image.fromarray(target.astype(np.uint8) * 255).resize(
                (256, 256), Image.Resampling.NEAREST
            )
        )
        return (
            image,
            torch.from_numpy(box_normalized.astype(np.float32)),
            torch.from_numpy((target_256 > 0).astype(np.float32))[None],
        )


def _atomic_copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + f".{os.getpid()}.partial")
    shutil.copy2(source, temporary)
    os.replace(temporary, target)


def _prepare_yolo_dataset(
    records: Sequence[ManifestRecord], output_dir: Path
) -> tuple[Path, list[Path]]:
    """Create an outer-train-only YOLO view without modifying frozen pixels."""
    images = output_dir / "images" / "train"
    labels = output_dir / "labels" / "train"
    if output_dir.exists():
        shutil.rmtree(output_dir)
    images.mkdir(parents=True)
    labels.mkdir(parents=True)
    written: list[Path] = []
    for record in records:
        image_link = images / f"{record.image_id}.png"
        image_link.symlink_to(record.image_path.resolve())
        rows: list[str] = []
        for box in instance_boxes(connected_instances(mask_binary(record.mask_path))):
            x1, y1, x2, y2 = [float(value) for value in box]
            center_x = (x1 + x2) / (2.0 * record.width)
            center_y = (y1 + y2) / (2.0 * record.height)
            width = (x2 - x1) / record.width
            height = (y2 - y1) / record.height
            rows.append(f"0 {center_x:.10f} {center_y:.10f} {width:.10f} {height:.10f}")
        label = labels / f"{record.image_id}.txt"
        label.write_text("\n".join(rows) + ("\n" if rows else ""), encoding="utf-8")
        written.append(label)
    config = {
        "path": str(output_dir.resolve()),
        "train": "images/train",
        # Ultralytics requires a val key even when val=False. No validation
        # checkpoint selection is performed; the fixed final epoch is used.
        "val": "images/train",
        "nc": 1,
        "names": {0: "lesion"},
    }
    yaml_path = output_dir / "dataset.yaml"
    yaml_path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    written.append(yaml_path)
    return yaml_path, written


def _build_lora_samples(
    records: Sequence[ManifestRecord], yolo, cfg: dict[str, Any]
) -> list[tuple[Path, np.ndarray, np.ndarray]]:
    samples: list[tuple[Path, np.ndarray, np.ndarray]] = []
    for record in records:
        image_rgb = np.asarray(Image.open(record.image_path).convert("RGB"))
        result = yolo.predict(
            source=image_rgb,
            imgsz=int(cfg["autobusam"]["image_size"]),
            conf=float(cfg["autobusam"]["confidence"]),
            iou=float(cfg["autobusam"]["nms_iou"]),
            max_det=int(cfg["detector_top_k"]),
            verbose=False,
        )[0]
        boxes = result.boxes.xyxy.detach().float().cpu().numpy()
        scores = result.boxes.conf.detach().float().cpu().numpy()
        components = connected_instances(mask_binary(record.mask_path))
        matches = primary_candidate_matches(boxes, scores, components)
        for box, match in zip(boxes, matches):
            normalized = np.asarray(
                [
                    box[0] / record.width,
                    box[1] / record.height,
                    box[2] / record.width,
                    box[3] / record.height,
                ],
                dtype=np.float32,
            )
            target = (
                components[match]
                if match >= 0
                else np.zeros((record.height, record.width), dtype=np.uint8)
            )
            samples.append((record.image_path, normalized, target))
    return samples


def train_autobusam_adapted(
    records: Sequence[ManifestRecord],
    yolo_checkpoint: Path,
    sam_lora_checkpoint: Path,
    cfg: dict[str, Any],
    seed: int,
    device: torch.device,
    pretrained_checkpoint: Path,
    sam_checkpoint: Path,
    sam_repository: Path,
    work_dir: Path,
) -> dict[str, Any]:
    """Train the adapted official YOLOv8s-to-SAM-LoRA topology on outer train."""
    from ultralytics import YOLO

    if sha256_file(pretrained_checkpoint) != cfg["autobusam"]["pretrained_weight_sha256"]:
        raise RuntimeError("AUTOBUSAM_YOLOV8S_PRETRAINED_WEIGHT_DRIFT")
    if device.type != "cuda" or device.index is None:
        raise RuntimeError("Auto-BUSAM formal training requires an assigned CUDA device")
    dataset_yaml, written = _prepare_yolo_dataset(records, work_dir / "dataset")
    model = YOLO(str(pretrained_checkpoint))
    with Timer() as timer:
        model.train(
            data=str(dataset_yaml),
            epochs=int(cfg["epochs"]["autobusam_yolo"]),
            imgsz=int(cfg["autobusam"]["image_size"]),
            batch=int(cfg["autobusam"]["batch_size"]),
            device=int(device.index),
            workers=int(cfg["num_workers"]),
            project=str((work_dir / "ultralytics_runs").resolve()),
            name="outer_train_fixed_recipe",
            exist_ok=True,
            pretrained=True,
            optimizer="SGD",
            lr0=0.002,
            weight_decay=0.0005,
            warmup_epochs=3,
            patience=0,
            val=False,
            augment=False,
            multi_scale=True,
            amp=bool(cfg["amp"]),
            deterministic=bool(cfg["deterministic"]),
            seed=int(seed),
            plots=False,
            save=True,
            save_period=-1,
            verbose=False,
        )
    trained = Path(model.trainer.save_dir) / "weights" / "last.pt"
    if not trained.is_file():
        raise RuntimeError("AUTOBUSAM_YOLO_TRAINING_DID_NOT_PRODUCE_LAST_CHECKPOINT")
    _atomic_copy(trained, yolo_checkpoint)
    yolo = YOLO(str(yolo_checkpoint))
    samples = _build_lora_samples(records, yolo, cfg)
    if not samples:
        raise RuntimeError("AUTOBUSAM_YOLO_PRODUCED_NO_OUTER_TRAIN_PROMPTS")
    dataset = _AutoBUSAMLoRADataset(samples)
    loader = DataLoader(
        dataset,
        batch_size=max(1, int(cfg["batch_size"]["medsam"])),
        shuffle=True,
        num_workers=int(cfg["num_workers"]),
        pin_memory=True,
        generator=torch.Generator().manual_seed(seed + 1),
    )
    adapter = AutoBUSAMSamAdapter(
        sam_repository,
        sam_checkpoint,
        str(cfg["autobusam"]["sam_checkpoint_sha256_prefix"]),
        int(cfg["autobusam"]["lora_rank"]),
        int(cfg["autobusam"]["lora_alpha"]),
        device,
    )
    adapter.model.train()
    optimizer = torch.optim.SGD(
        adapter.trainable_parameters(), lr=0.004, momentum=0.9, weight_decay=0.0
    )
    scaler = torch.amp.GradScaler("cuda", enabled=bool(cfg["amp"]))
    lora_history: list[dict[str, float]] = []
    with Timer() as lora_timer:
        for epoch in range(int(cfg["epochs"]["autobusam_sam_lora"])):
            total = 0.0
            examples = 0
            for images, boxes, targets in loader:
                images = images.to(device, non_blocking=True)
                boxes = boxes.to(device, non_blocking=True)
                targets = targets.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast(
                    "cuda", torch.float16, enabled=bool(cfg["amp"])
                ):
                    logits = adapter.forward(images, boxes)
                    bce = F.binary_cross_entropy_with_logits(logits, targets)
                    probability = torch.sigmoid(logits)
                    dice = 1.0 - (
                        2.0 * (probability * targets).flatten(1).sum(1) + 1.0
                    ) / (
                        probability.flatten(1).sum(1)
                        + targets.flatten(1).sum(1)
                        + 1.0
                    )
                    loss = 0.7 * bce + 0.3 * dice.mean()
                if not torch.isfinite(loss):
                    raise RuntimeError("AUTOBUSAM_SAM_LORA_NONFINITE_LOSS")
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
                total += float(loss.detach()) * len(images)
                examples += len(images)
            lora_history.append({"epoch": epoch, "combined_loss": total / examples})
    sam_lora_payload = {
        "schema_version": 1,
        "architecture": AutoBUSAMSamAdapter.ARCHITECTURE,
        "mask_decoder": adapter.model.mask_decoder.state_dict(),
        "no_mask_embed": adapter.model.prompt_encoder.no_mask_embed.state_dict(),
        "training_patient_ids": sorted({record.patient_id for record in records}),
        "rank": int(cfg["autobusam"]["lora_rank"]),
        "alpha": int(cfg["autobusam"]["lora_alpha"]),
        "epochs": int(cfg["epochs"]["autobusam_sam_lora"]),
        "training_prompt_count": len(samples),
        "history": lora_history,
        "sam_checkpoint_sha256": sha256_file(sam_checkpoint),
        "official_source_commit": cfg["autobusam"]["official_source_commit"],
    }
    if max(timer.peak_vram_gib, lora_timer.peak_vram_gib) >= float(
        cfg["runtime"]["max_peak_vram_gib"]
    ):
        raise RuntimeError("AUTOBUSAM_VRAM_LIMIT_EXCEEDED")
    temporary_lora = sam_lora_checkpoint.with_suffix(
        sam_lora_checkpoint.suffix + f".{os.getpid()}.partial"
    )
    sam_lora_checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.save(sam_lora_payload, temporary_lora)
    os.replace(temporary_lora, sam_lora_checkpoint)
    payload = {
        "schema_version": 1,
        "architecture": "AutoBUSAM_adapted_YOLOv8s_prompt_generator",
        "official_source_repository": cfg["autobusam"]["official_source_repository"],
        "official_source_commit": cfg["autobusam"]["official_source_commit"],
        "adaptation_label": cfg["autobusam"]["adaptation_label"],
        "training_patient_ids": sorted({record.patient_id for record in records}),
        "training_image_ids": sorted(record.image_id for record in records),
        "outer_test_pixels_read": False,
        "checkpoint": str(yolo_checkpoint.resolve()),
        "checkpoint_sha256": sha256_file(yolo_checkpoint),
        "sam_lora_checkpoint": str(sam_lora_checkpoint.resolve()),
        "sam_lora_checkpoint_sha256": sha256_file(sam_lora_checkpoint),
        "pretrained_checkpoint_sha256": sha256_file(pretrained_checkpoint),
        "dataset_definition_sha256": sha256_tree(written),
        "epochs": int(cfg["epochs"]["autobusam_yolo"]),
        "fixed_official_operating_point": {
            "confidence": float(cfg["autobusam"]["confidence"]),
            "nms_iou": float(cfg["autobusam"]["nms_iou"]),
        },
        "seconds": timer.seconds,
        "peak_vram_gib": timer.peak_vram_gib,
        "sam_lora_seconds": lora_timer.seconds,
        "sam_lora_peak_vram_gib": lora_timer.peak_vram_gib,
        "sam_lora_history": lora_history,
        "created_at": utc_now(),
    }
    atomic_json(yolo_checkpoint.with_suffix(".provenance.json"), payload)
    atomic_json(yolo_checkpoint.with_suffix(".json"), payload)
    atomic_json(sam_lora_checkpoint.with_suffix(".json"), {
        **payload,
        "checkpoint": str(sam_lora_checkpoint.resolve()),
        "checkpoint_sha256": sha256_file(sam_lora_checkpoint),
    })
    return payload


def validate_autobusam_checkpoint(
    checkpoint: Path,
    sam_lora_checkpoint: Path,
    expected_training_patients: set[str],
    heldout_patients: set[str],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    provenance_path = checkpoint.with_suffix(".provenance.json")
    try:
        payload = json.loads(provenance_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"AUTOBUSAM_PROVENANCE_UNREADABLE: {exc}") from exc
    training = {str(value) for value in payload.get("training_patient_ids", [])}
    if training != {str(value) for value in expected_training_patients}:
        raise RuntimeError("AUTOBUSAM_YOLO_TRAINING_PATIENT_SET_MISMATCH")
    if training & {str(value) for value in heldout_patients}:
        raise RuntimeError("PATIENT_LEAKAGE: Auto-BUSAM YOLO includes held-out patient")
    if payload.get("checkpoint_sha256") != sha256_file(checkpoint):
        raise RuntimeError("AUTOBUSAM_YOLO_CHECKPOINT_HASH_DRIFT")
    if payload.get("sam_lora_checkpoint_sha256") != sha256_file(sam_lora_checkpoint):
        raise RuntimeError("AUTOBUSAM_SAM_LORA_CHECKPOINT_HASH_DRIFT")
    if payload.get("official_source_commit") != cfg["autobusam"]["official_source_commit"]:
        raise RuntimeError("AUTOBUSAM_SOURCE_COMMIT_DRIFT")
    return payload


def load_autobusam_yolo(checkpoint: Path):
    from ultralytics import YOLO

    return YOLO(str(checkpoint))


def load_autobusam_sam_adapter(
    cfg: dict[str, Any],
    repository: Path,
    sam_checkpoint: Path,
    adapter_checkpoint: Path,
    device: torch.device,
) -> AutoBUSAMSamAdapter:
    return AutoBUSAMSamAdapter(
        repository,
        sam_checkpoint,
        str(cfg["autobusam"]["sam_checkpoint_sha256_prefix"]),
        int(cfg["autobusam"]["lora_rank"]),
        int(cfg["autobusam"]["lora_alpha"]),
        device,
        adapter_checkpoint,
    )


@torch.inference_mode()
def infer_autobusam_adapted(
    yolo,
    sam_adapter: AutoBUSAMSamAdapter,
    records: Sequence[ManifestRecord],
    output_dir: Path,
    cfg: dict[str, Any],
    yolo_checkpoint_sha256: str,
) -> Path:
    """Adapt official YOLO-to-SAM topology to zero/multi-box BUS-UCLM views."""
    rows: list[dict[str, Any]] = []
    mask_dir = output_dir / "masks"
    mask_dir.mkdir(parents=True, exist_ok=True)
    for record in records:
        image_rgb = np.asarray(Image.open(record.image_path).convert("RGB"))
        results = yolo.predict(
            source=image_rgb,
            imgsz=int(cfg["autobusam"]["image_size"]),
            conf=float(cfg["autobusam"]["confidence"]),
            iou=float(cfg["autobusam"]["nms_iou"]),
            max_det=int(cfg["detector_top_k"]),
            verbose=False,
        )
        result = results[0]
        boxes = result.boxes.xyxy.detach().float().cpu().numpy()
        scores = result.boxes.conf.detach().float().cpu().numpy()
        gt = connected_instances(mask_binary(record.mask_path))
        arrays: dict[str, np.ndarray] = {}
        image_rows: list[dict[str, Any]] = []
        if len(boxes):
            masks, ious = sam_adapter.segment(image_rgb, boxes)
            primary = primary_candidate_matches(boxes, scores, gt)
            sensitivity = sensitivity_candidate_matches(
                boxes, scores, gt, cfg["matching"]["sensitivity_box_iou_threshold"]
            )
            for index, (mask, box, score, sam_iou) in enumerate(
                zip(masks, boxes, scores, ious)
            ):
                key = f"mask_{index}"
                arrays[key] = mask.astype(np.uint8)
                labels = _label_candidate(mask, gt, primary[index], sensitivity[index])
                feature_map = _candidate_features(
                    mask,
                    box,
                    float(score),
                    float(sam_iou),
                    [],
                    detector_rank=index,
                )
                image_rows.append(
                    {
                        **_base_row(record, len(gt), "predicted_box"),
                        "candidate_index": index,
                        "is_sentinel": 0,
                        "box_xyxy": [float(value) for value in box],
                        "features": [feature_map[name] for name in FEATURE_NAMES],
                        "feature_map": feature_map,
                        **labels,
                        "failure": int(
                            labels["candidate_valid"] == 0
                            or float(labels["mask_dice"]) < cfg["failure_dice_threshold"]
                        ),
                        "mask_key": key,
                    }
                )
        mask_path = mask_dir / f"{record.image_id}.npz"
        np.savez_compressed(mask_path, **arrays)
        if not image_rows:
            image_rows = [_sentinel(record, len(gt), "predicted_box")]
        for row in image_rows:
            row["mask_file"] = str(mask_path.resolve())
            row["mask_file_sha256"] = sha256_file(mask_path)
            row["upstream_checkpoint_sha256"] = yolo_checkpoint_sha256
            row["autobusam_sam_lora_checkpoint_sha256"] = (
                sam_adapter.adapter_checkpoint_sha256
            )
            rows.append(row)
    return _save_rows(
        output_dir,
        rows,
        {
            "created_at": utc_now(),
            "method": AUTOBUSAM_METHOD,
            "official_reproduction": False,
            "official_source_commit": cfg["autobusam"]["official_source_commit"],
            "adaptation": "official_YOLOv8_to_SAM_LoRA_topology_with_zero_and_multi_box_support",
            "outer_test_used_for_training_or_selection": False,
        },
    )
