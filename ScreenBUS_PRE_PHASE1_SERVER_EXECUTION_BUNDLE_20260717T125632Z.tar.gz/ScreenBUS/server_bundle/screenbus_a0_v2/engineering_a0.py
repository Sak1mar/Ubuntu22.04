"""Target-server, non-performance ENGINEERING_A0 checks for ScreenBUS v2.3."""

from __future__ import annotations

import hashlib
import os
import tarfile
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch

from .candidates import FEATURE_NAMES
from .config import load_config, resolve_environment
from .metrics import dual_threshold_states
from .models import (
    DeepLabV3PlusHardGate,
    MedSAMAdapter,
    build_faster_rcnn,
    build_mask_rcnn,
    semantic_loss,
)
from .protocol_v2_3 import ENGINEERING_A0_CHECKS
from .refine_verify import score_methods, train_verifier_and_controls
from .scheduler import ResourceAwareScheduler
from .util import atomic_json, sha256_file, utc_now


def reproject_box_to_original(
    box_xyxy: Sequence[float], resized_hw: tuple[int, int], original_hw: tuple[int, int]
) -> list[float]:
    resized_h, resized_w = resized_hw
    original_h, original_w = original_hw
    if min(resized_h, resized_w, original_h, original_w) <= 0:
        raise ValueError("BOX_REPROJECTION_INVALID_SHAPE")
    x1, y1, x2, y2 = (float(value) for value in box_xyxy)
    sx, sy = original_w / resized_w, original_h / resized_h
    projected = [x1 * sx, y1 * sy, x2 * sx, y2 * sy]
    projected[0] = min(max(projected[0], 0.0), float(original_w))
    projected[2] = min(max(projected[2], 0.0), float(original_w))
    projected[1] = min(max(projected[1], 0.0), float(original_h))
    projected[3] = min(max(projected[3], 0.0), float(original_h))
    if projected[2] < projected[0] or projected[3] < projected[1]:
        raise ValueError("BOX_REPROJECTION_INVALID_ORDER")
    return projected


def build_synthetic_verifier_rows(patient_count: int = 16) -> list[dict[str, Any]]:
    """Dedicated A0 fixture: no dataset pixels and no outer-test evidence."""

    rows: list[dict[str, Any]] = []
    for patient_index in range(patient_count):
        patient = f"A0_SYNTH_{patient_index:02d}"
        for candidate_index, (valid, dice) in enumerate(((1, 0.90), (1, 0.50), (0, 0.0))):
            base = 0.15 + 0.03 * patient_index + 0.07 * candidate_index
            feature_map = {
                name: float(np.clip(base + 0.01 * feature_index, 0.01, 0.99))
                for feature_index, name in enumerate(FEATURE_NAMES)
            }
            feature_map.update(
                detector_score=float(np.clip(0.85 - 0.25 * candidate_index + 0.002 * patient_index, 0.01, 0.99)),
                sam_predicted_iou=float(np.clip(dice + 0.02, 0.01, 0.99)),
                jitter_iou_mean=float(np.clip(dice + 0.01, 0.01, 0.99)),
                jitter_iou_variance_inverse=float(np.clip(0.2 + dice * 0.7, 0.01, 0.99)),
                jitter_iou_worst=float(np.clip(dice - 0.05, 0.01, 0.99)),
                area_ratio=0.03 + 0.001 * candidate_index,
                component_count_log=float(np.log1p(candidate_index + 1)),
                compactness=0.7,
                box_mask_coverage=0.8 if valid else 0.2,
                box_area_ratio=0.05,
                box_aspect_log=0.0,
                border_touch=float(candidate_index == 2),
                detector_rank_inverse=1.0 / (candidate_index + 1),
                image_presence_probability=0.8 if valid else 0.3,
            )
            rows.append(
                {
                    "image_id": f"{patient}_I{candidate_index}",
                    "patient_id": patient,
                    "condition": "predicted_box",
                    "candidate_index": candidate_index,
                    "is_sentinel": 0,
                    "is_positive_image": int(valid),
                    "candidate_valid": valid,
                    "matched_lesion": 0 if valid else -1,
                    "mask_dice": dice,
                    "failure": int(not valid or dice < 0.75),
                    "gt_lesion_count": int(valid),
                    "feature_map": feature_map,
                    "features": [feature_map[name] for name in FEATURE_NAMES],
                    "training_patient_ids": [],
                    "split_role": "engineering_synthetic_fixture",
                }
            )
    return rows


def validate_real_candidate_schema(row: dict[str, Any]) -> None:
    required = {
        "image_id",
        "patient_id",
        "condition",
        "candidate_index",
        "is_sentinel",
        "candidate_valid",
        "matched_lesion",
        "mask_dice",
        "failure",
        "gt_lesion_count",
        "feature_map",
        "features",
    }
    if not required <= set(row) or set(row["feature_map"]) < set(FEATURE_NAMES):
        raise RuntimeError("ENGINEERING_REAL_CANDIDATE_SCHEMA_INVALID")
    if len(row["features"]) != len(FEATURE_NAMES):
        raise RuntimeError("ENGINEERING_REAL_CANDIDATE_FEATURE_VECTOR_INVALID")


def _state_equal(first: Any, second: Any) -> bool:
    if isinstance(first, torch.Tensor) and isinstance(second, torch.Tensor):
        return bool(torch.equal(first.cpu(), second.cpu()))
    if isinstance(first, dict) and isinstance(second, dict):
        return set(first) == set(second) and all(
            _state_equal(first[key], second[key]) for key in first
        )
    if isinstance(first, (list, tuple)) and isinstance(second, (list, tuple)):
        return len(first) == len(second) and all(
            _state_equal(left, right) for left, right in zip(first, second)
        )
    return first == second


def _backward_detection(model: torch.nn.Module, *, with_masks: bool, device: torch.device) -> None:
    model.train()
    image = torch.rand(3, 64, 64, device=device)
    target: dict[str, torch.Tensor] = {
        "boxes": torch.tensor([[8.0, 8.0, 48.0, 48.0]], device=device),
        "labels": torch.tensor([1], dtype=torch.int64, device=device),
    }
    if with_masks:
        mask = torch.zeros((1, 64, 64), dtype=torch.uint8, device=device)
        mask[:, 8:48, 8:48] = 1
        target["masks"] = mask
    optimizer = torch.optim.SGD(model.parameters(), lr=1e-4)
    optimizer.zero_grad(set_to_none=True)
    loss = sum(model([image], [target]).values())
    if not torch.isfinite(loss):
        raise RuntimeError("ENGINEERING_DETECTION_LOSS_NONFINITE")
    loss.backward()
    optimizer.step()


def run_engineering_a0(config_path: Path) -> dict[str, Any]:
    cfg = load_config(config_path)
    if cfg["mode"] != "engineering_a0":
        raise RuntimeError("ENGINEERING_A0_REQUIRES_ENGINEERING_CONFIG")
    if os.environ.get("SCREENBUS_ACTIVE_STAGE") != "ENGINEERING_A0":
        raise RuntimeError("ENGINEERING_A0_FORBIDDEN_OUTSIDE_ORCHESTRATOR_STAGE")
    env = resolve_environment()
    if not torch.cuda.is_available():
        raise RuntimeError("ENGINEERING_A0_REQUIRES_TARGET_CUDA_SERVER")
    output = env["SCREENBUS_OUTPUT_ROOT"] / "engineering_a0"
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda")
    torch.cuda.reset_peak_memory_stats(device)

    phase1_config_path = env["SCREENBUS_ROOT"] / "server_bundle" / "screenbus_a0_v2" / "configs" / "server_a0.yaml"
    phase1_cfg = load_config(phase1_config_path)
    from .pipeline import build_phase1_split

    splits = [build_phase1_split(phase1_config_path, fold) for fold in range(5)]
    evaluated_patients = [patient for split in splits for patient in split["evaluation_patient_ids"]]
    if len(evaluated_patients) != len(set(evaluated_patients)) or any(
        set(split["train_patient_ids"]) & set(split["evaluation_patient_ids"])
        for split in splits
    ):
        raise RuntimeError("ENGINEERING_PATIENT_FOLD_OVERLAP")

    b1 = DeepLabV3PlusHardGate(False).to(device).train()
    optimizer = torch.optim.AdamW(b1.parameters(), lr=1e-4)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.9)
    image = torch.rand(2, 3, 64, 64, device=device)
    mask = (torch.rand(2, 1, 64, 64, device=device) > 0.5).float()
    presence = torch.tensor([1.0, 0.0], device=device)
    optimizer.zero_grad(set_to_none=True)
    semantic_loss(b1(image), mask, presence)["total"].backward()
    optimizer.step()
    scheduler.step()

    scaler = torch.amp.GradScaler("cuda")
    optimizer.zero_grad(set_to_none=True)
    with torch.autocast("cuda", torch.float16):
        amp_loss = semantic_loss(b1(image), mask, presence)["total"]
    scaler.scale(amp_loss).backward()
    scaler.step(optimizer)
    scaler.update()

    detector = build_faster_rcnn(False, 64, 64).to(device)
    _backward_detection(detector, with_masks=False, device=device)
    del detector
    mask_rcnn = build_mask_rcnn(False, 64, 64).to(device)
    _backward_detection(mask_rcnn, with_masks=True, device=device)
    del mask_rcnn

    medsam = MedSAMAdapter(
        env["SCREENBUS_CACHE_ROOT"] / phase1_cfg["medsam"]["repository_under_cache"],
        env["MEDSAM_CKPT"],
        phase1_cfg["medsam"]["expected_sha256"],
        phase1_cfg["medsam"]["expected_commit"],
        device,
    )
    for parameter in medsam.model.mask_decoder.parameters():
        parameter.requires_grad_(True)
    decoder_optimizer = torch.optim.AdamW(medsam.model.mask_decoder.parameters(), lr=1e-5)
    embedding = torch.randn(1, 256, 64, 64, device=device)
    box = torch.tensor([[[64.0, 64.0, 512.0, 512.0]]], device=device)
    sparse, dense = medsam.model.prompt_encoder(points=None, boxes=box, masks=None)
    low_resolution, predicted_iou = medsam.model.mask_decoder(
        image_embeddings=embedding,
        image_pe=medsam.model.prompt_encoder.get_dense_pe(),
        sparse_prompt_embeddings=sparse,
        dense_prompt_embeddings=dense,
        multimask_output=False,
    )
    decoder_loss = low_resolution.square().mean() + predicted_iou.square().mean()
    decoder_loss.backward()
    decoder_optimizer.step()

    synthetic_rows = build_synthetic_verifier_rows()
    for row in synthetic_rows:
        validate_real_candidate_schema(row)
    verifier_dir = output / "verifier_synthetic_fixture"
    verifier_metadata = train_verifier_and_controls(
        synthetic_rows, verifier_dir, phase1_cfg, 2027, device
    )
    control_scores = score_methods(synthetic_rows, verifier_dir, device)
    expected_scores = {
        "verifier",
        "verifier_existence",
        "verifier_quality",
        "detector_score",
        "sam_predicted_iou",
        "sam_stability",
        "jitter_variance",
        "area_component_rule",
        "lightweight_quality_regressor",
    }
    if set(control_scores) != expected_scores:
        raise RuntimeError("ENGINEERING_SIMPLE_CONTROL_TRAIN_INFER_INCOMPLETE")
    states = dual_threshold_states(
        synthetic_rows[:3], [0.2, 0.8, 0.8], 0.5, [0.9, 0.2, 0.9], 0.5
    )
    if states != ["empty", "refer", "accept"]:
        raise RuntimeError("ENGINEERING_EMPTY_REFER_ACCEPT_STATE_FAILED")

    projected = reproject_box_to_original([64, 32, 256, 160], (256, 512), (512, 1024))
    if projected != [128.0, 64.0, 512.0, 320.0]:
        raise RuntimeError("ENGINEERING_BOX_REPROJECTION_FAILED")

    checkpoint = output / "engineering_resume.pt"
    torch.save(
        {
            "model": b1.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "schema_version": 3,
            "protocol_version": "2.3",
        },
        checkpoint,
    )
    restored = torch.load(checkpoint, map_location="cpu", weights_only=False)
    restored_model = DeepLabV3PlusHardGate(False)
    restored_optimizer = torch.optim.AdamW(restored_model.parameters(), lr=1e-4)
    restored_scheduler = torch.optim.lr_scheduler.StepLR(restored_optimizer, step_size=1, gamma=0.9)
    restored_model.load_state_dict(restored["model"], strict=True)
    restored_optimizer.load_state_dict(restored["optimizer"])
    restored_scheduler.load_state_dict(restored["scheduler"])
    if not (
        _state_equal(b1.state_dict(), restored_model.state_dict())
        and _state_equal(optimizer.state_dict(), restored_optimizer.state_dict())
        and _state_equal(scheduler.state_dict(), restored_scheduler.state_dict())
    ):
        raise RuntimeError("ENGINEERING_CHECKPOINT_RESUME_STATE_MISMATCH")

    archive = output / "engineering_resume.tar.gz"
    with tarfile.open(archive, "w:gz") as handle:
        handle.add(checkpoint, arcname="engineering_resume.pt", recursive=False)
    with tarfile.open(archive, "r:gz") as handle:
        extracted = handle.extractfile(handle.getmember("engineering_resume.pt"))
        if extracted is None:
            raise RuntimeError("ENGINEERING_ARCHIVE_MEMBER_UNREADABLE")
        archived_sha = hashlib.sha256(extracted.read()).hexdigest()
    if archived_sha != sha256_file(checkpoint):
        raise RuntimeError("ENGINEERING_ARCHIVE_HASH_MISMATCH")

    scheduler_probe = ResourceAwareScheduler(phase1_cfg, output / "scheduler_probe")
    failed_lease = scheduler_probe.lease_dir / "a0_failure_fixture.attempt0.json"
    scheduler_probe._write_lease(
        failed_lease,
        {
            "state": "LAUNCH_FAILED",
            "task_id": "a0_failure_fixture",
            "attempt": 0,
            "run_token": "0" * 32,
            "failure_reason": "synthetic_fixture_expected_failure",
        },
    )
    if scheduler_probe._read_lease(failed_lease)["state"] != "LAUNCH_FAILED":
        raise RuntimeError("ENGINEERING_SCHEDULER_FAILURE_LEASE_RECOVERY_FAILED")

    torch.cuda.synchronize()
    peak = torch.cuda.max_memory_reserved(device) / (1024**3)
    if peak >= float(phase1_cfg["runtime"]["max_peak_vram_gib"]):
        raise RuntimeError(f"ENGINEERING_VRAM_LIMIT_EXCEEDED: {peak:.3f} GiB")

    evidence = {
        "schema_version": 3,
        "protocol_version": "2.3",
        "decision": "ENGINEERING_A0_PASS",
        "status": "ENGINEERING_CHECKS_ONLY_NOT_PAPER_RESULT",
        "completed_at": utc_now(),
        "allowed_checks": list(ENGINEERING_A0_CHECKS),
        "checks": {
            "data_loading_and_patient_folds": {"status": "PASS", "outer_folds": [0, 1, 2, 3, 4], "evaluation_patient_count": len(evaluated_patients), "patient_overlap": []},
            "b1_forward_backward": "PASS",
            "fpn_detector_forward_backward": "PASS",
            "mask_rcnn_forward_backward": "PASS",
            "medsam_decoder_forward_backward": "PASS",
            "predicted_box_coordinate_reprojection": "PASS",
            "real_candidate_schema": "PASS",
            "verifier_and_all_simple_controls_grouped_train_infer": {"status": "PASS", "metadata": verifier_metadata},
            "empty_refer_accept_states": "PASS",
            "checkpoint_resume_model_optimizer_scheduler": "PASS",
            "fp32_amp_peak_vram": {"status": "PASS", "peak_vram_gib": peak},
            "scheduler_lease_failure_archive_recovery": {"status": "PASS", "failed_lease": str(failed_lease), "archive_sha256": sha256_file(archive), "archived_checkpoint_sha256": archived_sha},
        },
        "checkpoint_sha256": sha256_file(checkpoint),
        "performance_based_method_selection": False,
        "outer_test_used": False,
        "paper_result": False,
        "method_effectiveness_claim": False,
    }
    atomic_json(output / "ENGINEERING_A0_EVIDENCE.json", evidence)
    atomic_json(env["SCREENBUS_ROOT"] / "gates" / "ENGINEERING_A0_STATUS.json", evidence)
    return evidence


__all__ = [
    "build_synthetic_verifier_rows",
    "reproject_box_to_original",
    "run_engineering_a0",
    "validate_real_candidate_schema",
]
