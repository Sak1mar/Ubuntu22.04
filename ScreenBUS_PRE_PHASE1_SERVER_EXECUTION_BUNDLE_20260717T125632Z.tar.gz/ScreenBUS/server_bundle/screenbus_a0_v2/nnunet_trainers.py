from __future__ import annotations

from functools import wraps
from typing import Any, TypeVar


Trainer = TypeVar("Trainer")


def register_checkpoint_cadence(
    trainer_class: Trainer,
    save_every_epochs: int,
) -> Trainer:
    """Patch a resolved nnU-Net trainer without changing its public class name.

    nnU-Net locates training results by ``trainer_class.__name__``.  Keeping the
    official name lets the unmodified prediction CLI reload the same folder,
    while the process-local constructor patch makes interrupted official runs
    produce ``checkpoint_latest.pth`` before their final epoch.
    """
    cadence = int(save_every_epochs)
    if cadence <= 0:
        raise ValueError("nnU-Net checkpoint cadence must be positive")
    original = getattr(
        trainer_class,
        "_screenbus_original_init",
        trainer_class.__init__,
    )

    @wraps(original)
    def screenbus_init(
        self,
        plans: dict,
        configuration: str,
        fold: int,
        dataset_json: dict,
        unpack_dataset: bool = True,
        device: Any = None,
    ) -> None:
        if device is None:
            original(self, plans, configuration, fold, dataset_json, unpack_dataset)
        else:
            original(
                self,
                plans,
                configuration,
                fold,
                dataset_json,
                unpack_dataset,
                device,
            )
        epochs = int(self.num_epochs)
        if cadence >= epochs:
            raise RuntimeError(
                "SCREENBUS_NNUNET_CHECKPOINT_CADENCE_INVALID: "
                f"save_every={cadence}, num_epochs={epochs}"
            )
        self.save_every = cadence
        self.screenbus_checkpoint_save_every_epochs = cadence

    trainer_class._screenbus_original_init = original
    trainer_class.__init__ = screenbus_init
    trainer_class.screenbus_checkpoint_save_every_epochs = cadence
    return trainer_class
