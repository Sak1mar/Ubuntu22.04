#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd -P)"
ENV_DIR="${SCREENBUS_ENV_DIR:-${SCRIPT_DIR}/.server_env}"
ENV_PYTHON="${ENV_DIR}/bin/python"
CONTROL_RUNTIME="${SCRIPT_DIR}/runtime"
LOG_DIR="${CONTROL_RUNTIME}/logs"
PID_FILE="${CONTROL_RUNTIME}/overnight.pid"
STATUS_FILE="${SCRIPT_DIR}/STATUS.json"
SELF="${SCRIPT_DIR}/screenbus_server.sh"

mkdir -p "${LOG_DIR}"
EARLY_FAILURE_FILE="${CONTROL_RUNTIME}/EARLY_FAILURE.txt"

record_early_failure() {
  code="$?"
  if [[ ! -f "${STATUS_FILE}" ]]; then
    printf 'EARLY_BOOTSTRAP_FAILED exit=%s at=%s; inspect %s/latest.log\n' \
      "${code}" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "${LOG_DIR}" >"${EARLY_FAILURE_FILE}"
  fi
  exit "${code}"
}
trap record_early_failure ERR

control_python() {
  if [[ -n "${SCREENBUS_ORCHESTRATOR_PYTHON:-}" ]]; then
    printf '%s\n' "${SCREENBUS_ORCHESTRATOR_PYTHON}"
  elif [[ -x "${ENV_PYTHON}" ]]; then
    printf '%s\n' "${ENV_PYTHON}"
  elif command -v python3 >/dev/null 2>&1; then
    command -v python3
  else
    return 127
  fi
}

prepare_control_environment() {
  export SCREENBUS_ROOT="${ROOT}"
  scientific_runtime="${SCREENBUS_RUNTIME_ROOT:-${SCRIPT_DIR}/runtime}"
  export SCREENBUS_CACHE_ROOT="${SCREENBUS_CACHE_ROOT:-${scientific_runtime}/cache}"
  export SCREENBUS_ENV_DIR="${ENV_DIR}"
  ready=0
  if [[ -x "${ENV_PYTHON}" && -f "${SCRIPT_DIR}/artifacts/environment/manifest.json" ]]; then
    # Never regenerate provenance while deciding whether an existing environment
    # is reusable.  Verification failure falls through to bootstrap_env.sh,
    # which performs a clean reinstall before writing a new manifest.
    if "${ENV_PYTHON}" "${SCRIPT_DIR}/env/write_manifest.py" --verify-existing \
      >/dev/null 2>&1; then
      ready=1
    fi
  fi
  if [[ "${ready}" -ne 1 ]]; then
    bash "${SCRIPT_DIR}/env/bootstrap_env.sh"
  fi
  [[ -x "${ENV_PYTHON}" ]] || { printf 'SERVER_ENV_PYTHON_MISSING: %s\n' "${ENV_PYTHON}" >&2; exit 20; }
  export SCREENBUS_PREBOOTSTRAPPED_ENV=1
}

usage() {
  command_name="$(basename -- "$0")"
  printf '%s\n' \
    "Usage: ${command_name} overnight|resume|run|status|logs|results|verify-results" \
    "" \
    "  overnight        detach one complete fail-closed run (recommended)" \
    "  resume           detach and resume the same STATUS.json state machine" \
    "  run              foreground run for debugging/interactive consoles" \
    "  status [--json]  show gates, stages, three-GPU memory, queue, progress" \
    "  logs [stage]     tail master log or a named stage log" \
    "  results          print the evidence-literal final result summary" \
    "  verify-results ARCHIVE MANIFEST SHA256_FILE" \
    "                   verify archive envelope and every payload hash"
}

is_live_pid() {
  [[ -f "${PID_FILE}" ]] || return 1
  pid="$(tr -dc '0-9' < "${PID_FILE}")"
  [[ -n "${pid}" ]] || return 1
  kill -0 "${pid}" 2>/dev/null
}

launch_detached() {
  if is_live_pid; then
    printf 'ALREADY_RUNNING pid=%s\n' "$(tr -dc '0-9' < "${PID_FILE}")" >&2
    exit 10
  fi
  timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
  master_log="${LOG_DIR}/overnight_${timestamp}.log"
  nohup "${SELF}" _foreground >>"${master_log}" 2>&1 </dev/null &
  child_pid="$!"
  printf '%s\n' "${child_pid}" >"${PID_FILE}"
  ln -sfn "$(basename -- "${master_log}")" "${LOG_DIR}/latest.log"
  sleep 1
  if ! kill -0 "${child_pid}" 2>/dev/null; then
    printf 'LAUNCH_FAILED pid=%s log=%s\n' "${child_pid}" "${master_log}" >&2
    tail -n 80 "${master_log}" >&2 || true
    exit 20
  fi
  printf 'DETACHED pid=%s\n' "${child_pid}"
  printf 'STATUS: %s status\n' "${SELF}"
  printf 'LOG: %s logs\n' "${SELF}"
  printf 'MASTER_LOG: %s\n' "${master_log}"
}

command="${1:-}"
case "${command}" in
  overnight|resume)
    launch_detached
    ;;
  run|_foreground)
    prepare_control_environment
    exec "${ENV_PYTHON}" "${SCRIPT_DIR}/ops/orchestrator.py" run --root "${ROOT}"
    ;;
  status)
    shift
    if [[ ! -f "${STATUS_FILE}" ]]; then
      printf 'STATUS_NOT_CREATED: %s\n' "${STATUS_FILE}" >&2
      if [[ -f "${EARLY_FAILURE_FILE}" ]]; then
        sed -n '1,20p' "${EARLY_FAILURE_FILE}" >&2
      fi
      exit 3
    fi
    PYTHON="$(control_python)" || { printf 'PYTHON_UNAVAILABLE_FOR_STATUS\n' >&2; exit 127; }
    "${PYTHON}" "${SCRIPT_DIR}/ops/orchestrator.py" status --status "${STATUS_FILE}" "$@"
    if [[ "${1:-}" != "--json" ]]; then
      if is_live_pid; then
        printf 'detached_process: RUNNING pid=%s\n' "$(tr -dc '0-9' < "${PID_FILE}")"
      else
        printf 'detached_process: NOT_RUNNING\n'
      fi
    fi
    ;;
  logs)
    stage="${2:-master}"
    lines="${SCREENBUS_LOG_LINES:-120}"
    if [[ "${stage}" == "master" ]]; then
      log_path="${LOG_DIR}/latest.log"
    else
      case "${stage}" in
        P0_PROTOCOL_REPAIR|G2_SERVER_ENGINEERING|ENGINEERING_A0|PHASE1_FIVE_FOLD_ONE_SEED|G3_METHOD_GATE|PHASE2_THREE_SEEDS_AND_FULL_BASELINES|EXTERNAL_POSITIVE_STRESS|RESULT_FREEZE)
          log_path="${LOG_DIR}/${stage}.log"
          ;;
        *)
          printf 'UNKNOWN_STAGE_LOG: %s\n' "${stage}" >&2
          exit 2
          ;;
      esac
    fi
    [[ -e "${log_path}" ]] || { printf 'LOG_NOT_FOUND: %s\n' "${log_path}" >&2; exit 3; }
    tail -n "${lines}" "${log_path}"
    ;;
  results)
    if [[ ! -f "${STATUS_FILE}" ]]; then
      printf 'STATUS_NOT_CREATED: %s\n' "${STATUS_FILE}" >&2
      [[ -f "${EARLY_FAILURE_FILE}" ]] && sed -n '1,20p' "${EARLY_FAILURE_FILE}" >&2
      exit 3
    fi
    PYTHON="$(control_python)" || { printf 'PYTHON_UNAVAILABLE_FOR_RESULTS\n' >&2; exit 127; }
    exec "${PYTHON}" "${SCRIPT_DIR}/ops/inspect_results.py" \
      --root "${ROOT}" --status "${STATUS_FILE}" \
      --write "${SCRIPT_DIR}/reports/FINAL_RESULT_SUMMARY.md"
    ;;
  verify-results)
    [[ "$#" -eq 4 ]] || { usage >&2; exit 2; }
    PYTHON="$(control_python)" || { printf 'PYTHON_UNAVAILABLE_FOR_VERIFY\n' >&2; exit 127; }
    exec "${PYTHON}" "${SCRIPT_DIR}/ops/archive_results.py" verify \
      --archive "$2" --manifest "$3" --sha256-file "$4"
    ;;
  help|-h|--help)
    usage
    ;;
  *)
    usage >&2
    exit 2
    ;;
esac
