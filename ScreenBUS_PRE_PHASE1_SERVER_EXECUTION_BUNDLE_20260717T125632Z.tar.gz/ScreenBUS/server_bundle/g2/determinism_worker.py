#!/usr/bin/env python3
"""Fresh-process deterministic CUDA fingerprint used twice by G2."""

from __future__ import annotations

import hashlib
import json
import os

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("PYTHONHASHSEED", "2027")

import numpy as np
import torch


def main() -> int:
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.manual_seed(2027)
    torch.cuda.manual_seed_all(2027)
    device = torch.device("cuda:0")
    x = torch.randn(2, 3, 32, 32, device=device, requires_grad=True)
    weight = torch.randn(5, 3, 3, 3, device=device, requires_grad=True)
    result = torch.nn.functional.conv2d(x, weight, padding=1)
    loss = result.square().mean()
    loss.backward()
    torch.cuda.synchronize()
    arrays = [result.detach().cpu().numpy(), x.grad.cpu().numpy(), weight.grad.cpu().numpy()]
    digest = hashlib.sha256()
    for array in arrays:
        digest.update(np.ascontiguousarray(array).tobytes())
    print(json.dumps({"status": "PASS", "seed": 2027, "sha256": digest.hexdigest()}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
