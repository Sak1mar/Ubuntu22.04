#!/usr/bin/env python3
"""Actual nnU-Net v2 plan/preprocess/two-step/reload/predict/evaluate probe."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("PYTHONHASHSEED", "2027")
os.environ.setdefault("nnUNet_compile", "false")
os.environ.setdefault("nnUNet_n_proc_DA", "1")

import numpy as np
import SimpleITK as sitk
import torch


DATASET = "Dataset997_ScreenBUSG2"


def write_case(path: Path, image: np.ndarray) -> None:
    itk = sitk.GetImageFromArray(image)
    itk.SetSpacing((0.25, 0.25, 1.0))
    sitk.WriteImage(itk, str(path), useCompression=True)


def fixture(role: str, seed: int) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    image = rng.normal(0.25, 0.05, size=(1, 64, 64)).clip(0, 1).astype(np.float32)
    mask = np.zeros((1, 64, 64), dtype=np.uint8)
    yy, xx = np.ogrid[:64, :64]
    if role in {"single", "multi"}:
        lesion = (yy - 28) ** 2 + (xx - 27) ** 2 <= 9**2
        mask[0, lesion] = 1
        image[0, lesion] += 0.35
    if role == "multi":
        lesion = (yy - 44) ** 2 + (xx - 46) ** 2 <= 5**2
        mask[0, lesion] = 1
        image[0, lesion] += 0.30
    return image.clip(0, 1), mask


def make_dataset(raw_root: Path) -> tuple[Path, Path]:
    dataset = raw_root / DATASET
    images_tr = dataset / "imagesTr"
    labels_tr = dataset / "labelsTr"
    images_ts = dataset / "imagesTs"
    labels_ts = dataset / "labelsTs"
    for folder in (images_tr, labels_tr, images_ts, labels_ts):
        folder.mkdir(parents=True, exist_ok=True)
    roles = ["empty", "single", "multi", "empty", "single", "multi"]
    for index, role in enumerate(roles):
        image, mask = fixture(role, 2027 + index)
        case = f"g2tr_{index:03d}"
        write_case(images_tr / f"{case}_0000.nii.gz", image)
        write_case(labels_tr / f"{case}.nii.gz", mask)
    for index, role in enumerate(("empty", "multi")):
        image, mask = fixture(role, 3027 + index)
        case = f"g2ts_{index:03d}"
        write_case(images_ts / f"{case}_0000.nii.gz", image)
        write_case(labels_ts / f"{case}.nii.gz", mask)
    dataset_json = {
        "channel_names": {"0": "ultrasound"},
        "labels": {"background": 0, "lesion": 1},
        "numTraining": 6,
        "file_ending": ".nii.gz",
        "licence": "SYNTHETIC_G2_FIXTURE",
    }
    (dataset / "dataset.json").write_text(json.dumps(dataset_json, indent=2) + "\n")
    return dataset, labels_ts


def main() -> int:
    root = Path(os.environ["SCREENBUS_ROOT"]).resolve()
    work = root / "server_bundle" / "artifacts" / "g2" / "nnunet"
    if work.exists():
        shutil.rmtree(work)
    raw = work / "nnUNet_raw"
    preprocessed = work / "nnUNet_preprocessed"
    results = work / "nnUNet_results"
    for path in (raw, preprocessed, results):
        path.mkdir(parents=True, exist_ok=True)
    os.environ["nnUNet_raw"] = str(raw)
    os.environ["nnUNet_preprocessed"] = str(preprocessed)
    os.environ["nnUNet_results"] = str(results)
    dataset, labels_ts = make_dataset(raw)

    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.manual_seed(2027)
    torch.cuda.manual_seed_all(2027)
    torch.cuda.set_device(0)
    torch.cuda.reset_peak_memory_stats(0)

    cli = Path(sys.executable).parent / "nnUNetv2_plan_and_preprocess"
    if not cli.is_file():
        raise RuntimeError(f"nnU-Net plan/preprocess CLI missing: {cli}")
    planning = subprocess.run(
        [
            str(cli), "-d", "997", "-c", "2d", "--verify_dataset_integrity",
            "-npfp", "1", "-np", "1",
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
        env=os.environ.copy(),
    )
    (work / "plan_preprocess.log").write_text(planning.stdout)
    if planning.returncode:
        raise RuntimeError(f"nnU-Net plan/preprocess failed: {planning.stdout[-4000:]}")

    from batchgenerators.utilities.file_and_folder_operations import load_json
    from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer

    pre = preprocessed / DATASET
    plans = load_json(pre / "nnUNetPlans.json")
    dataset_json = load_json(pre / "dataset.json")
    trainer = nnUNetTrainer(
        plans=plans,
        configuration="2d",
        fold=0,
        dataset_json=dataset_json,
        unpack_dataset=True,
        device=torch.device("cuda", 0),
    )
    trainer.num_epochs = 1
    trainer.num_iterations_per_epoch = 2
    trainer.num_val_iterations_per_epoch = 1
    trainer.save_every = 1
    trainer.run_training()
    checkpoint = Path(trainer.output_folder) / "checkpoint_final.pth"
    if not checkpoint.is_file():
        raise RuntimeError("nnU-Net two-step checkpoint was not written")

    reloaded = nnUNetTrainer(
        plans=plans,
        configuration="2d",
        fold=0,
        dataset_json=dataset_json,
        unpack_dataset=False,
        device=torch.device("cuda", 0),
    )
    reloaded.load_checkpoint(str(checkpoint))
    if reloaded.current_epoch != 1:
        raise RuntimeError(f"nnU-Net checkpoint epoch drift: {reloaded.current_epoch}")
    del reloaded, trainer
    torch.cuda.empty_cache()

    from nnunetv2.inference.predict_from_raw_data import nnUNetPredictor

    predictor = nnUNetPredictor(
        tile_step_size=0.5,
        use_gaussian=True,
        use_mirroring=False,
        perform_everything_on_device=True,
        device=torch.device("cuda", 0),
        verbose=False,
        verbose_preprocessing=False,
        allow_tqdm=False,
    )
    model_folder = results / DATASET / "nnUNetTrainer__nnUNetPlans__2d"
    predictor.initialize_from_trained_model_folder(
        str(model_folder), use_folds=(0,), checkpoint_name="checkpoint_final.pth"
    )
    predictions = work / "predictions"
    predictor.predict_from_files(
        str(dataset / "imagesTs"),
        str(predictions),
        save_probabilities=False,
        overwrite=True,
        num_processes_preprocessing=1,
        num_processes_segmentation_export=1,
    )
    predicted = sorted(predictions.glob("g2ts_*.nii.gz"))
    if len(predicted) != 2:
        raise RuntimeError(f"nnU-Net prediction count drift: {len(predicted)}")

    evaluator = Path(sys.executable).parent / "nnUNetv2_evaluate_folder"
    evaluation = subprocess.run(
        [
            str(evaluator), str(labels_ts), str(predictions),
            "-djfile", str(model_folder / "dataset.json"),
            "-pfile", str(model_folder / "plans.json"),
            "-o", str(predictions / "summary.json"), "-np", "1",
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
        env=os.environ.copy(),
    )
    (work / "evaluate.log").write_text(evaluation.stdout)
    if evaluation.returncode or not (predictions / "summary.json").is_file():
        raise RuntimeError(f"nnU-Net evaluation failed: {evaluation.stdout[-4000:]}")
    torch.cuda.synchronize(0)
    payload = {
        "status": "PASS",
        "dataset": DATASET,
        "fixture_roles": ["empty", "single", "multi"],
        "plan": "PASS",
        "preprocess": "PASS",
        "training_steps": 2,
        "checkpoint_reload": "PASS",
        "predictions": len(predicted),
        "evaluation": "PASS",
        "checkpoint": str(checkpoint.relative_to(root)),
        "summary": str((predictions / "summary.json").relative_to(root)),
        "peak_memory_gib": torch.cuda.max_memory_allocated(0) / (1024**3),
        "performance_interpretation": "PROHIBITED_SYNTHETIC_ENGINEERING_GATE_ONLY",
    }
    output = work / "probe.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(json.dumps(payload, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
