"""ScreenBUS RTX 3090 hard-gate probes."""
