#!/usr/bin/env python3
"""Fail-closed ScreenBUS G2 hard gate for a 3x RTX 3090 Linux server."""

from __future__ import annotations

import argparse
import gc
import hashlib
import importlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("PYTHONHASHSEED", "2027")
os.environ.setdefault("nnUNet_compile", "false")
os.environ.setdefault("nnUNet_n_proc_DA", "1")


MEMORY_LIMIT_GIB = 22.0
REQUIRED_DEVICE_IDS = [0, 1, 2]
REQUIRED_DRIVER_MINIMUM = (525, 60, 13)
REQUIRED_CONTAINER_IMAGE = "nvidia/cuda:12.1.1-cudnn8-devel-ubuntu22.04"
REQUIRED_CONTAINER_DIGEST = "sha256:cc55d151af1e8e083f3210af753a5cfbcbc5455421531eb0459887026bb4699f"
REQUIRED_TORCH_VERSION = "2.4.1+cu121"
REQUIRED_TORCH_CUDA = "12.1"
REQUIRED_TORCH_CUDNN = 90100
MEDSAM_SHA256 = "34b34b78c1d18cb8c6bf84cf9c00e135d6d6c965699f3c0e31ef1bc9dcb5be74"
FRCNN_SHA256 = "258fb6c638b15964ddcdd1ae0748c5eef1be9e732750120cc857feed3faac384"
MASKRCNN_SHA256 = "bf2d0c1efbc936eeee2bc95a48e80ebc86b891f61b0106485937fc29f9315fc0"
RESNET18_SHA256 = "f37072fd47e89c5e827621c5baffa7500819f7896bbacec160b1a16c560e07ec"
MEDSAM_COMMIT = "861d42440061c704762a9bb9a574e7c31d8d751a"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_or_missing(path: Path) -> str:
    return sha256(path) if path.is_file() else "MISSING"


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def strict_torch_settings(torch: Any) -> None:
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.manual_seed(2027)
    torch.cuda.manual_seed_all(2027)


def peak_gib(torch: Any, device: int) -> float:
    torch.cuda.synchronize(device)
    value = torch.cuda.max_memory_allocated(device) / (1024**3)
    if value >= MEMORY_LIMIT_GIB:
        raise RuntimeError(f"device {device} peak {value:.3f} GiB is not below {MEMORY_LIMIT_GIB} GiB")
    return value


def _version_tuple(value: str) -> tuple[int, ...]:
    pieces = value.split(".")
    if not pieces or any(not piece.isdigit() for piece in pieces):
        raise RuntimeError(f"invalid NVIDIA driver version: {value!r}")
    return tuple(int(piece) for piece in pieces)


def probe_container_runtime() -> dict[str, Any]:
    if os.environ.get("SCREENBUS_CONTAINER_RUNTIME_VERIFIED") != "1":
        raise RuntimeError("frozen container launcher attestation is absent")
    image = os.environ.get("SCREENBUS_CONTAINER_IMAGE")
    digest = os.environ.get("SCREENBUS_CONTAINER_DIGEST")
    if image != REQUIRED_CONTAINER_IMAGE or digest != REQUIRED_CONTAINER_DIGEST:
        raise RuntimeError(
            f"container identity drift: image={image!r}, digest={digest!r}"
        )
    os_release = Path("/etc/os-release").read_text(encoding="utf-8")
    if 'ID=ubuntu' not in os_release or 'VERSION_ID="22.04"' not in os_release:
        raise RuntimeError("container OS is not Ubuntu 22.04")
    return {
        "status": "PASS",
        "image": image,
        "digest": digest,
        "ubuntu_version": "22.04",
        "cuda_container_tag": "12.1.1",
        "cudnn_container_major": 8,
    }


def probe_hardware(root: Path, *, write_artifact: bool = True) -> dict[str, Any]:
    if platform.system() != "Linux" or platform.machine() != "x86_64":
        raise RuntimeError(f"unsupported host: {platform.system()} {platform.machine()}")
    import torch

    query = subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=index,name,driver_version,memory.total",
            "--format=csv,noheader,nounits",
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if query.returncode:
        raise RuntimeError(f"nvidia-smi failed: {query.stdout.strip()}")
    smi: dict[int, dict[str, Any]] = {}
    for line in query.stdout.splitlines():
        pieces = [piece.strip() for piece in line.split(",")]
        if len(pieces) != 4:
            raise RuntimeError(f"unexpected nvidia-smi inventory line: {line!r}")
        index = int(pieces[0])
        smi[index] = {
            "id": index,
            "name": pieces[1],
            "driver_version": pieces[2],
            "memory_total_mib_nvidia_smi": int(pieces[3]),
        }
    if not torch.cuda.is_available():
        raise RuntimeError("torch.cuda.is_available() is false")
    if torch.cuda.device_count() < 3 or not all(device in smi for device in REQUIRED_DEVICE_IDS):
        raise RuntimeError(
            f"at least GPU IDs 0,1,2 are required; torch={torch.cuda.device_count()}, smi={sorted(smi)}"
        )
    if torch.__version__ != REQUIRED_TORCH_VERSION:
        raise RuntimeError(f"PyTorch version drift: {torch.__version__!r} != {REQUIRED_TORCH_VERSION!r}")
    if torch.version.cuda != REQUIRED_TORCH_CUDA:
        raise RuntimeError(f"PyTorch CUDA runtime drift: {torch.version.cuda!r} != {REQUIRED_TORCH_CUDA!r}")
    cudnn_version = torch.backends.cudnn.version()
    if cudnn_version != REQUIRED_TORCH_CUDNN:
        raise RuntimeError(f"PyTorch cuDNN runtime drift: {cudnn_version!r} != {REQUIRED_TORCH_CUDNN}")
    strict_torch_settings(torch)
    devices: list[dict[str, Any]] = []
    for device in REQUIRED_DEVICE_IDS:
        record = smi[device]
        if _version_tuple(record["driver_version"]) < REQUIRED_DRIVER_MINIMUM:
            raise RuntimeError(
                f"GPU {device} NVIDIA driver {record['driver_version']} is below 525.60.13"
            )
        properties = torch.cuda.get_device_properties(device)
        torch_memory = int(properties.total_memory / (1024**2))
        if "RTX 3090" not in record["name"] or "RTX 3090" not in properties.name:
            raise RuntimeError(f"GPU {device} is not RTX 3090: {record['name']} / {properties.name}")
        if not (23000 <= record["memory_total_mib_nvidia_smi"] <= 25000 and 23000 <= torch_memory <= 25000):
            raise RuntimeError(f"GPU {device} is not 24-GiB class: {record['memory_total_mib_nvidia_smi']}/{torch_memory} MiB")
        torch.cuda.set_device(device)
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(device)
        generator = torch.Generator(device=f"cuda:{device}").manual_seed(2027)
        left = torch.randn((512, 512), generator=generator, device=f"cuda:{device}", requires_grad=True)
        right = torch.randn((512, 512), generator=generator, device=f"cuda:{device}", requires_grad=True)
        cuda_loss = (left @ right).square().mean()
        cuda_loss.backward()
        if not torch.isfinite(cuda_loss) or not torch.isfinite(left.grad).all():
            raise RuntimeError(f"GPU {device} FP32 CUDA smoke is non-finite")
        left.grad = None
        right.grad = None
        scaler = torch.cuda.amp.GradScaler()
        with torch.autocast(device_type="cuda", dtype=torch.float16):
            amp_loss = (left @ right).float().square().mean()
        scaler.scale(amp_loss).backward()
        scaler.unscale_(torch.optim.SGD([left, right], lr=0.0))
        if not torch.isfinite(amp_loss) or not torch.isfinite(left.grad).all():
            raise RuntimeError(f"GPU {device} AMP smoke is non-finite")
        per_device_peak = peak_gib(torch, device)
        devices.append(
            {
                **record,
                "torch_name": properties.name,
                "memory_total_mib_torch": torch_memory,
                "compute_capability": f"{properties.major}.{properties.minor}",
                "cuda_smoke": "PASS",
                "amp_fp16_smoke": "PASS",
                "peak_memory_gib": per_device_peak,
                "schedulable": True,
            }
        )
        del left, right, cuda_loss, amp_loss, scaler
        torch.cuda.empty_cache()
    payload = {
        "schema_version": 1,
        "created_at_utc": utc_now(),
        "status": "PASS",
        "profile": "server_rtx3090_linux",
        "required_device_ids": REQUIRED_DEVICE_IDS,
        "visible_device_count": torch.cuda.device_count(),
        "validated_device_count": 3,
        "schedulable_device_ids": REQUIRED_DEVICE_IDS,
        "torch": torch.__version__,
        "torch_cuda_runtime": torch.version.cuda,
        "torch_cudnn_runtime": cudnn_version,
        "driver_minimum": "525.60.13",
        "devices": devices,
    }
    if write_artifact:
        atomic_json(root / "server_bundle" / "artifacts" / "system" / "gpu_inventory.json", payload)
    return payload


def probe_environment(root: Path) -> dict[str, Any]:
    expected = {
        "torch": "2.4.1+cu121",
        "torchvision": "0.19.1+cu121",
        "numpy": "1.26.4",
        "scipy": "1.14.1",
        "pandas": "2.2.3",
        "monai": "1.4.0",
        "scikit-image": "0.24.0",
        "scikit-learn": "1.5.2",
        "opencv-python-headless": "4.10.0.84",
        "pycocotools": "2.0.8",
        "nnunetv2": "2.5.1",
    }
    observed = {name: importlib.metadata.version(name) for name in expected}
    mismatch = {name: [expected[name], observed[name]] for name in expected if observed[name] != expected[name]}
    if mismatch:
        raise RuntimeError(f"pinned package mismatch: {mismatch}")
    imports = [
        "torch", "torchvision", "numpy", "scipy", "pandas", "monai", "skimage",
        "sklearn", "cv2", "pycocotools", "nnunetv2", "SimpleITK", "nibabel", "yaml", "PIL",
    ]
    for module in imports:
        importlib.import_module(module)
    manifest_path = root / "server_bundle" / "artifacts" / "environment" / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    requirements = root / "server_bundle" / "env" / "requirements-cuda121.lock.txt"
    freeze = root / manifest["resolved_freeze"]
    if manifest.get("status") != "PASS" or manifest.get("requirements_sha256") != sha256(requirements):
        raise RuntimeError("bootstrap environment manifest is absent, failed, or stale")
    if manifest.get("resolved_freeze_sha256") != sha256(freeze):
        raise RuntimeError("post-install resolved freeze hash mismatch")
    if (
        manifest.get("lock_kind") != "COMPLETE_TRANSITIVE_REQUIRE_HASHES"
        or manifest.get("transitive_lock_claimed") is not True
        or not isinstance(manifest.get("locked_package_count"), int)
        or manifest["locked_package_count"] < len(expected)
    ):
        raise RuntimeError("environment was not installed from the complete transitive hash lock")
    if platform.python_version() != "3.10.14":
        raise RuntimeError(f"Python version drift: {platform.python_version()!r} != '3.10.14'")
    uv = root / "server_bundle" / ".tools" / "uv"
    check = subprocess.run(
        [str(uv), "pip", "check", "--python", sys.executable],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if check.returncode:
        raise RuntimeError(f"uv pip check failed: {check.stdout}")
    return {
        "status": "PASS",
        "python": platform.python_version(),
        "packages": observed,
        "imports": imports,
        "pip_check": check.stdout.strip(),
        "requirements_sha256": sha256(requirements),
        "resolved_freeze_sha256": sha256(freeze),
        "lock_kind": "COMPLETE_TRANSITIVE_REQUIRE_HASHES",
        "environment_mode": "BUNDLE_LOCAL_UV_VENV",
        "container_contract": "FROZEN_UBUNTU_22_04_CUDA_12_1_1_CUDNN8_DIGEST",
    }


def probe_assets(root: Path) -> dict[str, Any]:
    from server_bundle.data.official_assets import audit_busuclm, verify_medsam_repo

    prepared = audit_busuclm()
    weight_path = root / "server_bundle" / "artifacts" / "weights" / "weight_manifest.json"
    weights = json.loads(weight_path.read_text())
    if prepared.get("status") != "PASS" or weights.get("status") != "PASS":
        raise RuntimeError("official data or weight manifest is not PASS")
    _, _, cache, _, _ = (
        root,
        Path(os.environ["SCREENBUS_DATA_ROOT"]),
        Path(os.environ["SCREENBUS_CACHE_ROOT"]),
        Path(os.environ["SCREENBUS_OUTPUT_ROOT"]),
        Path(os.environ["SCREENBUS_WEIGHT_ROOT"]),
    )
    medsam = Path(os.environ["MEDSAM_CKPT"]).resolve()
    torch_home = Path(os.environ.get("TORCH_HOME", str(cache / "torch"))).resolve()
    checkpoints = torch_home / "hub" / "checkpoints"
    faster = checkpoints / "fasterrcnn_resnet50_fpn_coco-258fb6c6.pth"
    mask = checkpoints / "maskrcnn_resnet50_fpn_coco-bf2d0c1e.pth"
    resnet18_path = checkpoints / "resnet18-f37072fd.pth"
    if sha256(medsam) != MEDSAM_SHA256 or sha256(faster) != FRCNN_SHA256:
        raise RuntimeError("MedSAM or Faster R-CNN official full SHA-256 mismatch")
    mask_digest = sha256(mask)
    resnet_digest = sha256(resnet18_path)
    if mask_digest != MASKRCNN_SHA256 or resnet_digest != RESNET18_SHA256:
        raise RuntimeError("Mask R-CNN or ResNet18 official full SHA-256 mismatch")
    repo_verification = verify_medsam_repo(cache / "MedSAM")
    commit = repo_verification["commit"]
    manifest_medsam = weights.get("medsam", {})
    recorded_checkpoint = manifest_medsam.get("checkpoint_path")
    if not isinstance(recorded_checkpoint, str) or Path(recorded_checkpoint).resolve() != medsam:
        raise RuntimeError("MEDSAM_CKPT differs from the verified weight manifest path")
    if manifest_medsam.get("checkpoint_sha256") != MEDSAM_SHA256:
        raise RuntimeError("MedSAM weight manifest SHA-256 drift")
    recorded_torch_home = weights.get("torch_home")
    recorded_cache = weights.get("torchvision_cache")
    if (
        not isinstance(recorded_torch_home, str)
        or Path(recorded_torch_home).resolve() != torch_home
        or not isinstance(recorded_cache, str)
        or Path(recorded_cache).resolve() != checkpoints.resolve()
    ):
        raise RuntimeError("TORCH_HOME differs from the verified weight manifest paths")
    from torchvision.models import ResNet18_Weights, resnet18
    from torchvision.models.detection import (
        FasterRCNN_ResNet50_FPN_Weights,
        MaskRCNN_ResNet50_FPN_Weights,
        fasterrcnn_resnet50_fpn,
        maskrcnn_resnet50_fpn,
    )
    import torch.hub

    offline_builds: list[str] = []
    original_download = torch.hub.download_url_to_file
    def deny_download(*_args: Any, **_kwargs: Any) -> None:
        raise RuntimeError("network download attempted during required offline cache-hit probe")
    torch.hub.download_url_to_file = deny_download
    try:
        for name, builder in (
            ("Faster R-CNN DEFAULT", lambda: fasterrcnn_resnet50_fpn(weights=FasterRCNN_ResNet50_FPN_Weights.DEFAULT)),
            ("Mask R-CNN DEFAULT", lambda: maskrcnn_resnet50_fpn(weights=MaskRCNN_ResNet50_FPN_Weights.DEFAULT)),
            ("ResNet18 DEFAULT", lambda: resnet18(weights=ResNet18_Weights.DEFAULT)),
        ):
            model = builder()
            offline_builds.append(name)
            del model
            gc.collect()
    finally:
        torch.hub.download_url_to_file = original_download
    return {
        "status": "PASS",
        "official_data": prepared,
        "official_weights": {
            "medsam_sha256": MEDSAM_SHA256,
            "fasterrcnn_sha256": FRCNN_SHA256,
            "maskrcnn_sha256": mask_digest,
            "resnet18_sha256": resnet_digest,
            "medsam_commit": commit,
            "medsam_checkpoint": str(medsam),
            "medsam_repo_verification": repo_verification,
            "strict_load_status": weights["strict_load"]["status"],
            "torch_home": str(torch_home),
            "offline_default_cache_builds": offline_builds,
        },
        "input_semantics": {
            "empty": "PASS",
            "single": "PASS",
            "multi": "PASS",
            "evidence": "prepare_manifest labels and 1/2/3-component counts",
        },
    }


def probe_operators(device: int = 0) -> dict[str, Any]:
    import torch
    from torchvision.ops import nms, roi_align

    torch.cuda.set_device(device)
    torch.cuda.reset_peak_memory_stats(device)
    boxes = torch.tensor(
        [[0.0, 0.0, 10.0, 10.0], [1.0, 1.0, 9.0, 9.0], [20.0, 20.0, 30.0, 30.0]],
        device=f"cuda:{device}",
    )
    scores = torch.tensor([0.9, 0.8, 0.7], device=f"cuda:{device}")
    kept = nms(boxes, scores, 0.5)
    features = torch.randn(1, 4, 32, 32, device=f"cuda:{device}")
    rois = torch.tensor([[0.0, 0.0, 0.0, 16.0, 16.0]], device=f"cuda:{device}")
    with torch.autocast(device_type="cuda", dtype=torch.float16):
        pooled = roi_align(features, rois, output_size=(7, 7))
    if kept.tolist() != [0, 2] or tuple(pooled.shape) != (1, 4, 7, 7) or not torch.isfinite(pooled).all():
        raise RuntimeError("CUDA NMS/ROIAlign output mismatch")
    return {
        "status": "PASS",
        "device": device,
        "cuda_tensor": "PASS",
        "amp_fp16": "PASS",
        "nms": "PASS",
        "roi_align": "PASS",
        "peak_memory_gib": peak_gib(torch, device),
    }


def synthetic_targets(torch: Any, device: int, include_masks: bool) -> tuple[list[Any], list[dict[str, Any]]]:
    images = [torch.rand(3, 128, 128, device=f"cuda:{device}") for _ in range(3)]
    boxes_per_image = [[], [[28, 26, 78, 82]], [[10, 12, 44, 47], [72, 68, 111, 109]]]
    targets: list[dict[str, Any]] = []
    for image_index, boxes in enumerate(boxes_per_image):
        box_tensor = torch.tensor(boxes, dtype=torch.float32, device=f"cuda:{device}").reshape(-1, 4)
        target: dict[str, Any] = {
            "boxes": box_tensor,
            "labels": torch.ones(len(boxes), dtype=torch.int64, device=f"cuda:{device}"),
            "image_id": torch.tensor([image_index], dtype=torch.int64, device=f"cuda:{device}"),
            "area": ((box_tensor[:, 2] - box_tensor[:, 0]) * (box_tensor[:, 3] - box_tensor[:, 1])),
            "iscrowd": torch.zeros(len(boxes), dtype=torch.int64, device=f"cuda:{device}"),
        }
        if include_masks:
            masks = torch.zeros((len(boxes), 128, 128), dtype=torch.uint8, device=f"cuda:{device}")
            for index, box in enumerate(boxes):
                x1, y1, x2, y2 = box
                masks[index, y1:y2, x1:x2] = 1
            target["masks"] = masks
        targets.append(target)
    return images, targets


def probe_detection(kind: str, device: int = 0) -> dict[str, Any]:
    import torch
    from torchvision.models.detection import fasterrcnn_resnet50_fpn, maskrcnn_resnet50_fpn

    torch.cuda.set_device(device)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(device)
    common = {
        "weights": None,
        "weights_backbone": None,
        "num_classes": 2,
        "min_size": 128,
        "max_size": 192,
        "rpn_pre_nms_top_n_train": 64,
        "rpn_post_nms_top_n_train": 32,
        "box_detections_per_img": 16,
    }
    if kind == "Faster R-CNN":
        model = fasterrcnn_resnet50_fpn(**common).to(device)
        include_masks = False
    elif kind == "Mask R-CNN":
        model = maskrcnn_resnet50_fpn(**common).to(device)
        include_masks = True
    else:
        raise ValueError(kind)
    model.train()
    images, targets = synthetic_targets(torch, device, include_masks)
    optimizer = torch.optim.SGD(model.parameters(), lr=1e-5)
    output: dict[str, Any] = {"status": "PASS", "model": kind, "batch_roles": ["empty", "single", "multi"]}
    for precision in ("fp32", "amp_fp16"):
        optimizer.zero_grad(set_to_none=True)
        context = (
            torch.autocast(device_type="cuda", dtype=torch.float16)
            if precision == "amp_fp16"
            else torch.autocast(device_type="cuda", enabled=False)
        )
        with context:
            losses = model(images, targets)
            total = sum(losses.values())
        if not torch.isfinite(total):
            raise RuntimeError(f"{kind} {precision} non-finite loss: {losses}")
        if precision == "amp_fp16":
            scaler = torch.cuda.amp.GradScaler()
            scaler.scale(total).backward()
            scaler.unscale_(optimizer)
            scaler.step(optimizer)
            scaler.update()
        else:
            total.backward()
            optimizer.step()
        gradients = [parameter.grad for parameter in model.parameters() if parameter.grad is not None]
        if not gradients or any(not torch.isfinite(gradient).all() for gradient in gradients):
            raise RuntimeError(f"{kind} {precision} non-finite gradient")
        output[precision] = {name: float(value.detach()) for name, value in losses.items()}
    output["peak_memory_gib"] = peak_gib(torch, device)
    del model, optimizer, images, targets
    gc.collect()
    torch.cuda.empty_cache()
    return output


def load_medsam(root: Path, device: int):
    import torch

    repo = Path(os.environ["SCREENBUS_CACHE_ROOT"]) / "MedSAM"
    checkpoint = Path(os.environ["MEDSAM_CKPT"]).resolve()
    if sha256(checkpoint) != MEDSAM_SHA256:
        raise RuntimeError("MEDSAM_CKPT is not the verified official checkpoint")
    sys.path.insert(0, str(repo))
    try:
        segment_anything = importlib.import_module("segment_anything")
        model = segment_anything.sam_model_registry["vit_b"](checkpoint=None)
        state = torch.load(checkpoint, map_location="cpu", weights_only=True)
        model.load_state_dict(state, strict=True)
    finally:
        sys.path.pop(0)
    return model.to(device)


def medsam_forward(model: Any, image: Any, box: Any, torch: Any, *, gradient: bool) -> tuple[Any, Any]:
    encoder_context = torch.enable_grad() if gradient else torch.no_grad()
    with encoder_context:
        embedding = model.image_encoder(image)
    sparse, dense = model.prompt_encoder(points=None, boxes=box[:, None, :], masks=None)
    low_res, quality = model.mask_decoder(
        image_embeddings=embedding,
        image_pe=model.prompt_encoder.get_dense_pe(),
        sparse_prompt_embeddings=sparse,
        dense_prompt_embeddings=dense,
        multimask_output=False,
    )
    return low_res, quality


def probe_medsam(root: Path, device: int = 0) -> dict[str, Any]:
    import torch

    torch.cuda.set_device(device)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(device)
    model = load_medsam(root, device)
    model.eval()
    image = torch.rand(1, 3, 1024, 1024, device=f"cuda:{device}")
    box = torch.tensor([[128.0, 128.0, 896.0, 896.0]], device=f"cuda:{device}")
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    with torch.no_grad():
        logits, quality = medsam_forward(model, image, box, torch, gradient=False)
        full = torch.nn.functional.interpolate(logits, (1024, 1024), mode="bilinear", align_corners=False)
    if tuple(logits.shape) != (1, 1, 256, 256) or not torch.isfinite(full).all() or not torch.isfinite(quality).all():
        raise RuntimeError("MedSAM official 1024 box-prompt inference failed")
    for parameter in model.mask_decoder.parameters():
        parameter.requires_grad_(True)
    model.mask_decoder.train()
    with torch.no_grad():
        embedding = model.image_encoder(image)
        sparse, dense = model.prompt_encoder(points=None, boxes=box[:, None, :], masks=None)
    optimizer = torch.optim.AdamW(model.mask_decoder.parameters(), lr=1e-6)
    scaler = torch.cuda.amp.GradScaler()
    optimizer.zero_grad(set_to_none=True)
    with torch.autocast(device_type="cuda", dtype=torch.float16):
        train_logits, train_quality = model.mask_decoder(
            image_embeddings=embedding.detach(),
            image_pe=model.prompt_encoder.get_dense_pe(),
            sparse_prompt_embeddings=sparse.detach(),
            dense_prompt_embeddings=dense.detach(),
            multimask_output=False,
        )
        target = torch.zeros_like(train_logits)
        target[..., 64:192, 64:192] = 1
        loss = torch.nn.functional.binary_cross_entropy_with_logits(train_logits, target)
        loss = loss + 0.01 * (train_quality.float() - 0.5).square().mean()
    scaler.scale(loss).backward()
    scaler.unscale_(optimizer)
    gradients = [parameter.grad for parameter in model.mask_decoder.parameters() if parameter.grad is not None]
    if not torch.isfinite(loss) or not gradients or any(not torch.isfinite(gradient).all() for gradient in gradients):
        raise RuntimeError("MedSAM decoder AMP backward failed")
    scaler.step(optimizer)
    scaler.update()
    output = {
        "status": "PASS",
        "checkpoint_sha256": MEDSAM_SHA256,
        "input_shape": [1, 3, 1024, 1024],
        "box_prompt_inference": "PASS",
        "image_encoder": "FROZEN",
        "trainable_part": "mask_decoder_only",
        "decoder_amp_backward": "PASS",
        "finite_loss": float(loss.detach()),
        "peak_memory_gib": peak_gib(torch, device),
    }
    del model, image, box, logits, quality, full, embedding, sparse, dense, train_logits, train_quality
    del optimizer, scaler, loss
    gc.collect()
    torch.cuda.empty_cache()
    return output


def exercise_verifier_output_interface(device: str, *, use_amp: bool) -> dict[str, Any]:
    """Smoke the formal dual-head verifier and empty/refer/mask-set interface."""

    import torch
    from server_bundle.screenbus_a0_v2.candidates import FEATURE_NAMES
    from server_bundle.screenbus_a0_v2.metrics import dual_threshold_states
    from server_bundle.screenbus_a0_v2.models import CandidateVerifier

    torch_device = torch.device(device)
    if use_amp and torch_device.type != "cuda":
        raise ValueError("verifier AMP smoke requires a CUDA device")
    if not torch.are_deterministic_algorithms_enabled():
        raise RuntimeError("strict deterministic algorithms must remain enabled for verifier/output smoke")
    torch.manual_seed(2027)
    if torch_device.type == "cuda":
        torch.cuda.manual_seed_all(2027)
    verifier = CandidateVerifier(len(FEATURE_NAMES)).to(torch_device).eval()
    features = torch.arange(
        4 * len(FEATURE_NAMES), dtype=torch.float32, device=torch_device
    ).reshape(4, len(FEATURE_NAMES)) / 37.0
    verifier.set_normalizer(features)
    with torch.no_grad(), torch.autocast(
        device_type=torch_device.type, dtype=torch.float16, enabled=use_amp
    ):
        verifier_output = verifier(features)
        existence = torch.sigmoid(verifier_output["existence_logits"]).float()
        quality = torch.sigmoid(verifier_output["quality_logits"]).float()
        joint_failure_ranking = existence * quality
    if (
        tuple(verifier_output["existence_logits"].shape) != (4,)
        or tuple(verifier_output["quality_logits"].shape) != (4,)
        or not torch.isfinite(existence).all()
        or not torch.isfinite(quality).all()
        or not torch.isfinite(joint_failure_ranking).all()
    ):
        raise RuntimeError("formal CandidateVerifier output interface failed")

    empty_rows = [{"image_id": "empty", "candidate_index": -1, "is_sentinel": 1}]
    single_rows = [{"image_id": "single", "candidate_index": 0, "is_sentinel": 0}]
    multi_rows = [
        {"image_id": "multi", "candidate_index": index, "is_sentinel": 0}
        for index in range(3)
    ]
    existence_scores = existence.detach().cpu().tolist()
    quality_scores = quality.detach().cpu().tolist()

    # First connect the actual formal verifier components to the formal state
    # interface.  Permissive thresholds are deliberate here: G2 checks that a
    # K-candidate mask set is not silently merged, not that an untrained head is
    # scientifically valid.
    formal_states = {
        "empty": dual_threshold_states(
            empty_rows, [float("-inf")], 0.0, [float("-inf")], 0.0
        ),
        "single": dual_threshold_states(
            single_rows, existence_scores[:1], 0.0, quality_scores[:1], 0.0
        ),
        "multi": dual_threshold_states(
            multi_rows, existence_scores[1:], 0.0, quality_scores[1:], 0.0
        ),
    }
    rows_by_role = {"empty": empty_rows, "single": single_rows, "multi": multi_rows}
    outputs = {
        role: [row for row, state in zip(rows_by_role[role], states) if state == "accept"]
        for role, states in formal_states.items()
    }
    counts = {name: len(rows) for name, rows in outputs.items()}
    if counts != {"empty": 0, "single": 1, "multi": 3}:
        raise RuntimeError(f"formal empty/mask-set output counts are wrong: {counts}")
    if [row["candidate_index"] for row in outputs["multi"]] != [0, 1, 2]:
        raise RuntimeError("formal multi-candidate output silently merged or reordered masks")

    # Separately require all three protocol states.  Joint existence*quality is
    # never used to convert a quality-low suspected lesion into an empty output.
    protocol_rows = [
        {"image_id": "empty_state", "candidate_index": 0, "is_sentinel": 0},
        {"image_id": "refer_state", "candidate_index": 0, "is_sentinel": 0},
        {"image_id": "accept_state", "candidate_index": 0, "is_sentinel": 0},
    ]
    protocol_states = dual_threshold_states(
        protocol_rows,
        [0.1, 0.9, 0.9],
        0.5,
        [0.9, 0.1, 0.9],
        0.5,
    )
    if protocol_states != ["empty", "refer", "accept"]:
        raise RuntimeError(f"dual verifier protocol states are wrong: {protocol_states}")
    return {
        "status": "PASS",
        "verifier_interface": "server_bundle.screenbus_a0_v2.models.CandidateVerifier.forward",
        "output_interface": "server_bundle.screenbus_a0_v2.metrics.dual_threshold_states",
        "feature_names": list(FEATURE_NAMES),
        "output_counts": counts,
        "multi_candidate_indices": [row["candidate_index"] for row in outputs["multi"]],
        "protocol_states": protocol_states,
        "normal_fp_gate_component": "existence_probability",
        "quality_low_state": "refer_not_empty",
        "failure_ranking_component": "joint_existence_times_conditional_quality",
        "sentinel_rejected": True,
        "untrained_interface_smoke_no_validity_claim": True,
        "amp_forward": "PASS" if use_amp else "DISABLED_CPU_CONTRACT_TEST",
        "strict_deterministic_algorithms": True,
    }


def probe_determinism(root: Path) -> dict[str, Any]:
    worker = root / "server_bundle" / "g2" / "determinism_worker.py"
    fingerprints: list[str] = []
    outputs: list[dict[str, Any]] = []
    for _ in range(2):
        environment = os.environ.copy()
        environment["CUDA_VISIBLE_DEVICES"] = "0"
        environment["PYTHONHASHSEED"] = "2027"
        environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
        process = subprocess.run(
            [sys.executable, str(worker)], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            check=False, env=environment,
        )
        if process.returncode:
            raise RuntimeError(f"determinism child failed: {process.stderr[-2000:]}")
        payload = json.loads(process.stdout.strip().splitlines()[-1])
        outputs.append(payload)
        fingerprints.append(payload["sha256"])
    if len(set(fingerprints)) != 1:
        raise RuntimeError(f"fresh-process deterministic fingerprints differ: {fingerprints}")
    return {"status": "PASS", "processes": 2, "seed": 2027, "fingerprint_sha256": fingerprints[0], "runs": outputs}


def probe_nnunet(root: Path) -> dict[str, Any]:
    script = root / "server_bundle" / "g2" / "nnunet_probe.py"
    process = subprocess.run(
        [sys.executable, str(script)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        check=False, env=os.environ.copy(),
    )
    log = root / "server_bundle" / "artifacts" / "g2" / "nnunet_driver.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(process.stdout)
    if process.returncode:
        raise RuntimeError(f"nnU-Net G2 probe failed: {process.stdout[-6000:]}")
    payload = json.loads(process.stdout.strip().splitlines()[-1])
    if payload.get("status") != "PASS" or payload.get("training_steps") != 2:
        raise RuntimeError(f"nnU-Net probe returned invalid payload: {payload}")
    if float(payload["peak_memory_gib"]) >= MEMORY_LIMIT_GIB:
        raise RuntimeError("nnU-Net probe exceeded the 22-GiB hard limit")
    return payload


def probe_serial_pipeline(root: Path, device: int = 0) -> dict[str, Any]:
    import torch
    from torchvision.models.detection import fasterrcnn_resnet50_fpn

    torch.cuda.set_device(device)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(device)
    detector = fasterrcnn_resnet50_fpn(
        weights=None,
        weights_backbone=None,
        min_size=256,
        max_size=256,
        box_score_thresh=0.0,
        box_detections_per_img=5,
    )
    state = torch.load(
        Path(os.environ["TORCH_HOME"]) / "hub" / "checkpoints" / "fasterrcnn_resnet50_fpn_coco-258fb6c6.pth",
        map_location="cpu", weights_only=True,
    )
    detector.load_state_dict(state, strict=True)
    detector.to(device).eval()
    image = torch.rand(3, 256, 256, device=f"cuda:{device}")
    with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
        detections = detector([image])[0]
    if len(detections["boxes"]) == 0:
        raise RuntimeError("serial pipeline detector produced no candidate; candidate integration was not exercised")
    box = detections["boxes"][:1].detach() * 4.0
    detector_score = float(detections["scores"][0])
    del detector, state, detections
    gc.collect()
    torch.cuda.empty_cache()
    medsam = load_medsam(root, device)
    medsam.eval()
    image_1024 = torch.nn.functional.interpolate(image[None], (1024, 1024), mode="bilinear", align_corners=False)
    with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
        logits, quality = medsam_forward(medsam, image_1024, box, torch, gradient=False)
    if not torch.isfinite(logits).all() or not torch.isfinite(quality).all():
        raise RuntimeError("serial detector-to-MedSAM logits are non-finite")
    coarse = torch.nn.functional.interpolate(
        torch.sigmoid(logits.float()), (192, 192), mode="bilinear", align_corners=False
    ).detach()
    if tuple(coarse.shape) != (1, 1, 192, 192) or not torch.isfinite(coarse).all():
        raise RuntimeError("serial MedSAM coarse-mask output failed")
    verifier_output = exercise_verifier_output_interface(f"cuda:{device}", use_amp=True)
    output_masks = int((coarse > 0.5).any())
    result = {
        "status": "PASS",
        "order": [
            "Faster R-CNN",
            "MedSAM",
            "CandidateVerifier",
            "Empty/Mask Output",
        ],
        "top_k": 1,
        "detector_score": detector_score,
        "output_mask_sets": output_masks,
        "pointrend_status": "FORBIDDEN_BEFORE_G3_NOT_RUN",
        "verifier_output_interface_smoke": verifier_output,
        "candidate_processing": "sequential",
        "inter_module_graph_release": "PASS",
        "peak_memory_gib": peak_gib(torch, device),
        "performance_interpretation": "PROHIBITED_SYNTHETIC_ENGINEERING_GATE_ONLY",
    }
    del medsam, image, image_1024, box, logits, quality, coarse
    gc.collect()
    torch.cuda.empty_cache()
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command",
        nargs="?",
        choices=("full", "live-hardware"),
        default="full",
    )
    args = parser.parse_args(argv)
    root = Path(os.environ["SCREENBUS_ROOT"]).resolve()
    sys.path.insert(0, str(root))
    if args.command == "live-hardware":
        try:
            container = probe_container_runtime()
            payload = probe_hardware(root, write_artifact=False)
        except Exception as exc:
            print(
                json.dumps(
                    {
                        "status": "FAIL",
                        "mode": "READ_ONLY_LIVE_HARDWARE_REVALIDATION",
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    },
                    sort_keys=True,
                ),
                file=sys.stderr,
            )
            return 30
        print(
            json.dumps(
                {
                    "status": "PASS",
                    "mode": "READ_ONLY_LIVE_HARDWARE_REVALIDATION",
                    "container": container,
                    "hardware": payload,
                },
                sort_keys=True,
            )
        )
        return 0
    required_env = [
        "SCREENBUS_ROOT", "SCREENBUS_DATA_ROOT", "SCREENBUS_CACHE_ROOT",
        "SCREENBUS_OUTPUT_ROOT", "SCREENBUS_WEIGHT_ROOT", "MEDSAM_CKPT",
    ]
    missing = [name for name in required_env if not os.environ.get(name)]
    gate: dict[str, Any] = {
        "schema_version": 1,
        "started_at_utc": utc_now(),
        "status": "FAIL",
        "decision": "SERVER_NOT_READY",
        "profile": "unsupported_or_unknown",
        "required_gpu_topology": "at least device IDs 0,1,2, each RTX 3090 24-GiB class",
        "checks": {},
        "failures": [],
        "engineering_a0_authorized": False,
        "phase1_authorized": False,
        "phase2_authorized": False,
    }
    gate_path = root / "gates" / "G2_SERVER_READY.json"
    if missing:
        gate["failures"].append({"check": "required_environment_variables", "error": f"missing: {missing}"})
        gate["finished_at_utc"] = utc_now()
        atomic_json(gate_path, gate)
        return 30

    os.environ.setdefault("TORCH_HOME", str(Path(os.environ["SCREENBUS_CACHE_ROOT"]).resolve() / "torch"))
    gate["run_fingerprint"] = {
        "started_at_utc": gate["started_at_utc"],
        "g2_doctor_sha256": sha256(Path(__file__).resolve()),
        "python_executable": str(Path(sys.executable).resolve()),
    }
    gate["status"] = "RUNNING"
    atomic_json(gate_path, gate)
    probes: list[tuple[str, Callable[[], dict[str, Any]], bool]] = [
        ("frozen_container_digest_ubuntu_cuda_cudnn", probe_container_runtime, False),
        ("gpu_inventory_and_per_gpu_cuda_amp", lambda: probe_hardware(root), True),
        ("frozen_environment_pip_check_lock", lambda: probe_environment(root), False),
        ("official_data_weights_empty_single_multi", lambda: probe_assets(root), False),
        ("cuda_amp_nms_roi_align", lambda: probe_operators(0), True),
        ("faster_rcnn_fp32_amp_backward", lambda: probe_detection("Faster R-CNN", 0), True),
        ("mask_rcnn_fp32_amp_backward", lambda: probe_detection("Mask R-CNN", 0), True),
        ("medsam_1024_inference_decoder_amp_backward", lambda: probe_medsam(root, 0), True),
        ("nnunet_plan_preprocess_two_step_reload_predict_evaluate", lambda: probe_nnunet(root), True),
        ("two_fresh_process_determinism", lambda: probe_determinism(root), True),
        ("serial_pipeline_peak_memory", lambda: probe_serial_pipeline(root, 0), True),
    ]
    hard_failure = False
    for name, function, _needs_hardware in probes:
        if hard_failure:
            gate["checks"][name] = {
                "status": "BLOCKED",
                "reason": "prior hard G2 requirement failed; fail-fast contract stopped execution",
            }
            continue
        try:
            value = function()
            gate["checks"][name] = value
            if name == "gpu_inventory_and_per_gpu_cuda_amp":
                gate["gpu_inventory"] = value
                gate["profile"] = "server_rtx3090_linux"
        except Exception as exc:  # every exception is captured in the machine-readable hard gate
            gate["checks"][name] = {
                "status": "FAIL",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "traceback": traceback.format_exc(limit=12),
            }
            gate["failures"].append({"check": name, "error_type": type(exc).__name__, "error": str(exc)})
            hard_failure = True
    memory_checks: dict[str, float] = {}
    for name, value in gate["checks"].items():
        if isinstance(value, dict) and "peak_memory_gib" in value:
            memory_checks[name] = float(value["peak_memory_gib"])
    inventory = gate.get("gpu_inventory", {})
    for device in inventory.get("devices", []):
        memory_checks[f"per_gpu_cuda_amp_device_{device['id']}"] = float(device["peak_memory_gib"])
    memory_status = (
        "PASS"
        if memory_checks and all(value < MEMORY_LIMIT_GIB for value in memory_checks.values())
        else ("BLOCKED" if gate["failures"] and not memory_checks else "FAIL")
    )
    gate["memory_limit"] = {
        "status": memory_status,
        "limit_gib_strictly_below": MEMORY_LIMIT_GIB,
        "observed_peak_gib": memory_checks,
    }
    if gate["memory_limit"]["status"] == "FAIL":
        gate["failures"].append({"check": "memory_limit", "error": "missing or >=22-GiB peak measurement"})
    passed = not gate["failures"] and all(
        isinstance(check, dict) and check.get("status") == "PASS" for check in gate["checks"].values()
    )
    gate["status"] = "PASS" if passed else "FAIL"
    gate["decision"] = "SERVER_READY" if passed else "SERVER_NOT_READY"
    gate["engineering_a0_authorized"] = passed
    gate["phase1_authorized"] = False
    gate["phase2_authorized"] = False
    gate["authorization_note"] = "G2 authorizes ENGINEERING_A0 only; Phase-1 requires its pass and Phase-2 remains gated by G3."
    gate["finished_at_utc"] = utc_now()
    gate["input_fingerprints"] = {
        "g2_doctor_sha256": sha256(Path(__file__).resolve()),
        "requirements_sha256": sha256(root / "server_bundle" / "env" / "requirements-cuda121.lock.txt"),
        "portable_evidence_manifest_sha256": sha256(root / "bootstrap" / "evidence" / "MANIFEST.sha256"),
        "prepare_manifest_sha256": sha256_or_missing(root / "server_bundle" / "artifacts" / "data" / "prepare_manifest.json"),
        "weight_manifest_sha256": sha256_or_missing(root / "server_bundle" / "artifacts" / "weights" / "weight_manifest.json"),
    }
    atomic_json(gate_path, gate)
    server_manifest = {
        "schema_version": 1,
        "created_at_utc": utc_now(),
        "status": gate["status"],
        "profile": gate["profile"],
        "g2_gate": str(gate_path.relative_to(root)),
        "g2_gate_sha256": sha256(gate_path),
        "gpu_inventory": "server_bundle/artifacts/system/gpu_inventory.json",
        "engineering_a0_authorized": gate["engineering_a0_authorized"],
    }
    atomic_json(root / "server_bundle" / "artifacts" / "environment" / "server_manifest.json", server_manifest)
    print(json.dumps({"decision": gate["decision"], "gate": str(gate_path), "failures": gate["failures"]}))
    return 0 if passed else 30


if __name__ == "__main__":
    raise SystemExit(main())
