# G2_SERVER_ENGINEERING：环境与资产门

G2 只验证服务器工程可执行性：冻结环境、依赖锁、官方数据与权重哈希、GPU 0/1/2、CUDA/AMP、NMS/ROIAlign、Faster/Mask R-CNN、MedSAM、nnU-Net 工程链、确定性和串行候选管线峰值显存。所有模块实测峰值必须严格低于 22 GiB。

G2 不运行 PointRend，不产生论文指标，也不授权 Phase-1 或 Phase-2。G2 通过只设置 `engineering_a0_authorized=true`；Phase-1 还必须等待 `ENGINEERING_A0_PASS`，Phase-2 还必须等待完整五折后的 fresh `GO_EXPAND_TO_PHASE2`。

BUS-UCLM clean 是唯一正式主证据。BUSI 不属于 G2 硬资产，只能作为可选图像级 sanity check，缺失不阻断方法论文。BrEaST 和 BUS-BRA 也不作为 Phase-1 的前置硬门。

授权、资产完整性、网络和 G2 工程失败必须分别保留机器可读错误；任何未运行阶段必须写 `NOT_RUN`，不得用本地静态检查冒充服务器执行。
