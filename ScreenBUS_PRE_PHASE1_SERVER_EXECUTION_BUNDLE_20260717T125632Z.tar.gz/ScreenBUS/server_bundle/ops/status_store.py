#!/usr/bin/env python3
"""Atomic storage for the ScreenBUS v2.3 server state machine."""

from __future__ import annotations

import copy
import fcntl
import json
import os
import socket
import tempfile
import uuid
from contextlib import AbstractContextManager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 2
WORKFLOW_NAME = "screenbus_v2_3_method_protocol"
STAGE_ORDER = (
    "P0_PROTOCOL_REPAIR",
    "G2_SERVER_ENGINEERING",
    "ENGINEERING_A0",
    "PHASE1_FIVE_FOLD_ONE_SEED",
    "G3_METHOD_GATE",
    "PHASE2_THREE_SEEDS_AND_FULL_BASELINES",
    "EXTERNAL_POSITIVE_STRESS",
    "RESULT_FREEZE",
)
STAGE_STATES = {"PENDING", "RUNNING", "PASSED", "SKIPPED", "BLOCKED", "FAILED"}
WORKFLOW_STATES = {
    "NOT_STARTED",
    "RUNNING",
    "BLOCKED",
    "FAILED",
    "SCIENTIFIC_NO_GO",
    "NO_DECISION_INSUFFICIENT_EVIDENCE",
    "COMPLETE",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_status(root: Path) -> dict[str, Any]:
    now = utc_now()
    return {
        "schema_version": SCHEMA_VERSION,
        "protocol_version": "2.3",
        "workflow": WORKFLOW_NAME,
        "stage_order": list(STAGE_ORDER),
        "run_id": datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8],
        "state": "NOT_STARTED",
        "current_stage": None,
        "profile": "UNVERIFIED",
        "root": str(root.resolve()),
        "hostname": socket.gethostname(),
        "pid": None,
        "created_at": now,
        "started_at": None,
        "updated_at": now,
        "finished_at": None,
        "message": "Workflow has not started.",
        "resume_command": "./server_bundle/screenbus_server.sh resume",
        "decisions": {"g2": None, "engineering_a0": None, "g3": None},
        "claim_boundary": "CLINICAL_SCREENING_CLAIM_BLOCKED_MISSING_INDEPENDENT_NORMAL_PATIENT_COHORT",
        "resource_policy": {
            "gpu_ids": ["0", "1", "2"],
            "per_gpu_concurrency": 2,
            "min_free_vram_gib": 3.0,
            "heavy_exclusive": True,
            "oom_max_retries": 0,
            "resource_aware_required": True,
            "memory_gib": {"light": 4.0, "medium": 10.0, "heavy": 20.0},
            "admission_rule": "estimated_gib + min_free_vram_gib must fit; heavy jobs are exclusive",
        },
        "resources": {
            "observed_at": None,
            "gpu": {"status": "UNVERIFIED", "devices": []},
            "scheduler": {"status": "NOT_STARTED", "queued": 0, "running": 0, "completed": 0, "failed": 0},
        },
        "artifacts": {},
        "stages": {
            stage: {
                "state": "PENDING",
                "attempt": 0,
                "started_at": None,
                "finished_at": None,
                "exit_code": None,
                "message": None,
                "command": None,
                "log": None,
                "artifacts": [],
                "output_bindings": {},
            }
            for stage in STAGE_ORDER
        },
    }


def validate_status(status: dict[str, Any]) -> None:
    if status.get("schema_version") != SCHEMA_VERSION or status.get("protocol_version") != "2.3":
        raise ValueError("Unsupported STATUS.json schema/protocol")
    if status.get("workflow") != WORKFLOW_NAME or status.get("stage_order") != list(STAGE_ORDER):
        raise ValueError("STATUS.json belongs to a different workflow")
    if status.get("state") not in WORKFLOW_STATES:
        raise ValueError(f"Invalid workflow state: {status.get('state')!r}")
    stages = status.get("stages")
    if not isinstance(stages, dict) or set(stages) != set(STAGE_ORDER):
        raise ValueError("STATUS.json stage set drift")
    for stage in STAGE_ORDER:
        if stages[stage].get("state") not in STAGE_STATES:
            raise ValueError(f"Invalid state for stage {stage}")


def load_status(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        status = json.load(handle)
    if not isinstance(status, dict):
        raise ValueError("STATUS.json root must be an object")
    validate_status(status)
    return status


def atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
    finally:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass


def load_or_create(path: Path, root: Path) -> dict[str, Any]:
    if path.exists():
        return load_status(path)
    status = new_status(root)
    atomic_write_json(path, status)
    return status


def save_status(path: Path, status: dict[str, Any]) -> None:
    value = copy.deepcopy(status)
    value["updated_at"] = utc_now()
    validate_status(value)
    atomic_write_json(path, value)


def set_workflow_state(status: dict[str, Any], state: str, message: str, *, current_stage: str | None = None, finished: bool = False) -> None:
    if state not in WORKFLOW_STATES:
        raise ValueError(f"Invalid workflow state: {state}")
    status.update(state=state, message=message, current_stage=current_stage, pid=os.getpid() if state == "RUNNING" else None)
    if status.get("started_at") is None and state != "NOT_STARTED":
        status["started_at"] = utc_now()
    if finished:
        status["finished_at"] = utc_now()


def start_stage(status: dict[str, Any], stage: str, command: list[str], log: Path) -> None:
    if stage not in STAGE_ORDER:
        raise KeyError(stage)
    index = STAGE_ORDER.index(stage)
    for previous in STAGE_ORDER[:index]:
        if status["stages"][previous]["state"] not in {"PASSED", "SKIPPED"}:
            raise ValueError(f"NON_ADJACENT_STAGE_START_FORBIDDEN: {previous} is not complete")
    record = status["stages"][stage]
    if record["state"] == "PASSED":
        raise ValueError(f"Refusing to restart passed stage {stage}")
    record.update(state="RUNNING", attempt=int(record.get("attempt", 0)) + 1, started_at=utc_now(), finished_at=None, exit_code=None, message="Stage is running.", command=command, log=str(log), artifacts=[], output_bindings={})
    set_workflow_state(status, "RUNNING", f"Running stage: {stage}", current_stage=stage)


def finish_stage(status: dict[str, Any], stage: str, state: str, *, exit_code: int, message: str, artifacts: list[str] | None = None) -> None:
    if state not in STAGE_STATES - {"PENDING", "RUNNING"}:
        raise ValueError(f"Invalid terminal stage state: {state}")
    status["stages"][stage].update(state=state, finished_at=utc_now(), exit_code=exit_code, message=message, artifacts=artifacts or [])


def skip_remaining(status: dict[str, Any], after_stage: str, message: str) -> None:
    for stage in STAGE_ORDER[STAGE_ORDER.index(after_stage) + 1 :]:
        if status["stages"][stage]["state"] == "PENDING":
            finish_stage(status, stage, "SKIPPED", exit_code=0, message=message)


class SingleRunLock(AbstractContextManager["SingleRunLock"]):
    def __init__(self, path: Path):
        self.path = path
        self._handle: Any = None

    def __enter__(self) -> "SingleRunLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._handle = self.path.open("a+", encoding="utf-8")
        try:
            fcntl.flock(self._handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            self._handle.close()
            raise RuntimeError("Another ScreenBUS server workflow holds the run lock") from exc
        self._handle.seek(0)
        self._handle.truncate()
        self._handle.write(f"pid={os.getpid()} started={utc_now()}\n")
        self._handle.flush()
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self._handle is not None:
            fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
            self._handle.close()
            self._handle = None
