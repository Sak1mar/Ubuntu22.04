#!/usr/bin/env python3
"""Fail-closed ScreenBUS v2.3 server orchestrator."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

try:
    from .archive_results import create_archive, verify_archive
    from .g3_validation import G3ValidationError, validate_g3_go_payload
    from .resources import refresh_resources
    from .status_store import (
        STAGE_ORDER,
        SingleRunLock,
        finish_stage,
        load_or_create,
        load_status,
        save_status,
        set_workflow_state,
        skip_remaining,
        start_stage,
        utc_now,
    )
except ImportError:
    from archive_results import create_archive, verify_archive
    from g3_validation import G3ValidationError, validate_g3_go_payload
    from resources import refresh_resources
    from status_store import (
        STAGE_ORDER,
        SingleRunLock,
        finish_stage,
        load_or_create,
        load_status,
        save_status,
        set_workflow_state,
        skip_remaining,
        start_stage,
        utc_now,
    )


EXIT_OK = 0
EXIT_LOCKED = 10
EXIT_FAILED = 20
EXIT_BLOCKED = 30
EXIT_SCIENTIFIC_STOP = 40
G3_TERMINAL_STOPS = {
    "NO_GO_AUTOMATIC_PROMPT",
    "NO_GO_MEDSAM_ROUTE",
    "NO_GO_CANDIDATE_POOL",
    "NO_GO_VERIFIER",
    "NO_DECISION_INSUFFICIENT_EVIDENCE",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fingerprint(path: Path) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"BOUND_OUTPUT_MISSING_OR_UNSAFE: {path}")
    return {"bytes": path.stat().st_size, "sha256": sha256_file(path)}


def bind_outputs(paths: list[Path]) -> dict[str, dict[str, Any]]:
    return {str(path.resolve()): fingerprint(path) for path in paths}


def validate_output_bindings(paths: list[Path], bindings: Any) -> tuple[bool, str]:
    if not isinstance(bindings, dict) or set(bindings) != {str(path.resolve()) for path in paths}:
        return False, "output binding set drift"
    for path in paths:
        try:
            observed = fingerprint(path)
        except RuntimeError as exc:
            return False, str(exc)
        if bindings[str(path.resolve())] != observed:
            return False, f"bound output drifted: {path}"
    return True, "all bound outputs match"


def validate_g2_payload(payload: dict[str, Any], decision: str) -> tuple[bool, str]:
    if decision != "SERVER_READY" or payload.get("status") != "PASS":
        return False, f"G2 decision/status invalid: {decision}/{payload.get('status')}"
    if payload.get("engineering_a0_authorized") is not True:
        return False, "G2 engineering authorization missing"
    if payload.get("profile") != "server_rtx3090_linux" or payload.get("failures"):
        return False, "G2 profile/failures invalid"
    devices = payload.get("gpu_inventory", {}).get("devices", [])
    by_id = {int(device.get("id", -1)): device for device in devices if isinstance(device, dict)}
    if set(by_id) != {0, 1, 2}:
        return False, "G2 must validate GPU IDs 0,1,2"
    for device_id, device in by_id.items():
        if "RTX 3090" not in str(device.get("name", device.get("torch_name", ""))):
            return False, f"GPU {device_id} is not RTX 3090"
        if device.get("cuda_smoke") != "PASS" or device.get("amp_fp16_smoke") != "PASS":
            return False, f"GPU {device_id} CUDA/AMP check failed"
    return True, "SERVER_READY"


def _env(root: Path) -> dict[str, str]:
    bundle = root / "server_bundle"
    runtime = Path(os.environ.get("SCREENBUS_RUNTIME_ROOT", bundle / "runtime")).resolve()
    result = os.environ.copy()
    defaults = {
        "SCREENBUS_ROOT": root,
        "SCREENBUS_RUNTIME_ROOT": runtime,
        "SCREENBUS_DATA_ROOT": runtime / "data",
        "SCREENBUS_CACHE_ROOT": runtime / "cache",
        "SCREENBUS_OUTPUT_ROOT": runtime / "output",
        "SCREENBUS_WEIGHT_ROOT": runtime / "weights",
        "SCREENBUS_ENV_DIR": bundle / ".server_env",
        "MEDSAM_CKPT": runtime / "weights" / "medsam_vit_b.pth",
        "TORCH_HOME": runtime / "cache" / "torch",
        "YOLO_CONFIG_DIR": runtime / "cache" / "ultralytics_config",
    }
    for key, default in defaults.items():
        result[key] = str(Path(result.get(key, default)).resolve())
    for key in ("SCREENBUS_RUNTIME_ROOT", "SCREENBUS_DATA_ROOT", "SCREENBUS_CACHE_ROOT", "SCREENBUS_OUTPUT_ROOT", "SCREENBUS_WEIGHT_ROOT"):
        Path(result[key]).mkdir(parents=True, exist_ok=True)
    result.update(
        GPU_IDS=result.get("GPU_IDS", "0,1,2"),
        SCREENBUS_PER_GPU_CONCURRENCY=result.get("SCREENBUS_PER_GPU_CONCURRENCY", "2"),
        SCREENBUS_MIN_FREE_VRAM_GIB=result.get("SCREENBUS_MIN_FREE_VRAM_GIB", "3"),
        SCREENBUS_OOM_MAX_RETRIES=result.get("SCREENBUS_OOM_MAX_RETRIES", "0"),
        PYTHONHASHSEED="2027",
    )
    result["PYTHONPATH"] = str(bundle) + (os.pathsep + result["PYTHONPATH"] if result.get("PYTHONPATH") else "")
    if result["GPU_IDS"] != "0,1,2":
        raise RuntimeError("GPU_POLICY_INVALID: GPU_IDS must be exactly 0,1,2")
    return result


class Workflow:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.bundle = self.root / "server_bundle"
        self.status_path = self.bundle / "STATUS.json"
        self.log_dir = self.bundle / "runtime" / "logs"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.env = _env(self.root)
        self.env_python = Path(self.env["SCREENBUS_ENV_DIR"]) / "bin" / "python"
        self.status = load_or_create(self.status_path, self.root)
        if self.status.get("root") != str(self.root):
            raise RuntimeError("ROOT_DRIFT")
        runtime_keys = (
            "SCREENBUS_RUNTIME_ROOT", "SCREENBUS_DATA_ROOT", "SCREENBUS_CACHE_ROOT",
            "SCREENBUS_OUTPUT_ROOT", "SCREENBUS_WEIGHT_ROOT", "SCREENBUS_ENV_DIR",
            "MEDSAM_CKPT", "TORCH_HOME", "YOLO_CONFIG_DIR", "GPU_IDS",
            "SCREENBUS_PER_GPU_CONCURRENCY", "SCREENBUS_MIN_FREE_VRAM_GIB",
            "SCREENBUS_OOM_MAX_RETRIES",
        )
        current = {key: self.env[key] for key in runtime_keys}
        if self.status.get("runtime_paths") not in (None, current):
            raise RuntimeError("RUNTIME_PATH_DRIFT")
        self.status["runtime_paths"] = current
        refresh_resources(self.status, Path(self.env["SCREENBUS_OUTPUT_ROOT"]), self.env)
        save_status(self.status_path, self.status)

    @property
    def paths(self) -> dict[str, Path]:
        output = Path(self.env["SCREENBUS_OUTPUT_ROOT"])
        return {
            "protocol": self.root / "gates" / "V2_3_PRETRAINING_STATUS.json",
            "g2": self.root / "gates" / "G2_SERVER_READY.json",
            "engineering": self.root / "gates" / "ENGINEERING_A0_STATUS.json",
            "phase1_complete": output / "phase1" / "PHASE1_COMPLETE.json",
            "phase1_report": output / "phase1" / "PHASE1_FIVE_FOLD_REPORT.json",
            "g3": self.root / "gates" / "G3_A0_DECISION.json",
            "phase2": self.root / "reports" / "full_aggregate.json",
            "external": self.root / "reports" / "external_positive_stress.json",
            "final": self.bundle / "reports" / "FINAL_RESULT_SUMMARY.md",
        }

    def commands(self) -> dict[str, list[list[str]]]:
        py = str(self.env_python)
        v2 = self.bundle / "screenbus_a0_v2"
        return {
            "G2_SERVER_ENGINEERING": [
                [py, str(self.bundle / "data" / "official_assets.py"), "fetch-busuclm"],
                [py, str(self.bundle / "data" / "official_assets.py"), "fetch-busbra"],
                [py, str(self.bundle / "data" / "official_assets.py"), "prepare-busuclm"],
                [py, str(self.bundle / "data" / "official_assets.py"), "fetch-weights"],
                [py, str(self.bundle / "g2" / "g2_doctor.py")],
            ],
            "ENGINEERING_A0": [[py, "-m", "screenbus_a0_v2.cli", "engineering-a0", "--config", str(v2 / "configs" / "engineering_a0.yaml")]],
            "PHASE1_FIVE_FOLD_ONE_SEED": [[py, "-m", "screenbus_a0_v2.cli", "phase1", "--config", str(v2 / "configs" / "server_a0.yaml")]],
            "G3_METHOD_GATE": [[py, "-m", "screenbus_a0_v2.cli", "g3", "--config", str(v2 / "configs" / "server_a0.yaml")]],
            "PHASE2_THREE_SEEDS_AND_FULL_BASELINES": [[py, "-m", "screenbus_a0_v2.cli", "phase2", "--config", str(v2 / "configs" / "full_cv.yaml")]],
            "RESULT_FREEZE": [[sys.executable, str(self.bundle / "ops" / "inspect_results.py"), "--root", str(self.root), "--status", str(self.status_path), "--write", str(self.paths["final"])]],
        }

    def expected(self, stage: str) -> list[Path]:
        return {
            "P0_PROTOCOL_REPAIR": [self.paths["protocol"]],
            "G2_SERVER_ENGINEERING": [self.paths["g2"]],
            "ENGINEERING_A0": [self.paths["engineering"]],
            "PHASE1_FIVE_FOLD_ONE_SEED": [self.paths["phase1_complete"], self.paths["phase1_report"]],
            "G3_METHOD_GATE": [self.paths["g3"], self.paths["phase1_complete"], self.paths["phase1_report"]],
            "PHASE2_THREE_SEEDS_AND_FULL_BASELINES": [self.paths["phase2"]],
            "EXTERNAL_POSITIVE_STRESS": [self.paths["external"]],
            "RESULT_FREEZE": [self.paths["final"]],
        }[stage]

    def _save(self) -> None:
        refresh_resources(self.status, Path(self.env["SCREENBUS_OUTPUT_ROOT"]), self.env)
        save_status(self.status_path, self.status)

    def _run_commands(self, stage: str, commands: list[list[str]]) -> int:
        log = self.log_dir / f"{stage}.log"
        environment = self.env.copy()
        environment["SCREENBUS_ACTIVE_STAGE"] = stage
        with log.open("a", encoding="utf-8") as handle:
            handle.write(f"\n[{utc_now()}] stage={stage}\n")
            for command in commands:
                handle.write("COMMAND " + " ".join(command) + "\n")
                handle.flush()
                result = subprocess.run(command, cwd=self.root, env=environment, stdout=handle, stderr=subprocess.STDOUT, check=False)
                if result.returncode != 0:
                    return int(result.returncode)
        return 0

    def _pass_stage(self, stage: str, message: str) -> None:
        paths = self.expected(stage)
        bindings = bind_outputs(paths)
        record = self.status["stages"][stage]
        record["output_bindings"] = bindings
        finish_stage(self.status, stage, "PASSED", exit_code=0, message=message, artifacts=[str(path) for path in paths])
        self._save()

    def _run_stage(self, stage: str) -> int:
        record = self.status["stages"][stage]
        if record["state"] == "PASSED":
            valid, reason = validate_output_bindings(self.expected(stage), record.get("output_bindings"))
            if valid:
                return 0
            return self._fail(stage, "PASSED_STAGE_OUTPUT_DRIFT: " + reason)
        commands = self.commands().get(stage, [])
        start_stage(self.status, stage, commands, self.log_dir / f"{stage}.log")
        self._save()
        code = self._run_commands(stage, commands)
        if code != 0:
            return self._fail(stage, f"stage command failed with exit={code}", code)
        try:
            self._pass_stage(stage, f"{stage} completed with bound outputs")
        except Exception as exc:
            return self._fail(stage, f"stage output validation failed: {exc}")
        return 0

    def _fail(self, stage: str, message: str, code: int = EXIT_FAILED) -> int:
        finish_stage(self.status, stage, "FAILED", exit_code=code, message=message)
        set_workflow_state(self.status, "FAILED", message, current_stage=stage, finished=True)
        self._save()
        print(message, file=sys.stderr)
        return code

    def _p0(self) -> int:
        stage = "P0_PROTOCOL_REPAIR"
        if self.status["stages"][stage]["state"] == "PASSED":
            return self._run_stage(stage)
        start_stage(self.status, stage, [["internal:validate_protocol_v2_3"]], self.log_dir / f"{stage}.log")
        self._save()
        payload = json.loads(self.paths["protocol"].read_text(encoding="utf-8"))
        if payload.get("status") != "PROTOCOL_V2_3_READY" or payload.get("source_repair") != "SOURCE_REPAIR_PASS" or payload.get("training_run") is not False:
            return self._fail(stage, "P0 protocol status is not ready")
        self._pass_stage(stage, "PROTOCOL_V2_3_READY")
        return 0

    def _g2(self) -> int:
        code = self._run_stage("G2_SERVER_ENGINEERING")
        if code:
            return code
        payload = json.loads(self.paths["g2"].read_text(encoding="utf-8"))
        valid, reason = validate_g2_payload(payload, str(payload.get("decision", "")))
        if not valid:
            return self._fail("G2_SERVER_ENGINEERING", reason, EXIT_BLOCKED)
        self.status["decisions"]["g2"] = "SERVER_READY"
        self.status["profile"] = "server_rtx3090_linux"
        self._save()
        return 0

    def _g3(self) -> int:
        code = self._run_stage("G3_METHOD_GATE")
        if code:
            return code
        gate = json.loads(self.paths["g3"].read_text(encoding="utf-8"))
        decision = str(gate.get("decision", ""))
        self.status["decisions"]["g3"] = decision
        stage = self.status["stages"]["G3_METHOD_GATE"]
        gate_fp = fingerprint(self.paths["g3"])
        stage["gate_binding"] = {
            "path": str(self.paths["g3"].resolve()),
            **gate_fp,
            "decision": decision,
            "status_run_id": self.status["run_id"],
            "g3_attempt": int(stage["attempt"]),
            "g2_gate_sha256": sha256_file(self.paths["g2"]),
        }
        self._save()
        if decision == "GO_EXPAND_TO_PHASE2":
            try:
                validate_g3_go_payload(gate, root=self.root)
            except G3ValidationError as exc:
                return self._fail("G3_METHOD_GATE", f"invalid GO: {exc}")
            return 0
        if decision in G3_TERMINAL_STOPS:
            skip_remaining(self.status, "G3_METHOD_GATE", f"G3 terminal decision: {decision}")
            state = "NO_DECISION_INSUFFICIENT_EVIDENCE" if decision.startswith("NO_DECISION") else "SCIENTIFIC_NO_GO"
            set_workflow_state(self.status, state, f"G3={decision}; Phase-2 and later stages NOT_RUN", finished=True)
            self._save()
            return EXIT_SCIENTIFIC_STOP
        return self._fail("G3_METHOD_GATE", f"unsupported G3 decision: {decision}")

    def _external(self) -> int:
        stage = "EXTERNAL_POSITIVE_STRESS"
        if self.status["stages"][stage]["state"] == "PASSED":
            return self._run_stage(stage)
        start_stage(self.status, stage, [["internal:external_positive_stress"]], self.log_dir / f"{stage}.log")
        self._save()
        self.paths["external"].parent.mkdir(parents=True, exist_ok=True)
        self.paths["external"].write_text(json.dumps({
            "schema_version": 1,
            "protocol_version": "2.3",
            "status": "NOT_RUN_DATASET_NOT_CONFIGURED",
            "role": "POST_PHASE1_EXTERNAL_POSITIVE_LESION_STRESS_ONLY",
            "normal_patient_rule": "FOUR_NORMAL_PATIENTS_CASE_BY_CASE_DESCRIPTION_ONLY",
            "paper_blocker": False,
        }, indent=2) + "\n", encoding="utf-8")
        self._pass_stage(stage, "External positive stress recorded as optional NOT_RUN")
        return 0

    def _freeze(self) -> int:
        code = self._run_stage("RESULT_FREEZE")
        if code:
            return code
        result = create_archive(self.root, self.status_path, self.bundle / "results")
        result["verification"] = verify_archive(Path(result["archive"]), Path(result["manifest"]), Path(result["sha256_file"]))
        self.status["artifacts"]["results_archive"] = result
        set_workflow_state(self.status, "COMPLETE", "ScreenBUS v2.3 workflow complete and result-frozen", finished=True)
        self._save()
        return 0

    def run(self) -> int:
        if self.status["state"] == "COMPLETE":
            return 0
        set_workflow_state(self.status, "RUNNING", "ScreenBUS v2.3 workflow started or resumed")
        self._save()
        for action in (self._p0, self._g2):
            code = action()
            if code:
                return code
        code = self._run_stage("ENGINEERING_A0")
        if code:
            return code
        engineering = json.loads(self.paths["engineering"].read_text(encoding="utf-8"))
        if engineering.get("decision") != "ENGINEERING_A0_PASS":
            return self._fail("ENGINEERING_A0", "engineering checks did not pass", EXIT_BLOCKED)
        self.status["decisions"]["engineering_a0"] = "ENGINEERING_A0_PASS"
        self._save()
        code = self._run_stage("PHASE1_FIVE_FOLD_ONE_SEED")
        if code:
            return code
        code = self._g3()
        if code:
            return code
        code = self._run_stage("PHASE2_THREE_SEEDS_AND_FULL_BASELINES")
        if code:
            return code
        code = self._external()
        if code:
            return code
        return self._freeze()


def render_status(status: dict[str, Any]) -> str:
    lines = [
        f"run_id: {status['run_id']}",
        f"protocol_version: {status['protocol_version']}",
        f"state: {status['state']}",
        f"current_stage: {status.get('current_stage')}",
        f"g2: {status.get('decisions', {}).get('g2')}",
        f"engineering_a0: {status.get('decisions', {}).get('engineering_a0')}",
        f"g3: {status.get('decisions', {}).get('g3')}",
        "stages:",
    ]
    for stage in STAGE_ORDER:
        row = status["stages"][stage]
        lines.append(f"  {stage}: {row['state']} attempt={row['attempt']} exit={row['exit_code']}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    run.add_argument("--root", type=Path, required=True)
    status_cmd = sub.add_parser("status")
    status_cmd.add_argument("--status", type=Path, required=True)
    status_cmd.add_argument("--json", action="store_true")
    args = parser.parse_args()
    if args.command == "status":
        if not args.status.is_file():
            print(f"STATUS_NOT_CREATED: {args.status}", file=sys.stderr)
            return 3
        status = load_status(args.status)
        print(json.dumps(status, indent=2, sort_keys=True, ensure_ascii=False) if args.json else render_status(status))
        return 0
    root = args.root.resolve()
    try:
        with SingleRunLock(root / "server_bundle" / "runtime" / "run.lock"):
            return Workflow(root).run()
    except RuntimeError as exc:
        if "run lock" in str(exc):
            print(str(exc), file=sys.stderr)
            return EXIT_LOCKED
        raise


if __name__ == "__main__":
    raise SystemExit(main())
