"""Operations-layer import of the single ScreenBUS v2.3 G3 validator."""

try:
    from server_bundle.screenbus_a0_v2.g3_validation import (  # noqa: F401
        G3ValidationError,
        GO_DECISIONS,
        ValidatedG3,
        compute_screenbus_a0_v2_code_tree_sha256,
        validate_g3_go_payload,
    )
except ImportError:
    from screenbus_a0_v2.g3_validation import (  # type: ignore[no-redef] # noqa: F401
        G3ValidationError,
        GO_DECISIONS,
        ValidatedG3,
        compute_screenbus_a0_v2_code_tree_sha256,
        validate_g3_go_payload,
    )


__all__ = [
    "G3ValidationError",
    "GO_DECISIONS",
    "ValidatedG3",
    "compute_screenbus_a0_v2_code_tree_sha256",
    "validate_g3_go_payload",
]
