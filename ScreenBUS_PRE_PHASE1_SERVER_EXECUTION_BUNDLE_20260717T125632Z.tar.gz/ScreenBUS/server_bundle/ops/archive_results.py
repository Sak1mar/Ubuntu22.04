#!/usr/bin/env python3
"""Create and verify the small, auditable ScreenBUS result archive.

The archive deliberately excludes raw datasets, model weights, environments,
and checkpoints. It is a result/provenance archive, not the G4 code package.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

try:
    from .status_store import atomic_write_json, load_status
except ImportError:  # Direct script execution.
    from status_store import atomic_write_json, load_status


EXCLUDED_PARTS = {
    ".server_env",
    "checkpoints",
    "__pycache__",
}
FORBIDDEN_RESULT_SUFFIXES = frozenset(
    {
        ".7z",
        ".avi",
        ".bmp",
        ".bz2",
        ".ckpt",
        ".dcm",
        ".dicom",
        ".feather",
        ".gif",
        ".gz",
        ".h5",
        ".hdf5",
        ".jpeg",
        ".jpg",
        ".mat",
        ".mha",
        ".mhd",
        ".mp4",
        ".nii",
        ".npy",
        ".npz",
        ".nrrd",
        ".onnx",
        ".parquet",
        ".pickle",
        ".pkl",
        ".pt",
        ".pth",
        ".rar",
        ".safetensors",
        ".tar",
        ".tgz",
        ".tif",
        ".tiff",
        ".webp",
        ".xz",
        ".zip",
    }
)
RESULT_METADATA_SUFFIXES = frozenset({".csv", ".json", ".log", ".md", ".txt"})
RESULT_CONFIG_SUFFIXES = frozenset({".json", ".yaml", ".yml"})
FAILURE_CASE_SUFFIXES = frozenset({".json", ".png"})
MAX_RESULT_FILE_BYTES = 64 * 1024 * 1024
MAX_RESULT_TOTAL_BYTES = 512 * 1024 * 1024


def _has_forbidden_result_suffix(path: PurePosixPath) -> bool:
    name = path.name.lower()
    return any(name.endswith(suffix) for suffix in FORBIDDEN_RESULT_SUFFIXES)


def _allowed_result_relative(path: PurePosixPath) -> bool:
    """Mirror the creator's allow-listed result/provenance roots."""
    if _has_forbidden_result_suffix(path):
        return False
    parts = path.parts
    if path == PurePosixPath("server_bundle/STATUS.json"):
        return True
    suffix = path.suffix.lower()
    if len(parts) == 3 and parts[:2] == ("server_bundle", "gates"):
        return suffix in {".json", ".md"}
    if len(parts) >= 3 and parts[:2] == ("server_bundle", "artifacts"):
        return suffix in RESULT_METADATA_SUFFIXES
    if len(parts) >= 3 and parts[:2] == ("server_bundle", "reports"):
        return suffix in RESULT_METADATA_SUFFIXES
    if len(parts) == 4 and parts[:3] == ("server_bundle", "runtime", "logs"):
        return suffix == ".log"
    if len(parts) >= 4 and parts[:3] == (
        "server_bundle",
        "screenbus_a0_v2",
        "configs",
    ):
        return suffix in RESULT_CONFIG_SUFFIXES
    if len(parts) == 2 and parts[0] == "gates" and parts[1] in {
        "G2_SERVER_READY.json",
        "G3_A0_DECISION.json",
        "G3_A0_DECISION.md",
    }:
        return True
    if len(parts) == 2 and parts[0] == "reports":
        name = parts[1]
        return (
            (name.startswith("phase1_") and suffix in {".csv", ".json"})
            or (name.startswith("full_") and suffix in {".csv", ".json"})
            or (name.startswith("FINAL_") and suffix == ".md")
        )
    if len(parts) >= 3 and parts[:2] in {
        ("reports", "phase1_failure_cases"),
        ("reports", "full_failure_cases"),
    }:
        return suffix in FAILURE_CASE_SUFFIXES
    return False


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
    finally:
        Path(tmp_name).unlink(missing_ok=True)


def _load_json_strict(path: Path) -> dict[str, Any]:
    def no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON key in manifest: {key}")
            result[key] = value
        return result

    value = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=no_duplicate_keys)
    if not isinstance(value, dict):
        raise ValueError("Manifest root must be an object")
    return value


def _validate_result_manifest(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    if manifest.get("schema_version") != 1 or manifest.get("archive_kind") != "SCREENBUS_RESULTS_AND_PROVENANCE_NOT_G4_CODE_PACKAGE":
        raise ValueError("Invalid result manifest schema or archive_kind")
    entries = manifest.get("files")
    if not isinstance(entries, list) or not isinstance(manifest.get("file_count"), int):
        raise ValueError("Result manifest files/file_count types are invalid")
    if manifest["file_count"] != len(entries):
        raise ValueError("Result manifest file_count does not equal len(files)")
    if manifest["file_count"] <= 0:
        raise ValueError("Result manifest must contain at least one payload file")
    observed: set[str] = set()
    total_bytes = 0
    hexadecimal = set("0123456789abcdef")
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("Result manifest file entry must be an object")
        path = entry.get("path")
        digest = entry.get("sha256")
        size = entry.get("bytes")
        if not isinstance(path, str) or not path:
            raise ValueError("Result manifest path must be a non-empty string")
        parsed = PurePosixPath(path)
        if _has_forbidden_result_suffix(parsed):
            raise ValueError(f"Forbidden result payload suffix: {path}")
        if (
            parsed.is_absolute()
            or ".." in parsed.parts
            or str(parsed) != path
            or path.startswith("server_bundle/results/")
            or not _allowed_result_relative(parsed)
            or any(part in EXCLUDED_PARTS for part in parsed.parts)
        ):
            raise ValueError(f"Unsafe or self-conflicting result manifest path: {path}")
        if path in observed:
            raise ValueError(f"Duplicate result manifest path: {path}")
        observed.add(path)
        if not isinstance(size, int) or isinstance(size, bool) or size < 0:
            raise ValueError(f"Invalid byte count for {path}")
        if size > MAX_RESULT_FILE_BYTES:
            raise ValueError(f"Result payload file exceeds size limit: {path}")
        total_bytes += size
        if not isinstance(digest, str) or len(digest) != 64 or not set(digest) <= hexadecimal:
            raise ValueError(f"Invalid SHA-256 for {path}")
    if total_bytes > MAX_RESULT_TOTAL_BYTES:
        raise ValueError("Result manifest exceeds the total payload size limit")
    return entries


def _safe_relative(path: Path, root: Path) -> str:
    resolved = path.resolve(strict=True)
    root_resolved = root.resolve(strict=True)
    try:
        relative = resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"Archive candidate escapes root: {path}") from exc
    if path.is_symlink():
        raise ValueError(f"Symlinks are forbidden in result archives: {path}")
    return relative.as_posix()


def collect_result_files(root: Path) -> list[Path]:
    """Collect result/provenance files through explicit allow-listed roots."""

    roots_and_patterns: tuple[tuple[Path, tuple[str, ...]], ...] = (
        (root / "server_bundle", ("STATUS.json",)),
        (root / "server_bundle" / "gates", ("*.json", "*.md")),
        (
            root / "server_bundle" / "artifacts",
            ("**/*.json", "**/*.txt", "**/*.csv", "**/*.md", "**/*.log"),
        ),
        (root / "server_bundle" / "reports", ("**/*.json", "**/*.txt", "**/*.csv", "**/*.md")),
        (root / "server_bundle" / "runtime" / "logs", ("*.log",)),
        (root / "server_bundle" / "screenbus_a0_v2" / "configs", ("**/*.yaml", "**/*.yml", "**/*.json")),
        (root / "gates", ("G2_SERVER_READY.json", "G3_A0_DECISION.json", "G3_A0_DECISION.md")),
        (root / "reports", ("phase1_*.csv", "phase1_*.json", "full_*.csv", "full_*.json", "FINAL_*.md")),
        (root / "reports" / "phase1_failure_cases", ("**/*",)),
        (root / "reports" / "full_failure_cases", ("**/*",)),
    )
    selected: dict[str, Path] = {}
    for base, patterns in roots_and_patterns:
        if not base.exists():
            continue
        for pattern in patterns:
            for candidate in base.glob(pattern):
                if candidate.is_symlink():
                    raise ValueError(f"Symlinks are forbidden in result archives: {candidate}")
                if not candidate.is_file():
                    continue
                relative = _safe_relative(candidate, root)
                parsed = PurePosixPath(relative)
                if _has_forbidden_result_suffix(parsed):
                    raise ValueError(f"Forbidden result archive candidate suffix: {relative}")
                if not _allowed_result_relative(parsed):
                    raise ValueError(f"Result archive candidate is not explicitly allowed: {relative}")
                selected[relative] = candidate
    return [selected[key] for key in sorted(selected)]


def build_manifest(root: Path, status_path: Path, files: Iterable[Path]) -> dict[str, Any]:
    status = load_status(status_path)
    entries = []
    for path in files:
        relative = _safe_relative(path, root)
        entries.append(
            {
                "path": relative,
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return {
        "schema_version": 1,
        "archive_kind": "SCREENBUS_RESULTS_AND_PROVENANCE_NOT_G4_CODE_PACKAGE",
        "run_id": status["run_id"],
        "workflow_state": status["state"],
        "g2_decision": status.get("decisions", {}).get("g2"),
        "g3_decision": status.get("decisions", {}).get("g3"),
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "root_name": root.name,
        "excluded": ["raw data", "weights", "virtual environment", "checkpoints"],
        "file_count": len(entries),
        "files": entries,
    }


def result_archive_paths(output_dir: Path, status: dict[str, Any]) -> dict[str, str]:
    safe_run_id = "".join(ch for ch in status["run_id"] if ch.isalnum() or ch in "-_")
    base = f"ScreenBUS_results_{safe_run_id}"
    return {
        "archive": str((output_dir / f"{base}.tar.gz").resolve()),
        "manifest": str((output_dir / f"{base}.manifest.json").resolve()),
        "latest_manifest": str((output_dir / "MANIFEST.json").resolve()),
        "sha256_file": str((output_dir / f"{base}.sha256").resolve()),
    }


def create_archive(root: Path, status_path: Path, output_dir: Path) -> dict[str, str]:
    root = root.resolve(strict=True)
    status_path = status_path.resolve(strict=True)
    status = load_status(status_path)
    if status["state"] not in {"RUNNING", "COMPLETE", "SCIENTIFIC_NO_GO", "NO_DECISION_INSUFFICIENT_EVIDENCE", "BLOCKED", "FAILED"}:
        raise RuntimeError(f"Refusing final result archive while workflow state is {status['state']}")
    files = collect_result_files(root)
    if not files:
        raise RuntimeError("No result/provenance files were found")
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = result_archive_paths(output_dir, status)
    archive_path = Path(paths["archive"])
    manifest_path = Path(paths["manifest"])
    latest_manifest_path = Path(paths["latest_manifest"])
    sha_path = Path(paths["sha256_file"])
    base = archive_path.name.removesuffix(".tar.gz")

    manifest = build_manifest(root, status_path, files)
    atomic_write_json(manifest_path, manifest)
    atomic_write_json(latest_manifest_path, manifest)

    fd, tmp_name = tempfile.mkstemp(prefix=f".{base}.", suffix=".tar.gz.tmp", dir=output_dir)
    os.close(fd)
    tmp_path = Path(tmp_name)
    try:
        with tarfile.open(tmp_path, mode="w:gz", compresslevel=6) as archive:
            for path in files:
                archive.add(path, arcname=_safe_relative(path, root), recursive=False)
            archive.add(
                manifest_path,
                arcname=f"server_bundle/results/{manifest_path.name}",
                recursive=False,
            )
        os.replace(tmp_path, archive_path)
    finally:
        tmp_path.unlink(missing_ok=True)

    archive_sha = sha256_file(archive_path)
    atomic_write_text(sha_path, f"{archive_sha}  {archive_path.name}\n")
    return {
        "archive": str(archive_path),
        "sha256": archive_sha,
        "sha256_file": str(sha_path),
        "manifest": str(manifest_path),
        "latest_manifest": str(latest_manifest_path),
    }


def verify_archive(archive_path: Path, manifest_path: Path, sha_path: Path) -> dict[str, Any]:
    expected_line = sha_path.read_text(encoding="utf-8").strip().split()
    if len(expected_line) != 2 or expected_line[1] != archive_path.name:
        raise ValueError("Malformed SHA-256 sidecar or archive filename mismatch")
    actual_archive_sha = sha256_file(archive_path)
    if actual_archive_sha != expected_line[0]:
        raise ValueError("Archive SHA-256 mismatch")

    manifest = _load_json_strict(manifest_path)
    entries = _validate_result_manifest(manifest)
    expected = {entry["path"]: entry for entry in entries}
    envelope_name = f"server_bundle/results/{manifest_path.name}"
    with tarfile.open(archive_path, mode="r:gz") as archive:
        members = archive.getmembers()
        if any(not member.isfile() for member in members):
            raise ValueError("Result archive contains a non-regular-file member")
        names = {member.name for member in members}
        if len(names) != len(members):
            raise ValueError("Result archive contains duplicate member names")
        if names != set(expected) | {envelope_name}:
            missing = sorted(set(expected) - names)
            unexpected = sorted(names - set(expected) - {envelope_name})
            raise ValueError(f"Archive member mismatch; missing={missing}, unexpected={unexpected}")
        for member in members:
            parsed_member = PurePosixPath(member.name)
            if (
                parsed_member.is_absolute()
                or ".." in parsed_member.parts
                or str(parsed_member) != member.name
            ):
                raise ValueError(f"Unsafe archive member: {member.name}")
            if member.name == envelope_name:
                embedded = archive.extractfile(member)
                if embedded is None or embedded.read() != manifest_path.read_bytes():
                    raise ValueError("Archive result manifest differs from the external manifest")
                continue
            extracted = archive.extractfile(member)
            if extracted is None:
                raise ValueError(f"Cannot read archive member: {member.name}")
            digest = hashlib.sha256()
            size = 0
            for chunk in iter(lambda: extracted.read(1024 * 1024), b""):
                digest.update(chunk)
                size += len(chunk)
            entry = expected[member.name]
            if digest.hexdigest() != entry["sha256"] or size != entry["bytes"]:
                raise ValueError(f"Payload mismatch: {member.name}")
    return {
        "status": "PASS",
        "archive": str(archive_path.resolve()),
        "sha256": actual_archive_sha,
        "file_count": len(expected),
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    create = sub.add_parser("create")
    create.add_argument("--root", type=Path, required=True)
    create.add_argument("--status", type=Path, required=True)
    create.add_argument("--output-dir", type=Path, required=True)
    verify = sub.add_parser("verify")
    verify.add_argument("--archive", type=Path, required=True)
    verify.add_argument("--manifest", type=Path, required=True)
    verify.add_argument("--sha256-file", type=Path, required=True)
    return parser


def main() -> int:
    args = _parser().parse_args()
    if args.command == "create":
        result = create_archive(args.root, args.status, args.output_dir)
    else:
        result = verify_archive(args.archive, args.manifest, args.sha256_file)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
