#!/usr/bin/env python3
"""Deprecated filename retained as a fail-closed v2.3 bundle entry point.

The v2.1 PRE-A0 artifact is no longer buildable. Calls are delegated to the
canonical PRE-PHASE1 v2.3 builder so no stale pilot-gated package can be made.
"""

from __future__ import annotations

try:
    from .build_upload_bundle import main
except ImportError:
    from build_upload_bundle import main


if __name__ == "__main__":
    raise SystemExit(main())
