"""Operational controls for the server-side ScreenBUS runner.

This package is intentionally independent of the scientific implementation.
It coordinates the environment, data, G2, A0, full experiment, reporting, and
result-archive contracts without changing their internals.
"""

