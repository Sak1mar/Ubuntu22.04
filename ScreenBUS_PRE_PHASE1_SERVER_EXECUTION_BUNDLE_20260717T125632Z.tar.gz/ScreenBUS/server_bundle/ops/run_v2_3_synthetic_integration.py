#!/usr/bin/env python3
"""Execute the canonical v2.3 verifier path on a CPU-only synthetic fixture.

This is a source-integration check.  It does not read project data, run CUDA,
or generate scientific performance evidence.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from server_bundle.screenbus_a0_v2.config import load_config  # noqa: E402
from server_bundle.screenbus_a0_v2.engineering_a0 import (  # noqa: E402
    build_synthetic_verifier_rows,
)
from server_bundle.screenbus_a0_v2.refine_verify import (  # noqa: E402
    assert_threshold_selection_scores_are_meta_oof,
    score_methods,
    train_verifier_and_controls,
)


DEFAULT_CONFIG = ROOT / "server_bundle/screenbus_a0_v2/configs/server_a0.yaml"
DEFAULT_REPORT = ROOT / "reports/V2_3_CANONICAL_VERIFIER_SYNTHETIC_EXECUTION.json"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def execute(config_path: Path, report_path: Path) -> dict:
    config_path = config_path.resolve(strict=True)
    cfg = load_config(config_path)
    rows = build_synthetic_verifier_rows()
    with tempfile.TemporaryDirectory(prefix="screenbus_v2_3_verifier_synthetic.") as tmp:
        output_dir = Path(tmp)
        metadata = train_verifier_and_controls(
            rows, output_dir, cfg, 2027, __import__("torch").device("cpu")
        )
        scores = score_methods(rows, output_dir, __import__("torch").device("cpu"))
        score_payload = json.loads(
            (output_dir / "training_scores.json").read_text(encoding="utf-8")
        )
        assert_threshold_selection_scores_are_meta_oof(
            score_payload, ["lightweight_quality_regressor"]
        )
        provenance = score_payload["lightweight_quality_provenance"]
        if any(
            item["patient_id"] in item["training_patient_ids"]
            or item["patient_id"] not in item["heldout_patient_ids"]
            for item in provenance
        ):
            raise RuntimeError("SYNTHETIC_META_OOF_PATIENT_LEAKAGE")
        fold_hashes = sorted(
            {
                (int(item["fold"]), str(item["checkpoint_sha256"]))
                for item in provenance
            }
        )

    payload = {
        "schema_version": 1,
        "protocol_version": "2.3",
        "status": "PASS",
        "execution_kind": "CANONICAL_CONFIG_CPU_SYNTHETIC_POSTPROCESS_ONLY",
        "scientific_evidence": False,
        "performance_results": "NOT_GENERATED",
        "cuda": "NOT_RUN",
        "engineering_a0": "ENGINEERING_A0_NOT_RUN",
        "phase1": "PHASE1_NOT_RUN",
        "g3": "G3_NOT_RUN",
        "phase2": "PHASE2_NOT_RUN",
        "executed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "config": {
            "path": config_path.relative_to(ROOT).as_posix(),
            "sha256": _sha256(config_path),
            "hard_negative_mining_enabled": cfg["verifier"]["hard_negative_mining"]["enabled"],
        },
        "fixture": {
            "candidate_rows": len(rows),
            "unique_patients": len({str(row["patient_id"]) for row in rows}),
            "outer_test_rows": sum(
                str(row.get("split_role", "")).lower() == "outer_test" for row in rows
            ),
        },
        "canonical_path_proof": {
            "train_verifier_and_controls_executed": True,
            "score_methods_executed": True,
            "key_error": False,
            "all_legal_inner_oof_candidates_used": metadata[
                "all_legal_inner_oof_candidates_used"
            ],
            "hard_negative_mining_enabled": metadata["hard_negative_mining_enabled"],
            "score_methods": sorted(scores),
            "verifier_score_count": len(scores["verifier"]),
        },
        "lightweight_quality_meta_oof": {
            "selection_score_source": score_payload["score_source"][
                "lightweight_quality_regressor"
            ],
            "scored_rows": len(provenance),
            "patient_self_training_overlap_count": 0,
            "fold_checkpoint_hashes": [
                {"fold": fold, "checkpoint_sha256": digest}
                for fold, digest in fold_hashes
            ],
        },
    }
    _write_json(report_path, payload)
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    args = parser.parse_args()
    payload = execute(args.config, args.report)
    print(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
