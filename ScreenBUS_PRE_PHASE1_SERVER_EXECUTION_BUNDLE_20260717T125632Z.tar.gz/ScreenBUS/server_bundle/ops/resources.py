#!/usr/bin/env python3
"""GPU policy and live scheduler snapshots for STATUS.json."""

from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def policy_from_env(env: dict[str, str] | None = None) -> dict[str, Any]:
    source = env or os.environ
    gpu_ids = source.get("GPU_IDS", "0,1,2")
    return {
        "gpu_ids": [item.strip() for item in gpu_ids.split(",") if item.strip()],
        "per_gpu_concurrency": int(source.get("SCREENBUS_PER_GPU_CONCURRENCY", "2")),
        "min_free_vram_gib": float(source.get("SCREENBUS_MIN_FREE_VRAM_GIB", "3")),
        "heavy_exclusive": True,
        "oom_max_retries": int(source.get("SCREENBUS_OOM_MAX_RETRIES", "0")),
        "resource_aware_required": True,
        "memory_gib": {"light": 4.0, "medium": 10.0, "heavy": 20.0},
        "admission_rule": "estimated_gib + min_free_vram_gib must fit; heavy jobs are exclusive",
    }


def query_nvidia_smi() -> dict[str, Any]:
    command = [
        "nvidia-smi",
        "--query-gpu=index,name,memory.total,memory.used,memory.free,utilization.gpu",
        "--format=csv,noheader,nounits",
    ]
    try:
        completed = subprocess.run(command, text=True, capture_output=True, check=False, timeout=20)
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return {"status": "UNAVAILABLE", "error": str(exc), "devices": []}
    if completed.returncode != 0:
        return {
            "status": "UNAVAILABLE",
            "error": completed.stderr.strip() or f"exit {completed.returncode}",
            "devices": [],
        }
    devices = []
    for line in completed.stdout.splitlines():
        fields = [item.strip() for item in line.split(",")]
        if len(fields) != 6:
            continue
        try:
            devices.append(
                {
                    "id": fields[0],
                    "name": fields[1],
                    "total_mib": int(fields[2]),
                    "used_mib": int(fields[3]),
                    "free_mib": int(fields[4]),
                    "utilization_percent": int(fields[5]),
                }
            )
        except ValueError:
            continue
    return {"status": "PASS" if devices else "UNAVAILABLE", "devices": devices}


def load_scheduler_snapshot(output_root: Path) -> dict[str, Any]:
    candidates = (
        output_root / "scheduler" / "STATUS.json",
        output_root / "phase1" / "scheduler" / "STATUS.json",
        output_root / "full" / "scheduler" / "STATUS.json",
    )
    existing = [path for path in candidates if path.is_file()]
    if not existing:
        return {
            "status": "NOT_STARTED",
            "queued": 0,
            "running": 0,
            "completed": 0,
            "failed": 0,
            "cancelled": 0,
            "submitted": 0,
            "source": None,
        }
    path = max(existing, key=lambda item: item.stat().st_mtime_ns)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {"status": "INVALID", "error": str(exc), "source": str(path)}
    if not isinstance(value, dict):
        return {"status": "INVALID", "error": "root is not an object", "source": str(path)}
    def count(field: str) -> int:
        observed = value.get(f"{field}_count", value.get(field, 0))
        if isinstance(observed, list):
            return len(observed)
        return int(observed)

    result = value.copy()
    result["completed_tasks"] = value.get("completed", [])
    result["failed_tasks"] = value.get("failed", [])
    result["queued"] = count("queued")
    result["running"] = count("running")
    result["completed"] = count("completed")
    result["failed"] = count("failed")
    result["cancelled"] = count("cancelled")
    result["submitted"] = count("submitted")
    if result["failed"] or result["cancelled"]:
        result["status"] = "FAILED"
    elif result["queued"] or result["running"]:
        result["status"] = "RUNNING"
    else:
        result["status"] = "COMPLETE"
    result["source"] = str(path)
    return result


def refresh_resources(status: dict[str, Any], output_root: Path, env: dict[str, str] | None = None) -> None:
    status["resource_policy"] = policy_from_env(env)
    status["resources"] = {
        "observed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "gpu": query_nvidia_smi(),
        "scheduler": load_scheduler_snapshot(output_root),
    }
