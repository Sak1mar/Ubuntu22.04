#!/usr/bin/env python3
"""Build and verify the protocol-v2.3 PRE-PHASE1 server execution bundle.

This archive is an executable transport artifact. It is not evidence that
ENGINEERING_A0, Phase-1, G3, or Phase-2 ran. Raw data, weights, local
environments, runtime state, results,
checkpoints, caches, and Git metadata are excluded by construction.
"""

from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

try:
    from .archive_results import atomic_write_text, sha256_file
    from .status_store import atomic_write_json
except ImportError:
    from archive_results import atomic_write_text, sha256_file
    from status_store import atomic_write_json


ARCHIVE_KIND = "PRE_PHASE1_SERVER_EXECUTION_BUNDLE"
ARCHIVE_ROOT = "ScreenBUS"
MAX_PAYLOAD_FILE_BYTES = 16 * 1024 * 1024
MAX_PAYLOAD_TOTAL_BYTES = 64 * 1024 * 1024
EXPLICIT_SMALL_EVIDENCE = (
    "artifacts/data/busuclm_server_fetch_selection_probe.json",
    "artifacts/weights/server_torchvision_hash_verification.json",
)
EXPLICIT_PROTOCOL_ARTIFACTS = (
    "output/pdf/ScreenBUS_实验方案与科研动机_v2.3.pdf",
)
ALLOWLIST_ROOTS = (
    "server_bundle",
    "bootstrap/evidence",
    "prompts",
)
EXPLICIT_GATE_EVIDENCE = (
    "gates/G0_RESEARCH_GATE.md",
    "gates/G0_decision.json",
    "gates/G1_LOCAL_MICRO.json",
    "gates/OFFICIAL_DATA_GATE.json",
    "gates/OFFICIAL_DATA_GATE.md",
    "gates/claim_evidence_ledger.csv",
    "gates/novelty_collision_matrix.csv",
    "gates/data_and_compute_feasibility.md",
)
FORBIDDEN_NAMES = {".git", "__pycache__", ".pytest_cache", ".DS_Store"}
FORBIDDEN_SUFFIXES = {
    ".7z",
    ".bz2",
    ".pyc",
    ".pyo",
    ".partial",
    ".pth",
    ".pt",
    ".ckpt",
    ".dcm",
    ".gz",
    ".jpeg",
    ".jpg",
    ".nii",
    ".npy",
    ".npz",
    ".onnx",
    ".png",
    ".rar",
    ".safetensors",
    ".tar",
    ".tgz",
    ".xz",
    ".zip",
}
FORBIDDEN_PREFIXES = (
    ".venv-local",
    "artifacts",
    "cache",
    "data",
    "weights",
    "output",
    "server_bundle/.python",
    "server_bundle/.server_env",
    "server_bundle/.tools",
    "server_bundle/artifacts",
    "server_bundle/results",
    "server_bundle/runtime",
    "server_bundle/upload_dist",
    "server_bundle/screenbus_a0",
    "server_bundle/schemas/engineering_a0_v2_2_output.schema.json",
    "server_bundle/schemas/phase1_v2_2_output.schema.json",
    "server_bundle/tests",
    "server_bundle/conftest.py",
)
FORBIDDEN_ANY_PART = {"checkpoints", "tests"}
REQUIRED_RUNTIME_FILES = frozenset(
    {
        ".gitignore",
        "README_UPLOAD_CN.md",
        "README_PRE_A0_V2_1_CN.md",
        "ccfa.yaml",
        "screenbus.sh",
        "prompts/ScreenBUS_Codex_双环境总控Prompt.md",
        "server_bundle/G2_ENVIRONMENT_AND_ASSETS_CN.md",
        "server_bundle/README_SERVER_CN.md",
        "server_bundle/__init__.py",
        "server_bundle/screenbus_server.sh",
        "server_bundle/data/__init__.py",
        "server_bundle/data/fetch_official.py",
        "server_bundle/data/fetch_weights.py",
        "server_bundle/data/official_assets.py",
        "server_bundle/data/prepare_busuclm.py",
        "server_bundle/env/bootstrap_env.sh",
        "server_bundle/env/requirements-cuda121.in",
        "server_bundle/env/requirements-cuda121.lock.txt",
        "server_bundle/env/run_in_frozen_container.sh",
        "server_bundle/env/write_manifest.py",
        "server_bundle/g2/__init__.py",
        "server_bundle/g2/determinism_worker.py",
        "server_bundle/g2/g2_doctor.py",
        "server_bundle/g2/nnunet_probe.py",
        "server_bundle/ops/__init__.py",
        "server_bundle/ops/archive_results.py",
        "server_bundle/ops/build_pre_a0_v2_1_bundle.py",
        "server_bundle/ops/build_upload_bundle.py",
        "server_bundle/ops/g3_validation.py",
        "server_bundle/ops/inspect_results.py",
        "server_bundle/ops/orchestrator.py",
        "server_bundle/ops/resources.py",
        "server_bundle/ops/run_v2_3_synthetic_integration.py",
        "server_bundle/ops/status_store.py",
        "server_bundle/schemas/engineering_a0_v2_3_output.schema.json",
        "server_bundle/schemas/g3_a0_decision.schema.json",
        "server_bundle/schemas/phase1_v2_3_output.schema.json",
        "server_bundle/schemas/predictive_a0_v2_1_output.schema.json",
        "server_bundle/screenbus_a0_v2/__init__.py",
        "server_bundle/screenbus_a0_v2/__main__.py",
        "server_bundle/screenbus_a0_v2/authorization.py",
        "server_bundle/screenbus_a0_v2/autobusam_baseline.py",
        "server_bundle/screenbus_a0_v2/baselines.py",
        "server_bundle/screenbus_a0_v2/candidates.py",
        "server_bundle/screenbus_a0_v2/cli.py",
        "server_bundle/screenbus_a0_v2/config.py",
        "server_bundle/screenbus_a0_v2/configs/engineering_a0.yaml",
        "server_bundle/screenbus_a0_v2/configs/full_cv.yaml",
        "server_bundle/screenbus_a0_v2/configs/server_a0.yaml",
        "server_bundle/screenbus_a0_v2/data.py",
        "server_bundle/screenbus_a0_v2/engineering_a0.py",
        "server_bundle/screenbus_a0_v2/full_runner.py",
        "server_bundle/screenbus_a0_v2/g3_method_gate.py",
        "server_bundle/screenbus_a0_v2/g3_validation.py",
        "server_bundle/screenbus_a0_v2/leakage_ablation.py",
        "server_bundle/screenbus_a0_v2/metrics.py",
        "server_bundle/screenbus_a0_v2/models.py",
        "server_bundle/screenbus_a0_v2/nnunet_baseline.py",
        "server_bundle/screenbus_a0_v2/nnunet_seeded_launcher.py",
        "server_bundle/screenbus_a0_v2/nnunet_trainers.py",
        "server_bundle/screenbus_a0_v2/phase1_runner.py",
        "server_bundle/screenbus_a0_v2/pipeline.py",
        "server_bundle/screenbus_a0_v2/protocol_v2_1.py",
        "server_bundle/screenbus_a0_v2/protocol_v2_2.py",
        "server_bundle/screenbus_a0_v2/protocol_v2_3.py",
        "server_bundle/screenbus_a0_v2/refine_verify.py",
        "server_bundle/screenbus_a0_v2/scheduler.py",
        "server_bundle/screenbus_a0_v2/task_launcher.py",
        "server_bundle/screenbus_a0_v2/training.py",
        "server_bundle/screenbus_a0_v2/util.py",
        "server_bundle/screenbus_a0_v2/worker.py",
    }
)
FROZEN_BOOTSTRAP_EVIDENCE_FILES = frozenset(
    {
        "bootstrap/evidence/BUS-BRA/.verified_busbra.json",
        "bootstrap/evidence/BUS-BRA/busbra_data_gate.source.json",
        "bootstrap/evidence/BUS-BRA/busbra_positive_manifest.csv",
        "bootstrap/evidence/BUS-UCLM/FETCH_COMPLETE.json",
        "bootstrap/evidence/BUS-UCLM/api_snapshot.json",
        "bootstrap/evidence/BUS-UCLM/busuclm_data_gate.json",
        "bootstrap/evidence/BUS-UCLM/busuclm_route2_dev.csv",
        "bootstrap/evidence/BUS-UCLM/busuclm_route2_fold0.csv",
        "bootstrap/evidence/BUS-UCLM/busuclm_route2_fold1.csv",
        "bootstrap/evidence/BUS-UCLM/busuclm_route2_fold2.csv",
        "bootstrap/evidence/BUS-UCLM/busuclm_route2_fold3.csv",
        "bootstrap/evidence/BUS-UCLM/busuclm_route2_fold4.csv",
        "bootstrap/evidence/BUS-UCLM/busuclm_route2_summary.json",
        "bootstrap/evidence/BUS-UCLM/registry.yaml",
        "bootstrap/evidence/busuclm_component_audit.json",
    }
)
REQUIRED_UPLOAD_FILES = frozenset(
    {
        *REQUIRED_RUNTIME_FILES,
        "bootstrap/evidence/MANIFEST.sha256",
        *FROZEN_BOOTSTRAP_EVIDENCE_FILES,
        *EXPLICIT_SMALL_EVIDENCE,
        *EXPLICIT_GATE_EVIDENCE,
        "experiments/experiment-registry.yaml",
        "gates/G3_A0_DECISION.json",
        "gates/V2_3_PRETRAINING_STATUS.json",
        "project/PREDICTIVE_A0_PILOT_MANIFEST_SCHEMA.md",
        "project/route-freeze.md",
        "reports/V2_3_PROTOCOL_SOURCE_REPAIR_AUDIT.md",
        "reports/V2_3_CANONICAL_VERIFIER_SYNTHETIC_EXECUTION.json",
        "reports/build_screenbus_experiment_plan_v2_3.py",
        *EXPLICIT_PROTOCOL_ARTIFACTS,
    }
)


def _relative(path: Path, root: Path) -> str:
    resolved = path.resolve(strict=True)
    root_resolved = root.resolve(strict=True)
    try:
        relative = resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"Upload candidate escapes root: {path}") from exc
    if path.is_symlink():
        raise ValueError(f"Symlink is forbidden in upload bundle: {path}")
    return relative.as_posix()


def _is_forbidden(relative: str) -> bool:
    path = PurePosixPath(relative)
    if any(part in FORBIDDEN_NAMES or part in FORBIDDEN_ANY_PART for part in path.parts):
        return True
    if path.suffix in FORBIDDEN_SUFFIXES:
        return True
    return any(relative == prefix or relative.startswith(prefix + "/") for prefix in FORBIDDEN_PREFIXES)


def _is_excluded_source_location(relative: str) -> bool:
    """Ignore known local/runtime trees, but never hide a rogue payload by suffix."""
    path = PurePosixPath(relative)
    if any(part in FORBIDDEN_NAMES or part in FORBIDDEN_ANY_PART for part in path.parts):
        return True
    return any(relative == prefix or relative.startswith(prefix + "/") for prefix in FORBIDDEN_PREFIXES)


def _validate_pre_phase1_status(path: Path) -> None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"G4 package status is unreadable: {exc}") from exc
    required = {
        "archive_kind": ARCHIVE_KIND,
        "status": "PROTOCOL_V2_3_READY",
        "source_repair": "SOURCE_REPAIR_PASS",
        "server_execution": "NOT_RUN",
        "engineering_a0": "ENGINEERING_A0_NOT_RUN",
        "phase1": "PHASE1_NOT_RUN",
        "g3": "G3_NOT_RUN",
        "phase2": "PHASE2_NOT_RUN",
        "scientific_decision": "SCIENTIFIC_DECISION_NO_DECISION",
        "clinical_screening_claim": "CLINICAL_SCREENING_CLAIM_BLOCKED_MISSING_INDEPENDENT_NORMAL_PATIENT_COHORT",
        "training_run": False,
    }
    drift = {key: {"expected": expected, "observed": payload.get(key)} for key, expected in required.items() if payload.get(key) != expected}
    if drift:
        raise RuntimeError(
            "G4 package status would overclaim or is stale: "
            + json.dumps(drift, sort_keys=True)
        )


def collect_upload_files(root: Path) -> list[Path]:
    selected: dict[str, Path] = {}
    unexpected: list[str] = []
    for relative_root in ALLOWLIST_ROOTS:
        base = root / relative_root
        if not base.is_dir():
            continue
        for path in base.rglob("*"):
            if not path.is_file() and not path.is_symlink():
                continue
            relative = path.relative_to(root).as_posix()
            if not _is_excluded_source_location(relative) and relative not in REQUIRED_UPLOAD_FILES:
                unexpected.append(relative)
    if unexpected:
        raise RuntimeError(
            "Unexpected files under strict upload allow-list roots: "
            + ", ".join(sorted(unexpected))
        )
    missing: list[str] = []
    for relative in sorted(REQUIRED_UPLOAD_FILES):
        path = root / relative
        if not path.is_file():
            missing.append(relative)
            continue
        selected[_relative(path, root)] = path
    if missing:
        raise RuntimeError("Required upload files are missing: " + ", ".join(missing))
    _validate_pre_phase1_status(root / "gates" / "V2_3_PRETRAINING_STATUS.json")
    oversized = sorted(
        relative
        for relative, path in selected.items()
        if path.stat().st_size > MAX_PAYLOAD_FILE_BYTES
    )
    total_bytes = sum(path.stat().st_size for path in selected.values())
    if oversized or total_bytes > MAX_PAYLOAD_TOTAL_BYTES:
        raise RuntimeError(
            "Upload payload exceeds source/evidence size limits; "
            f"oversized={oversized}, total_bytes={total_bytes}"
        )
    cli_path = root / "server_bundle" / "screenbus_a0_v2" / "cli.py"
    try:
        tree = ast.parse(cli_path.read_text(encoding="utf-8"), filename=str(cli_path))
    except SyntaxError as exc:
        raise RuntimeError(f"Scientific CLI is not valid Python: {exc}") from exc
    commands = {
        node.args[0].value
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "add_parser"
        and node.args
        and isinstance(node.args[0], ast.Constant)
        and isinstance(node.args[0].value, str)
    }
    required_commands = {"engineering-a0", "phase1", "g3", "phase2", "phase2-fold"}
    if not required_commands <= commands:
        raise RuntimeError(
            "Scientific CLI is incomplete; missing commands: "
            + ", ".join(sorted(required_commands - commands))
        )
    absolute_home_needle = b"/" + b"Users/"
    executable_suffixes = {".py", ".sh", ".yaml", ".yml"}
    offenders = []
    for relative, path in selected.items():
        if relative.startswith("server_bundle/") and path.suffix in executable_suffixes:
            if absolute_home_needle in path.read_bytes():
                offenders.append(relative)
    if offenders:
        raise RuntimeError("Executable server files contain local /Users paths: " + ", ".join(sorted(offenders)))
    return [selected[key] for key in sorted(selected)]


def build_manifest(root: Path, files: Iterable[Path]) -> dict[str, Any]:
    entries = []
    for path in files:
        relative = _relative(path, root)
        entries.append(
            {
                "path": relative,
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
                "executable": bool(path.stat().st_mode & 0o111),
            }
        )
    return {
        "schema_version": 2,
        "archive_kind": ARCHIVE_KIND,
        "protocol_version": "2.3",
        "scientific_gate_claim": "NONE_PRE_PHASE1_TRANSPORT_ONLY",
        "execution_status": {
            "engineering_a0": "NOT_RUN",
            "phase1": "NOT_RUN",
            "phase2": "NOT_RUN",
            "scientific_decision": "NO_DECISION",
        },
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "archive_root": ARCHIVE_ROOT,
        "file_count": len(entries),
        "excluded": [
            ".git",
            "raw data",
            "weights",
            "virtual environments",
            "runtime state and logs",
            "result archives",
            "checkpoints",
            "caches",
            "pycache",
        ],
        "files": entries,
    }


def _add_deterministic_file(archive: tarfile.TarFile, path: Path, arcname: str) -> None:
    info = archive.gettarinfo(str(path), arcname=arcname)
    info.uid = 0
    info.gid = 0
    info.uname = "root"
    info.gname = "root"
    info.mtime = 0
    info.mode = 0o755 if path.stat().st_mode & 0o111 else 0o644
    with path.open("rb") as handle:
        archive.addfile(info, handle)


def create_bundle(root: Path, output_dir: Path) -> dict[str, str]:
    root = root.resolve(strict=True)
    files = collect_upload_files(root)
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    base = f"ScreenBUS_PRE_PHASE1_SERVER_EXECUTION_BUNDLE_{timestamp}"
    archive_path = output_dir / f"{base}.tar.gz"
    manifest_path = output_dir / f"{base}.manifest.json"
    latest_manifest = output_dir / "MANIFEST.json"
    sha_path = output_dir / f"{base}.sha256"
    manifest = build_manifest(root, files)
    atomic_write_json(manifest_path, manifest)
    atomic_write_json(latest_manifest, manifest)

    fd, temporary_name = tempfile.mkstemp(prefix=f".{base}.", suffix=".tar.gz.tmp", dir=output_dir)
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        with temporary.open("wb") as raw:
            with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
                with tarfile.open(fileobj=compressed, mode="w") as archive:
                    for path in files:
                        _add_deterministic_file(
                            archive,
                            path,
                            f"{ARCHIVE_ROOT}/{_relative(path, root)}",
                        )
                    _add_deterministic_file(
                        archive,
                        manifest_path,
                        f"{ARCHIVE_ROOT}/MANIFEST.json",
                    )
        os.replace(temporary, archive_path)
    finally:
        temporary.unlink(missing_ok=True)
    digest = sha256_file(archive_path)
    atomic_write_text(sha_path, f"{digest}  {archive_path.name}\n")
    return {
        "archive_kind": ARCHIVE_KIND,
        "archive": str(archive_path.resolve()),
        "manifest": str(manifest_path.resolve()),
        "latest_manifest": str(latest_manifest.resolve()),
        "sha256": digest,
        "sha256_file": str(sha_path.resolve()),
    }


def _safe_member_name(name: str) -> PurePosixPath:
    path = PurePosixPath(name)
    if (
        path.is_absolute()
        or ".." in path.parts
        or not path.parts
        or path.parts[0] != ARCHIVE_ROOT
        or str(path) != name
    ):
        raise ValueError(f"Unsafe or unexpected archive path: {name}")
    return path


def _load_json_strict(path: Path) -> dict[str, Any]:
    def no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON key in manifest: {key}")
            result[key] = value
        return result

    value = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=no_duplicate_keys)
    if not isinstance(value, dict):
        raise ValueError("Manifest root must be an object")
    return value


def _validate_manifest(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    if manifest.get("archive_kind") != ARCHIVE_KIND or manifest.get("schema_version") != 2:
        raise ValueError("Manifest is not a schema-v2 PRE-PHASE1 server execution bundle")
    if manifest.get("protocol_version") != "2.3":
        raise ValueError("Manifest protocol_version must be 2.3")
    entries = manifest.get("files")
    if not isinstance(entries, list) or not isinstance(manifest.get("file_count"), int):
        raise ValueError("Manifest files/file_count types are invalid")
    if manifest["file_count"] != len(entries):
        raise ValueError("Manifest file_count does not equal len(files)")
    if manifest["file_count"] <= 0:
        raise ValueError("Upload manifest must contain at least one payload file")
    observed: set[str] = set()
    total_bytes = 0
    hexadecimal = set("0123456789abcdef")
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("Manifest file entry must be an object")
        path = entry.get("path")
        digest = entry.get("sha256")
        size = entry.get("bytes")
        executable = entry.get("executable")
        if not isinstance(path, str) or not path:
            raise ValueError("Manifest entry path must be a non-empty string")
        parsed = PurePosixPath(path)
        if (
            parsed.is_absolute()
            or ".." in parsed.parts
            or str(parsed) != path
            or path == "MANIFEST.json"
        ):
            raise ValueError(f"Unsafe or self-conflicting manifest path: {path}")
        if _is_forbidden(path) and path not in EXPLICIT_SMALL_EVIDENCE + EXPLICIT_PROTOCOL_ARTIFACTS:
            raise ValueError(f"Forbidden upload payload path: {path}")
        if path in observed:
            raise ValueError(f"Duplicate manifest path: {path}")
        observed.add(path)
        if not isinstance(size, int) or isinstance(size, bool) or size < 0:
            raise ValueError(f"Invalid byte count for {path}")
        if size > MAX_PAYLOAD_FILE_BYTES:
            raise ValueError(f"Upload payload file exceeds size limit: {path}")
        total_bytes += size
        if not isinstance(digest, str) or len(digest) != 64 or not set(digest) <= hexadecimal:
            raise ValueError(f"Invalid SHA-256 for {path}")
        if not isinstance(executable, bool):
            raise ValueError(f"Invalid executable flag for {path}")
    missing = sorted(REQUIRED_UPLOAD_FILES - observed)
    if missing:
        raise ValueError("Upload manifest is missing required payloads: " + ", ".join(missing))
    unexpected = sorted(observed - REQUIRED_UPLOAD_FILES)
    if unexpected:
        raise ValueError("Upload manifest contains non-allow-listed payloads: " + ", ".join(unexpected))
    if total_bytes > MAX_PAYLOAD_TOTAL_BYTES:
        raise ValueError("Upload manifest exceeds the total payload size limit")
    return entries


def verify_bundle(
    archive_path: Path,
    manifest_path: Path,
    sha_path: Path,
    *,
    smoke: bool,
) -> dict[str, Any]:
    manifest = _load_json_strict(manifest_path)
    entries = _validate_manifest(manifest)
    expected_line = sha_path.read_text(encoding="utf-8").strip().split()
    if len(expected_line) != 2 or expected_line[1] != archive_path.name:
        raise ValueError("Malformed SHA-256 sidecar")
    observed_archive_sha = sha256_file(archive_path)
    if observed_archive_sha != expected_line[0]:
        raise ValueError("Upload bundle SHA-256 mismatch")
    expected = {f"{ARCHIVE_ROOT}/{item['path']}": item for item in entries}
    envelope = f"{ARCHIVE_ROOT}/MANIFEST.json"
    extracted_root: Path | None = None
    with tempfile.TemporaryDirectory(prefix="screenbus_upload_verify.") as tmp:
        temporary = Path(tmp)
        with tarfile.open(archive_path, mode="r:gz") as archive:
            members = archive.getmembers()
            if any(not member.isfile() for member in members):
                raise ValueError("Upload bundle contains a non-regular-file member")
            names = {member.name for member in members}
            if len(names) != len(members):
                raise ValueError("Upload bundle contains duplicate member names")
            if names != set(expected) | {envelope}:
                missing = sorted(set(expected) - names)
                unexpected = sorted(names - set(expected) - {envelope})
                raise ValueError(f"Archive membership mismatch; missing={missing}, unexpected={unexpected}")
            for member in members:
                safe_name = _safe_member_name(member.name)
                source = archive.extractfile(member)
                if source is None:
                    raise ValueError(f"Unreadable archive member: {member.name}")
                digest = hashlib.sha256()
                size = 0
                destination = temporary.joinpath(*safe_name.parts)
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open("wb") as output:
                    while True:
                        block = source.read(1024 * 1024)
                        if not block:
                            break
                        digest.update(block)
                        size += len(block)
                        output.write(block)
                os.chmod(destination, member.mode & 0o777)
                if member.name != envelope:
                    item = expected[member.name]
                    if size != item["bytes"] or digest.hexdigest() != item["sha256"]:
                        raise ValueError(f"Upload payload mismatch: {member.name}")
                    mode_executable = bool(member.mode & 0o111)
                    if mode_executable != item["executable"]:
                        raise ValueError(f"Executable mode mismatch: {member.name}")
                else:
                    external_bytes = manifest_path.read_bytes()
                    if destination.read_bytes() != external_bytes:
                        raise ValueError("Archive MANIFEST.json differs from the external manifest")
            extracted_root = temporary / ARCHIVE_ROOT
        smoke_result: dict[str, Any] = {"status": "NOT_REQUESTED"}
        if smoke:
            shell_checks = []
            for script in (
                extracted_root / "screenbus.sh",
                extracted_root / "server_bundle" / "screenbus_server.sh",
                extracted_root / "server_bundle" / "env" / "bootstrap_env.sh",
            ):
                checked = subprocess.run(
                    ["bash", "-n", str(script)],
                    cwd=extracted_root,
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    check=False,
                    timeout=30,
                )
                if checked.returncode != 0:
                    raise RuntimeError(f"Extracted shell syntax failed for {script}: {checked.stdout}")
                shell_checks.append(str(script.relative_to(extracted_root)))
            compile_run = subprocess.run(
                [sys.executable, "-m", "compileall", "-q", str(extracted_root / "server_bundle")],
                cwd=extracted_root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
                timeout=60,
            )
            if compile_run.returncode != 0:
                raise RuntimeError(f"Extracted Python compile smoke failed: {compile_run.stdout}")
            help_run = subprocess.run(
                ["bash", str(extracted_root / "screenbus.sh"), "help"],
                cwd=extracted_root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
                timeout=30,
            )
            if help_run.returncode != 0 or "overnight" not in help_run.stdout:
                raise RuntimeError(f"Extracted help smoke failed: {help_run.stdout}")
            status_run = subprocess.run(
                ["bash", str(extracted_root / "screenbus.sh"), "status"],
                cwd=extracted_root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
                timeout=30,
            )
            if status_run.returncode != 3 or "STATUS_NOT_CREATED" not in status_run.stdout:
                raise RuntimeError(
                    "Fresh extracted status must fail literally as STATUS_NOT_CREATED; "
                    f"exit={status_run.returncode}, output={status_run.stdout}"
                )
            smoke_result = {
                "status": "PASS",
                "help_exit": help_run.returncode,
                "fresh_status_exit": status_run.returncode,
                "fresh_status": "STATUS_NOT_CREATED_EXPECTED_BEFORE_FIRST_RUN",
                "shell_syntax": shell_checks,
                "python_compileall": "PASS",
            }
    return {
        "status": "PASS",
        "archive_kind": ARCHIVE_KIND,
        "archive": str(archive_path.resolve()),
        "sha256": observed_archive_sha,
        "file_count": len(expected),
        "smoke": smoke_result,
    }


def main() -> int:
    default_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    build = sub.add_parser("build")
    build.add_argument("--root", type=Path, default=default_root)
    build.add_argument("--output-dir", type=Path)
    build.add_argument("--skip-smoke", action="store_true")
    verify = sub.add_parser("verify")
    verify.add_argument("--archive", type=Path, required=True)
    verify.add_argument("--manifest", type=Path, required=True)
    verify.add_argument("--sha256-file", type=Path, required=True)
    verify.add_argument("--skip-smoke", action="store_true")
    args = parser.parse_args()
    if args.command == "build":
        output_dir = args.output_dir or (args.root / "server_bundle" / "upload_dist")
        result = create_bundle(args.root, output_dir)
        result["verification"] = verify_bundle(
            Path(result["archive"]),
            Path(result["manifest"]),
            Path(result["sha256_file"]),
            smoke=not args.skip_smoke,
        )
    else:
        result = verify_bundle(
            args.archive,
            args.manifest,
            args.sha256_file,
            smoke=not args.skip_smoke,
        )
    print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
