#!/usr/bin/env python3
"""Render an evidence-literal summary of the overnight server workflow."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Any

try:
    from .status_store import STAGE_ORDER, load_status
except ImportError:  # Direct script execution.
    from status_store import STAGE_ORDER, load_status


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def _escape(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def csv_preview(path: Path, max_rows: int = 20) -> tuple[int, list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        return len(rows), list(reader.fieldnames or []), rows[:max_rows]


def render_summary(root: Path, status_path: Path) -> str:
    status = load_status(status_path)
    lines = [
        "# ScreenBUS server run result summary",
        "",
        "> This document reports only files that exist. Missing stages and metrics remain explicitly NOT_RUN or UNAVAILABLE.",
        "",
        "## Workflow outcome",
        "",
        f"- Run ID: `{_escape(status['run_id'])}`",
        f"- Workflow state: `{_escape(status['state'])}`",
        f"- Current stage: `{_escape(status.get('current_stage'))}`",
        f"- G2 decision: `{_escape(status.get('decisions', {}).get('g2'))}`",
        f"- G3 decision: `{_escape(status.get('decisions', {}).get('g3'))}`",
        f"- Message: {_escape(status.get('message'))}",
        "",
        "## Stage ledger",
        "",
        "| Stage | State | Attempts | Exit | Message |",
        "|---|---:|---:|---:|---|",
    ]
    for stage in STAGE_ORDER:
        record = status["stages"][stage]
        lines.append(
            "| "
            + " | ".join(
                [
                    stage,
                    _escape(record.get("state")),
                    _escape(record.get("attempt")),
                    _escape(record.get("exit_code")),
                    _escape(record.get("message")),
                ]
            )
            + " |"
        )

    policy = status.get("resource_policy", {})
    resources = status.get("resources", {})
    gpu = resources.get("gpu", {})
    scheduler = resources.get("scheduler", {})
    lines.extend(
        [
            "",
            "## GPU and scheduler snapshot",
            "",
            f"- GPU IDs: `{_escape(policy.get('gpu_ids'))}`; per-GPU concurrency: `{_escape(policy.get('per_gpu_concurrency'))}`.",
            f"- Minimum free VRAM: `{_escape(policy.get('min_free_vram_gib'))} GiB`; heavy exclusive: `{_escape(policy.get('heavy_exclusive'))}`; OOM retries: `{_escape(policy.get('oom_max_retries'))}`.",
            f"- Live GPU snapshot status: `{_escape(gpu.get('status'))}`; observed: `{_escape(resources.get('observed_at'))}`.",
            f"- Scheduler: `{_escape(scheduler.get('status'))}`; queued `{_escape(scheduler.get('queued'))}`, running `{_escape(scheduler.get('running'))}`, completed `{_escape(scheduler.get('completed'))}`, failed `{_escape(scheduler.get('failed'))}`, cancelled `{_escape(scheduler.get('cancelled'))}`.",
            f"- Scheduler source: `{_escape(scheduler.get('source'))}`.",
        ]
    )

    g2_path = root / "gates" / "G2_SERVER_READY.json"
    g3_path = root / "gates" / "G3_A0_DECISION.json"
    phase1_path = root / "server_bundle" / "artifacts" / "phase1" / "PHASE1_FIVE_FOLD_REPORT.json"
    aggregate_path = root / "reports" / "full_aggregate.json"
    lines.extend(["", "## Gate evidence", ""])
    for label, path in (("G2", g2_path), ("G3", g3_path)):
        payload = read_json(path)
        if payload is None:
            lines.append(f"- {label}: `UNAVAILABLE`; `{path}` is missing or invalid JSON.")
        else:
            decision = payload.get("decision", payload.get("status", "FIELD_UNAVAILABLE"))
            trusted = status.get("decisions", {}).get(label.lower())
            if label == "G3" and trusted is None:
                lines.append(
                    f"- G3: `UNTRUSTED_STALE_OR_INVALID`; a file exists at `{path}` but this run did not produce a valid fresh G3; SHA-256 `{sha256_file(path)}`."
                )
                continue
            if label == "G3":
                binding = status.get("stages", {}).get("G3_METHOD_GATE", {}).get("gate_binding", {})
                if not isinstance(binding, dict) or binding.get("sha256") != sha256_file(path):
                    lines.append(
                        f"- G3: `UNTRUSTED_GATE_BINDING_DRIFT`; current file SHA-256 `{sha256_file(path)}` does not match this run's frozen five-fold Phase-1 binding."
                    )
                    continue
            if trusted is not None and decision != trusted:
                lines.append(
                    f"- {label}: `STATUS_GATE_MISMATCH`; STATUS records `{_escape(trusted)}` but file records `{_escape(decision)}`; `{path}`."
                )
                continue
            lines.append(
                f"- {label}: `{_escape(decision)}`; `{path}`; SHA-256 `{sha256_file(path)}`."
            )

    result_tables = (
        root / "reports" / "phase1_results.csv",
        root / "reports" / "phase1_risk_coverage.csv",
        root / "reports" / "full_results.csv",
        root / "reports" / "full_risk_coverage.csv",
        root / "reports" / "full_efficiency.csv",
    )
    lines.extend(["", "## Result tables", ""])
    found_table = False
    for path in result_tables:
        if not path.is_file():
            continue
        found_table = True
        try:
            row_count, fields, rows = csv_preview(path)
        except (OSError, csv.Error) as exc:
            lines.append(f"- `{path}` exists but could not be parsed: `{_escape(exc)}`")
            continue
        lines.extend(
            [
                f"### {path.name}",
                "",
                f"Rows: `{row_count}`; SHA-256: `{sha256_file(path)}`.",
                "",
            ]
        )
        if not fields:
            lines.append("No named columns were found.")
            lines.append("")
            continue
        lines.append("| " + " | ".join(_escape(field) for field in fields) + " |")
        lines.append("| " + " | ".join("---" for _ in fields) + " |")
        for row in rows:
            lines.append("| " + " | ".join(_escape(row.get(field, "")) for field in fields) + " |")
        if row_count > len(rows):
            lines.append("")
            lines.append(f"Preview truncated to {len(rows)} of {row_count} rows; inspect the CSV for all rows.")
        lines.append("")
    if not found_table:
        lines.append("`RESULT_TABLES_UNAVAILABLE` — no Phase-1 or Phase-2 result CSV exists.")

    lines.extend(["", "## Phase-1 five-fold report", ""])
    phase1 = read_json(phase1_path)
    if phase1 is None:
        lines.append(f"`PHASE1_REPORT_UNAVAILABLE` — `{phase1_path}` is missing or invalid.")
    else:
        lines.append(f"Source: `{phase1_path}`; SHA-256 `{sha256_file(phase1_path)}`.")

    lines.extend(["", "## Phase-2 aggregate", ""])
    aggregate = read_json(aggregate_path)
    if aggregate is None:
        lines.append(f"`PHASE2_AGGREGATE_UNAVAILABLE` — `{aggregate_path}` is missing or invalid.")
    else:
        lines.extend(
            [
                f"Source: `{aggregate_path}`; SHA-256 `{sha256_file(aggregate_path)}`.",
                "",
                "```json",
                json.dumps(aggregate, indent=2, sort_keys=True, ensure_ascii=False),
                "```",
            ]
        )

    archive = status.get("artifacts", {}).get("results_archive")
    lines.extend(["", "## Archive", ""])
    if isinstance(archive, dict) and archive.get("archive"):
        lines.append(f"- Archive: `{_escape(archive['archive'])}`")
        lines.append(f"- SHA-256: `{_escape(archive.get('sha256'))}`")
        lines.append(f"- Manifest: `{_escape(archive.get('manifest'))}`")
    else:
        lines.append("`RESULT_ARCHIVE_UNAVAILABLE`")

    engineering_state = status["stages"]["ENGINEERING_A0"]["state"]
    phase1_state = status["stages"]["PHASE1_FIVE_FOLD_ONE_SEED"]["state"]
    phase2_state = status["stages"]["PHASE2_THREE_SEEDS_AND_FULL_BASELINES"]["state"]
    lines.extend(["", "## Execution boundary", ""])
    lines.append(f"`ENGINEERING_A0_{'RAN' if engineering_state == 'PASSED' else 'NOT_RUN'}` — stage state is `{_escape(engineering_state)}`.")
    lines.append(f"`PHASE1_{'RAN' if phase1_state == 'PASSED' else 'NOT_RUN'}` — stage state is `{_escape(phase1_state)}`.")
    lines.append(f"`PHASE2_{'RAN' if phase2_state == 'PASSED' else 'NOT_RUN'}` — stage state is `{_escape(phase2_state)}`.")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--status", type=Path, required=True)
    parser.add_argument("--write", type=Path)
    args = parser.parse_args()
    content = render_summary(args.root.resolve(), args.status.resolve())
    if args.write:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        args.write.write_text(content, encoding="utf-8")
    print(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
