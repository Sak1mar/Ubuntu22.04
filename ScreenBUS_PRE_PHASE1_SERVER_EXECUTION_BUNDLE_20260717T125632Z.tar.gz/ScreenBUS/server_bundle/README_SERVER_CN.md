# ScreenBUS v2.3 服务器执行说明

## 唯一有效状态机

`P0_PROTOCOL_REPAIR -> G2_SERVER_ENGINEERING -> ENGINEERING_A0 -> PHASE1_FIVE_FOLD_ONE_SEED -> G3_METHOD_GATE -> PHASE2_THREE_SEEDS_AND_FULL_BASELINES -> EXTERNAL_POSITIVE_STRESS -> RESULT_FREEZE`

不得恢复独立 pilot、predictive A0 或“pilot 通过后才能 Full”的旧路径。

## 阶段边界

- `G2_SERVER_ENGINEERING`：环境、官方资产、依赖、三卡 CUDA/AMP 与基础算子工程验证；不运行 PointRend，不产生方法性能结论。
- `ENGINEERING_A0`：仅检查数据读取与患者 fold、forward/backward、FP32/AMP、峰值显存、checkpoint/resume、输出 schema、box 坐标回投、空 mask、scheduler 与归档。不得按性能选择路线。
- `PHASE1_FIVE_FOLD_ONE_SEED`：BUS-UCLM clean 全部 5 个 outer folds，唯一种子 2027，所有 fold 使用同一冻结代码/协议；outer-test 不得参与路线、阈值、校准、NMS 或后处理选择。
- `G3_METHOD_GATE`：仅在五折完整且每个 outer-test 患者只评估一次后独立重算。
- `PHASE2_THREE_SEEDS_AND_FULL_BASELINES`：仅 fresh `GO_EXPAND_TO_PHASE2` 可进入。
- `EXTERNAL_POSITIVE_STRESS`：BrEaST 阳性病灶域压力测试；4 名正常患者只逐例描述。

Phase-1 必跑 B1、Mask R-CNN、B3、6 个简单控制和 B5。PointRend 在 Phase-1 与 G2 禁止；只有 B3+B5 通过 G3 后，Phase-2 才可选运行 `B4 = B3 + original PointRend`。不得报告 US-PointRend 贡献名。

## 入口

```bash
./screenbus.sh overnight
./screenbus.sh status
./screenbus.sh logs G2_SERVER_ENGINEERING
./screenbus.sh logs ENGINEERING_A0
./screenbus.sh logs PHASE1_FIVE_FOLD_ONE_SEED
./screenbus.sh logs G3_METHOD_GATE
./screenbus.sh logs PHASE2_THREE_SEEDS_AND_FULL_BASELINES
```

所有服务器可变文件必须留在 `~/Yanjingjia` 下。当前本地包不含原始数据、权重、训练结果或 checkpoint。
