"""ScreenBUS uploadable server execution package."""
