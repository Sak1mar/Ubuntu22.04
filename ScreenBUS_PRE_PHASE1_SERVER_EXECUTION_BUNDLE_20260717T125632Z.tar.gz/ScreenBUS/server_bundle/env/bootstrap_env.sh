#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
BUNDLE_ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd -P)"
ROOT="${SCREENBUS_ROOT:-$(cd -- "${BUNDLE_ROOT}/.." && pwd -P)}"
ROOT="$(realpath -m -- "${ROOT}")"

REQUIRED_CONTAINER_IMAGE="nvidia/cuda:12.1.1-cudnn8-devel-ubuntu22.04"
REQUIRED_CONTAINER_DIGEST="sha256:cc55d151af1e8e083f3210af753a5cfbcbc5455421531eb0459887026bb4699f"
if [[ "${SCREENBUS_CONTAINER_RUNTIME_VERIFIED:-}" != "1" \
  || "${SCREENBUS_CONTAINER_IMAGE:-}" != "${REQUIRED_CONTAINER_IMAGE}" \
  || "${SCREENBUS_CONTAINER_DIGEST:-}" != "${REQUIRED_CONTAINER_DIGEST}" ]]; then
  echo "ERROR: use env/run_in_frozen_container.sh; frozen container identity is absent or mismatched" >&2
  exit 2
fi
if [[ ! -r /etc/os-release ]] || ! grep -qx 'VERSION_ID="22.04"' /etc/os-release; then
  echo "ERROR: target container must be Ubuntu 22.04" >&2
  exit 2
fi

if [[ "$(uname -s)" != "Linux" || "$(uname -m)" != "x86_64" ]]; then
  echo "ERROR: target environment requires Linux x86_64" >&2
  exit 2
fi
export SCREENBUS_ROOT="${ROOT}"
export UV_PYTHON_INSTALL_DIR="${BUNDLE_ROOT}/.python"
export UV_CACHE_DIR="${SCREENBUS_CACHE_ROOT:-${ROOT}/cache}/uv"
export UV_LINK_MODE=copy
mkdir -p "${BUNDLE_ROOT}/.tools" "${BUNDLE_ROOT}/artifacts/environment" "${UV_CACHE_DIR}"

UV="${BUNDLE_ROOT}/.tools/uv"
UV_VERSION="0.8.15"
UV_ARCHIVE="uv-x86_64-unknown-linux-gnu.tar.gz"
UV_SHA256="be9878e9d08ebcb621a683aba52e7fb8bbf92b2532e0d759026ffcc067673042"
if [[ ! -x "${UV}" ]]; then
  PARTIAL="${BUNDLE_ROOT}/.tools/${UV_ARCHIVE}.partial"
  URL="https://github.com/astral-sh/uv/releases/download/${UV_VERSION}/${UV_ARCHIVE}"
  curl --fail --location --retry 5 --retry-all-errors --continue-at - \
    --output "${PARTIAL}" "${URL}"
  printf '%s  %s\n' "${UV_SHA256}" "${PARTIAL}" | sha256sum --check --status
  TMPDIR="$(mktemp -d "${BUNDLE_ROOT}/.tools/uv.extract.XXXXXX")"
  trap 'rm -rf "${TMPDIR:-}"' EXIT
  tar -xzf "${PARTIAL}" -C "${TMPDIR}"
  install -m 0755 "${TMPDIR}/uv-x86_64-unknown-linux-gnu/uv" "${UV}.partial"
  mv "${UV}.partial" "${UV}"
  rm -f "${PARTIAL}"
  rm -rf "${TMPDIR}"
  trap - EXIT
fi
if [[ "$("${UV}" --version)" != "uv ${UV_VERSION}"* ]]; then
  echo "ERROR: unexpected uv version: $("${UV}" --version)" >&2
  exit 3
fi

"${UV}" python install 3.10.14
PYTHON="$("${UV}" python find 3.10.14 --python-preference only-managed)"
if [[ "$("${PYTHON}" -c 'import platform; print(platform.python_version())')" != "3.10.14" ]]; then
  echo "ERROR: managed Python is not 3.10.14" >&2
  exit 4
fi

ENV_DIR="${SCREENBUS_ENV_DIR:-${BUNDLE_ROOT}/.server_env}"
ENV_DIR="$(realpath -m -- "${ENV_DIR}")"
case "${ENV_DIR}" in
  /|"${ROOT}"|"${BUNDLE_ROOT}")
    echo "ERROR: unsafe SCREENBUS_ENV_DIR: ${ENV_DIR}" >&2
    exit 5
    ;;
esac
case "${BUNDLE_ROOT}/" in
  "${ENV_DIR}/"*)
    echo "ERROR: SCREENBUS_ENV_DIR may not be an ancestor of the upload bundle: ${ENV_DIR}" >&2
    exit 5
    ;;
esac
INSTALLING="${ENV_DIR}.installing"
OWNER="${ENV_DIR}/.screenbus_env_owner"
mkdir -p "$(dirname -- "${ENV_DIR}")"
if [[ -x "${ENV_DIR}/bin/python" && ! -e "${INSTALLING}" ]]; then
  if "${ENV_DIR}/bin/python" "${SCRIPT_DIR}/write_manifest.py" --verify-existing; then
    echo "SERVER_ENV_REUSED_PASS: ${ENV_DIR}"
    echo "G2_NOT_YET_AUTHORIZED: run server_bundle/g2/g2_doctor.py"
    exit 0
  fi
fi

if [[ -e "${ENV_DIR}" && ! -f "${OWNER}" && ! -f "${INSTALLING}" ]]; then
  echo "ERROR: refusing to replace an unowned SCREENBUS_ENV_DIR: ${ENV_DIR}" >&2
  exit 5
fi
rm -rf "${ENV_DIR}"
printf 'installation in progress\n' > "${INSTALLING}"
"${UV}" venv --clear --python "${PYTHON}" "${ENV_DIR}"
printf 'ScreenBUS managed environment\n' > "${OWNER}"
"${UV}" pip install --python "${ENV_DIR}/bin/python" \
  --index https://download.pytorch.org/whl/cu121 \
  --require-hashes \
  --no-build-isolation \
  --requirement "${SCRIPT_DIR}/requirements-cuda121.lock.txt"
"${UV}" pip check --python "${ENV_DIR}/bin/python"
"${ENV_DIR}/bin/python" "${SCRIPT_DIR}/write_manifest.py"
rm -f "${INSTALLING}"

echo "SERVER_ENV_INSTALL_PASS: ${ENV_DIR}"
echo "G2_NOT_YET_AUTHORIZED: run server_bundle/g2/g2_doctor.py"
