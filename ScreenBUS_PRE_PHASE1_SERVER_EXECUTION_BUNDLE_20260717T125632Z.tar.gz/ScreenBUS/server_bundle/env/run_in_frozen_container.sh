#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT="$(cd -- "${SCRIPT_DIR}/../.." && pwd -P)"
IMAGE_NAME="nvidia/cuda:12.1.1-cudnn8-devel-ubuntu22.04"
IMAGE_DIGEST="sha256:cc55d151af1e8e083f3210af753a5cfbcbc5455421531eb0459887026bb4699f"
IMAGE_REF="${IMAGE_NAME}@${IMAGE_DIGEST}"
CONTAINER_NAME="screenbus-$(date -u +%Y%m%dT%H%M%SZ)"
COMMAND="${1:-overnight}"

case "${COMMAND}" in
  overnight|resume|run) ;;
  *)
    printf 'Usage: %s overnight|resume|run\n' "$(basename -- "$0")" >&2
    exit 2
    ;;
esac

command -v docker >/dev/null 2>&1 || {
  printf 'ERROR: docker is required for the frozen ScreenBUS container contract\n' >&2
  exit 20
}

docker pull "${IMAGE_REF}"
INSPECTED_DIGEST="$(docker image inspect --format '{{join .RepoDigests "\n"}}' "${IMAGE_REF}" | sed -n 's/.*@\(sha256:[0-9a-f]\{64\}\)$/\1/p' | head -n 1)"
if [[ "${INSPECTED_DIGEST}" != "${IMAGE_DIGEST}" ]]; then
  printf 'ERROR: container digest mismatch: expected=%s observed=%s\n' \
    "${IMAGE_DIGEST}" "${INSPECTED_DIGEST:-MISSING}" >&2
  exit 21
fi

DOCKER_COMMAND=(docker run --rm --gpus all --ipc=host
  --name "${CONTAINER_NAME}"
  --mount "type=bind,src=${ROOT},dst=/workspace/ScreenBUS"
  --workdir /workspace/ScreenBUS
  --env SCREENBUS_CONTAINER_RUNTIME_VERIFIED=1
  --env "SCREENBUS_CONTAINER_IMAGE=${IMAGE_NAME}"
  --env "SCREENBUS_CONTAINER_DIGEST=${IMAGE_DIGEST}"
  "${IMAGE_REF}"
  ./screenbus.sh run)

if [[ "${COMMAND}" == "run" ]]; then
  exec "${DOCKER_COMMAND[@]}"
fi

CONTAINER_ID="$(docker run --detach --rm --gpus all --ipc=host \
  --name "${CONTAINER_NAME}" \
  --mount "type=bind,src=${ROOT},dst=/workspace/ScreenBUS" \
  --workdir /workspace/ScreenBUS \
  --env SCREENBUS_CONTAINER_RUNTIME_VERIFIED=1 \
  --env "SCREENBUS_CONTAINER_IMAGE=${IMAGE_NAME}" \
  --env "SCREENBUS_CONTAINER_DIGEST=${IMAGE_DIGEST}" \
  "${IMAGE_REF}" ./screenbus.sh run)"
printf 'CONTAINER_STARTED name=%s id=%s image=%s\n' \
  "${CONTAINER_NAME}" "${CONTAINER_ID}" "${IMAGE_REF}"
printf 'STATUS: ./screenbus.sh status\nLOGS: ./screenbus.sh logs\n'
