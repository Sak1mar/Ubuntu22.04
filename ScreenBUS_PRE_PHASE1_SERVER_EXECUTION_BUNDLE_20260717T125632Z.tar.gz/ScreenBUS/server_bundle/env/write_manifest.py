#!/usr/bin/env python3
"""Write the post-install server environment manifest without mutating it later."""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import platform
import re
import subprocess
import sys
import argparse
from datetime import datetime, timezone
from pathlib import Path


PINNED = {
    "torch": "2.4.1+cu121",
    "torchvision": "0.19.1+cu121",
    "numpy": "1.26.4",
    "scipy": "1.14.1",
    "pandas": "2.2.3",
    "monai": "1.4.0",
    "scikit-image": "0.24.0",
    "scikit-learn": "1.5.2",
    "opencv-python-headless": "4.10.0.84",
    "pycocotools": "2.0.8",
    "nnunetv2": "2.5.1",
    "simpleitk": "2.4.0",
    "nibabel": "5.3.2",
    "pillow": "10.4.0",
    "pyyaml": "6.0.2",
    "psutil": "6.1.0",
    "gdown": "5.2.0",
    "certifi": "2024.8.30",
    "pytest": "8.3.3",
    "ultralytics": "8.3.40",
}

LOCK_ENTRY = re.compile(r"^([A-Za-z0-9_.-]+)==([^ ;\\]+)(?:\s+\\)?$")


def normalized_name(value: str) -> str:
    return re.sub(r"[-_.]+", "-", value).lower()


def audit_complete_hash_lock(path: Path) -> dict[str, str]:
    """Return every exact lock pin, rejecting unhashed or duplicate entries."""
    lines = path.read_text(encoding="utf-8").splitlines()
    locked: dict[str, str] = {}
    current: str | None = None
    current_hashed = False
    for raw in lines:
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        match = LOCK_ENTRY.match(stripped)
        if match:
            if current is not None and not current_hashed:
                raise RuntimeError(f"hash lock entry has no SHA-256: {current}")
            name, version = normalized_name(match.group(1)), match.group(2)
            if name in locked:
                raise RuntimeError(f"duplicate hash lock entry: {name}")
            locked[name] = version
            current = name
            current_hashed = False
            continue
        if stripped.startswith("--hash=sha256:"):
            if current is None or not re.fullmatch(
                r"--hash=sha256:[0-9a-f]{64}(?:\s+\\)?", stripped
            ):
                raise RuntimeError(f"malformed SHA-256 lock line: {stripped}")
            current_hashed = True
            continue
        if stripped.startswith("--"):
            continue
        if stripped == "\\" or stripped.startswith("# via"):
            continue
        raise RuntimeError(f"unsupported requirements lock syntax: {stripped}")
    if current is not None and not current_hashed:
        raise RuntimeError(f"hash lock entry has no SHA-256: {current}")
    if not locked:
        raise RuntimeError("requirements hash lock is empty")
    return locked


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def provenance_path(path: Path, root: Path) -> str:
    """Use a portable relative path when possible, otherwise record the truth."""
    resolved = path.resolve()
    try:
        return str(resolved.relative_to(root.resolve()))
    except ValueError:
        # SCREENBUS_ENV_DIR is explicitly allowed on another filesystem.  An
        # absolute provenance path is preferable to rejecting that supported
        # layout or pretending the interpreter lives below the upload root.
        return str(resolved)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-existing", action="store_true")
    args = parser.parse_args(argv)
    root = Path(os.environ["SCREENBUS_ROOT"]).resolve()
    bundle = root / "server_bundle"
    output = bundle / "artifacts" / "environment"
    output.mkdir(parents=True, exist_ok=True)
    requirements = bundle / "env" / "requirements-cuda121.lock.txt"
    locked = audit_complete_hash_lock(requirements)
    freeze = output / "requirements.resolved.txt"
    uv = bundle / ".tools" / "uv"
    check = subprocess.run(
        [str(uv), "pip", "check", "--python", sys.executable],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if check.returncode:
        sys.stderr.write(check.stdout)
        return 4
    packages = sorted(
        (
            distribution.metadata["Name"].lower().replace("_", "-"),
            distribution.version,
        )
        for distribution in importlib.metadata.distributions()
        if distribution.metadata.get("Name")
    )
    package_map = {normalized_name(name): version for name, version in packages}
    resolved_text = "".join(f"{name}=={version}\n" for name, version in sorted(package_map.items()))
    lock_mismatch = {
        name: {"expected": version, "observed": package_map.get(name)}
        for name, version in locked.items()
        if package_map.get(name) != version
    }
    unexpected = sorted(set(package_map) - set(locked))
    observed = {name: importlib.metadata.version(name) for name in PINNED}
    mismatch = {
        name: {"expected": expected, "observed": observed[name]}
        for name, expected in PINNED.items()
        if observed[name] != expected
    }
    target = output / "manifest.json"
    if args.verify_existing:
        if mismatch or lock_mismatch or unexpected or not target.is_file() or not freeze.is_file():
            return 6
        previous = json.loads(target.read_text())
        valid = (
            previous.get("status") == "PASS"
            and previous.get("requirements_sha256") == sha256(requirements)
            and previous.get("resolved_freeze_sha256") == sha256(freeze)
            and freeze.read_text() == resolved_text
            and previous.get("python") == platform.python_version() == "3.10.14"
            and previous.get("python_executable")
            == provenance_path(Path(sys.executable), root)
            and check.returncode == 0
            and previous.get("transitive_lock_claimed") is True
            and previous.get("locked_package_count") == len(locked)
        )
        return 0 if valid else 6
    freeze.write_text(resolved_text)
    manifest = {
        "schema_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if not mismatch and not lock_mismatch and not unexpected else "FAIL",
        "scope": "SERVER_ENVIRONMENT_INSTALL_ONLY_NOT_G2",
        "profile_target": "server_rtx3090_linux",
        "python": platform.python_version(),
        "python_executable": provenance_path(Path(sys.executable), root),
        "platform": platform.platform(),
        "uv_version": subprocess.check_output([str(uv), "--version"], text=True).strip(),
        "requirements_file": str(requirements.relative_to(root)),
        "requirements_sha256": sha256(requirements),
        "lock_kind": "COMPLETE_TRANSITIVE_REQUIRE_HASHES",
        "transitive_lock_claimed": True,
        "locked_package_count": len(locked),
        "locked_packages": locked,
        "lock_mismatches": lock_mismatch,
        "unexpected_installed_packages": unexpected,
        "resolved_freeze": str(freeze.relative_to(root)),
        "resolved_freeze_sha256": sha256(freeze),
        "pip_check": {"status": "PASS", "output": check.stdout.strip()},
        "pinned_packages": observed,
        "version_mismatches": mismatch,
        "formal_training_authorized": False,
        "authorization_note": "Only g2_doctor.py can authorize server A0 after all hard checks pass.",
    }
    temporary = target.with_suffix(".json.partial")
    temporary.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, target)
    return 0 if not mismatch and not lock_mismatch and not unexpected else 5


if __name__ == "__main__":
    raise SystemExit(main())
