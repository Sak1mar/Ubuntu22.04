#!/usr/bin/env python3
"""Fetch and audit only official ScreenBUS data and model assets.

BUS-UCLM is acquired through Mendeley's per-file API. The five sealed patients
and HESN are discovered as metadata but their pixel URLs are never requested.
Every payload is written to `.partial`, verified, and atomically renamed.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import csv
import hashlib
import importlib
import json
import os
import shutil
import ssl
import subprocess
import sys
import urllib.parse
import urllib.error
import urllib.request
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SEALED = {"ANFO", "COPE", "CRCI", "ELCO", "FLKA"}
EXCLUDED = {"HESN"}
MEDSAM_COMMIT = "861d42440061c704762a9bb9a574e7c31d8d751a"
MEDSAM_REPO_URL = "https://github.com/bowang-lab/MedSAM.git"
AUTOBUSAM_COMMIT = "fe18a5cf85c9c58a94c802929d460d7bcf25578f"
AUTOBUSAM_REPO_URL = "https://github.com/aI-area/Auto-BUSAM.git"
MEDSAM_SHA256 = "34b34b78c1d18cb8c6bf84cf9c00e135d6d6c965699f3c0e31ef1bc9dcb5be74"
MEDSAM_BYTES = 375049145
FRCNN_SHA256 = "258fb6c638b15964ddcdd1ae0748c5eef1be9e732750120cc857feed3faac384"
FRCNN_BYTES = 167502836
MASKRCNN_SHA256 = "bf2d0c1efbc936eeee2bc95a48e80ebc86b891f61b0106485937fc29f9315fc0"
MASKRCNN_BYTES = 178090079
RESNET18_SHA256 = "f37072fd47e89c5e827621c5baffa7500819f7896bbacec160b1a16c560e07ec"
RESNET18_BYTES = 46830571
YOLOV8S_SHA256 = "595d3fd369b0791252c1d08d72036e6b6f1214f08e6ac5eae2861c2d9f10877f"
YOLOV8S_BYTES = 23375204
SAM_VIT_B_BYTES = 375042383
SAM_VIT_B_SHA256_PREFIX = "01ec64"
BUS_BRA_MD5 = "1f8b2be6476d58fc97bfb5e5a1ea9bab"
BUS_BRA_BYTES = 133917740


class AssetError(RuntimeError):
    exit_code = 21


class NetworkError(AssetError):
    exit_code = 22


class AuthError(AssetError):
    exit_code = 20


def verified_tls_context() -> ssl.SSLContext:
    try:
        import certifi
    except ImportError:
        return ssl.create_default_context()
    return ssl.create_default_context(cafile=certifi.where())


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def md5(path: Path) -> str:
    digest = hashlib.md5(usedforsecurity=False)
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(partial, path)


def roots(*, create: bool = True) -> tuple[Path, Path, Path, Path, Path]:
    root = Path(os.environ["SCREENBUS_ROOT"]).resolve()
    data = Path(os.environ["SCREENBUS_DATA_ROOT"]).resolve()
    cache = Path(os.environ["SCREENBUS_CACHE_ROOT"]).resolve()
    output = Path(os.environ["SCREENBUS_OUTPUT_ROOT"]).resolve()
    weights = Path(os.environ["SCREENBUS_WEIGHT_ROOT"]).resolve()
    if create:
        for path in (data, cache, output, weights):
            path.mkdir(parents=True, exist_ok=True)
    return root, data, cache, output, weights


def verify_portable_evidence(root: Path) -> dict[str, Any]:
    manifest = root / "bootstrap" / "evidence" / "MANIFEST.sha256"
    if not manifest.is_file():
        raise AssetError(f"portable evidence manifest missing: {manifest}")
    checked = 0
    for line in manifest.read_text().splitlines():
        if not line.strip():
            continue
        expected, relative = line.split("  ", 1)
        target = root / relative
        if not target.is_file() or sha256(target) != expected:
            raise AssetError(f"portable evidence mismatch: {relative}")
        checked += 1
    if checked != 15:
        raise AssetError(f"portable evidence count drift: {checked} != 15")
    return {"status": "PASS", "files": checked, "manifest_sha256": sha256(manifest)}


def request_json(url: str) -> Any:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname != "data.mendeley.com":
        raise AssetError(f"refusing non-Mendeley API URL: {url}")
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.mendeley-public-dataset.1+json",
            "User-Agent": "ScreenBUS/0.1 official-data-gate",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=90, context=verified_tls_context()) as response:
            if response.status != 200:
                raise NetworkError(f"Mendeley API HTTP {response.status}: {url}")
            return json.load(response)
    except urllib.error.HTTPError as exc:
        if exc.code in {401, 403}:
            raise AuthError(f"BLOCKED_DATA_AUTH: Mendeley HTTP {exc.code}: {url}") from exc
        raise NetworkError(f"Mendeley API HTTP {exc.code}: {url}") from exc
    except (OSError, ValueError) as exc:
        raise NetworkError(f"Mendeley API request failed: {url}: {exc}") from exc


def _safe_final_host(url: str, family: str) -> bool:
    parsed = urllib.parse.urlparse(url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https":
        return False
    if family == "mendeley":
        return host == "data.mendeley.com" or host.endswith(".amazonaws.com")
    if family == "pytorch":
        return host == "download.pytorch.org"
    if family == "zenodo":
        return host == "zenodo.org" or host.endswith(".zenodo.org")
    if family == "ultralytics":
        return host in {
            "github.com",
            "objects.githubusercontent.com",
            "release-assets.githubusercontent.com",
        }
    if family == "sam":
        return host == "dl.fbaipublicfiles.com"
    return False


def resumable_download(
    url: str,
    target: Path,
    *,
    family: str,
    expected_bytes: int,
    expected_sha256: str | None = None,
    sha256_prefix: str | None = None,
    expected_md5: str | None = None,
) -> dict[str, Any]:
    target.parent.mkdir(parents=True, exist_ok=True)

    def valid(path: Path) -> tuple[bool, str]:
        if not path.is_file() or path.stat().st_size != expected_bytes:
            return False, ""
        computed = sha256(path)
        if expected_sha256 and computed != expected_sha256:
            return False, computed
        if sha256_prefix and not computed.startswith(sha256_prefix):
            return False, computed
        if expected_md5 and md5(path) != expected_md5:
            return False, computed
        return True, computed

    ok, digest = valid(target)
    if ok:
        return {"status": "VERIFIED_CACHED", "bytes": expected_bytes, "sha256": digest}
    if target.exists():
        raise AssetError(f"existing final asset is invalid; refusing overwrite: {target}")
    partial = target.with_suffix(target.suffix + ".partial")
    offset = partial.stat().st_size if partial.exists() else 0
    headers = {"User-Agent": "ScreenBUS/0.1 official-asset-fetcher"}
    if offset:
        headers["Range"] = f"bytes={offset}-"
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=180, context=verified_tls_context()) as response:
            if not _safe_final_host(response.geturl(), family):
                raise AssetError(f"refusing redirected asset host: {response.geturl()}")
            append = offset > 0 and response.status == 206
            mode = "ab" if append else "wb"
            with partial.open(mode) as stream:
                while True:
                    block = response.read(4 * 1024 * 1024)
                    if not block:
                        break
                    stream.write(block)
    except urllib.error.HTTPError as exc:
        if exc.code in {401, 403}:
            raise AuthError(f"BLOCKED_ASSET_AUTH: HTTP {exc.code}: {url}") from exc
        raise NetworkError(f"asset HTTP {exc.code}; resumable partial retained: {url}") from exc
    except AssetError:
        raise
    except OSError as exc:
        raise NetworkError(f"asset download interrupted; resumable partial retained: {exc}") from exc
    ok, digest = valid(partial)
    if not ok:
        raise AssetError(
            f"download integrity failure: {target.name}, bytes={partial.stat().st_size}, sha256={digest}"
        )
    os.replace(partial, target)
    return {"status": "VERIFIED_DOWNLOADED", "bytes": expected_bytes, "sha256": digest}


def discover_busuclm(root: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    folders = request_json("https://data.mendeley.com/public-api/datasets/7fvgj4jsp7/folders/3")
    roots_found = [item for item in folders if not item.get("parent_id") and item.get("name") == "BUS-UCLM"]
    if len(roots_found) != 1:
        raise AssetError("Mendeley folder graph drift")
    root_id = str(roots_found[0]["id"])
    child_ids: dict[str, str] = {}
    for kind in ("images", "masks"):
        matches = [
            item for item in folders
            if str(item.get("parent_id")) == root_id and str(item.get("name", "")).lower() == kind
        ]
        if len(matches) != 1:
            raise AssetError(f"Mendeley {kind} folder drift")
        child_ids[kind] = str(matches[0]["id"])

    def records(kind: str) -> list[dict[str, Any]]:
        url = (
            "https://data.mendeley.com/public-api/datasets/7fvgj4jsp7/files"
            f"?folder_id={urllib.parse.quote(child_ids[kind])}&version=3"
        )
        payload = request_json(url)
        if len(payload) != 683:
            raise AssetError(f"public {kind} count drift: {len(payload)} != 683")
        result: list[dict[str, Any]] = []
        for item in payload:
            details = item.get("content_details", {})
            result.append(
                {
                    "filename": str(item.get("filename", "")),
                    "status": str(item.get("status", "")),
                    "size": int(details.get("size", item.get("size", -1))),
                    "sha256": str(details.get("sha256_hash", "")).lower(),
                    "url": str(details.get("download_url", "")),
                }
            )
        return result

    return records("images"), records("masks")


def load_frozen_rows(root: Path) -> list[dict[str, str]]:
    path = root / "bootstrap" / "evidence" / "BUS-UCLM" / "busuclm_route2_dev.csv"
    with path.open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 607:
        raise AssetError(f"frozen manifest count drift: {len(rows)}")
    cases = {row["case_id"] for row in rows}
    if cases & (SEALED | EXCLUDED):
        raise AssetError("frozen manifest contains protected or excluded patients")
    if len(cases) != 32:
        raise AssetError(f"frozen patient count drift: {len(cases)}")
    return rows


def fetch_busuclm(workers: int = 6) -> dict[str, Any]:
    root, data, _, _, _ = roots()
    evidence = verify_portable_evidence(root)
    rows = load_frozen_rows(root)
    image_records, mask_records = discover_busuclm(root)
    maps = {
        "images": {record["filename"]: record for record in image_records},
        "masks": {record["filename"]: record for record in mask_records},
    }
    public_cases = {name.split("_", 1)[0] for name in maps["images"]}
    expected_public = {row["case_id"] for row in rows} | SEALED | EXCLUDED
    if public_cases != expected_public:
        raise AssetError("public patient set differs from frozen 38-patient registry")
    jobs: list[tuple[dict[str, Any], Path, str]] = []
    selected_cases: set[str] = set()
    for row in rows:
        filename = row["image_id"] + ".png"
        selected_cases.add(row["case_id"])
        for kind, hash_field in (("images", "image_sha256"), ("masks", "mask_sha256")):
            record = maps[kind].get(filename)
            if not record or record["status"] != "COMPLETED":
                raise AssetError(f"missing/incomplete official record: {kind}/{filename}")
            if record["sha256"] != row[hash_field]:
                raise AssetError(f"official API hash differs from frozen evidence: {kind}/{filename}")
            if filename.split("_", 1)[0] in SEALED | EXCLUDED:
                raise AssetError(f"internal error: protected pixel selected: {filename}")
            jobs.append((record, data / "BUS-UCLM" / kind / filename, kind))

    def run(job: tuple[dict[str, Any], Path, str]) -> dict[str, Any]:
        record, target, _ = job
        return resumable_download(
            record["url"], target, family="mendeley",
            expected_bytes=record["size"], expected_sha256=record["sha256"],
        )

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, min(workers, 8))) as executor:
        results = list(executor.map(run, jobs))
    manifest = {
        "schema_version": 1,
        "created_at_utc": utc_now(),
        "status": "PASS",
        "dataset": "BUS-UCLM v3 frozen development cohort",
        "doi": "10.17632/7fvgj4jsp7.3",
        "licence": "CC BY 4.0",
        "source": "Mendeley per-file public API",
        "files": len(results),
        "images": 607,
        "masks": 607,
        "patients": len(selected_cases),
        "protected_pixel_download_requests": 0,
        "protected_pixel_payload_bytes_read": 0,
        "sealed_patients": sorted(SEALED),
        "geometry_exclusions": sorted(EXCLUDED),
        "portable_evidence": evidence,
        "download_status_counts": dict(Counter(result["status"] for result in results)),
    }
    atomic_json(root / "server_bundle" / "artifacts" / "data" / "fetch_manifest.json", manifest)
    return manifest


def audit_busuclm(*, write_manifest: bool = False) -> dict[str, Any]:
    """Audit the frozen tree; only the explicit prepare command may mutate provenance."""
    from PIL import Image
    import numpy as np
    from scipy import ndimage

    root, data, _, _, _ = roots(create=write_manifest)
    verify_portable_evidence(root)
    rows = load_frozen_rows(root)
    # Fail closed on the directory inventory before opening or hashing any
    # pixel.  Auditing only the 607 manifest paths would otherwise allow a
    # sealed patient (or any unregistered image) to coexist unnoticed in the
    # development tree.
    expected_names = {f"{row['image_id']}.png" for row in rows}
    for kind in ("images", "masks"):
        directory = data / "BUS-UCLM" / kind
        if directory.is_symlink():
            raise AssetError(f"symlinked BUS-UCLM {kind} directory is forbidden: {directory}")
        if not directory.is_dir():
            raise AssetError(f"BUS-UCLM {kind} directory missing: {directory}")
        entries = list(directory.iterdir())
        protected = sorted(
            entry.name
            for entry in entries
            if entry.name.split("_", 1)[0] in SEALED | EXCLUDED
        )
        if protected:
            raise AssetError(
                f"protected patient pixels present in BUS-UCLM/{kind}: {protected}"
            )
        unsafe = sorted(entry.name for entry in entries if entry.is_symlink())
        if unsafe:
            raise AssetError(f"symlinks are forbidden in BUS-UCLM/{kind}: {unsafe}")
        observed_names = {entry.name for entry in entries if entry.is_file()}
        unexpected = sorted(observed_names - expected_names)
        missing = sorted(expected_names - observed_names)
        non_files = sorted(entry.name for entry in entries if not entry.is_file())
        if unexpected or missing or non_files:
            raise AssetError(
                f"BUS-UCLM/{kind} inventory mismatch: "
                f"unexpected={unexpected}, missing={missing}, non_files={non_files}"
            )
    labels: Counter[str] = Counter()
    patients: set[str] = set()
    components: Counter[int] = Counter()
    image_hashes: set[str] = set()
    ids: set[str] = set()
    for row in rows:
        image_path = data / "BUS-UCLM" / "images" / f"{row['image_id']}.png"
        mask_path = data / "BUS-UCLM" / "masks" / f"{row['image_id']}.png"
        if sha256(image_path) != row["image_sha256"] or sha256(mask_path) != row["mask_sha256"]:
            raise AssetError(f"frozen file hash mismatch: {row['image_id']}")
        if row["image_sha256"] in image_hashes or row["image_id"] in ids:
            raise AssetError(f"duplicate image hash or ID: {row['image_id']}")
        image_hashes.add(row["image_sha256"])
        ids.add(row["image_id"])
        with Image.open(image_path) as image, Image.open(mask_path) as mask:
            if image.size != mask.size or image.size != (int(row["image_width"]), int(row["image_height"])):
                raise AssetError(f"geometry mismatch: {row['image_id']}")
            foreground = np.asarray(mask) > 0
            if foreground.ndim > 2:
                foreground = np.any(foreground, axis=tuple(range(2, foreground.ndim)))
            count = int(ndimage.label(foreground, structure=np.ones((3, 3), dtype=np.uint8))[1])
        expected_positive = row["is_positive"] == "1"
        if (count > 0) != expected_positive:
            raise AssetError(f"empty-mask semantic mismatch: {row['image_id']}")
        if expected_positive:
            components[count] += 1
        labels[row["label"].lower()] += 1
        patients.add(row["case_id"])
    expected_labels = {"normal": 373, "benign": 163, "malignant": 71}
    expected_components = {1: 223, 2: 10, 3: 1}
    if dict(labels) != expected_labels or dict(components) != expected_components or len(patients) != 32:
        raise AssetError(
            f"cohort audit drift: labels={dict(labels)}, components={dict(components)}, patients={len(patients)}"
        )
    observed = {
        "schema_version": 1,
        "status": "PASS",
        "decision": "BUS_UCLM_FROZEN_DATA_READY",
        "images": 607,
        "patients": 32,
        "labels": expected_labels,
        "positive_components": {str(key): value for key, value in expected_components.items()},
        "hash_mismatches": 0,
        "geometry_mismatches": 0,
        "empty_semantics_mismatches": 0,
        "duplicate_ids_or_hashes": 0,
        "protected_pixels_present": False,
    }
    manifest_path = root / "server_bundle" / "artifacts" / "data" / "prepare_manifest.json"
    if write_manifest:
        payload = {**observed, "created_at_utc": utc_now()}
        atomic_json(manifest_path, payload)
        return payload
    try:
        frozen = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise AssetError(f"frozen prepare manifest is missing or unreadable: {manifest_path}") from exc
    semantic_drift = {
        key: {"frozen": frozen.get(key), "observed": value}
        for key, value in observed.items()
        if frozen.get(key) != value
    }
    if semantic_drift:
        raise AssetError(f"frozen prepare manifest semantic drift: {semantic_drift}")
    return {
        **observed,
        "audit_mode": "READ_ONLY",
        "prepare_manifest_sha256": sha256(manifest_path),
    }


def fetch_busbra() -> dict[str, Any]:
    root, _, cache, _, _ = roots()
    target = cache / "data" / "BUSBRA.zip"
    record = resumable_download(
        "https://zenodo.org/api/records/8231412/files/BUSBRA.zip/content",
        target,
        family="zenodo",
        expected_bytes=BUS_BRA_BYTES,
        expected_md5=BUS_BRA_MD5,
    )
    with zipfile.ZipFile(target) as archive:
        members = archive.infolist()
        for member in members:
            path = Path(member.filename)
            if path.is_absolute() or ".." in path.parts:
                raise AssetError(f"unsafe BUS-BRA ZIP member: {member.filename}")
        bad_member = archive.testzip()
        if bad_member is not None:
            raise AssetError(f"BUS-BRA ZIP CRC failure: {bad_member}")
    payload = {
        "schema_version": 1,
        "created_at_utc": utc_now(),
        "status": "PASS",
        "dataset": "BUS-BRA v1.0",
        "doi": "10.5281/zenodo.8231412",
        "licence": "CC BY 4.0",
        "role": "positive_pretraining_only",
        "archive": record,
        "zip_entries": len(members),
        "zip_crc_test": "PASS",
        "md5": BUS_BRA_MD5,
        "sha256_status": "COMPUTED_AND_RECORDED_NOT_PROVIDER_PINNED",
        "normal_case_evaluation_allowed": False,
    }
    atomic_json(root / "server_bundle" / "artifacts" / "data" / "fetch_busbra.json", payload)
    return payload


def verify_medsam_repo(target: Path) -> dict[str, Any]:
    """Reject a shadowed or modified checkout even when HEAD still matches."""
    if target.is_symlink() or not target.is_dir():
        raise AssetError(f"MedSAM cache must be a real directory: {target}")
    try:
        observed = subprocess.check_output(
            ["git", "--no-optional-locks", "-C", str(target), "rev-parse", "HEAD"], text=True
        ).strip()
        remote = subprocess.check_output(
            ["git", "--no-optional-locks", "-C", str(target), "remote", "get-url", "origin"], text=True
        ).strip()
        dirty = subprocess.check_output(
            [
                "git",
                "--no-optional-locks",
                "-C",
                str(target),
                "status",
                "--porcelain=v1",
                "--untracked-files=all",
            ],
            text=True,
        ).strip()
    except (OSError, subprocess.CalledProcessError) as exc:
        raise AssetError(f"MedSAM cache is not a verifiable Git checkout: {target}: {exc}") from exc
    if observed != MEDSAM_COMMIT:
        raise AssetError(f"MedSAM cache commit mismatch: {observed}")
    if remote != MEDSAM_REPO_URL:
        raise AssetError(f"MedSAM origin URL mismatch: {remote}")
    if dirty:
        raise AssetError(f"MedSAM cache worktree is dirty or has untracked files: {dirty}")
    return {
        "status": "PASS",
        "commit": observed,
        "origin": remote,
        "worktree_clean": True,
    }


def _clone_medsam(cache: Path) -> Path:
    target = cache / "MedSAM"
    if target.is_symlink():
        raise AssetError(f"MedSAM cache symlink is forbidden: {target}")
    if target.exists():
        verify_medsam_repo(target)
        return target
    partial = cache / "MedSAM.partial"
    if partial.exists():
        if partial.is_symlink():
            raise AssetError(f"MedSAM partial cache symlink is forbidden: {partial}")
        shutil.rmtree(partial)
    subprocess.run(
        ["git", "clone", "--branch", "v1.0.0", "--depth", "1", MEDSAM_REPO_URL, str(partial)],
        check=True,
    )
    verify_medsam_repo(partial)
    os.replace(partial, target)
    verify_medsam_repo(target)
    return target


def verify_autobusam_repo(target: Path) -> dict[str, Any]:
    """Pin the public prior-art source used for the adapted YOLO-to-SAM control."""
    if target.is_symlink() or not target.is_dir():
        raise AssetError(f"Auto-BUSAM cache must be a real directory: {target}")
    try:
        observed = subprocess.check_output(
            ["git", "--no-optional-locks", "-C", str(target), "rev-parse", "HEAD"],
            text=True,
        ).strip()
        remote = subprocess.check_output(
            ["git", "--no-optional-locks", "-C", str(target), "remote", "get-url", "origin"],
            text=True,
        ).strip()
        dirty = subprocess.check_output(
            [
                "git",
                "--no-optional-locks",
                "-C",
                str(target),
                "status",
                "--porcelain=v1",
                "--untracked-files=all",
            ],
            text=True,
        ).strip()
    except (OSError, subprocess.CalledProcessError) as exc:
        raise AssetError(f"Auto-BUSAM cache is not verifiable: {target}: {exc}") from exc
    if observed != AUTOBUSAM_COMMIT or remote != AUTOBUSAM_REPO_URL or dirty:
        raise AssetError(
            "Auto-BUSAM source drift: "
            f"commit={observed}, origin={remote}, dirty={bool(dirty)}"
        )
    return {
        "status": "PASS",
        "commit": observed,
        "origin": remote,
        "worktree_clean": True,
        "role": "prior_art_source_for_adapted_reimplementation",
    }


def _clone_autobusam(cache: Path) -> Path:
    target = cache / "Auto-BUSAM"
    if target.is_symlink():
        raise AssetError(f"Auto-BUSAM cache symlink is forbidden: {target}")
    if target.exists():
        verify_autobusam_repo(target)
        return target
    partial = cache / "Auto-BUSAM.partial"
    if partial.exists():
        if partial.is_symlink():
            raise AssetError(f"Auto-BUSAM partial cache symlink is forbidden: {partial}")
        shutil.rmtree(partial)
    subprocess.run(
        ["git", "clone", "--no-checkout", AUTOBUSAM_REPO_URL, str(partial)], check=True
    )
    subprocess.run(
        ["git", "--no-optional-locks", "-C", str(partial), "checkout", "--detach", AUTOBUSAM_COMMIT],
        check=True,
    )
    verify_autobusam_repo(partial)
    os.replace(partial, target)
    verify_autobusam_repo(target)
    return target


def _strict_weight_load(
    medsam_repo: Path,
    medsam_checkpoint: Path,
    checkpoints: Path,
    yolov8s_checkpoint: Path,
    sam_checkpoint: Path,
) -> dict[str, Any]:
    import torch
    from torchvision.models.detection import (
        fasterrcnn_resnet50_fpn,
        maskrcnn_resnet50_fpn,
    )
    from torchvision.models import resnet18

    frcnn = fasterrcnn_resnet50_fpn(weights=None, weights_backbone=None)
    frcnn.load_state_dict(
        torch.load(checkpoints / "fasterrcnn_resnet50_fpn_coco-258fb6c6.pth", map_location="cpu", weights_only=True),
        strict=True,
    )
    del frcnn
    maskrcnn = maskrcnn_resnet50_fpn(weights=None, weights_backbone=None)
    maskrcnn.load_state_dict(
        torch.load(checkpoints / "maskrcnn_resnet50_fpn_coco-bf2d0c1e.pth", map_location="cpu", weights_only=True),
        strict=True,
    )
    del maskrcnn
    backbone = resnet18(weights=None)
    backbone.load_state_dict(
        torch.load(checkpoints / "resnet18-f37072fd.pth", map_location="cpu", weights_only=True), strict=True
    )
    del backbone
    sys.path.insert(0, str(medsam_repo))
    try:
        module = importlib.import_module("segment_anything")
        medsam = module.sam_model_registry["vit_b"](checkpoint=None)
        medsam.load_state_dict(
            torch.load(medsam_checkpoint, map_location="cpu", weights_only=True), strict=True
        )
        del medsam
        sam = module.sam_model_registry["vit_b"](checkpoint=str(sam_checkpoint))
        del sam
    finally:
        sys.path.pop(0)
    from ultralytics import YOLO

    yolo = YOLO(str(yolov8s_checkpoint))
    if yolo.model is None:
        raise AssetError("Ultralytics YOLOv8s strict load produced no model")
    del yolo
    return {
        "status": "PASS",
        "strict_state_dict_loads": [
            "Faster R-CNN",
            "Mask R-CNN",
            "ResNet18",
            "MedSAM ViT-B",
            "Ultralytics YOLOv8s",
            "SAM ViT-B",
        ],
    }


def fetch_weights() -> dict[str, Any]:
    root, _, cache, _, weights = roots()
    torch_home = Path(os.environ.get("TORCH_HOME", str(cache / "torch"))).resolve()
    checkpoints = torch_home / "hub" / "checkpoints"
    checkpoints.mkdir(parents=True, exist_ok=True)
    repo = _clone_medsam(cache)
    autobusam_repo = _clone_autobusam(cache)
    try:
        import gdown
    except ImportError as exc:
        raise AssetError("gdown is required; run bootstrap_env.sh first") from exc
    medsam_target = Path(
        os.environ.get("MEDSAM_CKPT", str(weights / "medsam_vit_b.pth"))
    ).resolve()
    ok = medsam_target.is_file() and medsam_target.stat().st_size == MEDSAM_BYTES and sha256(medsam_target) == MEDSAM_SHA256
    if not ok:
        if medsam_target.exists():
            raise AssetError("existing MedSAM checkpoint is invalid; refusing overwrite")
        partial = medsam_target.with_name(medsam_target.name + ".partial")
        partial.parent.mkdir(parents=True, exist_ok=True)
        result = gdown.download(id="1UAmWL88roYR7wKlnApw5Bcuzf2iQgk6_", output=str(partial), quiet=False, resume=True)
        if result is None or partial.stat().st_size != MEDSAM_BYTES or sha256(partial) != MEDSAM_SHA256:
            raise AuthError("BLOCKED_WEIGHT_AUTH: MedSAM official Drive checkpoint failed verification")
        os.replace(partial, medsam_target)
    frcnn = resumable_download(
        "https://download.pytorch.org/models/fasterrcnn_resnet50_fpn_coco-258fb6c6.pth",
        checkpoints / "fasterrcnn_resnet50_fpn_coco-258fb6c6.pth",
        family="pytorch", expected_bytes=FRCNN_BYTES, expected_sha256=FRCNN_SHA256,
    )
    maskrcnn = resumable_download(
        "https://download.pytorch.org/models/maskrcnn_resnet50_fpn_coco-bf2d0c1e.pth",
        checkpoints / "maskrcnn_resnet50_fpn_coco-bf2d0c1e.pth",
        family="pytorch", expected_bytes=MASKRCNN_BYTES, expected_sha256=MASKRCNN_SHA256,
    )
    resnet18_record = resumable_download(
        "https://download.pytorch.org/models/resnet18-f37072fd.pth",
        checkpoints / "resnet18-f37072fd.pth",
        family="pytorch", expected_bytes=RESNET18_BYTES, expected_sha256=RESNET18_SHA256,
    )
    yolov8s_target = weights / "yolov8s_v8.3.0.pt"
    yolov8s_record = resumable_download(
        "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8s.pt",
        yolov8s_target,
        family="ultralytics",
        expected_bytes=YOLOV8S_BYTES,
        expected_sha256=YOLOV8S_SHA256,
    )
    sam_target = weights / "sam_vit_b_01ec64.pth"
    sam_record = resumable_download(
        "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_b_01ec64.pth",
        sam_target,
        family="sam",
        expected_bytes=SAM_VIT_B_BYTES,
        sha256_prefix=SAM_VIT_B_SHA256_PREFIX,
    )
    strict = _strict_weight_load(
        repo, medsam_target, checkpoints, yolov8s_target, sam_target
    )
    repo_verification = verify_medsam_repo(repo)
    autobusam_repo_verification = verify_autobusam_repo(autobusam_repo)
    payload = {
        "schema_version": 1,
        "created_at_utc": utc_now(),
        "status": "PASS",
        "official_only": True,
        "medsam": {
            "repo": MEDSAM_REPO_URL,
            "tag": "v1.0.0",
            "commit": MEDSAM_COMMIT,
            "repo_verification": repo_verification,
            "checkpoint_path": str(medsam_target),
            "checkpoint_bytes": MEDSAM_BYTES,
            "checkpoint_sha256": MEDSAM_SHA256,
        },
        "fasterrcnn": frcnn,
        "maskrcnn": maskrcnn,
        "resnet18": resnet18_record,
        "yolov8s": {
            **yolov8s_record,
            "path": str(yolov8s_target.resolve()),
            "release": "ultralytics/assets/v8.3.0",
        },
        "sam_vit_b": {
            **sam_record,
            "path": str(sam_target.resolve()),
            "provider_sha256_prefix": SAM_VIT_B_SHA256_PREFIX,
        },
        "autobusam_source": autobusam_repo_verification,
        "torch_home": str(torch_home),
        "torchvision_cache": str(checkpoints),
        "offline_cache_ready": True,
        "strict_load": strict,
    }
    atomic_json(root / "server_bundle" / "artifacts" / "weights" / "weight_manifest.json", payload)
    return payload


def _read_manifest(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise AssetError(f"{label} is missing or unreadable: {path}") from exc
    if not isinstance(value, dict):
        raise AssetError(f"{label} root must be an object: {path}")
    return value


def _verify_regular_file(path: Path, *, expected_bytes: int, expected_sha256: str, label: str) -> None:
    if path.is_symlink() or not path.is_file():
        raise AssetError(f"{label} must be a real regular file: {path}")
    observed_bytes = path.stat().st_size
    observed_sha256 = sha256(path)
    if observed_bytes != expected_bytes or observed_sha256 != expected_sha256:
        raise AssetError(
            f"{label} integrity mismatch: bytes={observed_bytes}, sha256={observed_sha256}"
        )


def verify_runtime_assets() -> dict[str, Any]:
    """Read-only revalidation of every data/weight dependency authorized by G2."""
    root, _, cache, _, _ = roots(create=False)
    prepared = audit_busuclm(write_manifest=False)
    fetch_path = root / "server_bundle" / "artifacts" / "data" / "fetch_manifest.json"
    prepare_path = root / "server_bundle" / "artifacts" / "data" / "prepare_manifest.json"
    weight_path = root / "server_bundle" / "artifacts" / "weights" / "weight_manifest.json"
    fetched = _read_manifest(fetch_path, "BUS-UCLM fetch manifest")
    fetch_contract = {
        "status": "PASS",
        "dataset": "BUS-UCLM v3 frozen development cohort",
        "files": 1214,
        "images": 607,
        "masks": 607,
        "patients": 32,
        "protected_pixel_download_requests": 0,
        "protected_pixel_payload_bytes_read": 0,
        "sealed_patients": sorted(SEALED),
        "geometry_exclusions": sorted(EXCLUDED),
    }
    fetch_drift = {
        key: {"expected": expected, "observed": fetched.get(key)}
        for key, expected in fetch_contract.items()
        if fetched.get(key) != expected
    }
    if fetch_drift:
        raise AssetError(f"BUS-UCLM fetch manifest semantic drift: {fetch_drift}")

    weights = _read_manifest(weight_path, "weight manifest")
    medsam = Path(os.environ["MEDSAM_CKPT"]).resolve()
    torch_home = Path(os.environ["TORCH_HOME"]).resolve()
    checkpoints = torch_home / "hub" / "checkpoints"
    recorded_medsam = weights.get("medsam")
    if not isinstance(recorded_medsam, dict):
        raise AssetError("weight manifest has no MedSAM record")
    recorded_checkpoint = recorded_medsam.get("checkpoint_path")
    if not isinstance(recorded_checkpoint, str) or Path(recorded_checkpoint).resolve() != medsam:
        raise AssetError("weight manifest MEDSAM_CKPT differs from the current frozen path")
    recorded_torch_home = weights.get("torch_home")
    recorded_cache = weights.get("torchvision_cache")
    if (
        not isinstance(recorded_torch_home, str)
        or Path(recorded_torch_home).resolve() != torch_home
        or not isinstance(recorded_cache, str)
        or Path(recorded_cache).resolve() != checkpoints.resolve()
    ):
        raise AssetError("weight manifest TORCH_HOME/torchvision cache path drift")
    if (
        weights.get("status") != "PASS"
        or weights.get("official_only") is not True
        or weights.get("offline_cache_ready") is not True
        or not isinstance(weights.get("strict_load"), dict)
        or weights["strict_load"].get("status") != "PASS"
    ):
        raise AssetError("weight manifest is not a passed official offline-cache record")

    specs = (
        ("MedSAM", medsam, MEDSAM_BYTES, MEDSAM_SHA256, recorded_medsam, "checkpoint_bytes", "checkpoint_sha256"),
        (
            "Faster R-CNN",
            checkpoints / "fasterrcnn_resnet50_fpn_coco-258fb6c6.pth",
            FRCNN_BYTES,
            FRCNN_SHA256,
            weights.get("fasterrcnn"),
            "bytes",
            "sha256",
        ),
        (
            "Mask R-CNN",
            checkpoints / "maskrcnn_resnet50_fpn_coco-bf2d0c1e.pth",
            MASKRCNN_BYTES,
            MASKRCNN_SHA256,
            weights.get("maskrcnn"),
            "bytes",
            "sha256",
        ),
        (
            "ResNet18",
            checkpoints / "resnet18-f37072fd.pth",
            RESNET18_BYTES,
            RESNET18_SHA256,
            weights.get("resnet18"),
            "bytes",
            "sha256",
        ),
        (
            "YOLOv8s",
            Path(os.environ["SCREENBUS_WEIGHT_ROOT"]).resolve() / "yolov8s_v8.3.0.pt",
            YOLOV8S_BYTES,
            YOLOV8S_SHA256,
            weights.get("yolov8s"),
            "bytes",
            "sha256",
        ),
    )
    verified_weights: dict[str, dict[str, Any]] = {}
    for label, path, expected_bytes, expected_sha256, record, bytes_key, sha_key in specs:
        if not isinstance(record, dict):
            raise AssetError(f"weight manifest has no {label} record")
        if record.get(bytes_key) != expected_bytes or record.get(sha_key) != expected_sha256:
            raise AssetError(f"weight manifest {label} size/hash drift")
        _verify_regular_file(
            path,
            expected_bytes=expected_bytes,
            expected_sha256=expected_sha256,
            label=label,
        )
        verified_weights[label] = {
            "path": str(path.resolve()),
            "bytes": expected_bytes,
            "sha256": expected_sha256,
        }
    sam_record = weights.get("sam_vit_b")
    sam_path = Path(os.environ["SCREENBUS_WEIGHT_ROOT"]).resolve() / "sam_vit_b_01ec64.pth"
    if not isinstance(sam_record, dict):
        raise AssetError("weight manifest has no SAM ViT-B record")
    sam_sha = sam_record.get("sha256")
    if (
        sam_record.get("bytes") != SAM_VIT_B_BYTES
        or not isinstance(sam_sha, str)
        or not sam_sha.startswith(SAM_VIT_B_SHA256_PREFIX)
        or sam_record.get("provider_sha256_prefix") != SAM_VIT_B_SHA256_PREFIX
    ):
        raise AssetError("weight manifest SAM ViT-B size/hash-prefix drift")
    _verify_regular_file(
        sam_path,
        expected_bytes=SAM_VIT_B_BYTES,
        expected_sha256=sam_sha,
        label="SAM ViT-B",
    )
    verified_weights["SAM ViT-B"] = {
        "path": str(sam_path),
        "bytes": SAM_VIT_B_BYTES,
        "sha256": sam_sha,
    }

    repo_verification = verify_medsam_repo(cache / "MedSAM")
    expected_repo = {
        "status": "PASS",
        "commit": MEDSAM_COMMIT,
        "origin": MEDSAM_REPO_URL,
        "worktree_clean": True,
    }
    if repo_verification != expected_repo:
        raise AssetError(f"live MedSAM repository verification drift: {repo_verification}")
    if (
        recorded_medsam.get("repo") != MEDSAM_REPO_URL
        or recorded_medsam.get("commit") != MEDSAM_COMMIT
        or recorded_medsam.get("repo_verification") != expected_repo
    ):
        raise AssetError("weight manifest MedSAM repository provenance drift")
    autobusam_repo_verification = verify_autobusam_repo(cache / "Auto-BUSAM")
    if weights.get("autobusam_source") != autobusam_repo_verification:
        raise AssetError("weight manifest Auto-BUSAM source provenance drift")
    return {
        "status": "PASS",
        "mode": "READ_ONLY_LIVE_G2_DEPENDENCY_REVALIDATION",
        "official_data": prepared,
        "official_weights": verified_weights,
        "medsam_repo_verification": repo_verification,
        "autobusam_repo_verification": autobusam_repo_verification,
        "manifest_sha256": {
            "fetch_manifest": sha256(fetch_path),
            "prepare_manifest": sha256(prepare_path),
            "weight_manifest": sha256(weight_path),
        },
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command",
        choices=(
            "fetch-busuclm",
            "prepare-busuclm",
            "fetch-busbra",
            "fetch-weights",
            "verify-runtime",
            "all",
        ),
    )
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--include-busbra", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.command in {"fetch-busuclm", "all"}:
            fetch_busuclm(args.workers)
        if args.command in {"prepare-busuclm", "all"}:
            audit_busuclm(write_manifest=True)
        if args.command == "fetch-busbra" or (args.command == "all" and args.include_busbra):
            fetch_busbra()
        if args.command in {"fetch-weights", "all"}:
            fetch_weights()
        if args.command == "verify-runtime":
            verify_runtime_assets()
    except AssetError as exc:
        sys.stderr.write(f"ASSET_GATE_FAIL: {exc}\n")
        return exc.exit_code
    except subprocess.CalledProcessError as exc:
        sys.stderr.write(f"ASSET_GATE_FAIL: command failed: {exc}\n")
        return 22
    print(f"ASSET_COMMAND_PASS: {args.command}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
