#!/usr/bin/env python3
from official_assets import main

if __name__ == "__main__":
    raise SystemExit(main(["fetch-weights"]))
