"""Official, fail-closed ScreenBUS asset acquisition."""
